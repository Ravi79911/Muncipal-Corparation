# Akola Municipal Corporation

Swagger URL :- http://192.168.29.245:8085/amc/swagger-ui/index.html#/

Swagger URL Domain :- http://www.swatiind.co.in:8085/amc/swagger-ui/index.html#/

Base URL :- http://192.168.29.245:8085/amc/

Base URL Domain :- http://www.swatiind.co.in:8085/amc/
