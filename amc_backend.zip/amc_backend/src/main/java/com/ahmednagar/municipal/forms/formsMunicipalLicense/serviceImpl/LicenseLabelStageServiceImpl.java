package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseLabelStage;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.LicenseLabelStageRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.LicenseLabelStageService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class LicenseLabelStageServiceImpl implements LicenseLabelStageService {
    @Autowired
    private LicenseLabelStageRepository licenseLabelStageRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public LicenseLabelStage saveLicenseLabelStage(LicenseLabelStage licenseLabelStage) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        licenseLabelStage.setCreatedDate(currentDateTime);
        licenseLabelStage.setSuspendedStatus(licenseLabelStage.getSuspendedStatus() != null ? licenseLabelStage.getSuspendedStatus() : 0);      // 0 means active// 1 means admin
        return licenseLabelStageRepository.saveAndFlush(licenseLabelStage);
    }
}
