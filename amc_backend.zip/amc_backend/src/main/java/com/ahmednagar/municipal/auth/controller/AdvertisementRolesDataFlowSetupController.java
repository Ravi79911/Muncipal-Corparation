package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.AdvertisementRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.AdvertisementRolesDataFlowSetup;
import com.ahmednagar.municipal.auth.service.AdvertisementRolesDataFlowSetupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/advertisement/roles/data/flow/setup/")
public class AdvertisementRolesDataFlowSetupController {

    @Autowired
    private AdvertisementRolesDataFlowSetupService advertisementRolesDataFlowSetupService;

    @GetMapping("/getAllRole")
    public ResponseEntity<List<AdvertisementRolesDataFlowSetupDto>> getAllRolesDataFlowSetup() {
        List<AdvertisementRolesDataFlowSetupDto> role = advertisementRolesDataFlowSetupService.findAllRolesDataFlowSetup();
        return ResponseEntity.ok(role);
    }

    @GetMapping("/document/verification/accept/next-role")
    public ResponseEntity<?> getNextRoleIdForDocumentVerificationAccept(@RequestParam Long currentRoleId,@RequestParam Long statusCode, @RequestParam Integer isActive) {
        AdvertisementRolesDataFlowSetup advertisementRolesDataFlowSetup = advertisementRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRoleId, statusCode, isActive);
        return ResponseEntity.ok(advertisementRolesDataFlowSetup);

    }

    @GetMapping("/document/verification/reject/next-role")
    public ResponseEntity<List<AdvertisementRolesDataFlowSetup>> getNextRoleIdForDocumentVerificationReject(@RequestParam Long currentRoleId, @RequestParam Long statusCode, @RequestParam Integer isActive) {
        List<AdvertisementRolesDataFlowSetup> nextRoles = advertisementRolesDataFlowSetupService.getNextRoleListForListSelection(currentRoleId, statusCode, isActive);
        return ResponseEntity.ok(nextRoles);
    }

}
