package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationFirmDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFirmDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationFirmDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationFirmDetailsService;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyElectricityConnectionDetails;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ApplicationFirmDetailsServiceImpl implements ApplicationFirmDetailsService {
    @Autowired
    private ApplicationFirmDetailsRepository applicationFirmDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ApplicationFirmDetails saveApplicationFirmDetails(ApplicationFirmDetails applicationFirmDetails) {
        if (applicationFirmDetails.isDangerousTypeFlag()) {
            if (applicationFirmDetails.getTradeType() == null || applicationFirmDetails.getTradeType().isEmpty()) {
                throw new IllegalArgumentException("trade type must be provided when dangerous flag is true");
            }
        } else {
            applicationFirmDetails.setTradeType(null);
        }
        if (applicationFirmDetails.getSuspendedStatus() == null) {
            applicationFirmDetails.setSuspendedStatus(0);
        }
        applicationFirmDetails.setCreatedDate(LocalDateTime.now());
        return applicationFirmDetailsRepository.saveAndFlush(applicationFirmDetails);
    }

//    @Override
//    public List<ApplicationFirmDetailsDto> findAllApplicationFirmDetails() {
//        List<ApplicationFirmDetails> applicationFirmDetails = applicationFirmDetailsRepository.findAll();
//        return applicationFirmDetails.stream()
//                .map(applicationFirmDetail -> modelMapper.map(applicationFirmDetail, ApplicationFirmDetailsDto.class))
//                .collect(Collectors.toList());
//    }
//
//
//    @Override
//    public List<ApplicationFirmDetails> findAllActiveAppApplicantDetails(Integer status) {
//        return applicationFirmDetailsRepository.findBySuspendedStatus(status);
//    }

    @Override
    public ApplicationFirmDetails findApplicationFirmDetailsById(Long id) {
        Optional<ApplicationFirmDetails> applicationFirmDetails = applicationFirmDetailsRepository.findById(id);
        return applicationFirmDetails.orElse(null);

    }

    @Override
    public List<ApplicationFirmDetailsDto> findAllApplicationFirmDetailsByMunicipalId(int municipalId) {
        List<ApplicationFirmDetails> applicationFirmDetails = applicationFirmDetailsRepository.findByMunicipalId(municipalId);
        return applicationFirmDetails.stream()
                .map(ApplicationFirmDetail -> modelMapper.map(ApplicationFirmDetail, ApplicationFirmDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public ApplicationFirmDetails updateApplicationFirmDetails(Long id, ApplicationFirmDetails updatedApplicationFirmDetails) {
        Optional<ApplicationFirmDetails> applicationFirmDetailsOptional = applicationFirmDetailsRepository.findById(id);
        if (applicationFirmDetailsOptional.isPresent()) {
            ApplicationFirmDetails existingApplicationFirmDetails = applicationFirmDetailsOptional.get();
            existingApplicationFirmDetails.setFirmName(updatedApplicationFirmDetails.getFirmName());
            existingApplicationFirmDetails.setAdharNumber(updatedApplicationFirmDetails.getAdharNumber());
            existingApplicationFirmDetails.setTradeType(updatedApplicationFirmDetails.getTradeType());
            existingApplicationFirmDetails.setBusinessContactNumber(updatedApplicationFirmDetails.getBusinessContactNumber());
            existingApplicationFirmDetails.setBusinessAddressLine1(updatedApplicationFirmDetails.getBusinessAddressLine1());
            existingApplicationFirmDetails.setBusinessAddressLine2(updatedApplicationFirmDetails.getBusinessAddressLine2());
            existingApplicationFirmDetails.setBusinessCity(updatedApplicationFirmDetails.getBusinessCity());
            existingApplicationFirmDetails.setBusinessState(updatedApplicationFirmDetails.getBusinessState());
            existingApplicationFirmDetails.setBusinessPincode(updatedApplicationFirmDetails.getBusinessPincode());
            existingApplicationFirmDetails.setLandmark(updatedApplicationFirmDetails.getLandmark());
            existingApplicationFirmDetails.setNoOfWorkers(updatedApplicationFirmDetails.getNoOfWorkers());
            existingApplicationFirmDetails.setBusinessDescription(updatedApplicationFirmDetails.getBusinessDescription());
            //existingApplicationFirmDetails.setSuspendedStatus(updatedApplicationFirmDetails.getSuspendedStatus());
            //existingApplicationFirmDetails.setMunicipalId(updatedApplicationFirmDetails.getMunicipalId());
            existingApplicationFirmDetails.setTotalBuildupAreaOfBusiness(updatedApplicationFirmDetails.getTotalBuildupAreaOfBusiness());
            existingApplicationFirmDetails.setCinNumber(updatedApplicationFirmDetails.getCinNumber());
            existingApplicationFirmDetails.setPanNumber(updatedApplicationFirmDetails.getPanNumber());
            existingApplicationFirmDetails.setTanNumber(updatedApplicationFirmDetails.getTanNumber());
            existingApplicationFirmDetails.setGstNumber(updatedApplicationFirmDetails.getGstNumber());
            existingApplicationFirmDetails.setWardId(updatedApplicationFirmDetails.getWardId());
            existingApplicationFirmDetails.setZoneId(updatedApplicationFirmDetails.getZoneId());

            return applicationFirmDetailsRepository.saveAndFlush(existingApplicationFirmDetails);
        } else {
            throw new RuntimeException("app ApplicationFirmDetails Details not found with id: " + id);
        }
    }

    @Override
    public ApplicationFirmDetails changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<ApplicationFirmDetails> applicationFirmDetailsOptional = applicationFirmDetailsRepository.findById(id);
        if (applicationFirmDetailsOptional.isPresent()) {
            ApplicationFirmDetails applicationFirmDetails = applicationFirmDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            applicationFirmDetails.setSuspendedStatus(status);      // 1 means suspended
            return applicationFirmDetailsRepository.saveAndFlush(applicationFirmDetails);
        }
        return null;
    }

    @Transactional
    @Override
    public void deleteApplicationFirmDetailsByApplicationMasterId(Long applicationMasterId) {
        try{
            applicationFirmDetailsRepository.deleteApplicationFirmDetailsByApplicationMasterId(applicationMasterId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

}
