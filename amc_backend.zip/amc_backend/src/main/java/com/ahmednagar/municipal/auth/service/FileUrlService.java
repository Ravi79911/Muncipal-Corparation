package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.FileUrlDto;
import com.ahmednagar.municipal.auth.model.FileUrlMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface FileUrlService {

    FileUrlMaster createFileUrl(FileUrlMaster fileUrlMaster);

    List<FileUrlDto> findAllFileUrl();

    List<FileUrlDto> findAllFileUrlByMunicipalId(Long municipalId);

    FileUrlMaster updateFileUrl(Long id, FileUrlMaster updatedFileUrlMaster);

    FileUrlMaster changeSuspendedStatus(Long id, int status);

}
