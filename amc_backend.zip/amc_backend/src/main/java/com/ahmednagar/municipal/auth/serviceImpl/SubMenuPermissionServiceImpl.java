package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.SubMenuPermissionDto;
import com.ahmednagar.municipal.auth.model.SubMenuPermission;
import com.ahmednagar.municipal.auth.repository.SubMenuPermissionRepository;
import com.ahmednagar.municipal.auth.service.SubMenuPermissionService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SubMenuPermissionServiceImpl implements SubMenuPermissionService {
    @Autowired
    private SubMenuPermissionRepository subMenuPermissionRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public SubMenuPermission saveSubMenuPermission(SubMenuPermission subMenuPermission) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        subMenuPermission.setCreatedDate(currentDateTime);
        subMenuPermission.setUpdatedDate(LocalDateTime.now());
        subMenuPermission.setUpdatedBy(subMenuPermission.getUpdatedBy() != null ? subMenuPermission.getUpdatedBy() : 0);
        subMenuPermission.setSuspendedStatus(subMenuPermission.getSuspendedStatus() != null ? subMenuPermission.getSuspendedStatus() : 0);      // 0 means active// 1 means admin
        return subMenuPermissionRepository.saveAndFlush(subMenuPermission);
    }

    @Override
    public List<SubMenuPermissionDto> findAllSubMenuPermission() {
        List<SubMenuPermission> subMenuPermissions = subMenuPermissionRepository.findAll();
        return subMenuPermissions.stream()
                .map(subMenuPermission -> modelMapper.map(subMenuPermission, SubMenuPermissionDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<SubMenuPermissionDto> findAllSubMenuPermissionByMunicipalId(Long municipalId) {
        List<SubMenuPermission> subMenuPermissions = subMenuPermissionRepository.findByMunicipalId(municipalId);
        return subMenuPermissions.stream()
                .map(subMenuPermission -> modelMapper.map(subMenuPermission, SubMenuPermissionDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public SubMenuPermission updateSubMenuPermission(Long id, SubMenuPermission updatedSubMenuPermission) {
        Optional<SubMenuPermission> subMenuPermissionOptional = subMenuPermissionRepository.findById(id);
        if (subMenuPermissionOptional.isPresent()) {
            SubMenuPermission existingSubMenuPermission = subMenuPermissionOptional.get();
            existingSubMenuPermission.setSuspendedStatus(updatedSubMenuPermission.getSuspendedStatus());
            existingSubMenuPermission.setMunicipalId(updatedSubMenuPermission.getMunicipalId());

            return subMenuPermissionRepository.saveAndFlush(existingSubMenuPermission);
        } else {
            throw new RuntimeException("SubMenuPermission not found with id: " + id);
        }
    }

    @Override
    public SubMenuPermission changeSuspendedStatus(Long id, int status) {
        Optional<SubMenuPermission> subMenuPermissionOptional = subMenuPermissionRepository.findById(id);
        if (subMenuPermissionOptional.isPresent()) {
            SubMenuPermission subMenuPermission = subMenuPermissionOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            subMenuPermission.setUpdatedDate(currentDateTime);
            subMenuPermission.setSuspendedStatus(status);      // 1 means suspended
            subMenuPermission.setUpdatedBy(subMenuPermission.getUpdatedBy());
            return subMenuPermissionRepository.saveAndFlush(subMenuPermission);
        }
        return null;
    }
}
