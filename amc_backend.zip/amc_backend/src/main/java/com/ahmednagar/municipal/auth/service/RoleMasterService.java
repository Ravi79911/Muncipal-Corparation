package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.RoleDto;
import com.ahmednagar.municipal.auth.model.RoleMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface RoleMasterService {

    RoleMaster createRole(RoleMaster roleMaster);

    List<RoleDto> findAllRole();

    List<RoleDto> findAllRoleByMunicipalId(int municipalId);

    RoleMaster updateRole(Long id, RoleMaster updatedRole);

    RoleMaster changeSuspendedStatus(Long id, int status, int updatedBy);

}
