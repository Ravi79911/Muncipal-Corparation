package com.ahmednagar.municipal.auth.model;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationDocumentsDetails;
import com.ahmednagar.municipal.master.municipalLicence.model.MlDocumentGroupMaster;
import com.ahmednagar.municipal.master.municipalLicence.model.TradeApplicationType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_view_ml_documents_master")
public class ViewMlDocumentsMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "document_name")
    @NotNull
    @Size(max = 150, message = "Document name cannot exceed 150 characters")
    private String documentName;

    @Column(name = "created_by")
    @NotNull(message = "Created by is required")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @Column(name = "municipal_id")
    @NotNull(message = "Municipal ID is required")
    private int municipalId;

//    @OneToMany(mappedBy = "documentsMasterId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<ApplicationDocumentsDetails> applicationDocumentsDetails;

    @ManyToOne
    @JoinColumn(name = "application_type_id", nullable = false, referencedColumnName = "id")
    private ViewTradeApplicationTypeMasters viewTradeApplicationTypeMasters;

    @ManyToOne
    @JoinColumn(name = "ml_document_group_mas_id", nullable = false, referencedColumnName = "id")
    private ViewMlDocumentGroupMaster viewMlDocumentGroupMaster;
}
