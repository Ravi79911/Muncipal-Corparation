package com.ahmednagar.municipal.forms.formsWaterManagement.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationElectricityDetails;
import com.ahmednagar.municipal.forms.formsWaterManagement.model.NewConnectionFormShubham;
import com.ahmednagar.municipal.forms.formsWaterManagement.model.NewConnectionFormShubham;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.NewConnectionFormShubhamService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/water/form/new-connection")
public class NewConnectionFormShubhamController {

    @Autowired
    private NewConnectionFormShubhamService newConnectionFormShubhamService;

    //create ApplicationElectricityDetails
    @PostMapping("/create")
    public ResponseEntity<NewConnectionFormShubham> createNewConnectionFormShubham(@Valid @RequestBody NewConnectionFormShubham newConnectionForm, @RequestParam int createdBy){
        NewConnectionFormShubham savedForm=newConnectionFormShubhamService.saveNewConnectionFormShubham(newConnectionForm,createdBy);
        if(savedForm==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }else{
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(savedForm);
        }
    }

    // PATCH: Update only the suspended_status field
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> updateSuspendedStatus(@PathVariable int id, @RequestParam(required = false,defaultValue = "1") int suspendedStatus) {
        NewConnectionFormShubham deletedForm = newConnectionFormShubhamService.deleteNewConnectionForm(id,suspendedStatus);
        if(deletedForm == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("connection form deleted successfully");
        }
        return ResponseEntity.ok(deletedForm);
    }

    // GET: Find connection forms by municipalId
    @GetMapping("/municipal/{municipalId}")
    public ResponseEntity<?> findByMunicipalId(@PathVariable int municipalId) {
        List<NewConnectionFormShubham> connectionFormList = newConnectionFormShubhamService.findByMunicipalId(municipalId);
        if(connectionFormList == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Connection Form not found with the given municipalId");
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(connectionFormList);
    }


}
