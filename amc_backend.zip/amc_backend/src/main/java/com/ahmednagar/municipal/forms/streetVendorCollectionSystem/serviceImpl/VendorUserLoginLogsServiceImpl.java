package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserLoginLogs;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorUserLoginLogsRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorUserLoginLogsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class VendorUserLoginLogsServiceImpl implements VendorUserLoginLogsService {

    @Autowired
    private VendorUserLoginLogsRepository vendorUserLoginLogsRepository;

    @Override
    public VendorUserLoginLogs saveUserLoginLogs(VendorUserLoginLogs vendorUserLoginLogs) {
        vendorUserLoginLogs.setCreatedDate(LocalDateTime.now());
        vendorUserLoginLogs.setSuspendedStatus(0);
        return vendorUserLoginLogsRepository.save(vendorUserLoginLogs);
    }
}
