package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyBuildingPlanDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyBuildingPlanDetailsRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyBuildingPlanDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyBuildingPlanDetailsServiceImpl implements PropertyBuildingPlanDetailsService {

    @Autowired
    PropertyBuildingPlanDetailsRepository propertyBuildingPlanDetailsRepository;

    @Override
    public PropertyBuildingPlanDetails createPropertyBuildingPlanDetails(PropertyBuildingPlanDetails propertyBuildingPlanDetails) {
        if (propertyBuildingPlanDetails.getSuspendedStatus() == null) {
            propertyBuildingPlanDetails.setSuspendedStatus(0);
        }
        if (propertyBuildingPlanDetails.isFurtherBuildingPlanApprovedFlag()) {
            if (propertyBuildingPlanDetails.getBuildingPlanApprovalNo() == null ||
                    propertyBuildingPlanDetails.getBuildingPlanApprovalDate() == null) {
                throw new IllegalArgumentException("building plan approval number and date must be provided when further building plan approval flag is true");
            }
        } else {
            propertyBuildingPlanDetails.setBuildingPlanApprovalNo(null);
            propertyBuildingPlanDetails.setBuildingPlanApprovalDate(null);
        }
        if (propertyBuildingPlanDetails.isBuildingPlanCompletionFlag()) {
            if (propertyBuildingPlanDetails.getBuildingPlanCompletionNo() == null ||
                    propertyBuildingPlanDetails.getBuildingPlanCompletionDate() == null) {
                throw new IllegalArgumentException("building plan completion number and date must be provided when building plan completion flag is true");
            }
        } else {
            propertyBuildingPlanDetails.setBuildingPlanCompletionNo(null);
            propertyBuildingPlanDetails.setBuildingPlanCompletionDate(null);
        }
        propertyBuildingPlanDetails.setCreatedDate(LocalDateTime.now());
        return propertyBuildingPlanDetailsRepository.saveAndFlush(propertyBuildingPlanDetails);
    }

    @Override
    public List<PropertyBuildingPlanDetails> getAllPropertyBuildingPlanDetails() {
        return propertyBuildingPlanDetailsRepository.findAll();
    }

    @Override
    public Optional<PropertyBuildingPlanDetails> getPropertyBuildingPlanDetailsById(int id) {
        return propertyBuildingPlanDetailsRepository.findById(id);
    }

    @Override
    public List<PropertyBuildingPlanDetails> getPropertyBuildingPlanDetailsByMunicipalId(int municipalId) {
        return propertyBuildingPlanDetailsRepository.findByMunicipalId(municipalId);
    }

    @Override
    public PropertyBuildingPlanDetails patchPropertyBuildingPlanDetailsSuspendedStatus(int id, int suspendedStatus) {
        Optional<PropertyBuildingPlanDetails> patchPropertyBuildingPlan = propertyBuildingPlanDetailsRepository.findById(id);
        if (patchPropertyBuildingPlan.isPresent()) {
            PropertyBuildingPlanDetails existingPropertyBuildingPlan = patchPropertyBuildingPlan.get();
            existingPropertyBuildingPlan.setSuspendedStatus(suspendedStatus);
            return propertyBuildingPlanDetailsRepository.saveAndFlush(existingPropertyBuildingPlan);
        } else {
            throw new RuntimeException("property building plan details not found with id: " + id);
        }
    }

}
