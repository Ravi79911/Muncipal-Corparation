package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyALVCalculation;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyALVCalculationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("/forms")
public class PropertyALVCalculationController {

    @Autowired
    PropertyALVCalculationService propertyALVCalculationService;

    @PostMapping("/calculatePropertyALV")
    public ResponseEntity<PropertyALVCalculation> calculatePropertyALV(@RequestBody PropertyALVCalculation propertyALVCalculation) {
        PropertyALVCalculation resultPropertyALV = propertyALVCalculationService.calculatePropertyALV(propertyALVCalculation);
        return ResponseEntity.ok(resultPropertyALV);
    }

}
