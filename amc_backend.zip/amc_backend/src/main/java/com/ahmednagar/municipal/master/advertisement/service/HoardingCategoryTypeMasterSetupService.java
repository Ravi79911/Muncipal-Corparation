package com.ahmednagar.municipal.master.advertisement.service;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingCategoryTypeMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingCategoryTypeMasterSetup;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingCategoryTypeMasterSetupService {
    HoardingCategoryTypeMasterSetup saveHoardingCategoryTypeMasterSetup(HoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterSetup);

    List<HoardingCategoryTypeMasterSetupDto> findAllHoardingCategoryTypeMasterSetup();

    HoardingCategoryTypeMasterSetup findById(Long id);

    List<HoardingCategoryTypeMasterSetup> findAllByMunicipalId(int municipalId);

    HoardingCategoryTypeMasterSetup updateHoardingCategoryTypeMasterSetup(Long id, HoardingCategoryTypeMasterSetup updatedHoardingCategoryTypeMasterSetup, int updatedBy);

    HoardingCategoryTypeMasterSetup changeStatus(Long id, Integer status, int updatedBy);

}
