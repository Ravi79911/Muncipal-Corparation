package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUser;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorUserController {

    @Autowired
    private VendorUserService vendorUserService;

    @PostMapping("/userMaster/create")
    public ResponseEntity<VendorUser> createUserMaster(@RequestBody VendorUser vendorUser) {
        return ResponseEntity.ok(vendorUserService.saveUserMaster(vendorUser));
    }

    @GetMapping("/userMaster/getAll")
    public ResponseEntity<List<VendorUser>> getAllUsers() {
        return ResponseEntity.ok(vendorUserService.findAllUsers());
    }
}
