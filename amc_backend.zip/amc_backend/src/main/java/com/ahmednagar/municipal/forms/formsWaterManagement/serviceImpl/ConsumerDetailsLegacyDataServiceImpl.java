package com.ahmednagar.municipal.forms.formsWaterManagement.serviceImpl;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerDetailsLegacyData;
import com.ahmednagar.municipal.forms.formsWaterManagement.repository.ConsumerDetailsLegacyDataRepository;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.ConsumerDetailsLegacyDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class ConsumerDetailsLegacyDataServiceImpl implements ConsumerDetailsLegacyDataService {

    @Autowired
    private ConsumerDetailsLegacyDataRepository consumerDetailsLegacyDataRepository;

    @Override
    public Optional<ConsumerDetailsLegacyData> getConsumerDetailsLegacyData(String consumerNumber) {
//        return consumerDetailsLegacyDataRepository.findByConsumerNumber(consumerNumber)
//                .orElseThrow(() -> new RuntimeException("Consumer not found with number: " + consumerNumber));
        return consumerDetailsLegacyDataRepository.findByConsumerNumber(consumerNumber);
    }

    @Override
    public ConsumerDetailsLegacyData createConsumerDetailsLegacyData(ConsumerDetailsLegacyData consumerDetailsLegacyData) {
        consumerDetailsLegacyData.setSuspendedStatus(consumerDetailsLegacyData.getSuspendedStatus() != null ? consumerDetailsLegacyData.getSuspendedStatus() : 0);
        consumerDetailsLegacyData.setCreatedDate(LocalDateTime.now());
        consumerDetailsLegacyData.setUpdatedDate(LocalDateTime.now());
        return consumerDetailsLegacyDataRepository.saveAndFlush(consumerDetailsLegacyData);
    }

}
