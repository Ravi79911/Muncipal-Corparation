package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseLabelStage;
import org.springframework.stereotype.Service;

@Service
public interface LicenseLabelStageService {
    LicenseLabelStage saveLicenseLabelStage(LicenseLabelStage licenseLabelStage);
}
