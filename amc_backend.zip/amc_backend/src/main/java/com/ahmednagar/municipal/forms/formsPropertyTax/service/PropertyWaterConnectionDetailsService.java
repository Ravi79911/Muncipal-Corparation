package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyWaterConnectionDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface PropertyWaterConnectionDetailsService {

    PropertyWaterConnectionDetails createPropertyWaterConnectionDetails(PropertyWaterConnectionDetails propertyWaterConnectionDetails);

    List<PropertyWaterConnectionDetails> getAllPropertyWaterConnectionDetails();

    Optional<PropertyWaterConnectionDetails> getPropertyWaterConnectionDetailsById(Long id);

    List<PropertyWaterConnectionDetails> getPropertyWaterConnectionDetailsByMunicipalId(int municipalId);

    PropertyWaterConnectionDetails patchPropertyWaterConnectionDetailsSuspendedStatus(Long id, int suspendedStatus);

}
