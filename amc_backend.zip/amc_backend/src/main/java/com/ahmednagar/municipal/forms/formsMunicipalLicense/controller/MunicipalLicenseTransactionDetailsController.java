package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.MunicipalLicenseTransactionDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.MunicipalLicenseTransactionDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.MunicipalLicenseTransactionDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/forms/municipal/license/transaction/details")
public class MunicipalLicenseTransactionDetailsController {
    @Autowired
    private MunicipalLicenseTransactionDetailsService municipalLicenseTransactionDetailsService;

    //create Application Form
    @PostMapping("/create")
    public ResponseEntity<MunicipalLicenseTransactionDetails> createMunicipalLicenseTransactionDetails(@Valid @RequestBody MunicipalLicenseTransactionDetails municipalLicenseTransactionDetails) {
        MunicipalLicenseTransactionDetails createdMunicipalLicenseTransactionDetails = municipalLicenseTransactionDetailsService.saveMunicipalLicenseTransactionDetails(municipalLicenseTransactionDetails);
        return ResponseEntity.status(201).body(createdMunicipalLicenseTransactionDetails);
    }

    //  to get the Application Form by id for user
    @GetMapping("/get/{id}")
    public ResponseEntity<MunicipalLicenseTransactionDetails> getMunicipalLicenseTransactionDetailsById(@PathVariable Long id) {
        MunicipalLicenseTransactionDetails municipalLicenseTransactionDetails = municipalLicenseTransactionDetailsService.findMunicipalLicenseTransactionDetailsById(id);
        return ResponseEntity.ok(municipalLicenseTransactionDetails);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllMunicipalLicenseTransactionDetailsByMunicipalId(@PathVariable int municipalId) {
        List<MunicipalLicenseTransactionDetailsDto> municipalLicenseTransactionDetails = municipalLicenseTransactionDetailsService.findAllMunicipalLicenseTransactionDetailsByMunicipalId(municipalId);
        if (municipalLicenseTransactionDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No MunicipalLicenseTransactionDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(municipalLicenseTransactionDetails);
    }

    //     Update Application From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<MunicipalLicenseTransactionDetails> updateMunicipalLicenseTransactionDetails(@PathVariable("id") Long id, @RequestBody MunicipalLicenseTransactionDetails updatedMunicipalLicenseTransactionDetails) {
        try {
            MunicipalLicenseTransactionDetails updated = municipalLicenseTransactionDetailsService.updateMunicipalLicenseTransactionDetails(id, updatedMunicipalLicenseTransactionDetails, 1);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete Application From for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<MunicipalLicenseTransactionDetails> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        MunicipalLicenseTransactionDetails updatedMunicipalLicenseTransactionDetails = municipalLicenseTransactionDetailsService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedMunicipalLicenseTransactionDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedMunicipalLicenseTransactionDetails);
    }


}
