package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.*;
import com.ahmednagar.municipal.master.municipalLicence.dto.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ApplicationFromMasterDto {

    private Long id;
    private TradeApplicationTypeDto applicationTypeId;
    private MlFirmTypeDto firmTypeId;
    private MlBusinessPremisesDto permissesOwnershipId;
    private MlTradeTypeDto businessCatId;
    private MlBusinessNatureDto natureOfBusinessId;
    private String appliedFyYear;
    private String applicationNo;
    private String applicationAppliedFrom;
    private LocalDate applicationDate;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;
    private List<AppApplicantDetails> appApplicantDetails=null;
    private List<ApplicationDocumentsDetails> applicationDocumentsDetails=null;
    private List<ApplicationElectricityDetails> applicationElectricityDetails=null;
    private List<ApplicationFeePayMaster> applicationFeePayMasters=null;
    private List<ApplicationFirmDetails> applicationFirmDetails=null;
    private List<ApplicationLicenseDetails> applicationLicenseDetails=null;
    private List<ApplicationPermisesDetails> applicationPermisesDetails=null;
    private List<RenewalSurrenderAmendmentAppliedDetails> renewalSurrenderAmendmentAppliedDetails=null;

}
