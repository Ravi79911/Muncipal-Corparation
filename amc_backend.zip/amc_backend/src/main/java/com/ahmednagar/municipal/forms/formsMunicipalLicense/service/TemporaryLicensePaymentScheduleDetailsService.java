package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.TemporaryLicensePaymentScheduleDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.TemporaryLicensePaymentScheduleDetails;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public interface TemporaryLicensePaymentScheduleDetailsService {
    TemporaryLicensePaymentScheduleDetails createTemporaryLicensePaymentScheduleDetails(TemporaryLicensePaymentScheduleDetails temporaryLicensePaymentScheduleDetails);

    BigDecimal calculateTotalAmount(TemporaryLicensePaymentScheduleDetails temporaryLicensePaymentScheduleDetails);

    TemporaryLicensePaymentScheduleDetails findById(Long id);

    TemporaryLicensePaymentScheduleDetails findTemporaryLicensePaymentScheduleDetailsById(Long id);

    BigDecimal calculateTax(TemporaryLicensePaymentScheduleDetails temporaryLicensePaymentScheduleDetails, BigDecimal taxRate);

    List<TemporaryLicensePaymentScheduleDetailsDto> findAllTemporaryLicensePaymentScheduleDetails();

    List<TemporaryLicensePaymentScheduleDetails> findAllByMunicipalId(int municipalId);

}
