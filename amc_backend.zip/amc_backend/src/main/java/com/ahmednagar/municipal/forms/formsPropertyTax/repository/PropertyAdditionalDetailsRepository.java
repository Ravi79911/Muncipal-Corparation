package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyAdditionalDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface PropertyAdditionalDetailsRepository extends JpaRepository<PropertyAdditionalDetails, Long> {

    List<PropertyAdditionalDetails> findByMunicipalPropertyMasterId(Long municipalPropertyMasterId);

    void deleteByMunicipalPropertyMasterId(Long municipalPropertyMasterId);

    List<PropertyAdditionalDetails> findByMunicipalId(int municipalId);

}
