package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ApplicationFeePayMasterDto {
    private int id;
    private LocalDate startDate;
    private LocalDate endDate;
    private int noOfDays;
    private ApplicationFromMasterDto applicationMasterId;
    private int licenseAppliedForYears;
    private BigDecimal applicationFee;
    private BigDecimal penalty;
    private BigDecimal denialArrearAmount;
    private BigDecimal totalFeePaid;
    private String feePaymentMode;
    private String transactionNo;
    private Date transactionDate;
    private String paymentMode;
    private String chequeNoOnlineTransactionNo;
    private Date chequeDateOnlineTransactionDate;
    private String bankName;
    private String bankBranch;
    private String ifscCode;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;

}