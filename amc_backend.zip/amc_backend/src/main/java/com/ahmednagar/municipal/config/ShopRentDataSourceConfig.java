package com.ahmednagar.municipal.config;

import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = {
                "com.ahmednagar.municipal.master.shopRent.repository",
                "com.ahmednagar.municipal.forms.formsShopRent.repository"
        },
        entityManagerFactoryRef = "shopRentEntityManagerFactory",
        transactionManagerRef = "shopRentTransactionManager"
)
public class ShopRentDataSourceConfig {
    @Bean(name = "shopRentDataSource")
    @ConfigurationProperties(prefix = "spring.shop-rent.datasource")
    public DataSource shopRentDataSource() {return DataSourceBuilder.create().build();}

    @Bean(name = "shopRentEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean shopRentEntityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                               @Qualifier("shopRentDataSource") DataSource shopRentDataSource) {
        return builder
                .dataSource(shopRentDataSource)
                .packages(
                        "com.ahmednagar.municipal.master.shopRent.model",
                        "com.ahmednagar.municipal.forms.formsShopRent.model"
                )
                .persistenceUnit("shopRentPU")
                .build();
    }

    @Bean(name = "shopRentTransactionManager")
    public PlatformTransactionManager shopRentTransactionManager(
            @Qualifier("shopRentEntityManagerFactory") EntityManagerFactory shopRentEntityManagerFactory) {
        return new JpaTransactionManager(shopRentEntityManagerFactory);
    }
}
