package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyFloorMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface PropertyFloorMasterService {

    // single entity creation
    PropertyFloorMaster createPropertyFloorMaster(PropertyFloorMaster propertyFloorMaster);

    // list of entity creation
    List<PropertyFloorMaster> createPropertyFloorMasterList(List<PropertyFloorMaster> propertyFloorMasterList);

    List<PropertyFloorMaster> getAllPropertyFloorMaster();

    Optional<PropertyFloorMaster> getPropertyFloorMasterById(Long id);

    List<PropertyFloorMaster> getPropertyFloorMasterByMunicipalId(int municipalId);

    PropertyFloorMaster patchPropertyFloorMasterSuspendedStatus(Long id, int suspendedStatus);

}
