package com.ahmednagar.municipal.auth.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserMasterOtpHistoryDto {

    private Long id;
    private String email;
    private String mobileNumber;
    private String emailOtp;
    private String mobileOtp;
    private String emailOtpGeneratedDateTime;
    private String mobileOtpGeneratedDateTime;

}
