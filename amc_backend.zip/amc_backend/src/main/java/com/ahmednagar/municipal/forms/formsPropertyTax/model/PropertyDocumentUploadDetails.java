package com.ahmednagar.municipal.forms.formsPropertyTax.model;

import com.ahmednagar.municipal.master.propertyTax.model.PropertyUploadDocumentMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name = "tbl_muni_property_document_upload_details")
public class PropertyDocumentUploadDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "document path is required")
    @Size(max = 350, message = "document path can't exceed 350 characters")
    @Column(name = "document_path", nullable = false, length = 350)
    private String documentPath;

//    @NotNull(message = "document upload is required")
//    @Column(name = "document_upload", nullable = false)
//    private String documentUpload;

    @NotNull(message = "created by is required")
    @Column(name = "created_by", nullable = false)
    private Integer createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_by", nullable = false)
    private Integer updatedBy;

    @Column(name = "updated_date", nullable = false)
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private MunicipalPropertyMaster municipalPropertyMaster;

    @ManyToOne
    @JoinColumn(name = "property_document_upload_mas_id", referencedColumnName = "id", nullable = false)
    private PropertyUploadDocumentMaster propertyUploadDocumentMaster;

}
