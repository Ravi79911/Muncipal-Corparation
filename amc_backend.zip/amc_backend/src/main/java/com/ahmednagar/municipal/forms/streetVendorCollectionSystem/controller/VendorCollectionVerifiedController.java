package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionVerification;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorCollectionVerifiedService;
import com.ahmednagar.municipal.master.propertyTax.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorCollectionVerifiedController {

    @Autowired
    private VendorCollectionVerifiedService vendorCollectionVerifiedService;

    @PostMapping("/saveVendorCollectionVerification")
    public ResponseEntity<VendorCollectionVerification> createVendorCollectionVerification(@RequestBody VendorCollectionVerification vendorCollectionVerification) {
        return ResponseEntity.ok(vendorCollectionVerifiedService.saveVendorCollectionVerification(vendorCollectionVerification));
    }

    @PutMapping("/updateVendorCollectionVerifications")
    public ResponseEntity<List<VendorCollectionVerification>> updateVendorCollectionVerifications(
            @RequestParam List<Long> ids,
            @RequestBody List<VendorCollectionVerification> vendorCollectionVerifications) {
        try {
            return ResponseEntity.ok(vendorCollectionVerifiedService.updateVendorCollectionVerifications(ids, vendorCollectionVerifications));
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.emptyList());
        }
    }



    @GetMapping("/getAllVendorCollectionVerifications")
    public ResponseEntity<List<VendorCollectionVerification>> getAllVendorCollectionVerifications() {
        List<VendorCollectionVerification> records = vendorCollectionVerifiedService.getAllVendorCollectionVerifications();
        return ResponseEntity.ok(records);
    }

    @GetMapping("/getVendorCollectionVerificationById/{id}")
    public ResponseEntity<Optional<VendorCollectionVerification>> getVendorCollectionVerificationById(@PathVariable Long id) {
        Optional<VendorCollectionVerification> record = vendorCollectionVerifiedService.getVendorCollectionVerificationById(id);
        return ResponseEntity.ok(record);
    }

//    @GetMapping("/filter")
//    public ResponseEntity<List<VendorCollectionVerification>> getFilteredRecords(
//            @RequestParam(required = false) Long zoneId,
//            @RequestParam(required = false) Long zoneWardId,
//            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFrom,
//            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateTo,
//            @RequestParam(required = false) Long vendorUserId,
//            @RequestParam(required = false) String verifiedStatus) {
//        List<VendorCollectionVerification> records = vendorCollectionVerifiedService.getFilteredRecords(zoneId, zoneWardId, dateFrom, dateTo, vendorUserId, verifiedStatus);
//        return ResponseEntity.ok(records);
//    }

    @GetMapping("/getByCreatedDateAndVendorUserId")
    public ResponseEntity<List<VendorCollectionVerification>> getByCreatedDateAndVendorUserId(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate createdDate,
            @RequestParam(required = false) Long vendorUserId) {

        List<VendorCollectionVerification> records = vendorCollectionVerifiedService.getByCreatedDateAndVendorUserId(createdDate, vendorUserId);
        return ResponseEntity.ok(records);
    }



}
