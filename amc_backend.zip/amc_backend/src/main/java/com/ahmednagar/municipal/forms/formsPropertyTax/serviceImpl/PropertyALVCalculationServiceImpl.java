package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyALVCalculation;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyALVCalculationRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyALVCalculationService;
import com.ahmednagar.municipal.master.propertyTax.model.*;
import com.ahmednagar.municipal.master.propertyTax.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class PropertyALVCalculationServiceImpl implements PropertyALVCalculationService {

    @Autowired
    PropertyALVCalculationRepository propertyALVCalculationRepository;

    @Autowired
    AnnualRatingValueMasterRepository annualRatingValueMasterRepository;

    @Autowired
    RoadTypeRepository roadTypeRepository;

    @Autowired
    PropertyConstructionTypeRepository propertyConstructionTypeRepository;

    @Autowired
    BuildingAgingMaintenanceDeductionMasterRepository buildingAgingMaintenanceDeductionMasterRepository;

    @Autowired
    PropertyTaxComponentRepository propertyTaxComponentRepository;

    @Autowired
    PropertyTaxCessRateMasterRepository propertyTaxCessRateMasterRepository;

    @Autowired
    PropertyAreaRangeMasterRepository propertyAreaRangeMasterRepository;

    @Autowired
    DDUsageTypeMasterRepository DDUsageTypeMasterRepository;

    @Autowired
    DDOccupancyTypeMasterRepository DDOccupancyTypeMasterRepository;

    @Override
    public PropertyALVCalculation calculatePropertyALV(PropertyALVCalculation propertyALVCalculation) {
        DDOccupancyTypeMaster occupancyType = fetchOccupancyType(propertyALVCalculation.getOccupancyTypeId());

        if ("SELF OCCUPIED".equals(occupancyType.getOccupancyTypeName())) {
            processSelfOccupied(propertyALVCalculation, occupancyType);
        } else if ("TENANT".equals(occupancyType.getOccupancyTypeName())) {
            processTenant(propertyALVCalculation, occupancyType);
        }

        return propertyALVCalculation;
    }

    private DDOccupancyTypeMaster fetchOccupancyType(Long occupancyTypeId) {
        return DDOccupancyTypeMasterRepository.findById(occupancyTypeId)
                .orElseThrow(() -> new RuntimeException("Occupancy type not found"));
    }

    private void processSelfOccupied(PropertyALVCalculation propertyALVCalculation, DDOccupancyTypeMaster occupancyType) {
        System.out.println("Processing Self Occupied");

        convertArea(propertyALVCalculation);
        calculateAnnualRatingValue(propertyALVCalculation);
        applyMaintenanceDeduction(propertyALVCalculation);
        calculatePropertyTax(propertyALVCalculation);
        calculateStateAndProfessionalTax(propertyALVCalculation);
    }

    private void processTenant(PropertyALVCalculation propertyALVCalculation, DDOccupancyTypeMaster occupancyType) {
        System.out.println("Processing Tenant");

        convertArea(propertyALVCalculation);
        calculateRentBasedALV(propertyALVCalculation);
        applyMaintenanceDeductionForTenant(propertyALVCalculation);
        calculatePropertyTaxForTenant(propertyALVCalculation);
        calculateStateAndProfessionalTax(propertyALVCalculation);
    }

    private void convertArea(PropertyALVCalculation propertyALVCalculation) {
        if (propertyALVCalculation.getFloorBuildupAreaSqft() != null) {
            propertyALVCalculation.setFloorBuildupAreaSqMtr(convertToSquareMeters(propertyALVCalculation.getFloorBuildupAreaSqft()));
        }

        if (propertyALVCalculation.getCarpetAreaSqft() != null) {
            propertyALVCalculation.setCarpetAreaSqMtr(convertToSquareMeters(propertyALVCalculation.getCarpetAreaSqft()));
        }
    }

    private BigDecimal convertToSquareMeters(BigDecimal areaSqft) {
        return areaSqft.divide(BigDecimal.valueOf(10.76), 0, RoundingMode.CEILING);
    }

    private void calculateAnnualRatingValue(PropertyALVCalculation propertyALVCalculation) {
        RoadType roadType = fetchRoadType(propertyALVCalculation.getRoadTypeId());
        PropertyConstructionType constructionType = fetchConstructionType(propertyALVCalculation.getConstructionTypeId());
        AnnualRatingValueMaster ratingValue = fetchRatingValue(roadType, constructionType);

        if (ratingValue != null && ratingValue.getMultipliersValuePerSqMtr() != null) {
            BigDecimal multiplier = ratingValue.getMultipliersValuePerSqMtr();
            propertyALVCalculation.setAlvRateValue(multiplier);
            propertyALVCalculation.setFloorAlpValue(
                    propertyALVCalculation.getFloorBuildupAreaSqMtr().multiply(multiplier).setScale(0, RoundingMode.CEILING)
            );
        } else {
            propertyALVCalculation.setFloorRateableValue(BigDecimal.ZERO);
        }
    }

    private RoadType fetchRoadType(Long roadTypeId) {
        return roadTypeRepository.findById(roadTypeId)
                .orElseThrow(() -> new RuntimeException("RoadType not found"));
    }

    private PropertyConstructionType fetchConstructionType(Long constructionTypeId) {
        return propertyConstructionTypeRepository.findById(constructionTypeId)
                .orElseThrow(() -> new RuntimeException("PropertyConstructionType not found"));
    }

    private AnnualRatingValueMaster fetchRatingValue(RoadType roadType, PropertyConstructionType constructionType) {
        return annualRatingValueMasterRepository.findByRoadTypeAndPropertyConstructionType(roadType, constructionType);
    }

    private void applyMaintenanceDeduction(PropertyALVCalculation propertyALVCalculation) {
        List<BuildingAgingMaintenanceDeductionMaster> deductions = buildingAgingMaintenanceDeductionMasterRepository.findByPropertyConstructionTypeId(propertyALVCalculation.getConstructionTypeId());

        if (!deductions.isEmpty()) {
            BuildingAgingMaintenanceDeductionMaster applicableDeduction = findApplicableDeduction(deductions, propertyALVCalculation.getAgeOfBuildingId());
            if (applicableDeduction != null) {
                BigDecimal deductionRate = applicableDeduction.getDeductionRate().divide(BigDecimal.valueOf(100), RoundingMode.HALF_UP);
                BigDecimal deductionAmount = propertyALVCalculation.getFloorAlpValue().multiply(deductionRate).setScale(0, RoundingMode.CEILING);
                propertyALVCalculation.setBuildingMaintenanceRate(applicableDeduction.getDeductionRate());
                propertyALVCalculation.setFloorRateableValue(propertyALVCalculation.getFloorAlpValue().subtract(deductionAmount));
            }
        }
    }

    private BuildingAgingMaintenanceDeductionMaster findApplicableDeduction(List<BuildingAgingMaintenanceDeductionMaster> deductions, Long ageOfBuildingId) {
        return deductions.stream()
                .filter(deductionMaster -> deductionMaster.getPropertyConstructionAge().getId().equals(ageOfBuildingId))
                .findFirst()
                .orElse(null);
    }

    private void calculatePropertyTax(PropertyALVCalculation propertyALVCalculation) {
        List<PropertyTaxComponent> taxComponents = propertyTaxComponentRepository.findByMunicipalId(propertyALVCalculation.getMunicipalId());
        BigDecimal totalRateValue = taxComponents.stream()
                .filter(taxComponent -> taxComponent.getIsRateActive() == 1)
                .map(taxComponent -> BigDecimal.valueOf(taxComponent.getRateValue()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        System.out.println("Property Tax Components: " + taxComponents);
        System.out.println("Total Rate Value: " + totalRateValue);

        if (totalRateValue.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal annualTaxRate = totalRateValue.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
            BigDecimal totalAnnualTax = propertyALVCalculation.getFloorRateableValue().multiply(annualTaxRate).setScale(0, RoundingMode.CEILING);
            propertyALVCalculation.setTotalAnnualTax(totalAnnualTax);

            System.out.println("Annual Tax Rate: " + annualTaxRate);
            System.out.println("Total Annual Tax: " + totalAnnualTax);

        } else {
            propertyALVCalculation.setTotalAnnualTax(BigDecimal.ZERO);
        }
    }

    private void calculateStateAndProfessionalTax(PropertyALVCalculation propertyALVCalculation) {
        BigDecimal floorAlpValue = propertyALVCalculation.getFloorAlpValue();

        // fetch the UsageTypeMaster using the floorUsageType ID
        DDUsageTypeMaster usageType = DDUsageTypeMasterRepository.findById(propertyALVCalculation.getFloorUsageType())
                .orElseThrow(() -> new IllegalArgumentException("Invalid usage type id: " + propertyALVCalculation.getFloorUsageType()));

        System.out.println("usageType.getUsageTypeName(): " + usageType.getUsageTypeName());

        BigDecimal educationTax = BigDecimal.ZERO;
        BigDecimal professionalTax = BigDecimal.ZERO;

        // fetch the appropriate cess rates based on the property area range
        List<PropertyTaxCessRateMaster> cessRates = propertyTaxCessRateMasterRepository
                .findByPropertyAreaRangeMaster_FromRangeLessThanEqualAndPropertyAreaRangeMaster_ToRangeGreaterThanEqual(
                        floorAlpValue, floorAlpValue);

        System.out.println("cessRates: " + cessRates);

        if (!cessRates.isEmpty()) {
            for (PropertyTaxCessRateMaster rate : cessRates) {
                if ("State Education Cess".equalsIgnoreCase(rate.getTaxComponent())) {
                    if ("RESIDENTIAL".equalsIgnoreCase(usageType.getUsageTypeName())) {
                        educationTax = floorAlpValue.multiply(rate.getRateValue().divide(BigDecimal.valueOf(100), RoundingMode.CEILING));
                        break;
                    } else if ("COMMERCIAL".equalsIgnoreCase(usageType.getUsageTypeName())) {
                        educationTax = floorAlpValue.multiply(rate.getRateValue().divide(BigDecimal.valueOf(100), RoundingMode.CEILING));
                    }
                }

                // calculate Professional Tax (only for Commercial usage type)
                if ("State Professional Tax".equalsIgnoreCase(rate.getTaxComponent())
                        && "COMMERCIAL".equalsIgnoreCase(usageType.getUsageTypeName())) {
                    professionalTax = floorAlpValue.multiply(rate.getRateValue().divide(BigDecimal.valueOf(100), RoundingMode.CEILING));
                }
            }

            System.out.println("Education Tax: " + educationTax);
            System.out.println("Professional Tax: " + professionalTax);

            // total tax calculation
            BigDecimal totalTax = educationTax.add(professionalTax);

            System.out.println("Total Tax: " + totalTax);

            // set total state tax
            propertyALVCalculation.setTotalStateTax(totalTax);

            // update total annual tax
            BigDecimal currentTotalAnnualTax = propertyALVCalculation.getTotalAnnualTax() != null
                    ? propertyALVCalculation.getTotalAnnualTax()
                    : BigDecimal.ZERO;

            BigDecimal updatedTotalAnnualTax = currentTotalAnnualTax.add(totalTax);

            System.out.println("Updated Total Annual Tax: " + updatedTotalAnnualTax);

            // set total payable tax to the updated total annual tax
            propertyALVCalculation.setTotalPayableTax(updatedTotalAnnualTax);
        }
    }

    private DDUsageTypeMaster fetchUsageType(Long usageTypeId) {
        return DDUsageTypeMasterRepository.findById(usageTypeId)
                .orElseThrow(() -> new RuntimeException("Usage type not found"));
    }

    private void calculateRentBasedALV(PropertyALVCalculation propertyALVCalculation) {
        // ensure rent value amount is present and rent period is provided
        if (propertyALVCalculation.getRentValueAmount() != null &&
                propertyALVCalculation.getRentCalculatedFrom() != null &&
                propertyALVCalculation.getRentCalculatedFromUpTo() != null) {

            long daysBetween = ChronoUnit.DAYS.between(propertyALVCalculation.getRentCalculatedFrom(), propertyALVCalculation.getRentCalculatedFromUpTo());

            // if the period is greater than 0, calculate the rent for the given period
            if (daysBetween > 0) {
                BigDecimal rentPerDay = propertyALVCalculation.getRentValueAmount().divide(BigDecimal.valueOf(30), 2, RoundingMode.HALF_UP);
                BigDecimal totalRentValue = rentPerDay.multiply(BigDecimal.valueOf(daysBetween));

                System.out.println("Rent Per Day: " + rentPerDay);
                System.out.println("Total Rent Value for the Period: " + totalRentValue);

                // if the period is 12 months or more, set the annual rent
                if (daysBetween >= 365) {
                    BigDecimal totalRentForYear = propertyALVCalculation.getRentValueAmount().multiply(BigDecimal.valueOf(12));
                    System.out.println("Total Rent for 12 months: " + totalRentForYear);
                    propertyALVCalculation.setFloorAlpValue(totalRentForYear);
                } else {
                    propertyALVCalculation.setFloorAlpValue(totalRentValue);
                }

                // apply maintenance deduction (if applicable)
                applyMaintenanceDeductionForTenant(propertyALVCalculation);
            } else {
                System.out.println("Invalid rent period: The number of days is non-positive.");
            }
        } else {
            System.out.println("Rent value or rent period is missing.");
        }
    }

    private void applyMaintenanceDeductionForTenant(PropertyALVCalculation propertyALVCalculation) {
        // assuming that a 10% maintenance deduction applies for tenants
        BigDecimal maintenanceDeduction = propertyALVCalculation.getFloorAlpValue().multiply(BigDecimal.valueOf(0.10));
        BigDecimal floorRateableValue = propertyALVCalculation.getFloorAlpValue().subtract(maintenanceDeduction);

        System.out.println("Maintenance Deduction (10%): " + maintenanceDeduction);
        System.out.println("Floor Rateable Value (after deduction): " + floorRateableValue);

        // set the maintenance deduction and the updated floor rateable value
        propertyALVCalculation.setBuildingMaintenanceRate(maintenanceDeduction);
        propertyALVCalculation.setFloorRateableValue(floorRateableValue);
    }

    private void calculatePropertyTaxForTenant(PropertyALVCalculation propertyALVCalculation) {
        // calculate property tax based on the tenant's floor rateable value {44% of tax head & state tax(education tax & professional tax)}
        List<PropertyTaxComponent> taxComponents = propertyTaxComponentRepository.findByMunicipalId(propertyALVCalculation.getMunicipalId());
        BigDecimal totalRateValue = taxComponents.stream()
                .filter(taxComponent -> taxComponent.getIsRateActive() == 1)
                .map(taxComponent -> BigDecimal.valueOf(taxComponent.getRateValue()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        System.out.println("Property Tax Components: " + taxComponents);
        System.out.println("Total Rate Value: " + totalRateValue);

        if (totalRateValue.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal annualTaxRate = totalRateValue.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
            BigDecimal totalAnnualTax = propertyALVCalculation.getFloorRateableValue().multiply(annualTaxRate).setScale(0, RoundingMode.CEILING);
            propertyALVCalculation.setTotalAnnualTax(totalAnnualTax);

            System.out.println("Annual Tax Rate: " + annualTaxRate);
            System.out.println("Total Annual Tax: " + totalAnnualTax);

        } else {
            propertyALVCalculation.setTotalAnnualTax(BigDecimal.ZERO);
        }
    }
}