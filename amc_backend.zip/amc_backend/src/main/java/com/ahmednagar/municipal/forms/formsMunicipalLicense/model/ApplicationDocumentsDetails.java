package com.ahmednagar.municipal.forms.formsMunicipalLicense.model;

import com.ahmednagar.municipal.master.municipalLicence.model.MlDocumentsMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_application_documents_details")
public class ApplicationDocumentsDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
//    @NotNull(message = "id is required")
    private Long id;

    @Column(name = "document_file_name")
    @NotNull
    @Size(max = 150, message = "document file name cannot exceed 150 characters")
    private String documentFileName;

    @Column(name = "document_path")
    @NotNull(message = "document path is required")
    @Size(max = 150, message = "document path cannot exceed 150 characters")
    private String documentPath;

    @NotNull(message = "created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "application_master_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ApplicationFromMaster applicationMasterId;

    @ManyToOne
    @JoinColumn(name = "document_master_id", nullable = false, referencedColumnName = "id")
    private MlDocumentsMaster documentsMasterId;

}
