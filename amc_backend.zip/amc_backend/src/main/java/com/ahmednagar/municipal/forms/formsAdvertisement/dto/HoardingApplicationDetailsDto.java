package com.ahmednagar.municipal.forms.formsAdvertisement.dto;

import com.ahmednagar.municipal.master.advertisement.dto.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingApplicationDetailsDto {
    private Long id;
    private HoardingApplicationMasterDto hoardingApplicationMasterId;
    private HoardingTypeMasterSetupDto hoardingTypeMasterId;
    private DDAdvertisementUsageTypeMasterDto usageTypeId;
    private HoardingCategoryTypeMasterSetupDto hoardingCategoryTypeMasterId;
    private HoardingTypeSizeMasterSetupDto hoardingTypeSizeMasterId;
    private HoardingTypeRateMasterSetupDto hoardingTypeRateMasterId;
    private String calculatedAmount;
    private Long zoneId;
    private Long wardId;
    private LocalDate allocatedFromDate;
    private LocalDate allocatedUptoDate;
    private Long calculatedPeriodDays;
    private Long calculatedPeriodMonths;
    private Long calculatedPeriodYears;
    private BigDecimal hoardingLengthSqft;
    private BigDecimal hoardingWidthSqft;
    private Long hoardingSize;
    private String hoardingFullSiteAddress;
    private BigDecimal hoardingRateSqft;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
