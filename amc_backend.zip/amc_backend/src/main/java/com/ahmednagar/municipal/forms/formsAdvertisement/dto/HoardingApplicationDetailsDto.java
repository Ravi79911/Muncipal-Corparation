package com.ahmednagar.municipal.forms.formsAdvertisement.dto;

import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationMaster;
import com.ahmednagar.municipal.master.advertisement.dto.HoardingTypeMasterSetupDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingApplicationDetailsDto {
    private Long id;
    private HoardingApplicationMaster hoardingApplicationMasterId;
    private HoardingTypeMasterSetupDto hoardingTypeMasterId;
    private Long zoneNo;
    private Long wardNo;
    private Long hoardingSize;
    private String hoardingFullSiteAddress;
    private BigDecimal hoardingRateSqft;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
