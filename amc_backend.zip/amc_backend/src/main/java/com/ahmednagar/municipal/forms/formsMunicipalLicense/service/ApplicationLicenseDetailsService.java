package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationLicenseDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationLicenseDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ApplicationLicenseDetailsService {
    ApplicationLicenseDetails saveApplicationLicenseDetails(ApplicationLicenseDetails applicationLicenseDetails, int createdBy);

    ApplicationLicenseDetails findApplicationLicenseDetailsById(Long id);

    List<ApplicationLicenseDetailsDto> findAllApplicationLicenseDetailsByMunicipalId(Long municipalId);

    //ApplicationLicenseDetails updateApplicationLicenseDetails(Long id, ApplicationLicenseDetailsDto updatedApplicationLicenseDetails);

    //ApplicationLicenseDetails updateApplicationLicenseDetails(Long id, ApplicationLicenseDetailsDto updatedApplicationLicenseDetails);

    ApplicationLicenseDetails updateApplicationLicenseDetails(Long id, ApplicationLicenseDetails updatedApplicationLicenseDetails);

    ApplicationLicenseDetails changeSuspendedStatus(Long id, int status, int updatedBy);

    List<ApplicationLicenseDetailsDto> findAllApplicationLicenseDetailsByLicenseNo(String LicenseNo);

    boolean isLicenseNoExists(String licenseNo);

    void deleteApplicationLicenseDetailsByApplicationMasterId(Long applicationMasterId);

//    List<ApplicationLicenseDetailsDto> findAllApplicationLicenseDetails();
}
