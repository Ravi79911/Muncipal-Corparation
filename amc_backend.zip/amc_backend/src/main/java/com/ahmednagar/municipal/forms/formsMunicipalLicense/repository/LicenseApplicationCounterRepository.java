package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseApplicationCounter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface LicenseApplicationCounterRepository extends JpaRepository<LicenseApplicationCounter,Long> {

    Optional<Object> findByCounterName(String counterName);

}
