package com.ahmednagar.municipal.forms.formsAdvertisement.controller;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingAllottedDemandDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingAllottedDemand;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingAllottedDemandService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/advertisement/hoarding/allotted/demand/form")
@Validated
@CrossOrigin
public class HoardingAllottedDemandController {
    @Autowired
    private HoardingAllottedDemandService hoardingAllottedDemandService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingAllottedDemand> createHoardingAllottedDemand(@Valid @RequestBody HoardingAllottedDemand hoardingAllottedDemand){
        HoardingAllottedDemand savedHoardingAllottedDemand=hoardingAllottedDemandService.saveHoardingAllottedDemand(hoardingAllottedDemand);
        return ResponseEntity.status(201).body(savedHoardingAllottedDemand);

    }
    // list of entity creation method
    @PostMapping("/createList")
    public ResponseEntity<List<HoardingAllottedDemand>> createHoardingAllottedDemand(@Valid @RequestBody List<HoardingAllottedDemand> hoardingAllottedDemandList) {
        try {
            List<HoardingAllottedDemand> newHoardingAllottedDemandList = hoardingAllottedDemandService.createHoardingAllottedDemandList(hoardingAllottedDemandList);
            return ResponseEntity.ok(newHoardingAllottedDemandList);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(List.of());
        }
    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingAllottedDemandDto>> getAllHoardingAllottedDemand(){
        List<HoardingAllottedDemandDto> hoardingAllottedDemand=hoardingAllottedDemandService.findAllHoardingAllottedDemand();
        return ResponseEntity.ok(hoardingAllottedDemand);

    }

    //for single user by Id
    @GetMapping("/getHoardingAllottedDemandById/{id}")
    public ResponseEntity<HoardingAllottedDemand> getHoardingAllottedDemandById(@PathVariable Long id){
        HoardingAllottedDemand hoardingAllottedDemand=hoardingAllottedDemandService.findById(id);
        return ResponseEntity.ok(hoardingAllottedDemand);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingAllottedDemandByMunicipalId(@PathVariable int municipalId){
        List<HoardingAllottedDemand> hoardingAllottedDemands = hoardingAllottedDemandService.findAllByMunicipalId(municipalId);
        if (hoardingAllottedDemands.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingAllottedDemand found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingAllottedDemands);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingAllottedDemand> updateHoardingAllottedDemand(@PathVariable("id") Long id, @RequestBody HoardingAllottedDemand updatedHoardingAllottedDemand){
        try{
            HoardingAllottedDemand updated=hoardingAllottedDemandService.updateHoardingAllottedDemand(id,updatedHoardingAllottedDemand,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingAllottedDemandService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }

    @DeleteMapping("/deleteHoardingAllottedDemand/{hoardingApplicationMasterId}")
    public ResponseEntity<String> deleteHoardingAllottedDemand(@PathVariable Long hoardingApplicationMasterId) {
        try {
            hoardingAllottedDemandService.deleteHoardingAllottedDemandByHoardingApplicationMasterId(hoardingApplicationMasterId);
            return ResponseEntity.ok("HoardingAllottedDemand records deleted successfully for HoardingApplicationMasterId id: " + hoardingApplicationMasterId);
        } catch (Exception ex) {
            return ResponseEntity.status(500).body("An unexpected error occurred: " + ex.getMessage());
        }
    }
}

