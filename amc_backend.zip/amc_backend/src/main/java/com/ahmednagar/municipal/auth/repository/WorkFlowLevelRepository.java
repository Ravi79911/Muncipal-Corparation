package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.LicenseWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.ViewMunicipalPropertyMaster;
import com.ahmednagar.municipal.auth.model.WorkFlowLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;


@EnableJpaRepositories
public interface WorkFlowLevelRepository extends JpaRepository<WorkFlowLevel,Long> {

    @Query(value = "SELECT TOP 1 * FROM tbl_work_flow_level WHERE application_id = :applicationId AND status_code = :statusCode ORDER BY created_date DESC", nativeQuery = true)
    Optional<WorkFlowLevel> findLatestWorkFlowByApplicationIdAndStatusCode(@Param("applicationId") Long applicationId, @Param("statusCode") Long statusCode);

    Optional<WorkFlowLevel> findTopByApplicationIdOrderByCreatedDateDesc(ViewMunicipalPropertyMaster applicationId);

    List<WorkFlowLevel> findByApplicationId_Id(Long applicationId);
}
