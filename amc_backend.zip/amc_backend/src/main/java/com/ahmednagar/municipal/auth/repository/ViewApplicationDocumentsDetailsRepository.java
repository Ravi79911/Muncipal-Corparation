package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.ViewApplicationDocumentsDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ViewApplicationDocumentsDetailsRepository extends JpaRepository<ViewApplicationDocumentsDetails,Long> {
    List<ViewApplicationDocumentsDetails> findByViewApplicationFromMaster_Id(Long id);

    List<ViewApplicationDocumentsDetails> findByviewApplicationFromMaster_Id(Long applicationMasterId);
}
