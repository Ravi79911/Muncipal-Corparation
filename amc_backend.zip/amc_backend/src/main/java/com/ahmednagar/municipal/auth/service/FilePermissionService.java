package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.FilePermissionDto;
import com.ahmednagar.municipal.auth.model.FilePermission;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface FilePermissionService {
    FilePermission saveFilePermissionService(FilePermission filePermission);

    List<FilePermissionDto> findAllFilePermission();

    List<FilePermissionDto> findAllFilePermissionByMunicipalId(Long municipalId);

    FilePermission updateFilePermission(Long id, FilePermission updatedFilePermission);

    FilePermission changeSuspendedStatus(Long id, int status);
}
