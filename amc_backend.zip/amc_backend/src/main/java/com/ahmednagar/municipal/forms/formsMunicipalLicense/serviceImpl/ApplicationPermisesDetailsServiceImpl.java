package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationPermisesDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFirmDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationPermisesDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationPermisesDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationPermisesDetailsService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ApplicationPermisesDetailsServiceImpl implements ApplicationPermisesDetailsService {
    @Autowired
    private ApplicationPermisesDetailsRepository applicationPermisesDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ApplicationPermisesDetails saveApplicationPermisesDetails(ApplicationPermisesDetails applicationPermisesDetails, int createdBy) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        applicationPermisesDetails.setCreatedDate(currentDateTime);
        applicationPermisesDetails.setSuspendedStatus(applicationPermisesDetails.getSuspendedStatus() != null ? applicationPermisesDetails.getSuspendedStatus() : 0);      // 0 means active
        applicationPermisesDetails.setCreatedBy(createdBy);            // 1 means admin
        return applicationPermisesDetailsRepository.saveAndFlush(applicationPermisesDetails);
    }

//    @Override
//    public List<ApplicationPermisesDetailsDto> findAllApplicationPermisesDetails() {
//        List<ApplicationPermisesDetails> applicationPermisesDetails = applicationPermisesDetailsRepository.findAll();
//        return applicationPermisesDetails.stream()
//                .map(applicationPermisesDetail -> modelMapper.map(applicationPermisesDetail, ApplicationPermisesDetailsDto.class))
//                .collect(Collectors.toList());
//    }
//
//    @Override
//    public List<ApplicationPermisesDetails> findAllActiveApplicationPermisesDetails(Integer status) {
//        return applicationPermisesDetailsRepository.findBySuspendedStatus(status);
//    }

    @Override
    public ApplicationPermisesDetails findAppApplicationPermisesDetailsById(Long id) {
        Optional<ApplicationPermisesDetails> applicationPermisesDetails=applicationPermisesDetailsRepository.findById(id);
        return applicationPermisesDetails.orElse(null);

    }

    @Override
    public List<ApplicationPermisesDetailsDto> findAllApplicationPermisesDetailsByMunicipalId(int municipalId) {
        List<ApplicationPermisesDetails> applicationPermisesDetails = applicationPermisesDetailsRepository.findByMunicipalId(municipalId);
        return applicationPermisesDetails.stream()
                .map(applicationPermisesDetail -> modelMapper.map(applicationPermisesDetail, ApplicationPermisesDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public ApplicationPermisesDetails updateApplicationPermisesDetails(Long id, ApplicationPermisesDetails updatedApplicationPermisesDetails, int updatedBy) {
        Optional<ApplicationPermisesDetails> applicationPermisesDetailsOptional = applicationPermisesDetailsRepository.findById(id);
        if (applicationPermisesDetailsOptional.isPresent()) {
            ApplicationPermisesDetails existingApplicationPermisesDetails = applicationPermisesDetailsOptional.get();
            //existingApplicationPermisesDetails.setSuspendedStatus(updatedApplicationPermisesDetails.getSuspendedStatus());
            existingApplicationPermisesDetails.setPermissesOwnershipId(updatedApplicationPermisesDetails.getPermissesOwnershipId());
            existingApplicationPermisesDetails.setRentAgreementDate(updatedApplicationPermisesDetails.getRentAgreementDate());
            existingApplicationPermisesDetails.setAgreementNo(updatedApplicationPermisesDetails.getAgreementNo());
            existingApplicationPermisesDetails.setAgreementValidFrom(updatedApplicationPermisesDetails.getAgreementValidFrom());
            existingApplicationPermisesDetails.setAgreementValidUpto(updatedApplicationPermisesDetails.getAgreementValidUpto());
            existingApplicationPermisesDetails.setAgreementBetweenFirstPartyName(updatedApplicationPermisesDetails.getAgreementBetweenFirstPartyName());
            existingApplicationPermisesDetails.setAgreementBetweenSecondPartyName(updatedApplicationPermisesDetails.getAgreementBetweenSecondPartyName());
            existingApplicationPermisesDetails.setHoldingPropertyNo(updatedApplicationPermisesDetails.getHoldingPropertyNo());
            existingApplicationPermisesDetails.setLeaseRentedPeriod(updatedApplicationPermisesDetails.getLeaseRentedPeriod());
            //existingApplicationPermisesDetails.setMunicipalId(updatedApplicationPermisesDetails.getMunicipalId());

            return applicationPermisesDetailsRepository.saveAndFlush(existingApplicationPermisesDetails);
        } else {
            throw new RuntimeException("app ApplicationPermisesDetails Details not found with id: " + id);
        }
    }

    @Override
    public ApplicationPermisesDetails changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<ApplicationPermisesDetails> applicationPermisesDetailsOptional = applicationPermisesDetailsRepository.findById(id);
        if (applicationPermisesDetailsOptional.isPresent()) {
            ApplicationPermisesDetails applicationPermisesDetails = applicationPermisesDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            applicationPermisesDetails.setSuspendedStatus(status);      // 1 means suspended
            return applicationPermisesDetailsRepository.saveAndFlush(applicationPermisesDetails);
        }
        return null;
    }

    @Transactional
    @Override
    public void deleteApplicationPermisesDetailsByApplicationMasterId(Long applicationMasterId) {
        try{
            applicationPermisesDetailsRepository.deleteApplicationPermisesDetailsByApplicationMasterId(applicationMasterId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

}