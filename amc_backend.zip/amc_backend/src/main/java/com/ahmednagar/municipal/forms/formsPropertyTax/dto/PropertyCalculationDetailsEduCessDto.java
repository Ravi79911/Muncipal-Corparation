package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PropertyCalculationDetailsEduCessDto {

    private Long id;
    private int propertyMasId;
    private int cessHeadMasId;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;

}
