package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyAdditionalDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyAdditionalDetailsRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyAdditionalDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyAdditionalDetailsServiceImpl implements PropertyAdditionalDetailsService {

    @Autowired
    PropertyAdditionalDetailsRepository propertyAdditionalDetailsRepository;

    @Autowired
    MunicipalPropertyMasterRepository municipalPropertyMasterRepository;

//    @Override
//    public PropertyAdditionalDetails createPropertyAdditionalDetails(PropertyAdditionalDetails propertyAdditionalDetails) {
//        Optional<MunicipalPropertyMaster> municipalPropertyMaster =
//                municipalPropertyMasterRepository.findById(propertyAdditionalDetails.getMunicipalPropertyMaster().getId());
//
//        if (!municipalPropertyMaster.isPresent()) {
//            throw new IllegalArgumentException("municipal property master id doesn't exist");
//        }
//        propertyAdditionalDetails.setCreatedDate(LocalDate.now());
//        return propertyAdditionalDetailsRepository.saveAndFlush(propertyAdditionalDetails);
//    }

    @Override
    public List<PropertyAdditionalDetails> createPropertyAdditionalDetails(List<PropertyAdditionalDetails> propertyAdditionalDetails) {
        LocalDateTime currentDate = LocalDateTime.now();

        for (PropertyAdditionalDetails propertyDetails : propertyAdditionalDetails) {
            Long municipalPropertyMasterId = propertyDetails.getMunicipalPropertyMaster().getId();
            Optional<MunicipalPropertyMaster> municipalPropertyMaster = municipalPropertyMasterRepository.findById(municipalPropertyMasterId);

            if (municipalPropertyMaster.isEmpty()) {
                throw new IllegalArgumentException("municipal property master with id " + municipalPropertyMasterId + " doesn't exist.");
            }
            propertyDetails.setCreatedDate(currentDate);
            switch (propertyAdditionalDetails.indexOf(propertyDetails)) {
                case 0:
                    propertyDetails.setProvisionName("Water Harvesting");
                    break;
                case 1:
                    propertyDetails.setProvisionName("Mobile Tower");
                    break;
                case 2:
                    propertyDetails.setProvisionName("Hoarding");
                    break;
                case 3:
                    propertyDetails.setProvisionName("Petrol Pump");
                    break;
                default:
                    propertyDetails.setProvisionName(null);
                    break;
            }
            if (Boolean.TRUE.equals(propertyDetails.isFlagStatus())) {
                validateRequiredFields(propertyDetails);
            } else {
                propertyDetails.setInstallationAtOn(null);
                propertyDetails.setInstallationDate(null);
                propertyDetails.setAreaOccupiedSqft(null);
            }
        }
        return propertyAdditionalDetailsRepository.saveAll(propertyAdditionalDetails);
    }

    private void validateRequiredFields(PropertyAdditionalDetails propertyAdditionalDetails) {
        if (propertyAdditionalDetails.getAreaOccupiedSqft() == null || propertyAdditionalDetails.getAreaOccupiedSqft().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("buildup area is required and must be non-negative.");
        }
        if (propertyAdditionalDetails.getInstallationAtOn() == null || propertyAdditionalDetails.getInstallationAtOn().isEmpty()) {
            throw new IllegalArgumentException("installation at on is required.");
        }
        if (propertyAdditionalDetails.getInstallationDate() == null) {
            throw new IllegalArgumentException("installation date is required.");
        }
    }

    @Override
    public List<PropertyAdditionalDetails> getAllPropertyAdditionalDetails() {
        return propertyAdditionalDetailsRepository.findAll();
    }

    @Override
    public Optional<PropertyAdditionalDetails> getPropertyAdditionalDetailsById(Long id) {
        return propertyAdditionalDetailsRepository.findById(id);
    }

    @Override
    public List<PropertyAdditionalDetails> getPropertyAdditionalDetailsByMunicipalId(int municipalId) {
        return propertyAdditionalDetailsRepository.findByMunicipalId(municipalId);
    }

    @Override
    public PropertyAdditionalDetails patchPropertyAdditionalDetailsSuspendedStatus(Long id, int suspendedStatus) {
        Optional<PropertyAdditionalDetails> patchPropertyAdditionalDetails = propertyAdditionalDetailsRepository.findById(id);
        if (patchPropertyAdditionalDetails.isPresent()) {
            PropertyAdditionalDetails existingPropertyAdditionalDetails = patchPropertyAdditionalDetails.get();
            existingPropertyAdditionalDetails.setSuspendedStatus(suspendedStatus);
            return propertyAdditionalDetailsRepository.saveAndFlush(existingPropertyAdditionalDetails);
        } else {
            throw new RuntimeException("property additional details not found with id: " + id);
        }
    }

}
