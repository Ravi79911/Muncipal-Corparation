package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PropertyAdditionalDetailsDto {

    private Long id;
    private int propertyMasId;
    private String provisionMasterName;
    private String buildupArea;
    private String occupantType;
    private String occupantFirmName;
    private String occupantOwnerContactPersonName;
    private String contactNumber;
    private String emailId;
    private boolean haveDangerousConditionFlag;
    private String remarks;
    private int municipalId;
    private int createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;

}
