package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.UserMasterOtpHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface UserMasterOtpHistoryRepository extends JpaRepository<UserMasterOtpHistory, Long> {

}
