package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDocumentUploadDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyDocumentUploadDetailsService;
import com.ahmednagar.municipal.master.propertyTax.repository.PropertyUploadDocumentMasterRepository;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@CrossOrigin
@RequestMapping("/forms")
public class PropertyDocumentUploadDetailsController {

    @Autowired
    PropertyDocumentUploadDetailsService propertyDocumentUploadDetailsService;

    @Autowired
    MunicipalPropertyMasterRepository municipalPropertyMasterRepository;

    @Autowired
    PropertyUploadDocumentMasterRepository propertyUploadDocumentMasterRepository;

    @PostMapping("/createPropertyDocumentUploadDetails")
    public ResponseEntity<ApiResponse> createPropertyDocumentUploadDetails(@Valid @RequestParam(value = "documentPath", required = false)
                                                                           MultipartFile documentPath,
                                                                           @RequestParam("propertyMasId") Long propertyMasId,
                                                                           @RequestParam("documentUploadMasId") Long documentUploadMasId,
                                                                           @RequestParam("municipalId") int municipalId,
                                                                           @RequestParam("createdBy") int createdBy) {

        try {
            PropertyDocumentUploadDetails propertyDocumentUploadDetails = new PropertyDocumentUploadDetails();
            propertyDocumentUploadDetails.setMunicipalPropertyMaster(municipalPropertyMasterRepository.findById(propertyMasId)
                    .orElseThrow(() -> new ResourceNotFoundException("Municipal Property Master", "id", propertyMasId)));
            propertyDocumentUploadDetails.setPropertyUploadDocumentMaster(propertyUploadDocumentMasterRepository.findById(documentUploadMasId)
                    .orElseThrow(() -> new ResourceNotFoundException("Property Upload Document Master", "id", documentUploadMasId)));
            propertyDocumentUploadDetails.setMunicipalId(municipalId);
            propertyDocumentUploadDetails.setCreatedBy(createdBy);

            PropertyDocumentUploadDetails createPropertyDocumentUpload = propertyDocumentUploadDetailsService
                    .createPropertyDocumentUploadDetails(propertyDocumentUploadDetails, documentPath);

            return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponse("Document uploaded successfully.", true, createPropertyDocumentUpload));
        } catch (ResourceNotFoundException ex) {
            log.error("Resource not found: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException ex) {
            log.error("Invalid argument: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (RuntimeException ex) {
            log.error("Internal server error: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse("An internal error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception ex) {
            log.error("Unexpected error: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse("Unexpected error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getPropertyDocumentUploadDetailsURLs/{propertyMasId}")
    public ResponseEntity<ApiResponse> getPropertyDocumentsByMunicipalPropertyId(@PathVariable("propertyMasId") Long propertyMasId) {
        try {
            List<String> documentUrls = propertyDocumentUploadDetailsService.getDocumentUrlsByMunicipalPropertyId(propertyMasId);
            return ResponseEntity.ok(new ApiResponse("Document URLs retrieved successfully.", true, documentUrls));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An unexpected error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getPropertyDocumentUploadDetailsURLsWithAllDetails/{propertyMasId}")
    public ResponseEntity<ApiResponse> getAllDocumentDetailsByPropertyMasterId(@PathVariable("propertyMasId") Long propertyMasId) {
        try {
            List<PropertyDocumentUploadDetails> documentDetails = propertyDocumentUploadDetailsService.getAllDocumentDetailsByPropertyMasterId(propertyMasId);
            return ResponseEntity.ok(new ApiResponse("Document details retrieved successfully.", true, documentDetails));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An unexpected error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//    @GetMapping("/propertyDocumentUploadDetails/{id}")
//    public ResponseEntity<Resource> getPropertyDocumentUploadDetails(@PathVariable Long id) {
//        try {
//            Resource file = propertyDocumentUploadDetailsService.loadPropertyDocumentUploadDetails(id);
//            return ResponseEntity.ok()
//                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
//                    .body(file);
//        } catch (IOException e) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
//        }
//    }

    @GetMapping("/getAllPropertyDocumentUploadDetails")
    public ResponseEntity<ApiResponse> getAllPropertyDocumentUploadDetails() {
        try {
            List<PropertyDocumentUploadDetails> documentUploadDetailsList =
                    propertyDocumentUploadDetailsService.getAllPropertyDocumentUploadDetails();
            return ResponseEntity.ok(new ApiResponse("Documents retrieved successfully.", true, documentUploadDetailsList));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An unexpected error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/propertyDocumentUploadDetailsById/{id}")
    public ResponseEntity<Object> getPropertyDocumentUploadDetailsById(@PathVariable Long id) {
        try {
            Optional<PropertyDocumentUploadDetails> documentDetails = propertyDocumentUploadDetailsService.getPropertyDocumentUploadDetailsById(id);
            return ResponseEntity.ok(documentDetails.get());
        } catch (ResourceNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while fetching the document.");
        }
    }

    @GetMapping("/getPropertyDocumentUploadDetailsByMunicipalId/{municipalId}")
    public ResponseEntity<List<PropertyDocumentUploadDetails>> getPropertyDocumentUploadDetailsByMunicipalId(@PathVariable int municipalId) {
        try {
            List<PropertyDocumentUploadDetails> documentDetails = propertyDocumentUploadDetailsService.getPropertyDocumentUploadDetailsByMunicipalId(municipalId);
            return ResponseEntity.ok(documentDetails);
        } catch (ResourceNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<>());
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }
    }

    @PutMapping("/updatePropertyDocumentUploadDetailsById/{id}")
    public ResponseEntity<ApiResponse> updatePropertyDocumentUploadDetails(@PathVariable Long id,
                                                                           @RequestParam("documentPath") MultipartFile documentPath,
                                                                           @RequestParam("updatedBy") int updatedBy) {
        try {
            PropertyDocumentUploadDetails updatedDetails = propertyDocumentUploadDetailsService.updatePropertyDocumentUploadDetailsById(id, documentPath, updatedBy);
            return ResponseEntity.ok(new ApiResponse("Document updated successfully.", true, updatedDetails));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An internal error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PatchMapping("/propertyDocumentUploadDetails/suspendedStatus/{id}")
    public ResponseEntity<Object> patchMunicipalPropertyOwnerMasterSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        try {
            if (suspendedStatus < 0 || suspendedStatus > 1) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid suspended status. It should be either 0 or 1.");
            }
            PropertyDocumentUploadDetails updatedDocumentDetails = propertyDocumentUploadDetailsService.patchPropertyDocumentUploadDetailsSuspendedStatus(id, suspendedStatus);
            return ResponseEntity.ok(updatedDocumentDetails);
        } catch (ResourceNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while updating the suspended status.");
        }
    }

}
