package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDocumentUploadDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyDocumentUploadDetailsService;
import com.ahmednagar.municipal.master.propertyTax.repository.PropertyUploadDocumentMasterRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/forms")
public class PropertyDocumentUploadDetailsController {

    @Autowired
    PropertyDocumentUploadDetailsService propertyDocumentUploadDetailsService;

    @Autowired
    MunicipalPropertyMasterRepository municipalPropertyMasterRepository;

    @Autowired
    PropertyUploadDocumentMasterRepository propertyUploadDocumentMasterRepository;

    @PostMapping("/createPropertyDocumentUploadDetails")
    public ResponseEntity<PropertyDocumentUploadDetails> createPropertyDocumentUploadDetails(@Valid @RequestParam(value = "documentPath", required = false)
                                                                                             MultipartFile documentPath,
                                                                                             @RequestParam("propertyMasId") Long propertyMasId,
                                                                                             @RequestParam("documentUploadMasId") Long documentUploadMasId,
                                                                                             @RequestParam("municipalId") int municipalId,
                                                                                             @RequestParam("createdBy") int createdBy,
                                                                                             @RequestParam("suspendedStatus") int suspendedStatus) {

        PropertyDocumentUploadDetails propertyDocumentUploadDetails = new PropertyDocumentUploadDetails();
        propertyDocumentUploadDetails.setMunicipalPropertyMaster(municipalPropertyMasterRepository.findById(propertyMasId).get());
        propertyDocumentUploadDetails.setPropertyUploadDocumentMaster(propertyUploadDocumentMasterRepository.findById(documentUploadMasId).get());
        propertyDocumentUploadDetails.setMunicipalId(municipalId);
        propertyDocumentUploadDetails.setCreatedBy(createdBy);
        propertyDocumentUploadDetails.setSuspendedStatus(suspendedStatus);

        PropertyDocumentUploadDetails createPropertyDocumentUpload = propertyDocumentUploadDetailsService
                .createPropertyDocumentUploadDetails(propertyDocumentUploadDetails, documentPath);
        return ResponseEntity.status(HttpStatus.CREATED).body(createPropertyDocumentUpload);
    }

    @GetMapping("/propertyDocumentUploadDetails/{id}")
    public ResponseEntity<Resource> getPropertyDocumentUploadDetails(@PathVariable Long id) {
        try {
            Resource file = propertyDocumentUploadDetailsService.loadPropertyDocumentUploadDetails(id);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
                    .body(file);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @GetMapping("/getAllPropertyDocumentUploadDetails")
    public ResponseEntity<List<PropertyDocumentUploadDetails>> getAllPropertyDocumentUploadDetails() {
        return ResponseEntity.ok(propertyDocumentUploadDetailsService.getAllPropertyDocumentUploadDetails());
    }

    @GetMapping("/propertyDocumentUploadDetailsById/{id}")
    public ResponseEntity<Object> getPropertyDocumentUploadDetailsById(@PathVariable Long id) {
        Optional<PropertyDocumentUploadDetails> propertyDocumentUploadDetails = propertyDocumentUploadDetailsService.getPropertyDocumentUploadDetailsById(id);
        if (propertyDocumentUploadDetails.isPresent()) {
            return ResponseEntity.ok(propertyDocumentUploadDetails.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getPropertyDocumentUploadDetailsByMunicipalId/{municipalId}")
    public List<PropertyDocumentUploadDetails> getPropertyDocumentUploadDetailsByMunicipalId(@PathVariable int municipalId) {
        return propertyDocumentUploadDetailsService.getPropertyDocumentUploadDetailsByMunicipalId(municipalId);
    }

    @PatchMapping("/propertyDocumentUploadDetails/suspendedStatus/{id}")
    public ResponseEntity<PropertyDocumentUploadDetails> patchMunicipalPropertyOwnerMasterSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        PropertyDocumentUploadDetails patchedPropertyDocumentUploadDetails = propertyDocumentUploadDetailsService.patchPropertyDocumentUploadDetailsSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedPropertyDocumentUploadDetails);
    }
}
