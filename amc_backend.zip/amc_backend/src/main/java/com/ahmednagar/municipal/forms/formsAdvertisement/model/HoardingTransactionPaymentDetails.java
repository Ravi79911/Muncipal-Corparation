package com.ahmednagar.municipal.forms.formsAdvertisement.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb2_hoarding_transaction_payment_details")
public class HoardingTransactionPaymentDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name = "payment_collection_master_id", nullable = false)
    @NotNull(message = "Payment collection master ID cannot be null")
    private Long paymentCollectionMasterId;

    @Column(name = "payment_mode", nullable = false)
    @NotBlank(message = "Payment mode cannot be blank")
    @Size(max = 150, message = "Payment mode cannot exceed 150 characters")
    private String paymentMode;

    @Column(name = "bank_name", nullable = false)
    @NotBlank(message = "Bank name cannot be blank")
    @Size(max = 150, message = "Bank name cannot exceed 150 characters")
    private String bankName;

    @Column(name = "dd_chaque_trans_no", nullable = false)
    @NotBlank(message = "DD/Chaque transaction number cannot be blank")
    @Size(max = 150, message = "DD/Chaque transaction number cannot exceed 150 characters")
    private String ddChaqueTransNo;

    @Column(name = "dd_chaque_trans_date", nullable = false)
    private LocalDateTime ddChaqueTransDate;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;
}
