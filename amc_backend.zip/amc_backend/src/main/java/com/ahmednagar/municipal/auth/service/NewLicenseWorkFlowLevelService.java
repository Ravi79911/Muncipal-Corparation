package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.NewLicenseWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.NewLicenseWorkFlowLevel;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface NewLicenseWorkFlowLevelService {

    NewLicenseWorkFlowLevel handleWorkFlowsTransition(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel);

    List<NewLicenseWorkFlowLevelDto> getAllNewWaterWorkFlowLevel();

    NewLicenseWorkFlowLevel createNewApplicationTransation(NewLicenseWorkFlowLevel newLicenseWorkFlowLevelRequest);

}
