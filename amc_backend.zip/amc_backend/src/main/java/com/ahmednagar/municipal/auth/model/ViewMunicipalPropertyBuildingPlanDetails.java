package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_view_muni_property_building_plan_details")
public class ViewMunicipalPropertyBuildingPlanDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "further building plan approved flag can't be null")
    @Column(name = "further_building_plan_approved_flag")
    private boolean furtherBuildingPlanApprovedFlag;

    @Size(max = 50, message = "building plan approval number can't be longer than 150 characters")
    @Column(name = "building_plan_approval_no")
    private String buildingPlanApprovalNo;

    @Column(name = "building_plan_approval_date")
    private LocalDate buildingPlanApprovalDate;

    @NotNull(message = "building plan completion flag can't be null")
    @Column(name = "building_plan_completion_flag")
    private boolean buildingPlanCompletionFlag;

    @Size(max = 50, message = "building plan completion number can't be longer than 150 characters")
    @Column(name = "building_plan_completion_no")
    private String buildingPlanCompletionNo;

    @Column(name = "building_plan_completion_date")
    private LocalDate buildingPlanCompletionDate;

    @NotBlank(message = "property status can't be blank")
    @Size(max = 50, message = "property status can't be longer than 150 characters")
    @Column(name = "property_status")
    private String propertyStatus;

    @NotNull(message = "property status date can't be null")
    @Column(name = "property_status_date")
    private LocalDate propertyStatusDate;

    @NotNull(message = "created by can't be null")
    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "municipal id can't be null")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewMunicipalPropertyMaster viewMunicipalPropertyMaster;

}
