package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_view_app_applicant_details")
public class ViewAppApplicantDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "firm_owner_name")
    @NotNull(message = "Firm owner name is required")
    @Size(max = 150, message = "Firm owner name cannot exceed 150 characters")
    private String firmOwnerName;

    @Column(name = "relation_name")
    @NotNull(message = "Firm owner relation name is required")
    @Size(max = 150, message = "relation name cannot exceed 150 characters")
    private String relationName;

    @Column(name = "firm_owner_father_husband_name")
    @NotNull(message = "Firm owner's father husband name is required")
    @Size(max = 150, message = "Firm owner's father husband name cannot exceed 150 characters")
    private String firmOwnerFatherHusbandName;

    @Column(name = "firm_owner_mob_no")
    @NotNull(message = "Firm owner mobile number is required")
    @Size(max = 20, message = "Firm owner mobile number cannot exceed 20 characters")
    private String firmOwnerMobNo;

    @Column(name = "firm_owner_email_id")
    @NotNull(message = "Firm owner email ID is required")
    @Email(message = "Firm owner email ID should be valid")
    @Size(max = 150, message = "Firm owner email ID cannot exceed 150 characters")
    private String firmOwnerEmailId;

//    @NotNull(message = "PAN number is required")
//    @Size(min = 10, max = 10, message = "PAN number must be exactly 10 characters")
//    @Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "invalid PAN number format")
//    @Column(name = "pan_number")
//    private String panNumber;

    @Column(name = "firm_owner_designation")
    @NotNull(message = "Firm owner designation is required")
    @Size(max = 150, message = "Firm owner designation cannot exceed 150 characters")
    private String firmOwnerDesignation;

    @Column(name = "gender")
    @NotNull(message = "Gender is required")
    @Size(max = 50, message = "Gender cannot exceed 50 characters")
    private String gender;

    @Column(name = "owner_address")
    @NotNull(message = "Owner address is required")
    @Size(max = 150, message = "Owner address cannot exceed 50 characters")
    private String ownerAddress;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @Column(name = "applicant_photo")
    private String applicantPhoto;

    @ManyToOne
    @JoinColumn(name = "application_master_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewApplicationFromMaster viewApplicationFromMaster;

}
