package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "tbl_citizen_login_logoff_history")
public class CitizenLoginLogOffHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "Citizen ID is required")
    @Size(max = 150, message = "Citizen ID must not exceed 150 characters")
    @Column(name = "citizen_id", nullable = false, length = 150)
    private String citizenId;

    @Column(name = "login_logoff_datetime")
    private LocalDateTime loginLogoffDatetime;

    @Size(max = 150, message = "IP Address must not exceed 150 characters")
    @Column(name = "ip_address", length = 150)
    private String ipAddress;

    @Size(max = 50, message = "Longitude must not exceed 50 characters")
    @Column(name = "longitude", length = 50)
    private String longitude;

    @Size(max = 50, message = "Latitude must not exceed 50 characters")
    @Column(name = "latitude", length = 50)
    private String latitude;

    @Size(max = 15, message = "Login/Logoff Status must not exceed 15 characters")
    @Column(name = "login_logoff_status", length = 15)
    private String loginLogoffStatus;

    @Size(max = 500, message = "Location Address must not exceed 500 characters")
    @Column(name = "location_address", length = 500)
    private String locationAddress;

    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @Column(name = "municipal_id")
    private Long municipalId;

}
