package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseApplicationAutoTransfer;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.LicenseApplicationAutoTransferRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.LicenseApplicationAutoTransferService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class LicenseApplicationAutoTransferServiceImpl implements LicenseApplicationAutoTransferService {
    @Autowired
    private LicenseApplicationAutoTransferRepository licenseApplicationAutoTransferRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public LicenseApplicationAutoTransfer saveLicenseApplicationAutoTransfer(LicenseApplicationAutoTransfer licenseApplicationAutoTransfer) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        licenseApplicationAutoTransfer.setCreatedDate(currentDateTime);
        licenseApplicationAutoTransfer.setSuspendedStatus(licenseApplicationAutoTransfer.getSuspendedStatus() != null ? licenseApplicationAutoTransfer.getSuspendedStatus() : 0);      // 0 means active// 1 means admin
        return licenseApplicationAutoTransferRepository.saveAndFlush(licenseApplicationAutoTransfer);
    }
}
