package com.ahmednagar.municipal.forms.formsAdvertisement.controller;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingTransactionPaymentDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingTransactionPaymentDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingTransactionPaymentDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/advertisement/hoarding/transaction/payment/details/form")
@Validated
@CrossOrigin
public class HoardingTransactionPaymentDetailsController {
    @Autowired
    private HoardingTransactionPaymentDetailsService hoardingTransactionPaymentDetailsService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingTransactionPaymentDetails> createHoardingTransactionPaymentDetails(@Valid @RequestBody HoardingTransactionPaymentDetails hoardingTransactionPaymentDetails){
        HoardingTransactionPaymentDetails savedHoardingTransactionPaymentDetails=hoardingTransactionPaymentDetailsService.saveHoardingTransactionPaymentDetails(hoardingTransactionPaymentDetails);
        return ResponseEntity.status(201).body(savedHoardingTransactionPaymentDetails);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingTransactionPaymentDetailsDto>> getAllHoardingTransactionPaymentDetails(){
        List<HoardingTransactionPaymentDetailsDto> hoardingTransactionPaymentDetails=hoardingTransactionPaymentDetailsService.findAllHoardingTransactionPaymentDetails();
        return ResponseEntity.ok(hoardingTransactionPaymentDetails);

    }

    //for single user by Id
    @GetMapping("/getMlBusinessNatureById/{id}")
    public ResponseEntity<HoardingTransactionPaymentDetails> getHoardingTransactionPaymentDetailsById(@PathVariable Long id){
        HoardingTransactionPaymentDetails hoardingTransactionPaymentDetails=hoardingTransactionPaymentDetailsService.findById(id);
        return ResponseEntity.ok(hoardingTransactionPaymentDetails);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingTransactionPaymentDetailsByMunicipalId(@PathVariable int municipalId){
        List<HoardingTransactionPaymentDetails> hoardingTransactionPaymentDetails = hoardingTransactionPaymentDetailsService.findAllByMunicipalId(municipalId);
        if (hoardingTransactionPaymentDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingTransactionPaymentDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingTransactionPaymentDetails);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingTransactionPaymentDetails> updateHoardingTransactionPaymentDetails(@PathVariable("id") Long id, @RequestBody HoardingTransactionPaymentDetails updatedHoardingTransactionPaymentDetails){
        try{
            HoardingTransactionPaymentDetails updated=hoardingTransactionPaymentDetailsService.updateHoardingTransactionPaymentDetails(id,updatedHoardingTransactionPaymentDetails,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingTransactionPaymentDetailsService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }
}

