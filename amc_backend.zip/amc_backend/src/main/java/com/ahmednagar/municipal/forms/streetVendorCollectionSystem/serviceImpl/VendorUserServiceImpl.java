package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUser;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorUserRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class VendorUserServiceImpl implements VendorUserService {

    @Autowired
    private VendorUserRepository vendorUserRepository;

    @Override
    public VendorUser saveUserMaster(VendorUser vendorUser) {
        vendorUser.setCreatedDate(LocalDateTime.now());
        vendorUser.setSuspendedStatus(0);
        return vendorUserRepository.save(vendorUser);
    }

    @Override
    public List<VendorUser> findAllUsers() {
        return vendorUserRepository.findAll();
    }
}
