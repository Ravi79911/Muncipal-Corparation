package com.ahmednagar.municipal.auth.dto;

import com.ahmednagar.municipal.auth.model.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class WaterWorkFlowLevelDto {

    private Long id;
    private String status;
    private Integer mailStatus;
    private String remarks;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;
    private ViewNewWaterConnectionFormMaster waterApplicationId;
    private UserMasterDTO currentUserId;
    private UserMasterDTO nextUserId;
    private WorkFlowMaster workFlowMasterId;
    private CitizenSignUpMaster citizenId;
}
