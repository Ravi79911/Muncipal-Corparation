package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.UserMasterPasswordChangeHistory;
import com.ahmednagar.municipal.auth.repository.UserMasterPasswordChangeHistoryRepository;
import com.ahmednagar.municipal.auth.service.UserMasterPasswordChangeHistoryService;
import com.ahmednagar.municipal.auth.utils.IpAddressService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class UserMasterPasswordChangeHistoryServiceImpl implements UserMasterPasswordChangeHistoryService {

    @Autowired
    UserMasterPasswordChangeHistoryRepository userMasterPasswordChangeHistoryRepository;

    @Autowired
    IpAddressService ipAddressService;

    @Override
    public List<UserMasterPasswordChangeHistory> getAllUserMasterPasswordChangeHistory() {
        return userMasterPasswordChangeHistoryRepository.findAll();
    }

    @Override
    public List<UserMasterPasswordChangeHistory> getHistoryByUserMasterId(Long userMasterId) {
        return userMasterPasswordChangeHistoryRepository.findPasswordChangeHistoryWithUserMaster(userMasterId);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public UserMasterPasswordChangeHistory createPasswordChangeHistory(UserMasterPasswordChangeHistory userMasterPasswordChangeHistory, HttpServletRequest request) {

        // Set the created date and time
        userMasterPasswordChangeHistory.setCreatedDate(LocalDateTime.now());
        userMasterPasswordChangeHistory.setPwdChangedDateTime(LocalDateTime.now());
        // Automatically set the IP address
        String ipAddress = ipAddressService.getClientIp(request);
        userMasterPasswordChangeHistory.setIpAddress(ipAddress);

        // Save to repository
        userMasterPasswordChangeHistoryRepository.save(userMasterPasswordChangeHistory);

        return userMasterPasswordChangeHistory;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
