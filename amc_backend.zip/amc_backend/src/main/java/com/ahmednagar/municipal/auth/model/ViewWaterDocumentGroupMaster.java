package com.ahmednagar.municipal.auth.model;

import com.ahmednagar.municipal.master.waterManagement.modal.DocumentTypeMaster;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_view_water_document_group_master")
public class ViewWaterDocumentGroupMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "Document group must not be null")
    @Size(max = 50, message = "Document group must be at most 50 characters long")
    @Column(name = "document_group")
    private String documentGroup;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID must not be null")
    @Column(name = "municipal_id")
    private int municipalId;

//    @OneToMany(mappedBy = "documentGroupID", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<DocumentTypeMaster> documentTypeMasters;

//    @OneToMany(mappedBy = "viewWaterDocumentGroupMaster", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
////    @JsonManagedReference
//    private List<ViewWaterDocumentTypeMasters> viewWaterDocumentTypeMasters=null;

}
