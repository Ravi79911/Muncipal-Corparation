package com.ahmednagar.municipal.auth.model;

import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationDetails;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb2_view_hoarding_application_master")
public class ViewHoardingApplicationMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name = "no_of_hoardings", nullable = false)
    @NotNull(message = "Number of hoardings cannot be null")
    @Min(value = 1, message = "Number of hoardings must be at least 1")
    private Long noOfHoardings;

    @Column(name = "application_no", nullable = false)
    private String applicationNo;

    @Column(name = "uses_type_id", nullable = false)
    @NotNull(message = "Uses type ID cannot be null")
    private Long usesTypeId;

    @Column(name = "application_date", nullable = false)
    @NotNull(message = "Application date cannot be null")
    private LocalDateTime applicationDate;

    @Column(name = "name_of_advertiser", nullable = false)
    @NotBlank(message = "Name of advertiser cannot be blank")
    @Size(max = 50, message = "Name of advertiser cannot exceed 50 characters")
    private String nameOfAdvertiser;

    @Column(name = "advertiser_mobile_no", nullable = false)
    @NotNull(message = "Advertiser mobile number cannot be null")
    //@Pattern(regexp = "^\\d{10}$", message = "Advertiser mobile number must be a 10-digit number")
    private Long advertiserMobileNo;

    @Column(name = "email_id", nullable = false)
    @NotBlank(message = "Email ID cannot be blank")
    @Email(message = "Invalid email format")
    @Size(max = 50, message = "Email ID cannot exceed 50 characters")
    private String emailId;

    @Column(name = "whatsapp_no", nullable = false)
    @NotNull(message = "WhatsApp number cannot be null")
    //@Pattern(regexp = "^\\d{10}$", message = "WhatsApp number must be a 10-digit number")
    private Long whatsappNo;

    @Column(name = "advertiser_address", nullable = false)
    @NotBlank(message = "Advertiser address cannot be blank")
    @Size(max = 150, message = "Advertiser address cannot exceed 150 characters")
    private String advertiserAddress;

    @Column(name = "purpose_of_hoarding", nullable = false)
    @NotBlank(message = "Purpose of hoarding cannot be blank")
    @Size(max = 150, message = "Purpose of hoarding cannot exceed 150 characters")
    private String purposeOfHoarding;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "hoarding_category_type_master_id", nullable = false, referencedColumnName = "id")
    private ViewHoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterId;

    @ToString.Exclude
    @OneToMany(mappedBy = "hoardingApplicationMasterId", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JsonManagedReference
    private List<ViewHoardingApplicationDetails> viewHoardingApplicationDetails=null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewHoardingApplicationMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewHoardingDocumentsDetails> viewHoardingDocumentsDetails = null;

//    @OneToMany(mappedBy = "hoardingApplicationMasterId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<HoardingPaymentCollectionMaster> hoardingPaymentCollectionMasters;
}
