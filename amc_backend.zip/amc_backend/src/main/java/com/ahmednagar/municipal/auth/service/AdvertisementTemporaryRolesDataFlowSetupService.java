package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.AdvertisementTemporaryRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.AdvertisementTemporaryRolesDataFlowSetup;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface AdvertisementTemporaryRolesDataFlowSetupService {

    List<AdvertisementTemporaryRolesDataFlowSetupDto> findAllRolesDataFlowSetup();

    AdvertisementTemporaryRolesDataFlowSetup getNextRoleForSingleSelection(Long currentRoleId, Long statusCode, Integer isActive);

    List<AdvertisementTemporaryRolesDataFlowSetup> getNextRoleListForListSelection(Long currentRoleId, Long statusCode, Integer isActive);

}
