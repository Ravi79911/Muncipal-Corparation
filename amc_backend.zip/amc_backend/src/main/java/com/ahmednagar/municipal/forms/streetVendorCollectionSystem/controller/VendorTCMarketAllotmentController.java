package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorTCMarketAllotment;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorTCMarketAllotmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorTCMarketAllotmentController {

    @Autowired
    private VendorTCMarketAllotmentService vendorTCMarketAllotmentService;

    @PostMapping("/saveVendorTCMarketAllotmentMaster")
   public ResponseEntity<VendorTCMarketAllotment> saveVendorTCMarketAllotmentMaster(@RequestBody VendorTCMarketAllotment vendorTCMarketAllotment) {
        return ResponseEntity.ok(vendorTCMarketAllotmentService.saveVendorTCMarketAllotment(vendorTCMarketAllotment));
    }

    @GetMapping("/getAllVendorTCMarketAllotmentMaster")
    public ResponseEntity<Iterable<VendorTCMarketAllotment>> getAllVendorTCMarketAllotmentMaster() {
        return ResponseEntity.ok(vendorTCMarketAllotmentService.getAllVendorTCMarketAllotment());
    }

    @GetMapping("/getVendorTCMarketAllotmentMasterById/{id}")
    public ResponseEntity<Optional<VendorTCMarketAllotment>> getVendorTCMarketAllotmentMasterById(@PathVariable Long id) {
        return ResponseEntity.ok(vendorTCMarketAllotmentService.getVendorTCMarketAllotmentById(id));
    }

    @PatchMapping("/updateVendorTCMarketAllotmentMaster/{id}")
    public ResponseEntity<Optional<VendorTCMarketAllotment>> updateVendorTCMarketAllotmentMaster(@PathVariable Long id, @RequestBody VendorTCMarketAllotment vendorTCMarketAllotment) {
        return ResponseEntity.ok(vendorTCMarketAllotmentService.updateVendorTCMarketAllotment(id, vendorTCMarketAllotment));
    }

    @PatchMapping("/deleteVendorTCMarketAllotmentMaster/{id}")
    public ResponseEntity<Optional<VendorTCMarketAllotment>> deleteVendorTCMarketAllotmentMaster(@PathVariable Long id) {
        return ResponseEntity.ok(vendorTCMarketAllotmentService.deleteVendorTCMarketAllotment(id));
    }
}
