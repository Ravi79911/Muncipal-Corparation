package com.ahmednagar.municipal.forms.formsWaterManagement.serviceImpl;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.UserBasicDetails;
import com.ahmednagar.municipal.forms.formsWaterManagement.repository.UserBasicDetailsRepository;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.UserBasicDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserBasicDetailsServiceImpl implements UserBasicDetailsService {

    @Autowired
    private UserBasicDetailsRepository userBasicDetailsRepository;

    @Override
    public UserBasicDetails createUserBasicDetails(UserBasicDetails userBasicDetails, int createdBy) {
        LocalDateTime currentDateTime = LocalDateTime.now();            // current date and time
        userBasicDetails.setCreatedDate(currentDateTime);
//        userBasicDetails.setUpdatedDate(currentDateTime);
        userBasicDetails.setSuspendedStatus(userBasicDetails.getSuspendedStatus() != null ? userBasicDetails.getSuspendedStatus() : 0);      // 0 means active
//        userBasicDetails.setUpdatedBy(createdBy);                       // 1 means admin
        userBasicDetails.setCreatedBy(createdBy);                       // 1 means admin
        return userBasicDetailsRepository.saveAndFlush(userBasicDetails);
    }

//    @Override
//    public UserBasicDetails updateUserBasicDetails(int id, UserBasicDetails userBasicDetails, int updatedBy) {
//        Optional<UserBasicDetails> userBasicDetailsById = userBasicDetailsRepository.findById(id);
//        if (userBasicDetailsById.isPresent()) {
//            UserBasicDetails userBasicDetailsEntity = userBasicDetailsById.get();
//            userBasicDetailsEntity.setAddress(userBasicDetails.getAddress());
//            userBasicDetailsEntity.setCity(userBasicDetails.getCity());
//            userBasicDetailsEntity.setState(userBasicDetails.getState());
//            userBasicDetailsEntity.setPincode(userBasicDetails.getPincode());
////            userBasicDetailsEntity.setUpdatedDate(userBasicDetails.getUpdatedDate());
////            userBasicDetailsEntity.setUpdatedBy(updatedBy);
//            return userBasicDetailsRepository.saveAndFlush(userBasicDetailsEntity);
//        }
//        return null;
//    }

    @Override
    public UserBasicDetails deleteUserBasicDetailsById(int id, int suspendedStatus, int updatedBy) {
        Optional<UserBasicDetails> userBasicDetailsById = userBasicDetailsRepository.findById(id);
        if (userBasicDetailsById.isPresent()) {
            UserBasicDetails userBasicDetailsEntity = userBasicDetailsById.get();
            userBasicDetailsEntity.setSuspendedStatus(suspendedStatus);          // 1 means suspended
//            userBasicDetailsEntity.setUpdatedBy(updatedBy);
//            userBasicDetailsEntity.setUpdatedDate(LocalDateTime.now());
            return userBasicDetailsRepository.saveAndFlush(userBasicDetailsEntity);
        }
        return null;
    }

//    @Override
//    public UserBasicDetails getUserBasicDetailsById(int id) {
//        return userBasicDetailsRepository.findById(id).orElse(null);
//    }

    @Override
    public List<UserBasicDetails> getUserBasicDetailsByMunicipalId(int municipalId) {
        return userBasicDetailsRepository.findByMunicipalId(municipalId);
    }
}
