package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandTransactionMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface PropertyDemandTransactionMasterRepository extends JpaRepository<PropertyDemandTransactionMaster, Long> {

    List<PropertyDemandTransactionMaster> findByMunicipalId(int municipalId);

}
