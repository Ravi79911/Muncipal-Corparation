package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationElectricityDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationElectricityDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFirmDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationElectricityDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationElectricityDetailsService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ApplicationElectricityDetailsServiceImpl implements ApplicationElectricityDetailsService {
    @Autowired
    private ApplicationElectricityDetailsRepository applicationElectricityDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ApplicationElectricityDetails saveApplicationElectricityDetails(ApplicationElectricityDetails applicationElectricityDetails, int createdBy) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        applicationElectricityDetails.setCreatedDate(currentDateTime);
        //applicationElectricityDetails.setUpdatedDate(currentDateTime);
        applicationElectricityDetails.setSuspendedStatus(applicationElectricityDetails.getSuspendedStatus() != null ? applicationElectricityDetails.getSuspendedStatus() : 0);      // 0 means active
        //applicationElectricityDetails.setUpdatedBy(createdBy);            // 1 means admin
        applicationElectricityDetails.setCreatedBy(createdBy);            // 1 means admin
        return applicationElectricityDetailsRepository.saveAndFlush(applicationElectricityDetails);
    }

//    @Override
//    public List<ApplicationElectricityDetailsDto> findAllApplicationElectricityDetails() {
//        List<ApplicationElectricityDetails> applicationElectricityDetails = applicationElectricityDetailsRepository.findAll();
//        return applicationElectricityDetails.stream()
//                .map(applicationElectricityDetail -> modelMapper.map(applicationElectricityDetail, ApplicationElectricityDetailsDto.class))
//                .collect(Collectors.toList());
//    }
//
//    @Override
//    public List<ApplicationElectricityDetails> findAllActiveApplicationElectricityDetails(Integer status) {
//        return applicationElectricityDetailsRepository.findBySuspendedStatus(status);
//    }

    @Override
    public ApplicationElectricityDetails findApplicationElectricityDetailsById(Long id) {
        Optional<ApplicationElectricityDetails> applicationElectricityDetails=applicationElectricityDetailsRepository.findById(id);
        return applicationElectricityDetails.orElse(null);

    }

    @Override
    public List<ApplicationElectricityDetailsDto> findAllApplicationElectricDetailsByMunicipalId(int municipalId) {
        List<ApplicationElectricityDetails> applicationElectricityDetails= applicationElectricityDetailsRepository.findByMunicipalId(municipalId);
        return applicationElectricityDetails.stream()
                .map(applicationElectricityDetail -> modelMapper.map(applicationElectricityDetail, ApplicationElectricityDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public ApplicationElectricityDetails updateapplicationElectricityDetailsService(Long id, ApplicationElectricityDetails updatedApplicationElectricityDetails, int updatedBy) {
        Optional<ApplicationElectricityDetails> applicationElectricityDetailsOptional = applicationElectricityDetailsRepository.findById(id);
        if (applicationElectricityDetailsOptional.isPresent()) {
            ApplicationElectricityDetails existingApplicationElectricityDetails= applicationElectricityDetailsOptional.get();
            //existingApplicationElectricityDetails.setUpdatedBy(updatedBy);
            existingApplicationElectricityDetails.setConsumerNo(updatedApplicationElectricityDetails.getConsumerNo());
            existingApplicationElectricityDetails.setConnectionType(updatedApplicationElectricityDetails.getConnectionType());
            existingApplicationElectricityDetails.setElectricityKNumber(updatedApplicationElectricityDetails.getElectricityKNumber());
            //existingApplicationElectricityDetails.setSuspendedStatus(updatedApplicationElectricityDetails.getSuspendedStatus());
            existingApplicationElectricityDetails.setConsumerName(updatedApplicationElectricityDetails.getConsumerName());

            return applicationElectricityDetailsRepository.saveAndFlush(existingApplicationElectricityDetails);
        } else {
            throw new RuntimeException("app ApplicationElectricityDetails not found with id: " + id);
        }
    }

    @Override
    public ApplicationElectricityDetails changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<ApplicationElectricityDetails> applicationElectricityDetailsOptional = applicationElectricityDetailsRepository.findById(id);
        if (applicationElectricityDetailsOptional.isPresent()) {
            ApplicationElectricityDetails applicationElectricityDetails = applicationElectricityDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            //applicationElectricityDetails.setUpdatedDate(currentDateTime);
            applicationElectricityDetails.setSuspendedStatus(status);      // 1 means suspended
            //applicationElectricityDetails.setUpdatedBy(updatedBy);
            return applicationElectricityDetailsRepository.saveAndFlush(applicationElectricityDetails);
        }
        return null;
    }

    @Transactional
    @Override
    public void deleteApplicationElectricityDetailsByApplicationMasterId(Long applicationMasterId) {
        try{
            applicationElectricityDetailsRepository.deleteApplicationElectricityDetailsByApplicationMasterId(applicationMasterId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }
}
