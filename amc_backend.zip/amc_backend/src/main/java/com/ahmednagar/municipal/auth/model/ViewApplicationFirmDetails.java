package com.ahmednagar.municipal.auth.model;

import com.ahmednagar.municipal.master.municipalLicence.model.ViewLicenceWardMaster;
import com.ahmednagar.municipal.master.municipalLicence.model.ViewLicenceZoneMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_view_application_firm_details")
public class ViewApplicationFirmDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private int id;

    @NotNull(message = "Aadhaar number cannot be null.")
    @Positive(message = "Aadhaar number must be a positive number.")
    @Digits(integer = 12, fraction = 0, message = "Aadhaar number must be exactly 12 digits.")
    @Column(name = "adhar_number", length = 12, nullable = false)
    private Long adharNumber;

//    @NotBlank
//    @Size(max = 50)
//    @Column(name = "ward_no", length = 50, nullable = false)
//    private String wardNo;
//
//    @NotBlank
//    @Size(max = 150)
//    @Column(name = "zone_no", length = 150, nullable = false)
//    private String zoneNo;

    @NotBlank
    @Size(max = 150)
    @Column(name = "firm_name", length = 150, nullable = false)
    private String firmName;

    @NotNull
    @Column(name = "firm_estd_date", nullable = false)
    private Date firmEstdDate;

    @NotNull
    @Column(name = "total_buildup_area_of_business", nullable = false)
    private int totalBuildupAreaOfBusiness;

    @Column(name = "cin_number", nullable = false)
    private int cinNumber;

    @NotNull
    @Column(name = "business_contact_number", nullable = false)
    private Long businessContactNumber;

    @NotNull(message = "PAN number is required")
    @Size(min = 10, max = 10, message = "PAN number must be exactly 10 characters")
    @Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "Invalid PAN number format")
    @Column(name = "pan_number")
    private String panNumber;

    @NotNull(message = "TAN number is required")
    @Size(min = 10, max = 10, message = "TAN number must be exactly 10 characters")
    @Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "invalid TAN number format")
    @Column(name = "tan_number")
    private String tanNumber;

    @NotNull(message = "GST number is required")
    @Size(min = 15, max = 15, message = "GST number must be exactly 15 characters")
    @Pattern(regexp = "[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{3}", message = "Invalid GST number format")
    @Column(name = "gst_number")
    private String gstNumber;

    @NotBlank
    @Size(max = 150)
    @Column(name = "business_address_line1", length = 150, nullable = false)
    private String businessAddressLine1;

    @NotBlank
    @Size(max = 150)
    @Column(name = "business_address_line2", length = 150, nullable = false)
    private String businessAddressLine2;

    @NotBlank
    @Size(max = 150)
    @Column(name = "business_city", length = 150, nullable = false)
    private String businessCity;

    @NotBlank
    @Size(max = 150)
    @Column(name = "business_state", length = 150, nullable = false)
    private String businessState;

    @NotBlank
    @Size(max = 50)
    @Column(name = "business_pincode", length = 50, nullable = false)
    private String businessPincode;

    @NotBlank
    @Size(max = 100)
    @Column(name = "landmark", length = 100, nullable = false)
    private String landmark;

    @NotBlank
    @Size(max = 255)
    @Column(name = "business_description", length = 255, nullable = false)
    private String businessDescription;

    @NotNull
    @Column(name = "no_of_workers", nullable = false)
    private int noOfWorkers;

    @NotNull(message = "dangerous type flag is required")
    @Column(name = "dangerous_type_flag")
    private boolean dangerousTypeFlag;

    @Column(name = "trade_type", length = 150)
    private String tradeType;

    @NotNull
    @Column(name = "created_by", nullable = false)
    private int createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @NotNull
    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "application_master_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewApplicationFromMaster viewApplicationFromMaster;

    @ManyToOne
    @JoinColumn(name = "ward_id", referencedColumnName = "id", nullable = false)
//    @JsonBackReference
    private AuthWardMaster wardId;

    @ManyToOne
    @JoinColumn(name = "zone_id", referencedColumnName = "id", nullable = false)
//    @JsonBackReference
    private AuthZoneMaster zoneId;

}
