package com.ahmednagar.municipal.auth.dto;

import com.ahmednagar.municipal.auth.model.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class NewAdvertisementWorkFlowLevelDto {

    private Long id;
    private Long zoneId;
    private Long wardId;
    private String status;
    private Long statusCode;
    private Integer mailStatus;
    private String remarks;
    private int createdBy;
    private LocalDateTime createdDate;
    private int municipalId;
    private ViewHoardingApplicationMaster hoardingApplicationMasterId;
    private ViewHoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterId;
    private RoleMaster currentRoleId;
    private UserMasterDTO currentUserId;
    private RoleMaster nextRoleId;
    private UserMasterDTO nextUserId;
    private WorkFlowMaster workFlowMasterId;
    private CitizenSignUpMaster citizenId;

}
