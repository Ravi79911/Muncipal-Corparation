package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.AdvertisementRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.dto.AdvertisementTemporaryRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.AdvertisementRolesDataFlowSetup;
import com.ahmednagar.municipal.auth.model.AdvertisementTemporaryRolesDataFlowSetup;
import com.ahmednagar.municipal.auth.repository.AdvertisementTemporaryRolesDataFlowSetupRepository;
import com.ahmednagar.municipal.auth.service.AdvertisementTemporaryRolesDataFlowSetupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdvertisementTemporaryRolesDataFlowSetupServiceImpl implements AdvertisementTemporaryRolesDataFlowSetupService {

    @Autowired
    private AdvertisementTemporaryRolesDataFlowSetupRepository advertisementTemporaryRolesDataFlowSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<AdvertisementTemporaryRolesDataFlowSetupDto> findAllRolesDataFlowSetup() {
        List<AdvertisementTemporaryRolesDataFlowSetup> roles = advertisementTemporaryRolesDataFlowSetupRepository.findAll();
        return roles.stream()
                .map(role -> modelMapper.map(role, AdvertisementTemporaryRolesDataFlowSetupDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public AdvertisementTemporaryRolesDataFlowSetup getNextRoleForSingleSelection(Long currentRoleId, Long statusCode, Integer isActive) {
        return advertisementTemporaryRolesDataFlowSetupRepository
                .findByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId, statusCode, isActive)
                .orElseThrow(() -> new RuntimeException(
                        "No next role found for currentRoleId: " + currentRoleId +
                                ", statusCode: " + statusCode + ", isActive: " + isActive));
    }

    @Override
    public List<AdvertisementTemporaryRolesDataFlowSetup> getNextRoleListForListSelection(Long currentRoleId, Long statusCode, Integer isActive) {
        List<AdvertisementTemporaryRolesDataFlowSetup> list = advertisementTemporaryRolesDataFlowSetupRepository
                .findAllByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId,statusCode, isActive);
        if (list.isEmpty()) {
            throw new RuntimeException("No next roles found for currentRoleId: " + currentRoleId + " and status code: " + 1007L+"(DocumentVerificationReject)");
        }
        return list;
    }
}
