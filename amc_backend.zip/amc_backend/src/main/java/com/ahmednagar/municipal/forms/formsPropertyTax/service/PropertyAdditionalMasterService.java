//package com.ahmednagar.municipal.forms.formsPropertyTax.service;
//
//import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyAdditionalMaster;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public interface PropertyAdditionalMasterService {
//
//    PropertyAdditionalMaster createPropertyAdditionalMaster(PropertyAdditionalMaster propertyAdditionalMaster);
//
//    List<PropertyAdditionalMaster> getAllPropertyAdditionalMaster();
//
//    Optional<PropertyAdditionalMaster> getPropertyAdditionalMasterById(Long id);
//
//    List<PropertyAdditionalMaster> getPropertyAdditionalMasterByMunicipalId(int municipalId);
//
//    PropertyAdditionalMaster patchPropertyAdditionalMasterSuspendedStatus(Long id, int suspendedStatus);
//
//}
