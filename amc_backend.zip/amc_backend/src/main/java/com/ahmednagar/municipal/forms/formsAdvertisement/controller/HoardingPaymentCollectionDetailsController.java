package com.ahmednagar.municipal.forms.formsAdvertisement.controller;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingPaymentCollectionDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingPaymentCollectionDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingPaymentCollectionDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/advertisement/hoarding/payment/collection/details/form")
@Validated
@CrossOrigin
public class HoardingPaymentCollectionDetailsController {
    @Autowired
    private HoardingPaymentCollectionDetailsService hoardingPaymentCollectionDetailsService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingPaymentCollectionDetails> createHoardingPaymentCollectionDetails(@Valid @RequestBody HoardingPaymentCollectionDetails hoardingPaymentCollectionDetails){
        HoardingPaymentCollectionDetails savedHoardingPaymentCollectionDetails=hoardingPaymentCollectionDetailsService.saveHoardingPaymentCollectionDetails(hoardingPaymentCollectionDetails);
        return ResponseEntity.status(201).body(savedHoardingPaymentCollectionDetails);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingPaymentCollectionDetailsDto>> getAllHoardingPaymentCollectionDetails(){
        List<HoardingPaymentCollectionDetailsDto> hoardingPaymentCollectionDetails=hoardingPaymentCollectionDetailsService.findAllHoardingPaymentCollectionDetails();
        return ResponseEntity.ok(hoardingPaymentCollectionDetails);

    }

    //for single user by Id
    @GetMapping("/getMlBusinessNatureById/{id}")
    public ResponseEntity<HoardingPaymentCollectionDetails> getHoardingPaymentCollectionDetailsById(@PathVariable Long id){
        HoardingPaymentCollectionDetails hoardingPaymentCollectionDetails=hoardingPaymentCollectionDetailsService.findById(id);
        return ResponseEntity.ok(hoardingPaymentCollectionDetails);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingPaymentCollectionDetailsByMunicipalId(@PathVariable int municipalId){
        List<HoardingPaymentCollectionDetails> hoardingPaymentCollectionDetails = hoardingPaymentCollectionDetailsService.findAllByMunicipalId(municipalId);
        if (hoardingPaymentCollectionDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingPaymentCollectionDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingPaymentCollectionDetails);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingPaymentCollectionDetails> updateHoardingPaymentCollectionDetails(@PathVariable("id") Long id, @RequestBody HoardingPaymentCollectionDetails updatedHoardingPaymentCollectionDetails){
        try{
            HoardingPaymentCollectionDetails updated=hoardingPaymentCollectionDetailsService.updateHoardingPaymentCollectionDetails(id,updatedHoardingPaymentCollectionDetails,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingPaymentCollectionDetailsService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }
}

