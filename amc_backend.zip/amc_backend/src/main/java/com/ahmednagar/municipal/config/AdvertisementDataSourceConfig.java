package com.ahmednagar.municipal.config;

import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = {
                "com.ahmednagar.municipal.master.advertisement.repository",
                "com.ahmednagar.municipal.forms.formsAdvertisement.repository"
        },
        entityManagerFactoryRef = "advertisementEntityManagerFactory",
        transactionManagerRef = "advertisementTransactionManager"
)
public class AdvertisementDataSourceConfig {
    @Bean(name = "advertisementDataSource")
    @ConfigurationProperties(prefix = "spring.advertisement.datasource")
    public DataSource advertisementDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "advertisementEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean advertisementEntityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                            @Qualifier("advertisementDataSource") DataSource advertisementDataSource) {
        return builder
                .dataSource(advertisementDataSource)
                .packages(
                        "com.ahmednagar.municipal.master.advertisement.model",
                        "com.ahmednagar.municipal.forms.formsAdvertisement.model"
                )
                .persistenceUnit("advertisementPU")
                .build();
    }

    @Bean(name = "advertisementTransactionManager")
    public PlatformTransactionManager advertisementTransactionManager(
            @Qualifier("advertisementEntityManagerFactory") EntityManagerFactory advertisementEntityManagerFactory) {
        return new JpaTransactionManager(advertisementEntityManagerFactory);
    }
}
