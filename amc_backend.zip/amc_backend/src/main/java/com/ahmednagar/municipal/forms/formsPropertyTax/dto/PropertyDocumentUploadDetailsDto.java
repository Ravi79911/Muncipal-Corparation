package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PropertyDocumentUploadDetailsDto {

    private Long id;
    private Long propertyMasId;
    private Long propertyUploadMasId;
    private String documentPath;
    private int createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;
    private int municipalId;

}
