package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_zone_ward_master")
public class VendorZoneWard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "Ward number is required")
    @Size(min = 1, message = "Ward number cannot be blank")
    @Column(name = "ward_no")
    private String wardNo;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @NotNull(message = "created by is required")
    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @Column(name="zone_mas_id")
    private Long zoneMasId;

//    @OneToMany(mappedBy = "zoneWard", cascade = CascadeType.ALL)
//    private Set<CollectionMaster> collectionMasters;

//    @ManyToOne
//    @JoinColumn(name = "zone_mas_id")
//    private VendorZone vendorZone;


}
