package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.TemporaryLicensePaymentScheduleDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.TemporaryLicensePaymentScheduleDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.TemporaryLicensePaymentScheduleDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/forms/license/temporary/license/payment/schedule/details")
public class TemporaryLicensePaymentScheduleDetailsController {
    @Autowired
    private TemporaryLicensePaymentScheduleDetailsService temporaryLicensePaymentScheduleDetailsService;

    @PostMapping("/create")
    public ResponseEntity<TemporaryLicensePaymentScheduleDetails> createTemporaryLicensePaymentScheduleDetails(@RequestBody TemporaryLicensePaymentScheduleDetails temporaryLicensePaymentScheduleDetails) {
        TemporaryLicensePaymentScheduleDetails createdTemporaryLicensePaymentScheduleDetails = temporaryLicensePaymentScheduleDetailsService.createTemporaryLicensePaymentScheduleDetails(temporaryLicensePaymentScheduleDetails);
        return ResponseEntity.ok(createdTemporaryLicensePaymentScheduleDetails);
    }

    @GetMapping("/calculate-tax/{id}/{taxRate}")
    public ResponseEntity<BigDecimal> calculateTax(@PathVariable Long id, @PathVariable BigDecimal taxRate) {
        TemporaryLicensePaymentScheduleDetails temporaryLicensePaymentScheduleDetails = temporaryLicensePaymentScheduleDetailsService.findById(id); // Add a method to find the schedule by id
        BigDecimal tax = temporaryLicensePaymentScheduleDetailsService.calculateTax(temporaryLicensePaymentScheduleDetails, taxRate);
        return ResponseEntity.ok(tax);
    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<TemporaryLicensePaymentScheduleDetailsDto>> getAllTemporaryLicensePaymentScheduleDetails(){
        List<TemporaryLicensePaymentScheduleDetailsDto> temporaryLicensePaymentScheduleDetails=temporaryLicensePaymentScheduleDetailsService.findAllTemporaryLicensePaymentScheduleDetails();
        return ResponseEntity.ok(temporaryLicensePaymentScheduleDetails);

    }

    //for single user by Id
    @GetMapping("/getTemporaryLicensePaymentScheduleDetailsById/{id}")
    public ResponseEntity<TemporaryLicensePaymentScheduleDetails> getTemporaryLicensePaymentScheduleDetailsById(@PathVariable Long id){
        TemporaryLicensePaymentScheduleDetails temporaryLicensePaymentScheduleDetails=temporaryLicensePaymentScheduleDetailsService.findTemporaryLicensePaymentScheduleDetailsById(id);
        return ResponseEntity.ok(temporaryLicensePaymentScheduleDetails);

    }
    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllTemporaryLicensePaymentScheduleDetailsByMunicipalId(@PathVariable int municipalId){
        List<TemporaryLicensePaymentScheduleDetails> temporaryLicensePaymentScheduleDetails = temporaryLicensePaymentScheduleDetailsService.findAllByMunicipalId(municipalId);
        if (temporaryLicensePaymentScheduleDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No temporaryLicensePaymentScheduleDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(temporaryLicensePaymentScheduleDetails);
    }
}
