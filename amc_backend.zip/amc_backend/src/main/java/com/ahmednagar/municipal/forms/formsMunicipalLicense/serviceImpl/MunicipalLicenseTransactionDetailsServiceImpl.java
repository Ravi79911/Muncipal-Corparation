package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.MunicipalLicenseTransactionDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.MunicipalLicenseTransactionDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.MunicipalLicenseTransactionDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.MunicipalLicenseTransactionDetailsService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MunicipalLicenseTransactionDetailsServiceImpl implements MunicipalLicenseTransactionDetailsService {
    @Autowired
    private MunicipalLicenseTransactionDetailsRepository municipalLicenseTransactionDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public MunicipalLicenseTransactionDetails saveMunicipalLicenseTransactionDetails(MunicipalLicenseTransactionDetails municipalLicenseTransactionDetails) {
        municipalLicenseTransactionDetails.setCreatedDate(LocalDateTime.now());
        municipalLicenseTransactionDetails.setUpdatedDate(LocalDateTime.now());
        municipalLicenseTransactionDetails.setUpdatedBy(municipalLicenseTransactionDetails.getUpdatedBy() != null ? municipalLicenseTransactionDetails.getUpdatedBy() : 0);
        municipalLicenseTransactionDetails.setSuspendedStatus(municipalLicenseTransactionDetails.getSuspendedStatus() != null ? municipalLicenseTransactionDetails.getSuspendedStatus() : 0);

        return municipalLicenseTransactionDetailsRepository.save(municipalLicenseTransactionDetails);

    }



    @Override
    public MunicipalLicenseTransactionDetails findMunicipalLicenseTransactionDetailsById(Long id) {
        Optional<MunicipalLicenseTransactionDetails> municipalLicenseTransactionDetails=municipalLicenseTransactionDetailsRepository.findById(id);
        return municipalLicenseTransactionDetails.orElse(null);

    }

    @Override
    public List<MunicipalLicenseTransactionDetailsDto> findAllMunicipalLicenseTransactionDetailsByMunicipalId(int municipalId) {
        List<MunicipalLicenseTransactionDetails> municipalLicenseTransactionDetails = municipalLicenseTransactionDetailsRepository.findByMunicipalId(municipalId);
        return municipalLicenseTransactionDetails.stream()
                .map(municipalLicenseTransactionDetails1 -> modelMapper.map(municipalLicenseTransactionDetails1, MunicipalLicenseTransactionDetailsDto.class))
                .collect(Collectors.toList());
    }


    @Override
    public MunicipalLicenseTransactionDetails updateMunicipalLicenseTransactionDetails(Long id, MunicipalLicenseTransactionDetails updatedMunicipalLicenseTransactionDetails, int updatedBy) {
        Optional<MunicipalLicenseTransactionDetails> municipalLicenseTransactionDetailsOptional = municipalLicenseTransactionDetailsRepository.findById(id);
        if (municipalLicenseTransactionDetailsOptional.isPresent()) {
            MunicipalLicenseTransactionDetails existingMunicipalLicenseTransactionDetails = municipalLicenseTransactionDetailsOptional.get();
            existingMunicipalLicenseTransactionDetails.setSuspendedStatus(updatedMunicipalLicenseTransactionDetails.getSuspendedStatus());
            existingMunicipalLicenseTransactionDetails.setMunicipalId(updatedMunicipalLicenseTransactionDetails.getMunicipalId());

            return municipalLicenseTransactionDetailsRepository.saveAndFlush(existingMunicipalLicenseTransactionDetails);
        } else {
            throw new RuntimeException("municipalLicenseTransactionDetail not found with id: " + id);
        }
    }

    @Override
    public MunicipalLicenseTransactionDetails changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<MunicipalLicenseTransactionDetails> municipalLicenseTransactionDetailsOptional = municipalLicenseTransactionDetailsRepository.findById(id);
        if (municipalLicenseTransactionDetailsOptional.isPresent()) {
            MunicipalLicenseTransactionDetails municipalLicenseTransactionDetails = municipalLicenseTransactionDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            municipalLicenseTransactionDetails.setSuspendedStatus(status);      // 1 means suspended
            return municipalLicenseTransactionDetailsRepository.saveAndFlush(municipalLicenseTransactionDetails);
        }
        return null;
    }

}
