package com.ahmednagar.municipal.auth.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AdvertisementRolesDataFlowSetupDto {

    private Long id;
    private Long currentRoleId;
    private Long nextRoleId;
    private Long statusCode;
    private Float canEdit;
    private Float isActive;
    private Long createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;

}
