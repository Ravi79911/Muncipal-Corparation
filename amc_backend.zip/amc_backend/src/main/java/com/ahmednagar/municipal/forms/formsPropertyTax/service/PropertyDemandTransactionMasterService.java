package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandTransactionMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface PropertyDemandTransactionMasterService {

    PropertyDemandTransactionMaster createPropertyDemandTransactionMaster(PropertyDemandTransactionMaster propertyDemandTransactionMaster);

    List<PropertyDemandTransactionMaster> getAllPropertyDemandTransactionMaster();

    Optional<PropertyDemandTransactionMaster> getPropertyDemandTransactionMasterById(Long id);

    List<PropertyDemandTransactionMaster> getPropertyDemandTransactionMasterByMunicipalId(int municipalId);

    PropertyDemandTransactionMaster patchPropertyDemandTransactionMasterSuspendedStatus(Long id, int suspendedStatus);

}
