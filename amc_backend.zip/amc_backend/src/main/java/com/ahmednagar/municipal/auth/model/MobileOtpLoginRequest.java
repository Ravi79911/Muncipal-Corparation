package com.ahmednagar.municipal.auth.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MobileOtpLoginRequest {

    private String mobileNumber;
    private String otp;

}
