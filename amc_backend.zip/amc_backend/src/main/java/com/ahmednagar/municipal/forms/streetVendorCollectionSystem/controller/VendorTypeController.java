package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorType;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorTypeController {

    @Autowired
    private VendorTypeService vendorTypeService;

    @PostMapping("/saveVendorTypeMaster")
    public ResponseEntity<VendorType> saveVendorTypeMaster(@RequestBody VendorType vendorType) {
        return ResponseEntity.ok(vendorTypeService.saveVendorType(vendorType));
    }

    @GetMapping("/findVendorTypeById/{id}")
    public ResponseEntity<Optional<VendorType>> getVendorTypeById(@PathVariable("id") Long id) {
        return ResponseEntity.ok(vendorTypeService.findVendorTypeById(id));
    }

    @GetMapping("/getAllVendorTypeMasters")
    public ResponseEntity<Iterable<VendorType>> getAllVendorTypeMasters() {
        return ResponseEntity.ok(vendorTypeService.getAllVendorTypes());
    }

    @PutMapping("/updateVendorTypeMaster")
   public ResponseEntity<Optional<VendorType>> updateVendorTypeMaster(@RequestParam("id") Long id,@RequestBody VendorType vendorType) {
       return ResponseEntity.ok(vendorTypeService.updateVendorType(id,vendorType));
   }

   @PatchMapping("/deleteVendorTypeMaster/{id}")
   public ResponseEntity<Optional<VendorType>> deleteVendorTypeMaster(@PathVariable Long id) {
       return ResponseEntity.ok(vendorTypeService.deleteVendorType(id));
   }
}
