package com.ahmednagar.municipal.auth.service;
import com.ahmednagar.municipal.auth.dto.LicenseWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.model.LicenseWorkFlowLevel;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface LicenseWorkFlowLevelService {
    LicenseWorkFlowLevel handleWorkFlowTransition(LicenseWorkFlowLevel licenseWorkFlowLevel);
    List<LicenseWorkFlowLevelDto> findAllWorkFlow();

    LicenseWorkFlowLevel createNewApplicationTransation(LicenseWorkFlowLevel workFlowRequest);

    List<RemarksDto> getRemarksByApplicationId(Long applicationId);
}