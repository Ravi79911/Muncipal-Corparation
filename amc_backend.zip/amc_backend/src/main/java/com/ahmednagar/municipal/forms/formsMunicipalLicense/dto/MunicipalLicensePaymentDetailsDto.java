package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationLicenseDetails;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MunicipalLicensePaymentDetailsDto {
    private Long id;
    private ApplicationLicenseDetailsDto municipalLicenseId;
    private LocalDateTime paymentDate;
    private BigDecimal amountPaid;
    private BigDecimal amountDue;
    private String paymentMode;
    private String transactionId;
    private String status;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
