package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseApplicationAutoTransfer;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.LicenseApplicationAutoTransferService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/license/label/auto/transfer")
public class LicenseApplicationAutoTransferController {
    @Autowired
    private LicenseApplicationAutoTransferService licenseApplicationAutoTransferService;

    @PostMapping("/create")
    public ResponseEntity<LicenseApplicationAutoTransfer> createLicenseApplicationAutoTransfer(@Valid @RequestBody LicenseApplicationAutoTransfer licenseApplicationAutoTransfer) {
        LicenseApplicationAutoTransfer createdLicenseApplicationAutoTransfer= licenseApplicationAutoTransferService.saveLicenseApplicationAutoTransfer(licenseApplicationAutoTransfer);
        return ResponseEntity.status(201).body(createdLicenseApplicationAutoTransfer);
    }

}
