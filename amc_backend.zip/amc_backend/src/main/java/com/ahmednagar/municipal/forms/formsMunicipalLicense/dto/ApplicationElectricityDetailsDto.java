package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ApplicationElectricityDetailsDto {
    private int id;
    private ApplicationFromMasterDto applicationMasterId;
    private String electricityKNumber;
    private String consumerNo;
    private String connectionType;
    private String consumerName;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;
}
