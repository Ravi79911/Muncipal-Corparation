package com.ahmednagar.municipal.forms.formsAdvertisement.service;

import org.springframework.stereotype.Service;

@Service
public interface ApplicationCounterService {

    int getNextCounterValue(String counterName);

}
