package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.FilePermissionDto;
import com.ahmednagar.municipal.auth.model.FilePermission;
import com.ahmednagar.municipal.auth.service.FilePermissionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class FilePermissionController {
    @Autowired
    private FilePermissionService filePermissionService;

    // create new user
    @PostMapping("create/FilePermissioin")
    public ResponseEntity<FilePermission> createFilePermission(@Valid @RequestBody FilePermission filePermission){
        FilePermission createdFilePermission=filePermissionService.saveFilePermissionService(filePermission);
        if(createdFilePermission==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdFilePermission);

    }
    //find all file permission
    @GetMapping("/all/filePermission")
    public ResponseEntity<List<FilePermissionDto>> getAllFilePermission(){
        List<FilePermissionDto> filePermission=filePermissionService.findAllFilePermission();
        return ResponseEntity.ok(filePermission);
    }
    //get menu By MunicipalId
    @GetMapping("/MunicipalFilePermission/{municipalId}")
    public ResponseEntity<?> getAllFilePermissionByMunicipalId(@PathVariable Long municipalId){
        List<FilePermissionDto> filePermission=filePermissionService.findAllFilePermissionByMunicipalId(municipalId);
        if (filePermission.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No FilePermission found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(filePermission);
    }
    //     Update menu for admin
    @PutMapping("/updatedFilePermission/{id}")
    public ResponseEntity<FilePermission> updateFilePermission(@PathVariable("id") Long id, @RequestBody FilePermission updatedFilePermission){
        try{
            FilePermission updated=filePermissionService.updateFilePermission(id,updatedFilePermission);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete fileUrl for admin
    @PatchMapping("/deleteFilePermission/{id}")
    public ResponseEntity<FilePermission> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        FilePermission updatedFilePermission = filePermissionService.changeSuspendedStatus(id, status);         // updatedBy is always 1 for now as it is the admin
        if (updatedFilePermission== null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedFilePermission);
    }

}
