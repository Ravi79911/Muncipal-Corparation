package com.ahmednagar.municipal.forms.formsPropertyTax.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_muni_property_demand_transaction_details")
public class PropertyDemandTransactionDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "transaction type is required")
    @Size(max = 50, message = "transaction type can't exceed 50 characters")
    @Column(name = "transaction_type")
    private String transactionType;

    @NotBlank(message = "chq dd online number is required")
    @Size(max = 50, message = "chq dd online number can't exceed 50 characters")
    @Column(name = "chq_dd_online_number")
    private String chqDdOnlineNumber;

    @Column(name = "chq_dd_online_date")
    private LocalDate chqDdOnlineDate;

    @NotBlank(message = "bank name is required")
    @Size(max = 50, message = "bank name can't exceed 50 characters")
    @Column(name = "bank_name")
    private String bankName;

    @NotBlank(message = "bank branch is required")
    @Size(max = 50, message = "bank branch can't exceed 50 characters")
    @Column(name = "bank_branch")
    private String bankBranch;

    @NotBlank(message = "payment status is required")
    @Size(max = 50, message = "payment status can't exceed 50 characters")
    @Column(name = "payment_status_paid_bal")
    private String paymentStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @NotNull(message = "created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Min(value = 0, message = "suspended status must be 0 (inactive) or 1 (active)")
    @Max(value = 1, message = "suspended status must be 0 (inactive) or 1 (active)")
    @Column(name = "suspended_status")
    private int suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
    private MunicipalPropertyMaster municipalPropertyMaster;

    @ManyToOne
    @JoinColumn(name = "transaction_mas_id", referencedColumnName = "id", nullable = false)
    private PropertyDemandTransactionMaster propertyDemandTransactionMaster;

}
