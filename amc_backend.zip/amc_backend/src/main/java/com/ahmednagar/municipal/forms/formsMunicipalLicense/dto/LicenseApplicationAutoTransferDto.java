package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class LicenseApplicationAutoTransferDto {
    private Long id;
    private LicenseApplicationWorkflowDto applicationWorkflowId;
    private Long applicationMasterId;
    private LocalDateTime transferTime;
    private String transferredFromStage;
    private String transferredToStage;
    private String reason;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private Long municipalId;
}
