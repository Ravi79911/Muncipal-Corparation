package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorMaster;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorMasterController {

    @Autowired
    private VendorMasterService vendorMasterService;

    @PostMapping("/saveVendorMaster")
    public ResponseEntity<VendorMaster> saveVendorMaster(@RequestBody VendorMaster vendorMaster) {
        return ResponseEntity.ok(vendorMasterService.saveVendorMaster(vendorMaster));
    }

    @GetMapping("/getVendorMasterById/{id}")
    public ResponseEntity<Optional<VendorMaster>> getVendorMasterById(@PathVariable Long id) {
        return ResponseEntity.ok(vendorMasterService.findByIdVendorMaster(id));
    }

    @GetMapping("/getAllVendorMaster")
    public ResponseEntity<Iterable<VendorMaster>> getAllVendorMaster() {
        return ResponseEntity.ok(vendorMasterService.getAllVendorMasters());
    }

    @PutMapping("/updateVendorMaster/{id}")
    public ResponseEntity<Optional<VendorMaster>> updateVendorMaster(@PathVariable Long id, @RequestBody VendorMaster vendorMaster) {
        return ResponseEntity.ok(vendorMasterService.updateVendorMaster(id, vendorMaster));
    }

    @DeleteMapping("/deleteVendorMaster/{id}")
    public ResponseEntity<Optional<VendorMaster>> deleteVendorMaster(@PathVariable Long id) {
        return ResponseEntity.ok(vendorMasterService.deleteVendorMaster(id));
    }

    @GetMapping("/getVendors/{marketNameId}/{vendorNameEng}")
    public ResponseEntity<List<VendorMaster>> getVendors(
            @RequestParam(required = false) Long marketNameId,
            @RequestParam(required = false) String vendorNameEng) {
        List<VendorMaster> vendors = vendorMasterService.getVendors(marketNameId, vendorNameEng);
        return ResponseEntity.ok(vendors);
    }

}
