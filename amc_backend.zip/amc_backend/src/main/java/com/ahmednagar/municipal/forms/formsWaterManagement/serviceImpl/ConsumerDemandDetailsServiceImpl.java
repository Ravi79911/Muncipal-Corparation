package com.ahmednagar.municipal.forms.formsWaterManagement.serviceImpl;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerDemandDetails;
import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerDetailsLegacyData;
import com.ahmednagar.municipal.forms.formsWaterManagement.repository.ConsumerDemandDetailsRepository;
import com.ahmednagar.municipal.forms.formsWaterManagement.repository.ConsumerDetailsLegacyDataRepository;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.ConsumerDemandDetailsService;
import com.ahmednagar.municipal.forms.formsWaterManagement.utils.WaterBillNoGenerator;
import com.ahmednagar.municipal.master.waterManagement.modal.TariffRateMaster;
import com.ahmednagar.municipal.master.waterManagement.service.TariffRateMasterService;
import jakarta.persistence.NoResultException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
public class ConsumerDemandDetailsServiceImpl implements ConsumerDemandDetailsService {

    @Autowired
    private ConsumerDemandDetailsRepository consumerDemandDetailsRepository;

    @Autowired
    private ConsumerDetailsLegacyDataRepository consumerDetailsLegacyDataRepository;
    
    @Autowired
    private TariffRateMasterService tariffRateService;

    private static final Logger logger = LogManager.getLogger(ConsumerDemandDetailsServiceImpl.class);

    @Override
    public ConsumerDemandDetails createDemandDetail(ConsumerDemandDetails consumerDemandDetails) {

        // Fetch the consumer details legacy data
        ConsumerDetailsLegacyData consumerDetailsLegacyData = consumerDetailsLegacyDataRepository.findById(consumerDemandDetails.getConsumerDetailsLegacyDataId().getId())
                .orElseThrow(() -> new RuntimeException("ConsumerDetailsLegacyData not found with id: " + consumerDemandDetails.getConsumerDetailsLegacyDataId().getId()));
        
        // Extract the values from the tariff rate master
        TariffRateMaster tariffRate = tariffRateService.getTariffDetails(
                consumerDetailsLegacyData.getPipelineTypeId().getId(),
                consumerDetailsLegacyData.getConsPropsCategoryUseTypeDdId().getId(),
                consumerDetailsLegacyData.getConsWaterPropsUseTypeDdId().getId(),
                consumerDemandDetails.getMeterStatusId().getId()
        );
        // Set the charges
        Long perUnitCharges = tariffRate.getPerUnitCharges();
        Long fixedCharges = tariffRate.getFixedCharges();
        int minUnit = tariffRate.getMinUnit();

        logger.info("minUnit: " + minUnit+", fixedCharges: "+fixedCharges+", perUnitCharges: "+perUnitCharges);
        logger.info("pipelineTypeId: "+consumerDetailsLegacyData.getPipelineTypeId().getId()+
                ", consPropCatUseTypeDdId: "+consumerDetailsLegacyData.getConsPropsCategoryUseTypeDdId().getId()+
                ", consWaterPropUseTypeDdId: "+consumerDetailsLegacyData.getConsWaterPropsUseTypeDdId().getId()+
                ", meterStatusId: "+consumerDemandDetails.getMeterStatusId().getId());

        if(consumerDetailsLegacyData.isMetered()){
            // Set the previous reading by fetching the latest reading for the consumer
            consumerDemandDetails.setPreviousReading(getCurrentReadingByConsumerId(
                    consumerDemandDetails.getConsumerDetailsLegacyDataId().getId()));

            int usedUnit = (consumerDemandDetails.getCurrentReading() - consumerDemandDetails.getPreviousReading());
            consumerDemandDetails.setConsumptionUnit(usedUnit);

            if (minUnit == 0) {
                // If minUnit is 0, always charge the fixed charges
                consumerDemandDetails.setPerUnitCharges(0L);
                consumerDemandDetails.setBillAmount(BigDecimal.valueOf(fixedCharges));
            } else if (usedUnit < minUnit) {
                // For usage below minimum threshold, apply fixed charges
                consumerDemandDetails.setPerUnitCharges(0L);
                consumerDemandDetails.setBillAmount(BigDecimal.valueOf(fixedCharges));
            } else {
                // For usage above or equal to the minimum threshold, calculate bill dynamically
                consumerDemandDetails.setPerUnitCharges(perUnitCharges);
                BigDecimal billAmount = BigDecimal.valueOf(perUnitCharges)
                        .multiply(BigDecimal.valueOf(usedUnit));
                consumerDemandDetails.setBillAmount(billAmount);
            }
        }
        else{
            consumerDemandDetails.setBillAmount(BigDecimal.valueOf(fixedCharges));
        }

        LocalDate dueDate = LocalDate.now()
                            .plusMonths(1)   // Move to the next month
                            .withDayOfMonth(7); // Set the day to the 7th
        consumerDemandDetails.setDueDate(dueDate);   // Set the due date to the 7th of the next month

        String generatedBillNo = WaterBillNoGenerator.generateBillNo();   // Generate a new bill number
        consumerDemandDetails.setBillNum(generatedBillNo);   // Set the bill number

        consumerDemandDetails.setBillingMonth(LocalDate.now());   // Set the billing month to the current month
        consumerDemandDetails.setSuspendedStatus(consumerDemandDetails.getSuspendedStatus()!=null?consumerDemandDetails.getSuspendedStatus():0);
        consumerDemandDetails.setGeneratedDate(LocalDate.now());
        consumerDemandDetails.setCreatedDate(LocalDateTime.now());
        consumerDemandDetails.setUpdatedDate(LocalDateTime.now());
        return consumerDemandDetailsRepository.save(consumerDemandDetails);
    }

    @Override
    public int getCurrentReadingOfLatestBill(String consumerNo) {

        ConsumerDetailsLegacyData consumerDetailsLegacyData = consumerDetailsLegacyDataRepository.findByConsumerNumber(consumerNo)
                .orElseThrow(() -> new RuntimeException("No consumer found for consumer number: " + consumerNo));

        logger.info("consumerDetailsLegacyData.getId(): {}", consumerDetailsLegacyData.getId());

        Long consumerId = consumerDetailsLegacyData.getId();
        return getCurrentReadingByConsumerId(consumerId);
    }

    public int getCurrentReadingByConsumerId(Long consumerId) {
        try {
            ConsumerDemandDetails latestBill = consumerDemandDetailsRepository.findLatestBillByConsumerId(consumerId);
            return latestBill.getCurrentReading();
        } catch (NoResultException e) {
            throw new RuntimeException("No bills found for consumer ID: " + consumerId);
        }
    }

}
