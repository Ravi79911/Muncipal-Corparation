package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.AdvertisementWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.*;
import com.ahmednagar.municipal.auth.service.AdvertisementWorkFlowLevelService;
import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AdvertisementWorkFlowLevelServiceImpl implements AdvertisementWorkFlowLevelService {

    @Autowired
    private AdvertisementWorkFlowLevelRepository advertisementWorkFlowLevelRepository;

    @Autowired
    private RoleMasterRepository roleMasterRepository;

    @Autowired
    private WorkFlowMasterRepository workFlowMasterRepository;

    @Autowired
    private UserMasterRepository userMasterRepository;

    @Autowired
    private CitizenSignUpRepository citizenSignUpRepository;

    @Autowired
    private ViewHoardingCategoryTypeMasterSetupRepository viewHoardingCategoryTypeMasterSetupRepository;

    @Autowired
    private ViewHoardingDocumentsDetailsRepository viewHoardingDocumentsDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    public UserMaster getLipikForAdvertisementCitizen(Long citizenId , Long hoardingCategoryTypeMasterId) {
        if(hoardingCategoryTypeMasterId.equals(1L)) { // Permanent Hoarding
            Long roleId = 1L; // Role ID for Lipik

            CitizenSignUpMaster citizen = citizenSignUpRepository.findById(citizenId)
                    .orElseThrow(() -> new EntityNotFoundException("Citizen not found with ID: " + citizenId));

            // Fetch the first Lipik (UserMaster) matching Zone, Ward, Role
            return userMasterRepository.findFirstByZoneWardAndRole(citizen.getZoneId(), citizen.getWardId(), roleId)
                    .orElseThrow(() -> new EntityNotFoundException("No Lipik found for Zone: " + citizen.getZoneId()
                            + " and Ward: " + citizen.getWardId()));
        }else {
            Long roleId = 5L; // Role ID for TS

            CitizenSignUpMaster citizen = citizenSignUpRepository.findById(citizenId)
                    .orElseThrow(() -> new EntityNotFoundException("Citizen not found with ID: " + citizenId));

            // Fetch the first TS (UserMaster) matching Zone, Ward, Role
            return userMasterRepository.findFirstByZoneWardAndRole(citizen.getZoneId(), citizen.getWardId(), roleId)
                    .orElseThrow(() -> new EntityNotFoundException("No TS found for Zone: " + citizen.getZoneId()
                            + " and Ward: " + citizen.getWardId()));
        }
    }

    @Override
    public AdvertisementWorkFlowLevel createNewApplicationTransation(AdvertisementWorkFlowLevel newApplicationAdvertisementWorkFlowRequest) {
        Long citizenId = newApplicationAdvertisementWorkFlowRequest.getCitizenId().getId();
        Long hoardingCategoryTypeMasterId = newApplicationAdvertisementWorkFlowRequest.getHoardingCategoryTypeMasterId().getId();
        UserMaster newApplicationLipik = getLipikForAdvertisementCitizen(citizenId, hoardingCategoryTypeMasterId);
        // Validate WorkFlow Master
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newApplicationAdvertisementWorkFlowRequest.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Master not found"));

        // Build WorkFlowLevel Object with Defaults
        AdvertisementWorkFlowLevel newWorkFlow = AdvertisementWorkFlowLevel.builder()
                .hoardingApplicationMasterId(newApplicationAdvertisementWorkFlowRequest.getHoardingApplicationMasterId())
                .currentUserId(null)
                .nextUserId(newApplicationLipik)
                .workFlowMasterId(workFlowMaster)
                .status("NEW") // Default status for new applications
                .statusCode(1000L) // Example status code
                .createdBy(newApplicationAdvertisementWorkFlowRequest.getCreatedBy())
                .createdDate(LocalDateTime.now())
                .mailStatus(newApplicationAdvertisementWorkFlowRequest.getMailStatus())
                .remarks(newApplicationAdvertisementWorkFlowRequest.getRemarks())
                .suspendedStatus(0) // Default
                .municipalId(newApplicationAdvertisementWorkFlowRequest.getMunicipalId())
                .citizenId(newApplicationAdvertisementWorkFlowRequest.getCitizenId())
                .hoardingCategoryTypeMasterId(newApplicationAdvertisementWorkFlowRequest.getHoardingCategoryTypeMasterId())
                .build();
        updateApprovedStatus(newApplicationAdvertisementWorkFlowRequest.getHoardingApplicationMasterId().getId());

        // Save Workflow to Database
        return advertisementWorkFlowLevelRepository.save(newWorkFlow);
    }

    @Override
    public List<AdvertisementWorkFlowLevelDto> findAllWorkFlow() {
        List<AdvertisementWorkFlowLevel> advertisementWorkFlowLevels = advertisementWorkFlowLevelRepository.findAll();

        return advertisementWorkFlowLevels.stream().map(advertisementWorkFlowLevel -> {
            AdvertisementWorkFlowLevelDto dto = modelMapper.map(advertisementWorkFlowLevel, AdvertisementWorkFlowLevelDto.class);

            // Manually map UserMaster to UserMasterDTO
            if (advertisementWorkFlowLevel.getCurrentUserId() != null) {
                dto.setCurrentUserId(modelMapper.map(advertisementWorkFlowLevel.getCurrentUserId(), UserMasterDTO.class));
            }
            if (advertisementWorkFlowLevel.getNextUserId() != null) {
                dto.setNextUserId(modelMapper.map(advertisementWorkFlowLevel.getNextUserId(), UserMasterDTO.class));
            }

            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public AdvertisementWorkFlowLevel handleWorkFlowTransition(AdvertisementWorkFlowLevel advertisementWorkFlowLevel) {
        advertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        Long currentRoleMasterId = getCurrentRoleMasterId(advertisementWorkFlowLevel);  // Get RoleMasterId for Current User
        Long nextRoleMasterId = getNextRoleMasterId(advertisementWorkFlowLevel);       // Get RoleMasterId for Next User
        //Long nextRoleCitizenMasterId =getNextRoleCitizenMasterId(workFlowLevel);

        RoleMaster currentRole = roleMasterRepository.findById(currentRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));

        RoleMaster nextRole = roleMasterRepository.findById(nextRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Next Role not found"));

        // Fetch hoarding category type to determine if it is permanent or temporary
        Long hoardingCategoryId = advertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId();
        boolean isPermanentHoarding = hoardingCategoryId.equals(1L); // Permanent hoarding if hoarding_category_type_master_id = 1


        // Dynamically fetch workflow status from WorkFlowMaster table
        WorkFlowMaster currentStatus = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Status not found"));

        List<Long> rejectDocumentIdes = advertisementWorkFlowLevel.getRejectedDocumentIdes();

        // Fetch the current status of the application
        Optional<AdvertisementWorkFlowLevel> existingWorkflow = advertisementWorkFlowLevelRepository
                .findTopByHoardingApplicationMasterIdOrderByCreatedDateDesc(advertisementWorkFlowLevel.getHoardingApplicationMasterId());

        if (existingWorkflow.isPresent()) {
            Long existingStatusCode = existingWorkflow.get().getStatusCode();

            // Check if the application has already been accepted or rejected
            if (existingStatusCode.equals(1002L) || existingStatusCode.equals(1003L)) {
                throw new IllegalStateException("This application has already been " +
                        (existingStatusCode.equals(1002L) ? "Accepted" : "Rejected") +
                        " and cannot be processed further.");
            }
        }

        // Transition based on the current status and role
        switch (currentStatus.getStatus()) {

            case "FORWARDED":
                return handleForwardedStatus(advertisementWorkFlowLevel, currentRole, nextRole,isPermanentHoarding);

            case "BACKWARD":
                return handleBackwardStatus(advertisementWorkFlowLevel, currentRole, nextRole);

            case "ACCEPT":
                return handleAcceptStatus(advertisementWorkFlowLevel, currentRole);

            case "REJECT":
                return handleRejectStatus(advertisementWorkFlowLevel, currentRole, nextRole);

            case "BACK TO CITIZEN":
                return handleBackToCitizenStatus(advertisementWorkFlowLevel, currentRole);

            case "BACK TO CITIZEN IN BACKWARD":
                return handleBackToCitizenInBackWardCaseStatus(advertisementWorkFlowLevel, currentRole, nextRole);

            case "BACK TO BACK OFFICE":
                return handleBackToBackOfficeStatus(advertisementWorkFlowLevel, currentRole, nextRole);

            case "DOCUMENT VERIFICATION ACCEPT":
                return handleDocumentVerificationAccept(advertisementWorkFlowLevel, currentRole, nextRole);

            case "DOCUMENT VERIFICATION REJECT":
                return handleDocumentVerificationReject(advertisementWorkFlowLevel, currentRole, nextRole, rejectDocumentIdes);

            default:
                throw new RuntimeException("Invalid Status: " + currentStatus.getStatus());
        }
    }


    private AdvertisementWorkFlowLevel handleForwardedStatus(AdvertisementWorkFlowLevel advertisementWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole,boolean isPermanentHoarding) {

        Long nextUserId = advertisementWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = advertisementWorkFlowLevel.getCurrentUserId().getId();

        // Check the status_code and call the corresponding forward methods
        if (advertisementWorkFlowLevel.getStatusCode() == 1005) {
            // Call forwardFromBackOffice when status_code is 1005
            return forwardFromBackOffice(advertisementWorkFlowLevel);

        } else if (advertisementWorkFlowLevel.getStatusCode() == 1004) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromCitizen(advertisementWorkFlowLevel);

        }else if (advertisementWorkFlowLevel.getStatusCode() == 1001) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromBackWard(advertisementWorkFlowLevel);
        }
        else {
            // Fetch the next role based on the workFlowMasterId from the database
            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
            advertisementWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            advertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

            // Validate nextRole
            if (nextRole == null && !"deputy municipal commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Next role is required but not provided.");
            }

            // Validate nextRole for permanent hoarding
            if (isPermanentHoarding) {
                return handlePermanentHoardingForward(advertisementWorkFlowLevel, currentRole, nextRole, nextUserId, currentUserId);
            } else {
                return handleTemporaryHoardingForward(advertisementWorkFlowLevel, currentRole, nextRole, nextUserId, currentUserId);
            }
        }
    }

    private AdvertisementWorkFlowLevel handlePermanentHoardingForward(AdvertisementWorkFlowLevel advertisementWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole, Long nextUserId, Long currentUserId) {
        switch (currentRole.getRoleName().toLowerCase()) {
            case "back office":
                if (nextRole.getRoleName().equalsIgnoreCase("lipik")) {
                    advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                    advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                    advertisementWorkFlowLevel.setMailStatus(1);
                } else {
                    throw new IllegalStateException("Back Office can only forward to Lipik.");
                }
                break;

            case "lipik":
                if (nextRole.getRoleName().equalsIgnoreCase("section head")) {
                    advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                    advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                    advertisementWorkFlowLevel.setMailStatus(1);
                } else {
                    throw new IllegalStateException("Lipik can only forward to Section Head.");
                }
                break;

            case "section head":
                if (nextRole.getRoleName().equalsIgnoreCase("deputy municipal commissioner")) {
                    advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                    advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                    advertisementWorkFlowLevel.setMailStatus(1);
                } else {
                    throw new IllegalStateException("Section Head can only forward to Deputy Municipal Commissioner.");
                }
                break;

            case "deputy municipal commissioner":
                advertisementWorkFlowLevel.setNextUserId(null);
                advertisementWorkFlowLevel.setStatus("Application Successfully Approved");
                advertisementWorkFlowLevel.setStatusCode(1002L); // Status Code for "Accepted"
                advertisementWorkFlowLevel.setMailStatus(0);
                break;

            default:
                throw new IllegalStateException("Invalid current role for permanent hoarding.");
        }
        return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
    }

    private AdvertisementWorkFlowLevel handleTemporaryHoardingForward(AdvertisementWorkFlowLevel advertisementWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole, Long nextUserId, Long currentUserId) {
        switch (currentRole.getRoleName().toLowerCase()) {
            case "back office":
                if (nextRole.getRoleName().equalsIgnoreCase("tax superintendent")) {
                    advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                    advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                    advertisementWorkFlowLevel.setMailStatus(1);
                } else {
                    throw new IllegalStateException("Back Office can only forward to Tax Superintendent.");
                }
                break;

            case "tax superintendent":
                advertisementWorkFlowLevel.setNextUserId(null);
                advertisementWorkFlowLevel.setStatus("Application Successfully Approved");
                advertisementWorkFlowLevel.setStatusCode(1002L); // Status Code for "Accepted"
                advertisementWorkFlowLevel.setMailStatus(0);
                break;

            default:
                throw new IllegalStateException("Invalid current role for temporary hoarding.");
        }
        return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
    }

    private AdvertisementWorkFlowLevel handleBackwardStatus(AdvertisementWorkFlowLevel advertisementWorkFlowLevel, RoleMaster currentRole, RoleMaster previousRole) {
        // Fetch the next role based on the workFlowMasterId from the database
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = advertisementWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = advertisementWorkFlowLevel.getCurrentUserId().getId();

        // Set the status from WorkFlowMaster to WorkFlow
        advertisementWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        advertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        // Fetch hoarding category type master id (permanent or temporary)
        Long hoardingCategoryTypeMasterId = advertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId();


        // Validate nextRole
        if (previousRole == null && !"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Next role is required but not provided.");
        }

        // Logic for backward status (WorkFlowMasterId = 8)
        if (workFlowMaster.getId().equals(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())) {
            switch (currentRole.getRoleName().toLowerCase()) {
                case "lipik":
                    // Lipik can reject and return to Back Office (Only for permanent hoarding)
                    if (hoardingCategoryTypeMasterId.equals(1L)) { // Permanent hoarding
                        if ("back office".equalsIgnoreCase(previousRole.getRoleName())) {
                            advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(previousRole, nextUserId)); // Reject and return to Back Office
                            advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                            advertisementWorkFlowLevel.setStatus("Rejected by Lipik");
                        } else {
                            throw new IllegalStateException("Lipik can only reject and return to Back Office.");
                        }
                    } else {
                        throw new IllegalStateException("Lipik role is not valid for temporary hoarding rejection.");
                    }
                    break;

                case "section head":
                    // Section Head can reject to Lipik or Back Office (Only for permanent hoarding)
                    if (hoardingCategoryTypeMasterId.equals(1L)) { // Permanent hoarding
                        if (isValidRoleForSectionHead(previousRole)) {
                            advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(previousRole, nextUserId)); // Reject and return to the selected role
                            advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                            advertisementWorkFlowLevel.setStatus("Rejected by Section Head");
                        } else {
                            throw new IllegalStateException("Section Head can only reject to Lipik or Back Office.");
                        }
                    } else {
                        throw new IllegalStateException("Section Head role is not valid for temporary hoarding rejection.");
                    }
                    break;

                case "deputy municipal commissioner":
                    // DMC can reject to Section Head, Lipik, or Back Office (Only for permanent hoarding)
                    if (hoardingCategoryTypeMasterId.equals(1L)) { // Permanent hoarding
                        if (isValidRoleForDMC(previousRole)) {
                            advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(previousRole, nextUserId)); // Reject and return to the selected role
                            advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                            advertisementWorkFlowLevel.setStatus("Rejected by DMC");
                        } else {
                            throw new IllegalStateException("DMC can only reject to Section Head, Lipik, or Back Office.");
                        }
                    } else {
                        throw new IllegalStateException("DMC role is not valid for temporary hoarding rejection.");
                    }
                    break;

                case "tax superintendent":
                    // TS (Tax Superintendent) can reject to Back Office (Only for temporary hoarding)
                    if (hoardingCategoryTypeMasterId.equals(2L)) { // Temporary hoarding
                        advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(previousRole, nextUserId)); // Reject and return to Back Office
                        advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        advertisementWorkFlowLevel.setStatus("Rejected by TS");
                    } else {
                        throw new IllegalStateException("Tax Superintendent role is only valid for temporary hoarding rejection.");
                    }
                    break;

                default:
                    throw new IllegalStateException("Invalid current role for Document Verification Reject: " + currentRole.getRoleName());
            }

            // Set mail status and created date for all cases except TS → ID Generation rejection
            if (!"deputy municipal commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
                advertisementWorkFlowLevel.setMailStatus(0);  // Assuming 0 means mail sent for rejection
                advertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            }

            // Update rejection status for the rejected documents
            //updateRejectStatus(advertisementWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);
            advertisementWorkFlowLevel.setMailStatus(2);
        }

        // Validate previousRole
        if (previousRole == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }
        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
        if (advertisementWorkFlowLevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            advertisementWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

            //updateRejectStatus(advertisementWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);

            return handleBackToCitizenInBackWardCaseStatus(advertisementWorkFlowLevel, currentRole,previousRole);  // Handle transition to citizen
        }

        return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
    }

    private AdvertisementWorkFlowLevel handleAcceptStatus(AdvertisementWorkFlowLevel advertisementWorkFlowLevel, RoleMaster currentRole) {
        Long nextUserId = advertisementWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = advertisementWorkFlowLevel.getCurrentUserId().getId();

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        // Check if the application is already accepted or rejected
        Optional<AdvertisementWorkFlowLevel> existingStatus = advertisementWorkFlowLevelRepository
                .findLatestWorkFlowByHoardingApplicationMasterIdAndStatusCode(advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId(), 1002L);

        if (existingStatus.isPresent()) {
            throw new IllegalStateException("This application has already been accepted and cannot be processed again.");
        }

        // Ensure only WorkFlowMasterId = 3 is processed for acceptance
        if (!workFlowMaster.getId().equals(3L)) {
            throw new IllegalStateException("This workflow is not eligible for acceptance.");
        }

        // Fetch hoarding category type master id (permanent or temporary)
        Long hoardingCategoryTypeMasterId = advertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId();

        // Ensure the correct role based on hoarding type
        if (hoardingCategoryTypeMasterId.equals(1L)) { // Permanent Hoarding
            // Only Deputy Municipal Commissioner can accept for permanent hoarding
            if (!"Deputy Municipal Commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Only Deputy Municipal Commissioner can accept the application for permanent hoarding.");
            }
        } else if (hoardingCategoryTypeMasterId.equals(2L)) { // Temporary Hoarding
            // Only TS (Tax Superintendent) can accept for temporary hoarding
            if (!"Tax Superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Only Tax Superintendent can accept the application for temporary hoarding.");
            }
        } else {
            throw new IllegalStateException("Invalid hoarding category type for acceptance.");
        }

        // Update status to "Accepted"
        advertisementWorkFlowLevel.setStatus("Application Successfully Accepted");
        advertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        advertisementWorkFlowLevel.setNextUserId(null); // No further forwarding
        advertisementWorkFlowLevel.setMailStatus(0);
        advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
        advertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
    }


    private AdvertisementWorkFlowLevel handleRejectStatus(AdvertisementWorkFlowLevel advertisementWorkFlowLevel, RoleMaster currentRole, RoleMaster previousRole) {

        Long nextUserId = advertisementWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = advertisementWorkFlowLevel.getCurrentUserId().getId();

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        // Check if the application is already accepted or rejected
        Optional<AdvertisementWorkFlowLevel> existingStatus = advertisementWorkFlowLevelRepository
                .findLatestWorkFlowByHoardingApplicationMasterIdAndStatusCode(advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId(), 1003L);

        if (existingStatus.isPresent()) {
            throw new IllegalStateException("This application has already been rejected and cannot be processed again.");
        }

        // Ensure only WorkFlowMasterId = 4 is processed for rejection
        if (!workFlowMaster.getId().equals(4L)) {
            throw new IllegalStateException("This workflow is not eligible for rejection.");
        }

        // Fetch hoarding category type master id (permanent or temporary)
        Long hoardingCategoryTypeMasterId = advertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId();

        // Ensure the correct role based on hoarding type
        if (hoardingCategoryTypeMasterId.equals(1L)) { // Permanent Hoarding
            // Only Deputy Municipal Commissioner can reject for permanent hoarding
            if (!"Deputy Municipal Commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Only Deputy Municipal Commissioner can reject the application for permanent hoarding.");
            }
        } else if (hoardingCategoryTypeMasterId.equals(2L)) { // Temporary Hoarding
            // Only TS (Tax Superintendent) can reject for temporary hoarding
            if (!"Tax Superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Only Tax Superintendent can reject the application for temporary hoarding.");
            }
        } else {
            throw new IllegalStateException("Invalid hoarding category type for rejection.");
        }

        // Update status to "Rejected"
        advertisementWorkFlowLevel.setStatus("Application Rejected");
        advertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        advertisementWorkFlowLevel.setNextUserId(null); // No further forwarding
        advertisementWorkFlowLevel.setMailStatus(2); // Set mail notification for rejection
        advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
        advertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
    }

//    private AdvertisementWorkFlowLevel handleBackToCitizenStatus(AdvertisementWorkFlowLevel workFlow, RoleMaster currentRole) {
//        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));
//
//        Long nextUserId = workFlow.getNextUserId().getId();
//        Long currentUserId = workFlow.getCurrentUserId().getId();
//
//        if (workFlowMaster.getId().equals(5L)) {
//            workFlow.setStatus(workFlowMaster.getStatus());
//            workFlow.setStatusCode(workFlowMaster.getStatusCode());
//
//            workFlow.setNextUserId(null);
//            workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
//            workFlow.setCitizenId(workFlow.getCitizenId());
//        }
//        workFlow.setMailStatus(1);
//        workFlow.setCreatedDate(LocalDateTime.now());
//        return advertisementWorkFlowLevelRepository.save(workFlow);
//    }

    private AdvertisementWorkFlowLevel handleBackToCitizenStatus(AdvertisementWorkFlowLevel workFlow, RoleMaster currentRole) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = workFlow.getNextUserId() != null ? workFlow.getNextUserId().getId() : null;
        Long currentUserId = workFlow.getCurrentUserId().getId();

        // Fetch hoarding category type master id (permanent or temporary)
        Long hoardingCategoryTypeMasterId = workFlow.getHoardingCategoryTypeMasterId().getId();

        if (workFlowMaster.getId().equals(5L)) {  // Backward Flow for WorkFlowMasterId = 5 (Water Workflow)

            workFlow.setStatus(workFlowMaster.getStatus());
            workFlow.setStatusCode(workFlowMaster.getStatusCode());

            switch (currentRole.getRoleName().toLowerCase()) {
                case "lipik":
                    // Lipik can only go backward to "Back to Citizen"
                    workFlow.setNextUserId(null);
                    workFlow.setCitizenId(workFlow.getCitizenId());
                    workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                    workFlow.setStatus("Backward to Citizen");
                    break;

                case "section head":
                    // Section Head can go backward to "Lipik" and "Back to Citizen"
                    if (hoardingCategoryTypeMasterId.equals(1L)) {
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                case "deputy municipal commissioner":
                    // DMC can go backward to "Section Head", "Lipik", or "Back to Citizen"
                    if (hoardingCategoryTypeMasterId.equals(1L)) {
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                case "tax superintendent":
                    // TS (Tax Superintendent) for Temporary Hoarding: Always go backward to "Back to Citizen"
                    if (hoardingCategoryTypeMasterId.equals(2L)) {
                        // Temporary Hoarding: Always go to Back to Citizen
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                default:
                    throw new IllegalStateException("Invalid current role for Backward Flow: " + currentRole.getRoleName());
            }
        }

        // Set the mail status and created date after the operation
        workFlow.setMailStatus(1);  // Assuming 1 means mail sent for rejection
        workFlow.setCreatedDate(LocalDateTime.now());

        return advertisementWorkFlowLevelRepository.save(workFlow);
    }

    private AdvertisementWorkFlowLevel handleBackToCitizenInBackWardCaseStatus(AdvertisementWorkFlowLevel workFlow, RoleMaster currentRole, RoleMaster nextRole) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = workFlow.getNextUserId() != null ? workFlow.getNextUserId().getId() : null;
        Long currentUserId = workFlow.getCurrentUserId().getId();

        // Fetch hoarding category type master id (permanent or temporary)
        Long hoardingCategoryTypeMasterId = workFlow.getHoardingCategoryTypeMasterId().getId();

        if (workFlowMaster.getId().equals(5L)) {  // Backward Flow for WorkFlowMasterId = 5 (Water Workflow)

            workFlow.setStatus(workFlowMaster.getStatus());
            workFlow.setStatusCode(workFlowMaster.getStatusCode());

            switch (currentRole.getRoleName().toLowerCase()) {
                case "lipik":
                    // Lipik can only go backward to "Back to Citizen"
                    workFlow.setNextUserId(null);
                    workFlow.setCitizenId(workFlow.getCitizenId());
                    workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                    workFlow.setStatus("Backward to Citizen");
                    break;

                case "section head":
                    // Section Head can go backward to "Lipik" and "Back to Citizen"
                    if (hoardingCategoryTypeMasterId.equals(1L) && isValidRolesForSectionHead(nextRole)) {
                        workFlow.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to " + currentRole.getRoleName());
                    } else {
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                case "deputy municipal commissioner":
                    // DMC can go backward to "Section Head", "Lipik", or "Back to Citizen"
                    if (hoardingCategoryTypeMasterId.equals(1L) && isValidRolesForDeputyMunicipalCommissioner(nextRole)) {
                        workFlow.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to " + currentRole.getRoleName());
                    } else {
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                case "tax superintendent":
                    // TS (Tax Superintendent) for Temporary Hoarding: Always go backward to "Back to Citizen"
                    if (hoardingCategoryTypeMasterId.equals(2L)) {
                        // Temporary Hoarding: Always go to Back to Citizen
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                default:
                    throw new IllegalStateException("Invalid current role for Backward Flow: " + currentRole.getRoleName());
            }
        }

        // Set the mail status and created date after the operation
        workFlow.setMailStatus(1);  // Assuming 1 means mail sent for rejection
        workFlow.setCreatedDate(LocalDateTime.now());

        return advertisementWorkFlowLevelRepository.save(workFlow);
    }

    private boolean isValidRolesForSectionHead(RoleMaster nextRole) {
        // Section Head can go back to "Lipik" and "Back to Citizen"
        return "lipik".equalsIgnoreCase(nextRole.getRoleName()) ||
                "back to citizen".equalsIgnoreCase(nextRole.getRoleName());
    }

    private boolean isValidRolesForDeputyMunicipalCommissioner(RoleMaster nextRole) {
        // Deputy Municipal Commissioner can go back to "Section Head", "Lipik", or "Back to Citizen"
        return "section head".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName()) ||
                "back to citizen".equalsIgnoreCase(nextRole.getRoleName());
    }


    private AdvertisementWorkFlowLevel handleBackToBackOfficeStatus(AdvertisementWorkFlowLevel advertisementWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole) {
        // Fetch WorkFlowMaster for validation
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = advertisementWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = advertisementWorkFlowLevel.getCurrentUserId().getId();

        // Fetch hoarding category type master id (permanent or temporary)
        Long hoardingCategoryTypeMasterId = advertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId();

        if (!workFlowMaster.getId().equals(6L)) {
            throw new IllegalStateException("Invalid workflow operation. Expected 'Back to Back Office' status.");
        }

        advertisementWorkFlowLevel.setStatus(workFlowMaster.getStatus()); // Set status to Backward
        advertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        // Validate nextRole (must be "Back Office")
        if (nextRole == null || !"back office".equalsIgnoreCase(nextRole.getRoleName())) {
            throw new IllegalStateException(currentRole.getRoleName() + " can only backward to Back Office.");
        }

        // Only allow Backward movement to Back Office
        switch (currentRole.getRoleName().toLowerCase()) {
            case "lipik":
            case "section head":
            case "deputy municipal commissioner":
                if (hoardingCategoryTypeMasterId.equals(1L)) {
                    // Set workflow details
                    advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));  // Back to Back Office
                    advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                    break;
                }else {
                    throw new RuntimeException("Hoarding Category type must be permanent");
                }

            case "tax superintendent":
                if (hoardingCategoryTypeMasterId.equals(2L)) {
                    // Set workflow details
                    advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));  // Back to Back Office
                    advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                    break;
                }else {
                    throw new RuntimeException("Hoarding Category type must be Temporary");
                }


            default:
                throw new IllegalStateException(currentRole.getRoleName() + " is not allowed to perform this Backward action.");
        }

        // Set mail status and created date
        advertisementWorkFlowLevel.setMailStatus(1); // Notify user
        advertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
    }

    private AdvertisementWorkFlowLevel handleDocumentVerificationAccept(AdvertisementWorkFlowLevel advertisementWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole) {
        // Fetch the next role based on the workFlowMasterId from the database
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = advertisementWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = advertisementWorkFlowLevel.getCurrentUserId().getId();

        // Set the status and status code from WorkFlowMaster
        advertisementWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        advertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        // Validate nextRole
        if (nextRole == null && !"deputy municipal commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Next role is required but not provided.");
        }

        // Process only if workFlowMasterId is 7 (Document Verification Accept)
        if (workFlowMaster.getId().equals(7L)) {
            switch (currentRole.getRoleName().toLowerCase()) {
                case "back office":
                    if (nextRole.getRoleName().equalsIgnoreCase("lipik")) {
                        advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to Lipik
                        advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    } else {
                        throw new IllegalStateException("Invalid next role for Back Office.");
                    }
                    break;

                case "lipik":
                    if (nextRole.getRoleName().equalsIgnoreCase("section head")) {
                        advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));  // Forward to Section Head
                        advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    } else {
                        throw new IllegalStateException("Invalid next role for Lipik.");
                    }
                    break;

                case "section head":
                    if (nextRole.getRoleName().equalsIgnoreCase("deputy municipal commissioner")) {
                        advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to Deputy Municipal Commissioner
                        advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    } else {
                        throw new IllegalStateException("Invalid next role for Section Head.");
                    }
                    break;

                case "deputy municipal commissioner":
                    advertisementWorkFlowLevel.setStatus("Application Document Successfully Accepted");
                    advertisementWorkFlowLevel.setStatusCode(1002L); // Status Code for "Accepted"
                    advertisementWorkFlowLevel.setNextUserId(null); // No further processing
                    advertisementWorkFlowLevel.setMailStatus(0);
                    System.out.println("appoved status +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                    if (nextRole == null) {
                        throw new IllegalStateException("Next role is required but not provided.");
                    }

                    advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    advertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());

            }
            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId());

        }

        return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
    }
    private void updateApprovedStatus(Long applicationId) {
        List<ViewHoardingDocumentsDetails> documentDetails =
                viewHoardingDocumentsDetailsRepository.findByViewHoardingApplicationMaster_Id(applicationId);

        for(ViewHoardingDocumentsDetails details : documentDetails){

            details.setApprovedStatus(1f); // Set approved_status to 1
            viewHoardingDocumentsDetailsRepository.save(details);
        };
    }

    private AdvertisementWorkFlowLevel handleDocumentVerificationReject(AdvertisementWorkFlowLevel advertisementWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole,List<Long> rejectDocumentIdes) {
        // Fetch the next role based on the workFlowMasterId from the database
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        System.out.println("Current role: " + currentRole);
        System.out.println("Previous role: " + nextRole);

        if (workFlowMaster.getId().equals(8L)) {  // Backward
            advertisementWorkFlowLevel.setStatus(workFlowMaster.getStatus()); // Set to Backward status
            advertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

            // Validate previousRole
            if (nextRole == null) {
                throw new IllegalStateException("Previous role is required but not provided.");
            }

            // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
            if (advertisementWorkFlowLevel.getCitizenId() != null) {
                WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                        .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

                advertisementWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

                updateRejectStatus(advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId(), rejectDocumentIdes);

                return handleBackToCitizenStatus(advertisementWorkFlowLevel, currentRole);  // Handle transition to citizen
            }

            WorkFlowMaster backOfficeMaster = workFlowMasterRepository.findById(6L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 6 not found"));

            advertisementWorkFlowLevel.setWorkFlowMasterId(backOfficeMaster);

            // Call handleBackToBackOfficeStatus for BackOffice rejections
            AdvertisementWorkFlowLevel workFlowLevel1 = handleBackToBackOfficeStatus(advertisementWorkFlowLevel, currentRole, nextRole);


            // Update reject status after returning to back office
            updateRejectStatus(advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId(), rejectDocumentIdes);

            return workFlowLevel1;
        }

        // Update rejected documents for all other roles
        updateRejectStatus(advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId(), rejectDocumentIdes);
        advertisementWorkFlowLevel.setMailStatus(2);

        return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
    }

    /**
     * Update approved_status to 0 for rejected documents
     */
    private void updateRejectStatus(Long applicationMasterId, List<Long> rejectDocumentIdes) {
        if (rejectDocumentIdes == null || rejectDocumentIdes.isEmpty()) {
            System.out.println("No documents to update for rejection.");
            return;
        }

        List<ViewHoardingDocumentsDetails> documentDetails =
                viewHoardingDocumentsDetailsRepository.findAllById(rejectDocumentIdes);

        if (documentDetails.isEmpty()) {
            System.out.println("No matching documents found for rejection.");
            return;
        }

        documentDetails.forEach(details -> details.setApprovedStatus(0f)); // Set approved_status to 0

        // Save all updates in batch
        viewHoardingDocumentsDetailsRepository.saveAll(documentDetails);

        System.out.println("Updated " + documentDetails.size() + " documents to rejected status.");
    }


//    private AdvertisementWorkFlowLevel handleDocumentVerificationReject1(AdvertisementWorkFlowLevel advertisementWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole,List<Long> rejectDocumentIdes) {
//        // Fetch the next role based on the workFlowMasterId from the database
//        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));
//
//        Long nextUserId = advertisementWorkFlowLevel.getNextUserId().getId();
//        Long currentUserId = advertisementWorkFlowLevel.getCurrentUserId().getId();
//
//        // Set the status from WorkFlowMaster to WorkFlow
//        advertisementWorkFlowLevel.setStatus(workFlowMaster.getStatus());
//        advertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
//
//        // Fetch hoarding category type master id (permanent or temporary)
//        Long hoardingCategoryTypeMasterId = advertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId();
//
//        // Validate nextRole
//        if (nextRole == null && !"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
//            throw new IllegalStateException("Next role is required but not provided.");
//        }
//
//        // Logic for backward status (WorkFlowMasterId = 8)
//        if (workFlowMaster.getId().equals(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())) {
//            switch (currentRole.getRoleName().toLowerCase()) {
//                case "lipik":
//                    // Lipik can reject and return to Back Office (Only for permanent hoarding)
//                    if (hoardingCategoryTypeMasterId.equals(1L)) { // Permanent hoarding
//                        if ("back office".equalsIgnoreCase(nextRole.getRoleName())) {
//                            advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId)); // Reject and return to Back Office
//                            advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
//                            advertisementWorkFlowLevel.setStatus("Rejected by Lipik");
//                        } else {
//                            throw new IllegalStateException("Lipik can only reject and return to Back Office.");
//                        }
//                    } else {
//                        throw new IllegalStateException("Lipik role is not valid for temporary hoarding rejection.");
//                    }
//                    break;
//                case "section head":
//                    // Section Head can reject to Lipik or Back Office (Only for permanent hoarding)
//                    if (hoardingCategoryTypeMasterId.equals(1L)) { // Permanent hoarding
//                        if (isValidRoleForSectionHead(nextRole)) {
//                            advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId)); // Reject and return to the selected role
//                            advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
//                            advertisementWorkFlowLevel.setStatus("Rejected by Section Head");
//                        } else {
//                            throw new IllegalStateException("Section Head can only reject to Lipik or Back Office.");
//                        }
//                    } else {
//                        throw new IllegalStateException("Section Head role is not valid for temporary hoarding rejection.");
//                    }
//                    break;
//                case "deputy municipal commissioner":
//                    // DMC can reject to Section Head, Lipik, or Back Office (Only for permanent hoarding)
//                    if (hoardingCategoryTypeMasterId.equals(1L)) { // Permanent hoarding
//                        if (isValidRoleForDMC(nextRole)) {
//                            advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId)); // Reject and return to the selected role
//                            advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
//                            advertisementWorkFlowLevel.setStatus("Rejected by DMC");
//                        } else {
//                            throw new IllegalStateException("DMC can only reject to Section Head, Lipik, or Back Office.");
//                        }
//                    } else {
//                        throw new IllegalStateException("DMC role is not valid for temporary hoarding rejection.");
//                    }
//                    break;
//
//                case "tax superintendent":
//                    // TS (Tax Superintendent) can reject to Back Office (Only for temporary hoarding)
//                    if (hoardingCategoryTypeMasterId.equals(2L)) { // Temporary hoarding
//                        advertisementWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId)); // Reject and return to Back Office
//                        advertisementWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
//                        advertisementWorkFlowLevel.setStatus("Rejected by TS");
//                    } else {
//                        throw new IllegalStateException("Tax Superintendent role is only valid for temporary hoarding rejection.");
//                    }
//                    break;
//
//                default:
//                    throw new IllegalStateException("Invalid current role for Document Verification Reject: " + currentRole.getRoleName());
//            }
//
//            // Set mail status and created date for all cases except TS → ID Generation rejection
//            if (!"deputy municipal commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
//                advertisementWorkFlowLevel.setMailStatus(0);  // Assuming 0 means mail sent for rejection
//                advertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
//            }
//
//            // Update rejection status for the rejected documents
//            updateRejectStatus(advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId(), rejectDocumentIdes);
//            advertisementWorkFlowLevel.setMailStatus(2);
//        }
//
//        // Validate previousRole
//        if (nextRole == null) {
//            throw new IllegalStateException("Previous role is required but not provided.");
//        }
//        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
//        if (advertisementWorkFlowLevel.getCitizenId() != null) {
//            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));
//
//            advertisementWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);
//
//            updateRejectStatus(advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId(), rejectDocumentIdes);
//
//            return handleBackToCitizenStatus(advertisementWorkFlowLevel, currentRole,nextRole);  // Handle transition to citizen
//        }
//
//        return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
//    }

    private boolean isValidRoleForSectionHead(RoleMaster nextRole) {
        // Section Head can go back to Lipik or Back Office
        return "lipik".equalsIgnoreCase(nextRole.getRoleName()) || "back office".equalsIgnoreCase(nextRole.getRoleName());
    }

    private boolean isValidRoleForDMC(RoleMaster nextRole) {
        // DMC can go back to Section Head, Lipik, or Back Office
        return "section head".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName()) ||
                "back office".equalsIgnoreCase(nextRole.getRoleName());
    }

//    private void updateRejectStatus(Long applicationId, List<Long> rejectDocumentIds) {
//        if (rejectDocumentIds == null || rejectDocumentIds.isEmpty()) {
//            System.out.println("No documents to update for rejection.");
//            return;
//        }
//        // Update the reject status for the provided document IDs
//        List<ViewHoardingDocumentsDetails> documentDetails =
//                viewHoardingDocumentsDetailsRepository.findAllById(rejectDocumentIds);
//
//        for (ViewHoardingDocumentsDetails details : documentDetails) {
//            details.setApprovedStatus(0f); // Set approved_status to 0 (rejected)
//            viewHoardingDocumentsDetailsRepository.save(details);
//        }
//    }



    public Long getCurrentRoleMasterId(AdvertisementWorkFlowLevel advertisementWorkFlowLevel) {
        if (advertisementWorkFlowLevel == null || advertisementWorkFlowLevel.getCurrentUserId() == null) {
            throw new IllegalArgumentException("WorkFlow or CurrentUserId cannot be null");
        }
        return userMasterRepository.findById(advertisementWorkFlowLevel.getCurrentUserId().getId())
                .map(UserMaster::getRoleMaster)  // Get RoleMaster directly
                .map(RoleMaster::getId)         // Extract RoleMaster ID
                .orElseThrow(() -> new RuntimeException("RoleMaster not found for User ID: " + advertisementWorkFlowLevel.getCurrentUserId().getId()));
    }


    public Long getNextRoleMasterId(AdvertisementWorkFlowLevel advertisementWorkFlowLevel) {
        if (advertisementWorkFlowLevel == null || advertisementWorkFlowLevel.getNextUserId() == null) {
            throw new IllegalArgumentException("WorkFlow or NextUserId cannot be null");
        }
        UserMaster nextUserId = userMasterRepository.findById(advertisementWorkFlowLevel.getNextUserId().getId())
                .orElseThrow(() -> new RuntimeException("next User not found"));
        Long NextRoleId = nextUserId.getRoleMaster().getId();
        RoleMaster roleMaster = roleMasterRepository.findById(NextRoleId)
                .orElseThrow(() -> new RuntimeException("next Role not found"));
        if (roleMaster == null) {
            throw new RuntimeException("RoleMaster not found for NextUser ID: " + advertisementWorkFlowLevel.getNextUserId().getId());
        }
        return roleMaster.getId();
    }

    public UserMaster getUserMasterByRoleMaster(RoleMaster roleMaster, Long userId) {
        if (roleMaster == null || roleMaster.getId() == null) {
            throw new IllegalArgumentException("RoleMaster or RoleMasterId cannot be null");
        }
//        return userMasterRepository.findFirstByRoleMaster(roleMaster)
//                .orElseThrow(() -> new RuntimeException("No UserMaster found for RoleMaster: " + roleMaster.getRoleName()));
        return userMasterRepository.findFirstByRoleMasterAndId(roleMaster, userId)
                .orElseThrow(() -> new RuntimeException(
                        "No UserMaster found for RoleMaster: " + roleMaster.getRoleName() + " and User ID: " + userId));
    }


    private AdvertisementWorkFlowLevel forwardFromBackOffice(AdvertisementWorkFlowLevel advertisementWorkFlowLevel) {

        Long hoardingApplicationMasterId = advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId();
        if (hoardingApplicationMasterId == null) {
            throw new IllegalArgumentException("hoardingApplicationMaster ID cannot be null");
        }
        Long statusCode = advertisementWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        AdvertisementWorkFlowLevel latestWorkFlow = advertisementWorkFlowLevelRepository
                .findLatestWorkFlowByHoardingApplicationMasterIdAndStatusCode(hoardingApplicationMasterId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for licenseDetails ID: " + hoardingApplicationMasterId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1005) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            advertisementWorkFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            advertisementWorkFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
//        workFlowLevel.setStatus(workFlowMaster.getStatus());
            advertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            advertisementWorkFlowLevel.setStatus("Forwarded from Back Office");
            advertisementWorkFlowLevel.setMailStatus(1);
            advertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            updateApprovedStatus(advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId());

            return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }
    private AdvertisementWorkFlowLevel forwardFromBackWard(AdvertisementWorkFlowLevel advertisementWorkFlowLevel) {

        Long hoardingApplicationMasterId = advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId();
        if (hoardingApplicationMasterId == null) {
            throw new IllegalArgumentException("hoardingApplicationMaster ID cannot be null");
        }
        Long statusCode = advertisementWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        AdvertisementWorkFlowLevel latestWorkFlow = advertisementWorkFlowLevelRepository
                .findLatestWorkFlowByHoardingApplicationMasterIdAndStatusCode(hoardingApplicationMasterId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for licenseDetails ID: " + hoardingApplicationMasterId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1001) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            advertisementWorkFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            advertisementWorkFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
//        workFlowLevel.setStatus(workFlowMaster.getStatus());
            advertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            advertisementWorkFlowLevel.setStatus("Forwarded from Back Office");
            advertisementWorkFlowLevel.setMailStatus(1);
            advertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            updateApprovedStatus(advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId());

            return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private AdvertisementWorkFlowLevel forwardFromCitizen(AdvertisementWorkFlowLevel advertisementWorkFlowLevel) {

        Long hoardingApplicationMasterId = advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId();
        if (hoardingApplicationMasterId == null) {
            throw new IllegalArgumentException("hoardingApplicationMaster ID cannot be null");
        }
        Long statusCode = advertisementWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        AdvertisementWorkFlowLevel latestWorkFlow = advertisementWorkFlowLevelRepository
                .findLatestWorkFlowByHoardingApplicationMasterIdAndStatusCode(hoardingApplicationMasterId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for hoardingApplicationMaster ID: " + hoardingApplicationMasterId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1004) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            advertisementWorkFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            advertisementWorkFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(advertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
//        workFlowLevel.setStatus(workFlowMaster.getStatus());
            advertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            advertisementWorkFlowLevel.setStatus("Forwarded from Citizen");
            advertisementWorkFlowLevel.setMailStatus(1);
            advertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            updateApprovedStatus(advertisementWorkFlowLevel.getHoardingApplicationMasterId().getId());

            return advertisementWorkFlowLevelRepository.save(advertisementWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    @Override
    public List<RemarksDto> getRemarksByApplicationId(Long applicationId) {
        return advertisementWorkFlowLevelRepository.findByHoardingApplicationMasterId_Id(applicationId).stream()
                .filter(level -> level.getRemarks() != null)
                .sorted(Comparator.comparing(AdvertisementWorkFlowLevel::getCreatedDate))
                .map(level -> new RemarksDto(
                        level.getRemarks(),
                        level.getCreatedDate(),
                        level.getCurrentUserId() != null ? level.getCurrentUserId().getRoleMaster().getRoleName(): "UNKNOWN",
                        level.getCurrentUserId() != null ? level.getCurrentUserId().getNameOfUser(): "UNKNOWN",
                        level.getNextUserId() != null ? level.getNextUserId().getRoleMaster().getRoleName(): "UNKNOWN",
                        level.getNextUserId() != null ? level.getNextUserId().getNameOfUser(): "UNKNOWN"
                ))
                .collect(Collectors.toList());
    }
}

