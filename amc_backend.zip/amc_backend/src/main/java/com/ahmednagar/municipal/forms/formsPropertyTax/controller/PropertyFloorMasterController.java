package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyFloorMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyFloorMasterService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/forms")
public class PropertyFloorMasterController {

    @Autowired
    PropertyFloorMasterService propertyFloorMasterService;

    private static final Logger logger = LoggerFactory.getLogger(PropertyDemandMasterController.class);

    // single entity creation method
    @PostMapping("/createPropertyFloorMasterSingle")
    public ResponseEntity<PropertyFloorMaster> createPropertyFloor(@Valid @RequestBody PropertyFloorMaster propertyFloorMaster) {
        PropertyFloorMaster newPropertyFloor = propertyFloorMasterService.createPropertyFloorMaster(propertyFloorMaster);
        return ResponseEntity.ok(newPropertyFloor);
    }

    // list of entity creation method
    @PostMapping("/createPropertyFloorMaster")
    public ResponseEntity<?> createPropertyFloorMasters(@Valid @RequestBody List<PropertyFloorMaster> propertyFloorMaster) {
        try {
            List<PropertyFloorMaster> newPropertyFloorMasterList = propertyFloorMasterService.createPropertyFloorMasterList(propertyFloorMaster);
            return ResponseEntity.ok(newPropertyFloorMasterList);
        } catch (IllegalArgumentException e) {
            logger.error("error creating PropertyFloorMaster: " + e.getMessage(), e);
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            logger.error("unexpected error: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "An unexpected error occurred"));
        }
    }

    // list of entity creation method
//    @PostMapping("/createPropertyFloorMaster")
//    public ResponseEntity<List<PropertyFloorMaster>> createPropertyFloorMasters(@Valid @RequestBody List<PropertyFloorMaster> propertyFloorMasterList) {
//        try {
//            List<PropertyFloorMaster> newPropertyFloorMasterList = propertyFloorMasterService.createPropertyFloorMasterList(propertyFloorMasterList);
//            return ResponseEntity.ok(newPropertyFloorMasterList);
//        } catch (IllegalArgumentException e) {
//            return ResponseEntity.badRequest().body(List.of());
//        }
//    }

    @GetMapping("/getAllPropertyFloorMaster")
    public ResponseEntity<List<PropertyFloorMaster>> getAllPropertyFloor() {
        return ResponseEntity.ok(propertyFloorMasterService.getAllPropertyFloorMaster());
    }

    @GetMapping("/propertyFloorMaster/{id}")
    public ResponseEntity<Object> getPropertyFloorById(@PathVariable Long id) {
        Optional<PropertyFloorMaster> propertyFloor = propertyFloorMasterService.getPropertyFloorMasterById(id);
        if (propertyFloor.isPresent()) {
            return ResponseEntity.ok(propertyFloor.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getPropertyFloorMasterByMunicipalId/{municipalId}")
    public List<PropertyFloorMaster> getPropertyFloorByMunicipalId(@PathVariable int municipalId) {
        return propertyFloorMasterService.getPropertyFloorMasterByMunicipalId(municipalId);
    }

    @PatchMapping("/propertyFloorMaster/suspendedStatus/{id}")
    public ResponseEntity<PropertyFloorMaster> patchPropertyFloorSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        PropertyFloorMaster patchedPropertyFloor = propertyFloorMasterService.patchPropertyFloorMasterSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedPropertyFloor);
    }

    @PutMapping(value = "/updatePropertyFloorMasterById/{id}")
    public ResponseEntity<ApiResponse> updatePropertyFloorMasterById(@PathVariable Long id,
                                                                     @RequestBody PropertyFloorMaster updatedFloorMaster) {
        try {
            PropertyFloorMaster updatedPropertyFloorMaster = propertyFloorMasterService.updatePropertyFloorMasterById(id, updatedFloorMaster);
            return ResponseEntity.ok(new ApiResponse("Property Floor Master updated successfully!", true, updatedPropertyFloorMaster));
        } catch (IllegalArgumentException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An internal error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/deletePropertyFloorMaster/{municipalPropertyMasterId}")
    public ResponseEntity<String> deletePropertyFloorMaster(@PathVariable Long municipalPropertyMasterId) {
        try {
            propertyFloorMasterService.deletePropertyFloorMasterByMunicipalPropertyMasterId(municipalPropertyMasterId);
            return ResponseEntity.ok("PropertyFloorMaster details records deleted successfully for MunicipalPropertyMaster id: " + municipalPropertyMasterId);
        } catch (Exception ex) {
            return ResponseEntity.status(500).body("An unexpected error occurred: " + ex.getMessage());
        }
    }

}
