package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.UserMasterDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserMasterDetailsRepository extends JpaRepository<UserMasterDetails, Long> {

    List<UserMasterDetails> findByMunicipalId(Long municipalId);

}
