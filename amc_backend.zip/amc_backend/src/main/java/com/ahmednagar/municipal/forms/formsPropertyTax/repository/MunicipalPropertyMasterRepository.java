package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface MunicipalPropertyMasterRepository extends JpaRepository<MunicipalPropertyMaster, Long> {

    List<MunicipalPropertyMaster> findByApplicationNo(String applicationNo);

    List<MunicipalPropertyMaster> findByMunicipalId(int municipalId);

    List<MunicipalPropertyMaster> findByZoneIdAndZoneWardIdAndHoldingNo(Long zoneId, Long zoneWard, String holdingNo);

}
