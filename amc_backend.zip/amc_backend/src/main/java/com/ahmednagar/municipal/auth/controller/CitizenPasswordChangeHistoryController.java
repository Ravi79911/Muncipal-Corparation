package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.CitizenPasswordChangeHistory;
import com.ahmednagar.municipal.auth.model.UserMasterPasswordChangeHistory;
import com.ahmednagar.municipal.auth.service.CitizenPasswordChangeHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/auth")
public class CitizenPasswordChangeHistoryController {

    @Autowired
    CitizenPasswordChangeHistoryService citizenPasswordChangeHistoryService;

    @GetMapping("/getCitizenPasswordChangeHistoryByUserMasterId/{citizenId}")
    public List<CitizenPasswordChangeHistory> getHistoryByUserMasterId(@PathVariable Long citizenId) {
        return citizenPasswordChangeHistoryService.findPasswordChangeHistoryWithCitizenId(citizenId);
    }

    @GetMapping("/getAllCitizenPasswordChangeHistory")
    public ResponseEntity<List<CitizenPasswordChangeHistory>> getAllCitizenPasswordChanges() {
        List<CitizenPasswordChangeHistory> userPasswordChangeHistory = citizenPasswordChangeHistoryService.getAllCitizenPasswordChanges();
        return ResponseEntity.ok(userPasswordChangeHistory);
    }

}
