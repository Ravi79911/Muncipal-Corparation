package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.MenuMaster;
import com.ahmednagar.municipal.auth.service.MenuMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class MenuMasterController {

    @Autowired
    MenuMasterService menuMasterService;

    @PostMapping("/createMenuMaster")
    public ResponseEntity<MenuMaster> createMenu(@Valid @RequestBody MenuMaster menuMaster) {
        MenuMaster createdMenuMaster = menuMasterService.saveMenu(menuMaster);
        if (createdMenuMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdMenuMaster);
    }

    @GetMapping("/getAllMenuMaster")
    public ResponseEntity<List<MenuMaster>> getAllMenu() {
        List<MenuMaster> menuMasters = menuMasterService.findAllMenu();
        return ResponseEntity.ok(menuMasters);
    }

    @GetMapping("/getAllMenuMasterByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllMenuByMunicipalId(@PathVariable Long municipalId) {
        List<MenuMaster> menuMasters = menuMasterService.findAllMenuByMunicipalId(municipalId);
        if (menuMasters.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No menu found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(menuMasters);
    }

    @PutMapping("/menuMaster/update/{id}")
    public ResponseEntity<MenuMaster> updateMenu(@PathVariable("id") Long id, @RequestBody MenuMaster updatedMenuMaster) {
        try {
            MenuMaster updated = menuMasterService.updateMenu(id, updatedMenuMaster);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/menuMaster/suspendedStatus/{id}")
    public ResponseEntity<MenuMaster> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        MenuMaster updatedMenuMaster = menuMasterService.changeSuspendedStatus(id, status);
        if (updatedMenuMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedMenuMaster);
    }

}

