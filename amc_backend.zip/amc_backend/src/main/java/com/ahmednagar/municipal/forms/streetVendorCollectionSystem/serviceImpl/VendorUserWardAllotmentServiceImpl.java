package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserWardAllotment;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorUserWardAllotmentRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorUserWardAllotmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class VendorUserWardAllotmentServiceImpl implements VendorUserWardAllotmentService {

    @Autowired
    private VendorUserWardAllotmentRepository vendorUserWardAllotmentRepository;

    @Override
    public VendorUserWardAllotment saveUserWardAllotment(VendorUserWardAllotment vendorUserWardAllotment) {
        vendorUserWardAllotment.setCreatedDate(LocalDateTime.now());
        vendorUserWardAllotment.setSuspendedStatus(0);
        return vendorUserWardAllotmentRepository.save(vendorUserWardAllotment);
    }

    @Override
    public Optional<VendorUserWardAllotment> getUserWardAllotment(Long id) {
        return vendorUserWardAllotmentRepository.findById(id);
    }
}
