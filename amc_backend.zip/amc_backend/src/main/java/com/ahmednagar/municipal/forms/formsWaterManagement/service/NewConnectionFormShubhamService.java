package com.ahmednagar.municipal.forms.formsWaterManagement.service;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.NewConnectionFormShubham;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface NewConnectionFormShubhamService {

    NewConnectionFormShubham saveNewConnectionFormShubham(NewConnectionFormShubham newConnectionFormShubham,int createdBy);

    NewConnectionFormShubham deleteNewConnectionForm(int id, int suspendedStatus);

    List<NewConnectionFormShubham> findByMunicipalId(int municipalId);

}
