package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.model.MenuMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MenuMasterService {

    MenuMaster saveMenu(MenuMaster menuMaster);

    List<MenuMaster> findAllMenu();

    List<MenuMaster> findAllMenuByMunicipalId(Long municipalId);

    MenuMaster updateMenu(Long id, MenuMaster updatedMenuMaster);

    MenuMaster changeSuspendedStatus(Long id, int status);

}
