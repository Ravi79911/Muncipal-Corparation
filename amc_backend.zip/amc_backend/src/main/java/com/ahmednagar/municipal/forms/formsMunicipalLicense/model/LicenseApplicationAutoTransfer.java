package com.ahmednagar.municipal.forms.formsMunicipalLicense.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb3_license_application_auto_transfer")
public class LicenseApplicationAutoTransfer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @NotNull(message = "Application Master ID cannot be null")
    @Column(name = "application_master_id")
    private Long applicationMasterId;

    @NotNull(message = "Transfer Time cannot be null")
    @Column(name = "transfer_time")
    private LocalDateTime transferTime;

    @NotNull(message = "Transferred From Stage cannot be null")
    @Size(max = 50, message = "Transferred From Stage cannot exceed 50 characters")
    @Column(name = "transferred_from_stage")
    private String transferredFromStage;

    @NotNull(message = "Transferred To Stage cannot be null")
    @Size(max = 50, message = "Transferred To Stage cannot exceed 50 characters")
    @Column(name = "transferred_to_stage")
    private String transferredToStage;

    @NotNull(message = "Reason cannot be null")
    @Column(name = "reason")
    private String reason;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private int updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private Long municipalId;

    @ManyToOne
    @JoinColumn(name = "application_workflow_id",nullable = false,referencedColumnName = "id")
    private LicenseApplicationWorkflow applicationWorkflowId;
}
