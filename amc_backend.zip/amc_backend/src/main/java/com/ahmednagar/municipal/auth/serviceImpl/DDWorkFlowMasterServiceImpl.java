package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.DDWorkFlowMasterDto;
import com.ahmednagar.municipal.auth.model.DDWorkFlowMaster;
import com.ahmednagar.municipal.auth.repository.DDWorkFlowMasterRepository;
import com.ahmednagar.municipal.auth.service.DDWorkFlowMasterService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DDWorkFlowMasterServiceImpl implements DDWorkFlowMasterService {

    @Autowired
    private DDWorkFlowMasterRepository ddWorkFlowMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<DDWorkFlowMasterDto> findAllDDWorkFlowMaster() {
        List<DDWorkFlowMaster> ddWorkFlowMasters = ddWorkFlowMasterRepository.findAll();
        return ddWorkFlowMasters.stream()
                .map(ddWorkFlowMaster -> modelMapper.map(ddWorkFlowMaster, DDWorkFlowMasterDto.class))
                .collect(Collectors.toList());
    }
}
