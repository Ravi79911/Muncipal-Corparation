package com.ahmednagar.municipal.forms.formsPropertyTax.model;

import com.ahmednagar.municipal.master.propertyTax.model.PropertyTaxCessRateMaster;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name = "tbl_muni_property_calculation_details_educess")
public class PropertyCalculationDetailsEduCess {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "created by can't be null")
    @Column(name = "created_by", nullable = false)
    private int createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @NotNull(message = "municipal id can't be null")
    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
    private MunicipalPropertyMaster municipalPropertyMaster;

    @ManyToOne
    @JoinColumn(name = "cess_head_mas_id", referencedColumnName = "id", nullable = false)
    private PropertyTaxCessRateMaster propertyTaxCessRateMaster;

}
