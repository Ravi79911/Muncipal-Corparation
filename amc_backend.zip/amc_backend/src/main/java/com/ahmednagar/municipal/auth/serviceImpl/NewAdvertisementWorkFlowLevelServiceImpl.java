package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.AdvertisementWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.NewAdvertisementWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.*;
import com.ahmednagar.municipal.auth.service.AdvertisementRolesDataFlowSetupService;
import com.ahmednagar.municipal.auth.service.AdvertisementTemporaryRolesDataFlowSetupService;
import com.ahmednagar.municipal.auth.service.NewAdvertisementWorkFlowLevelService;
import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class NewAdvertisementWorkFlowLevelServiceImpl implements NewAdvertisementWorkFlowLevelService {

    @Autowired
    private NewAdvertisementWorkFlowLevelRepository newAdvertisementWorkFlowLevelRepository;

    @Autowired
    private RoleMasterRepository roleMasterRepository;

    @Autowired
    private WorkFlowMasterRepository workFlowMasterRepository;

    @Autowired
    private AdvertisementRolesDataFlowSetupService advertisementRolesDataFlowSetupService;

    @Autowired
    private AdvertisementTemporaryRolesDataFlowSetupService advertisementTemporaryRolesDataFlowSetupService;

    @Autowired
    private UserMasterRepository userMasterRepository;

    @Autowired
    private CitizenSignUpRepository citizenSignUpRepository;

    @Autowired
    private ViewHoardingApplicationMasterRepository viewHoardingApplicationMasterRepository;

    @Autowired
    private ViewHoardingApplicationDetailsRepository viewHoardingApplicationDetailsRepository;

    @Autowired
    private ViewHoardingCategoryTypeMasterSetupRepository viewHoardingCategoryTypeMasterSetupRepository;

    @Autowired
    private ViewHoardingDocumentsDetailsRepository viewHoardingDocumentsDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    public UserMaster getLipikForAdvertisementCitizen(Long citizenId , Long hoardingCategoryTypeMasterId) {
        if(hoardingCategoryTypeMasterId.equals(1L)) { // Permanent Hoarding
            Long roleId = 1L; // Role ID for Lipik

            CitizenSignUpMaster citizen = citizenSignUpRepository.findById(citizenId)
                    .orElseThrow(() -> new EntityNotFoundException("Citizen not found with ID: " + citizenId));

            // Fetch the first Lipik (UserMaster) matching Zone, Ward, Role
            return userMasterRepository.findFirstByZoneWardAndRole(citizen.getZoneId(), citizen.getWardId(), roleId)
                    .orElseThrow(() -> new EntityNotFoundException("No Lipik found for Zone: " + citizen.getZoneId()
                            + " and Ward: " + citizen.getWardId()));
        }else {
            Long roleId = 5L; // Role ID for TS

            CitizenSignUpMaster citizen = citizenSignUpRepository.findById(citizenId)
                    .orElseThrow(() -> new EntityNotFoundException("Citizen not found with ID: " + citizenId));

            // Fetch the first TS (UserMaster) matching Zone, Ward, Role
            return userMasterRepository.findFirstByZoneWardAndRole(citizen.getZoneId(), citizen.getWardId(), roleId)
                    .orElseThrow(() -> new EntityNotFoundException("No TS found for Zone: " + citizen.getZoneId()
                            + " and Ward: " + citizen.getWardId()));
        }
    }

    @Override
    public NewAdvertisementWorkFlowLevel createNewApplicationTransation(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevelRequest) {

        Long citizenId = newAdvertisementWorkFlowLevelRequest.getCitizenId().getId();

        Long hoardingCategoryTypeMasterId = newAdvertisementWorkFlowLevelRequest.getHoardingCategoryTypeMasterId().getId();
        UserMaster newApplicationLipik = getLipikForAdvertisementCitizen(citizenId, hoardingCategoryTypeMasterId);

        // Fetch next role dynamically (e.g., based on workflow or hardcoded logic)
        RoleMaster currentRole = roleMasterRepository.findByRoleName("CITIZEN")
                .orElseThrow(() -> new RuntimeException("Role 'CITIZEN' not found"));

        // Fetch next role (e.g., LIPIK)
        RoleMaster nextRole = roleMasterRepository.findByRoleName("LIPIK")
                .orElseThrow(() -> new RuntimeException("Role 'LIPIK' not found"));


        // Validate WorkFlow Master
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newAdvertisementWorkFlowLevelRequest.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Master not found"));

        ViewHoardingApplicationMaster existingApplication = viewHoardingApplicationMasterRepository.findById(newAdvertisementWorkFlowLevelRequest.getHoardingApplicationMasterId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Hoarding Application not found with ID: " + newAdvertisementWorkFlowLevelRequest.getHoardingApplicationMasterId().getId()));

        ViewHoardingApplicationDetails existingApplicationFirmDetails = (ViewHoardingApplicationDetails) viewHoardingApplicationDetailsRepository.findByHoardingApplicationMasterId(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Hoarding Application Details not found with ID: " + newAdvertisementWorkFlowLevelRequest.getHoardingApplicationMasterId().getId()));


        // Build WorkFlowLevel Object with Defaults
        NewAdvertisementWorkFlowLevel newWorkFlow = NewAdvertisementWorkFlowLevel.builder()
                .hoardingApplicationMasterId(newAdvertisementWorkFlowLevelRequest.getHoardingApplicationMasterId())
                .hoardingCategoryTypeMasterId(newAdvertisementWorkFlowLevelRequest.getHoardingCategoryTypeMasterId())
                .currentUserId(null)
                .nextUserId(newApplicationLipik)
                .nextRoleId(nextRole)
                .workFlowMasterId(workFlowMaster)
                .status("NEW") // Default status for new applications
                .currentRoleId(currentRole)
                .statusCode(1000L) // Example status code
                .createdBy(newAdvertisementWorkFlowLevelRequest.getCreatedBy())
                .createdDate(LocalDateTime.now())
                //.mailStatus(newAdvertisementWorkFlowLevelRequest.getMailStatus())
                .mailStatus(1)
                .remarks(newAdvertisementWorkFlowLevelRequest.getRemarks())
                .municipalId(newAdvertisementWorkFlowLevelRequest.getMunicipalId())
                .wardId(existingApplicationFirmDetails.getWardId().getId())
                .zoneId(existingApplicationFirmDetails.getZoneId().getId())
                .citizenId(newAdvertisementWorkFlowLevelRequest.getCitizenId())
                .build();
        updateApprovedStatus(newAdvertisementWorkFlowLevelRequest.getHoardingApplicationMasterId().getId());

        // Save Workflow to Database
        return newAdvertisementWorkFlowLevelRepository.save(newWorkFlow);
    }

    @Override
    public List<NewAdvertisementWorkFlowLevelDto> findAllWorkFlow() {
        List<NewAdvertisementWorkFlowLevel> newAdvertisementWorkFlowLevels = newAdvertisementWorkFlowLevelRepository.findAll();

        return newAdvertisementWorkFlowLevels.stream().map(advertisementWorkFlowLevel -> {
            NewAdvertisementWorkFlowLevelDto dto = modelMapper.map(newAdvertisementWorkFlowLevels, NewAdvertisementWorkFlowLevelDto.class);

            // Manually map UserMaster to UserMasterDTO
            if (advertisementWorkFlowLevel.getCurrentUserId() != null) {
                dto.setCurrentUserId(modelMapper.map(advertisementWorkFlowLevel.getCurrentUserId(), UserMasterDTO.class));
            }
            if (advertisementWorkFlowLevel.getNextUserId() != null) {
                dto.setNextUserId(modelMapper.map(advertisementWorkFlowLevel.getNextUserId(), UserMasterDTO.class));
            }

            return dto;
        }).collect(Collectors.toList());
    }

    public UserMaster getNextRoleForApplication(ViewHoardingApplicationDetails existingApplication, RoleMaster nextRoleId) {

        Long roleId = nextRoleId.getId(); // Role ID for Lipik

        // Fetch the first UserId matching with Zone, Ward, Role provided
        return userMasterRepository.findFirstByZoneWardAndRole(existingApplication.getZoneId().getId(), existingApplication.getWardId().getId(), roleId)
                .orElseThrow(() -> new EntityNotFoundException("No "+ nextRoleId.getRoleName() +" found for Zone: " + existingApplication.getZoneId() + " and Ward: " + existingApplication.getWardId()));


    }

    private RoleMaster loadRoleOrThrow(RoleMaster role, String label) {                                                 // check if role exists
        if (role == null || role.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return roleMasterRepository.findById(role.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + role.getId() + " not found"));
    }

    private UserMaster loadUserOrThrow(UserMaster user, String label) {                                                  // check if user exists
        if (user == null || user.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return userMasterRepository.findById(user.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + user.getId() + " not found"));
    }

    private WorkFlowMaster loadWorkflowMasterOrThrow(WorkFlowMaster workflow, String label) {                           // check if workflow exists
        if (workflow == null || workflow.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return workFlowMasterRepository.findById(workflow.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + workflow.getId() + " not found"));
    }

    private void validateNoTerminalStateExists(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel) {                                     //check application "Accept or "Reject" status
        List<NewAdvertisementWorkFlowLevel> existingWorkflows =
                newAdvertisementWorkFlowLevelRepository.findByHoardingApplicationMasterId(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId());

        for (NewAdvertisementWorkFlowLevel wf : existingWorkflows) {
            if (wf.getStatusCode() == null) continue;

            switch (wf.getStatusCode().intValue()) {
                case 1002 -> throw new IllegalStateException("This application has already been Accepted.");
                case 1003 -> throw new IllegalStateException("This application has already been Rejected.");
            }
        }
    }


    @Override
    public NewAdvertisementWorkFlowLevel handleWorkFlowTransition(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel) {
        // 1. Validate and Load Current Role
        RoleMaster currentRole = loadRoleOrThrow(
                newAdvertisementWorkFlowLevel.getCurrentRoleId(), "Current Role");

        // 2. Optionally Load Next Role
        RoleMaster nextRole = null;
        if (newAdvertisementWorkFlowLevel.getNextRoleId() != null && newAdvertisementWorkFlowLevel.getNextRoleId().getId() != null) {
            nextRole = loadRoleOrThrow(newAdvertisementWorkFlowLevel.getNextRoleId(), "Next Role");
        }

        // 3. Load Current User
        UserMaster currentUser = loadUserOrThrow(
                newAdvertisementWorkFlowLevel.getCurrentUserId(), "Current User");

        List<Long> rejectedDocumentIds = newAdvertisementWorkFlowLevel.getRejectedDocumentIdes();

        // 4. Prevent redundant transitions
        validateNoTerminalStateExists(newAdvertisementWorkFlowLevel);

        // 5. Load Workflow Status
        WorkFlowMaster currentStatus = loadWorkflowMasterOrThrow(
                newAdvertisementWorkFlowLevel.getWorkFlowMasterId(), "Workflow Master");

        // 6. Handle transition based on status
        return switch (currentStatus.getStatus().toUpperCase()) {
            case "FORWARDED" -> forward(newAdvertisementWorkFlowLevel, currentStatus, currentRole, currentUser);

            case "BACKWARD" -> handleBackward(newAdvertisementWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser);

            case "ACCEPT" -> handleAcceptStatus(newAdvertisementWorkFlowLevel, currentRole, currentUser);

            case "REJECT" -> handleRejectStatus(newAdvertisementWorkFlowLevel, currentRole, currentUser);

            case "BACK TO CITIZEN" -> handleBackToCitizenStatus(newAdvertisementWorkFlowLevel, currentRole);

            case "BACK TO BACK OFFICE" -> handleBackToBackOfficeStatus(newAdvertisementWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser);

            case "DOCUMENT VERIFICATION ACCEPT" -> handleDocumentVerificationAccept(newAdvertisementWorkFlowLevel, currentStatus, currentRole, currentUser);

            case "DOCUMENT VERIFICATION REJECT" -> handleDocumentVerificationReject(newAdvertisementWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser, rejectedDocumentIds);

            default -> throw new IllegalArgumentException("Unsupported workflow status: " + currentStatus.getStatus());
        };
    }

    private NewAdvertisementWorkFlowLevel forward(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newAdvertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (newAdvertisementWorkFlowLevel.getStatusCode() == 1001) {
            return forwardFromBackWard(newAdvertisementWorkFlowLevel);
        } else if (newAdvertisementWorkFlowLevel.getStatusCode() == 1007) {
            return forwardFromBackOffice(newAdvertisementWorkFlowLevel);
        } else if (newAdvertisementWorkFlowLevel.getStatusCode() == 1004) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromCitizen(newAdvertisementWorkFlowLevel);
        } else {

            if (currentRole == null) {
                throw new IllegalStateException("Current role is required for forward action.");
            }

            if (currentUser == null || currentUser.getRoleMaster() == null) {
                throw new IllegalStateException("Current user or user's role is missing.");
            }

            if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
                String username = currentUser.getUsername();
                throw new SecurityException("User '" + username + "' is not authorized to perform forward action.");
            }

            Long applicationId = newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId();

            // Fetch application and firm details
            ViewHoardingApplicationMaster existingApplication = viewHoardingApplicationMasterRepository.findById(applicationId)
                    .orElseThrow(() -> new EntityNotFoundException("Hoarding Application not found with ID: " + applicationId));

            ViewHoardingApplicationDetails existingApplicationFirmDetails = (ViewHoardingApplicationDetails) viewHoardingApplicationDetailsRepository
                    .findByHoardingApplicationMasterId(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Hoarding Application Details not found with ID: " + applicationId));

            // Get the categoryId from the object (not the object itself!)
            Long categoryId = newAdvertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId();

            RoleMaster nextRole;

            if (categoryId == 1L) {
                // Permanent
                AdvertisementRolesDataFlowSetup setup = advertisementRolesDataFlowSetupService
                        .getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);
                if (setup == null || setup.getNextRoleId() == null) {
                    throw new IllegalStateException("No next role found for Permanent category.");
                }
                nextRole = roleMasterRepository.findById(setup.getNextRoleId())
                        .orElseThrow(() -> new RuntimeException("Next role not found for Permanent category."));
            } else if (categoryId == 2L) {
                // Temporary
                AdvertisementTemporaryRolesDataFlowSetup setup = advertisementTemporaryRolesDataFlowSetupService
                        .getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);
                if (setup == null || setup.getNextRoleId() == null) {
                    throw new IllegalStateException("No next role found for Temporary category.");
                }
                nextRole = roleMasterRepository.findById(setup.getNextRoleId())
                        .orElseThrow(() -> new RuntimeException("Next role not found for Temporary category."));
            } else {
                throw new IllegalStateException("Unsupported category type ID: " + categoryId);
            }

            // Get the next user for this role
            UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, nextRole);

            // Set the values in the workflow level entity
            newAdvertisementWorkFlowLevel.setNextUserId(nextUser);
            newAdvertisementWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
            newAdvertisementWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
            newAdvertisementWorkFlowLevel.setNextRoleId(nextRole);
            newAdvertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            newAdvertisementWorkFlowLevel.setStatusCode(currentStatus.getStatusCode());
            newAdvertisementWorkFlowLevel.setStatus(currentStatus.getStatus());
            newAdvertisementWorkFlowLevel.setMailStatus(1);

            return newAdvertisementWorkFlowLevelRepository.save(newAdvertisementWorkFlowLevel);
        }
    }

    private NewAdvertisementWorkFlowLevel handleBackward(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newAdvertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }

        Long categoryId = newAdvertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId(); // get from ViewHoardingCategoryTypeMasterSetup
        List<Long> validRoleIds;

        if (categoryId == 1L) {
            // Permanent
            List<AdvertisementRolesDataFlowSetup> validNextRoles = advertisementRolesDataFlowSetupService
                    .getNextRoleListForListSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

            if (validNextRoles.isEmpty()) {
                throw new IllegalStateException("No valid backward roles found for Permanent category.");
            }

            boolean isValidNextRole = validNextRoles.stream()
                    .anyMatch(role -> role.getNextRoleId().equals(nextRole.getId()));

            if (!isValidNextRole) {
                throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() + ") is not valid for backward action in Permanent category.");
            }

            validRoleIds = validNextRoles.stream().map(AdvertisementRolesDataFlowSetup::getNextRoleId).collect(Collectors.toList());

        } else if (categoryId == 2L) {
            // Temporary
            List<AdvertisementTemporaryRolesDataFlowSetup> validNextRoles = advertisementTemporaryRolesDataFlowSetupService
                    .getNextRoleListForListSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

            if (validNextRoles.isEmpty()) {
                throw new IllegalStateException("No valid backward roles found for Temporary category.");
            }

            boolean isValidNextRole = validNextRoles.stream()
                    .anyMatch(role -> role.getNextRoleId().equals(nextRole.getId()));

            if (!isValidNextRole) {
                throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() + ") is not valid for backward action in Temporary category.");
            }

            validRoleIds = validNextRoles.stream().map(AdvertisementTemporaryRolesDataFlowSetup::getNextRoleId).collect(Collectors.toList());

        } else {
            throw new IllegalStateException("Unsupported category type ID: " + categoryId);
        }

        List<RoleMaster> nextRoles = roleMasterRepository.findAllById(validRoleIds);

        ViewHoardingApplicationMaster existingApplication = viewHoardingApplicationMasterRepository
                .findById(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Hoarding Application not found with ID: " + newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

        ViewHoardingApplicationDetails existingApplicationFirmDetails = (ViewHoardingApplicationDetails) viewHoardingApplicationDetailsRepository
                .findByHoardingApplicationMasterId(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Hoarding Application Details not found with ID: " + newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

        UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, nextRole);

        // Validate previousRole
        if (nextRoles == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }
        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
        if (newAdvertisementWorkFlowLevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            newAdvertisementWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

            //updateRejectStatus(licenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);

            return handleBackToCitizenStatus(newAdvertisementWorkFlowLevel, nextRole);  // Handle transition to citizen
        }

        newAdvertisementWorkFlowLevel.setNextUserId(nextUser);
        newAdvertisementWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
        newAdvertisementWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
        newAdvertisementWorkFlowLevel.setNextRoleId(nextRole);
        newAdvertisementWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        newAdvertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        newAdvertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newAdvertisementWorkFlowLevel.setMailStatus(2);

        return newAdvertisementWorkFlowLevelRepository.save(newAdvertisementWorkFlowLevel);
    }

    private NewAdvertisementWorkFlowLevel handleAcceptStatus(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel, RoleMaster currentRole,UserMaster currentUser) {

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Accept action.");
        }

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newAdvertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (workFlowMaster.getId().equals(3L)) {  // Accept
            newAdvertisementWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            newAdvertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        }

        // Fetch hoarding category type master id (permanent or temporary)
        Long hoardingCategoryTypeMasterId = newAdvertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId();

        // Ensure the correct role based on hoarding type
        if (hoardingCategoryTypeMasterId.equals(1L)) { // Permanent Hoarding
            // Only Deputy Municipal Commissioner can accept for permanent hoarding
            if (!"Deputy Municipal Commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Only Deputy Municipal Commissioner can accept the application for permanent hoarding.");
            }
        } else if (hoardingCategoryTypeMasterId.equals(2L)) { // Temporary Hoarding
            // Only TS (Tax Superintendent) can accept for temporary hoarding
            if (!"Tax Superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Only Tax Superintendent can accept the application for temporary hoarding.");
            }
        } else {
            throw new IllegalStateException("Invalid hoarding category type for acceptance.");
        }

        // Update status to "Accepted"
        newAdvertisementWorkFlowLevel.setStatus("Application Successfully Accepted");
        newAdvertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        newAdvertisementWorkFlowLevel.setNextUserId(null); // No further forwarding
        newAdvertisementWorkFlowLevel.setNextRoleId(null);
        newAdvertisementWorkFlowLevel.setMailStatus(0);
        newAdvertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return newAdvertisementWorkFlowLevelRepository.save(newAdvertisementWorkFlowLevel);
    }

    private NewAdvertisementWorkFlowLevel handleRejectStatus(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel, RoleMaster currentRole,UserMaster currentUser) {

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Accept action.");
        }

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newAdvertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));


        if (workFlowMaster.getId().equals(4L)) {  // Accept
            newAdvertisementWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            newAdvertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        }

        // Fetch hoarding category type master id (permanent or temporary)
        Long hoardingCategoryTypeMasterId = newAdvertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId();

        // Ensure the correct role based on hoarding type
        if (hoardingCategoryTypeMasterId.equals(1L)) { // Permanent Hoarding
            // Only Deputy Municipal Commissioner can reject for permanent hoarding
            if (!"Deputy Municipal Commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Only Deputy Municipal Commissioner can reject the application for permanent hoarding.");
            }
        } else if (hoardingCategoryTypeMasterId.equals(2L)) { // Temporary Hoarding
            // Only TS (Tax Superintendent) can reject for temporary hoarding
            if (!"Tax Superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Only Tax Superintendent can reject the application for temporary hoarding.");
            }
        } else {
            throw new IllegalStateException("Invalid hoarding category type for rejection.");
        }

        // Update status to "Rejected"
        newAdvertisementWorkFlowLevel.setStatus("Application Rejected");
        newAdvertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        newAdvertisementWorkFlowLevel.setNextUserId(null); // No further forwarding
        newAdvertisementWorkFlowLevel.setNextRoleId(null);
        newAdvertisementWorkFlowLevel.setMailStatus(2); // Set mail notification for rejection
        newAdvertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());

    // Mark application as inactive or non-processable
        ViewHoardingApplicationMaster application = viewHoardingApplicationMasterRepository.findById(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Application not found"));

        //application.setActive(false); // Mark application as inactive
        viewHoardingApplicationMasterRepository.save(application);

        return newAdvertisementWorkFlowLevelRepository.save(newAdvertisementWorkFlowLevel);
    }

    private NewAdvertisementWorkFlowLevel handleBackToBackOfficeStatus(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newAdvertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }

// Fetch the hoarding category type (Permanent or Temporary) from the master setup
        Long categoryId = newAdvertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId(); // assumed field

        if (categoryId == 1L) {
            // Permanent
            AdvertisementRolesDataFlowSetup validNextRole = advertisementRolesDataFlowSetupService
                    .getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

            if (!validNextRole.getNextRoleId().equals(nextRole.getId())) {
                throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() +
                        ") is not valid for backward action in Permanent category from currentRoleId (" + currentRole.getId() + ")");
            }

        } else if (categoryId == 2L) {
            // Temporary
            AdvertisementTemporaryRolesDataFlowSetup validNextRole = advertisementTemporaryRolesDataFlowSetupService
                    .getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

            if (!validNextRole.getNextRoleId().equals(nextRole.getId())) {
                throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() +
                        ") is not valid for backward action in Temporary category from currentRoleId (" + currentRole.getId() + ")");
            }

        } else {
            throw new IllegalStateException("Unsupported hoarding category type ID: " + categoryId);
        }

        newAdvertisementWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        newAdvertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        newAdvertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newAdvertisementWorkFlowLevel.setMailStatus(2);

        return newAdvertisementWorkFlowLevelRepository.save(newAdvertisementWorkFlowLevel);
    }

    private NewAdvertisementWorkFlowLevel handleDocumentVerificationAccept(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newAdvertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform forward action.");
        }

        // Fetch Hoarding Application and its details
        ViewHoardingApplicationMaster existingApplication = viewHoardingApplicationMasterRepository.findById(
                        newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Hoarding Application not found with ID: "
                        + newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

        ViewHoardingApplicationDetails existingApplicationFirmDetails = (ViewHoardingApplicationDetails)
                viewHoardingApplicationDetailsRepository.findByHoardingApplicationMasterId(existingApplication)
                        .orElseThrow(() -> new EntityNotFoundException("Hoarding Application Details not found with ID: "
                                + newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

        // ✅ Fetch hoarding category type (Permanent or Temporary)
        Long categoryId = newAdvertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId(); // assumed getter

        RoleMaster nextRole;
        if (categoryId == 1L) {
            // Permanent
            AdvertisementRolesDataFlowSetup nextSetup = advertisementRolesDataFlowSetupService
                    .getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

            if (nextSetup == null || nextSetup.getNextRoleId() == null) {
                throw new IllegalStateException("No next role found for Permanent hoarding.");
            }

            nextRole = roleMasterRepository.findById(nextSetup.getNextRoleId())
                    .orElseThrow(() -> new RuntimeException("Next role not found for forward action."));
        } else if (categoryId == 2L) {
            // Temporary
            AdvertisementTemporaryRolesDataFlowSetup nextSetup = advertisementTemporaryRolesDataFlowSetupService
                    .getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

            if (nextSetup == null || nextSetup.getNextRoleId() == null) {
                throw new IllegalStateException("No next role found for Temporary hoarding.");
            }

            nextRole = roleMasterRepository.findById(nextSetup.getNextRoleId())
                    .orElseThrow(() -> new RuntimeException("Next role not found for forward action."));
        } else {
            throw new IllegalStateException("Unsupported hoarding category type ID: " + categoryId);
        }

        // Get the next user for the role
        UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, nextRole);

        // Populate workflow level entity
        newAdvertisementWorkFlowLevel.setNextUserId(nextUser);
        newAdvertisementWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
        newAdvertisementWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
        newAdvertisementWorkFlowLevel.setNextRoleId(nextRole);
        newAdvertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newAdvertisementWorkFlowLevel.setStatusCode(currentStatus.getStatusCode());
        newAdvertisementWorkFlowLevel.setStatus(currentStatus.getStatus());
        newAdvertisementWorkFlowLevel.setMailStatus(0);

        // ✅ Update approved status in documents
        updateApprovedStatus(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId());

        return newAdvertisementWorkFlowLevelRepository.save(newAdvertisementWorkFlowLevel);
    }
    private void updateApprovedStatus(Long hoardingApplicationMasterId) {
        List<ViewHoardingDocumentsDetails> documentDetails =
                viewHoardingDocumentsDetailsRepository.findByViewHoardingApplicationMaster_Id(hoardingApplicationMasterId);

        for (ViewHoardingDocumentsDetails details : documentDetails) {

            details.setApprovedStatus(1f); // Set approved_status to 1
            viewHoardingDocumentsDetailsRepository.save(details);
        }
    }

    private NewAdvertisementWorkFlowLevel handleDocumentVerificationReject(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser,List<Long> rejectDocumentIds) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newAdvertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (nextRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }

        // Fetch application and its category
        ViewHoardingApplicationMaster existingApplication = viewHoardingApplicationMasterRepository.findById(
                        newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Hoarding Application not found with ID: " +
                        newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

        ViewHoardingApplicationDetails existingApplicationFirmDetails = (ViewHoardingApplicationDetails)
                viewHoardingApplicationDetailsRepository.findByHoardingApplicationMasterId(existingApplication)
                        .orElseThrow(() -> new EntityNotFoundException("Hoarding Application Details not found with ID: " +
                                newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

        Long categoryId = newAdvertisementWorkFlowLevel.getHoardingCategoryTypeMasterId().getId();

        boolean isValidNextRole;
        if (categoryId == 1L) {
            // Permanent category
            List<AdvertisementRolesDataFlowSetup> validNextRoles =
                    advertisementRolesDataFlowSetupService.getNextRoleListForListSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

            isValidNextRole = validNextRoles.stream()
                    .anyMatch(role -> role.getNextRoleId().equals(nextRole.getId()));
        } else if (categoryId == 2L) {
            // Temporary category
            List<AdvertisementTemporaryRolesDataFlowSetup> validNextRoles =
                    advertisementTemporaryRolesDataFlowSetupService.getNextRoleListForListSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

            isValidNextRole = validNextRoles.stream()
                    .anyMatch(role -> role.getNextRoleId().equals(nextRole.getId()));
        } else {
            throw new IllegalArgumentException("Unsupported hoarding category type ID: " + categoryId);
        }

        if (!isValidNextRole) {
            throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() +
                    ") is not valid for backward action from currentRoleId (" + currentRole.getId() + ")");
        }

        UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, nextRole);

        // Validate previousRole
        if (nextRole == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }

        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
        if (newAdvertisementWorkFlowLevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            newAdvertisementWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

            updateRejectStatus(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId(), rejectDocumentIds);

            return handleBackToCitizenStatus(newAdvertisementWorkFlowLevel, currentRole);  // Handle transition to citizen
        }

        newAdvertisementWorkFlowLevel.setNextUserId(nextUser);
        newAdvertisementWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
        newAdvertisementWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
        newAdvertisementWorkFlowLevel.setNextRoleId(nextRole);
        newAdvertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newAdvertisementWorkFlowLevel.setStatusCode(currentStatus.getStatusCode());
        newAdvertisementWorkFlowLevel.setStatus(currentStatus.getStatus());
        newAdvertisementWorkFlowLevel.setMailStatus(2);

        updateRejectStatus(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId(), rejectDocumentIds);

        return newAdvertisementWorkFlowLevelRepository.save(newAdvertisementWorkFlowLevel);
    }

    /**
     * Update approved_status to 0 for rejected documents
     */
    private void updateRejectStatus(Long applicationId, List<Long> rejectDocumentIds) {
        if (rejectDocumentIds == null || rejectDocumentIds.isEmpty()) {
            System.out.println("No documents to update for rejection.");
            return;
        }

        List<ViewHoardingDocumentsDetails> documentDetails =
                viewHoardingDocumentsDetailsRepository.findAllById(rejectDocumentIds);

        if (documentDetails.isEmpty()) {
            System.out.println("No matching documents found for rejection.");
            return;
        }

        documentDetails.forEach(details -> details.setApprovedStatus(0f)); // Set approved_status to 0

        // Save all updates in batch
        viewHoardingDocumentsDetailsRepository.saveAll(documentDetails);

        System.out.println("Updated " + documentDetails.size() + " documents to rejected status.");
    }

    private NewAdvertisementWorkFlowLevel handleBackToCitizenStatus(NewAdvertisementWorkFlowLevel workFlow, RoleMaster currentRole) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        ViewHoardingApplicationMaster existingApplication = viewHoardingApplicationMasterRepository.findById(workFlow.getHoardingApplicationMasterId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Hoarding Application not found with ID: " + workFlow.getHoardingApplicationMasterId().getId()));

        ViewHoardingApplicationDetails existingApplicationFirmDetails = (ViewHoardingApplicationDetails) viewHoardingApplicationDetailsRepository.findByHoardingApplicationMasterId(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Hoarding Application Details not found with ID: " + workFlow.getHoardingApplicationMasterId().getId()));

//        Long nextUserId = workFlow.getNextUserId().getId();
        Long currentUserId = workFlow.getCurrentUserId().getId();

        if (workFlowMaster.getId().equals(5L)) {
            workFlow.setStatus(workFlowMaster.getStatus());
            workFlow.setStatusCode(workFlowMaster.getStatusCode());

            workFlow.setWardId(existingApplicationFirmDetails.getWardId().getId());
            workFlow.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
            workFlow.setNextUserId(null);
            workFlow.setNextRoleId(null);
            workFlow.setCurrentRoleId(workFlow.getCurrentRoleId());
            //workFlow.setNextRoleId(workFlow.getNextRoleId());
            workFlow.setCurrentUserId(workFlow.getCurrentUserId());
            workFlow.setCitizenId(workFlow.getCitizenId());
        }
        workFlow.setMailStatus(1);
        workFlow.setCreatedDate(LocalDateTime.now());
        return newAdvertisementWorkFlowLevelRepository.save(workFlow);
    }

    private NewAdvertisementWorkFlowLevel forwardFromBackWard(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel) {

        Long currentRoleId = newAdvertisementWorkFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));

        Long applicationId = newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = newAdvertisementWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewAdvertisementWorkFlowLevel latestWorkFlow = newAdvertisementWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1001) {

            newAdvertisementWorkFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newAdvertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewHoardingApplicationMaster existingApplication = viewHoardingApplicationMasterRepository.findById(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Hoarding Application not found with ID: " + newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

            ViewHoardingApplicationDetails existingApplicationFirmDetails = (ViewHoardingApplicationDetails) viewHoardingApplicationDetailsRepository.findByHoardingApplicationMasterId(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Hoarding Application Details not found with ID: " + newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

            UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, newAdvertisementWorkFlowLevel.getNextRoleId());

            newAdvertisementWorkFlowLevel.setNextUserId(nextUser);
            newAdvertisementWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
            newAdvertisementWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
            newAdvertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            newAdvertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            newAdvertisementWorkFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            newAdvertisementWorkFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId());
            return newAdvertisementWorkFlowLevelRepository.save(newAdvertisementWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private NewAdvertisementWorkFlowLevel forwardFromBackOffice(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel) {

        Long currentRoleId = newAdvertisementWorkFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));

        Long applicationId = newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = newAdvertisementWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewAdvertisementWorkFlowLevel latestWorkFlow = newAdvertisementWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1007) {

            newAdvertisementWorkFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newAdvertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewHoardingApplicationMaster existingApplication = viewHoardingApplicationMasterRepository.findById(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Hoarding Application not found with ID: " + newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

            ViewHoardingApplicationDetails existingApplicationFirmDetails = (ViewHoardingApplicationDetails) viewHoardingApplicationDetailsRepository.findByHoardingApplicationMasterId(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Hoarding Application Details not found with ID: " + newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

            UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, newAdvertisementWorkFlowLevel.getNextRoleId());

            newAdvertisementWorkFlowLevel.setNextUserId(nextUser);
            newAdvertisementWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
            newAdvertisementWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
            newAdvertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            newAdvertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            newAdvertisementWorkFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            newAdvertisementWorkFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId());
            return newAdvertisementWorkFlowLevelRepository.save(newAdvertisementWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private NewAdvertisementWorkFlowLevel forwardFromCitizen(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel) {

        Long currentRoleId = newAdvertisementWorkFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));

        Long applicationId = newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = newAdvertisementWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewAdvertisementWorkFlowLevel latestWorkFlow = newAdvertisementWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1004) {

            newAdvertisementWorkFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newAdvertisementWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewHoardingApplicationMaster existingApplication = viewHoardingApplicationMasterRepository.findById(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Hoarding Application not found with ID: " + newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

            ViewHoardingApplicationDetails existingApplicationFirmDetails = (ViewHoardingApplicationDetails) viewHoardingApplicationDetailsRepository.findByHoardingApplicationMasterId(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Hoarding Application Details not found with ID: " + newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId()));

            UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, newAdvertisementWorkFlowLevel.getNextRoleId());

            newAdvertisementWorkFlowLevel.setNextUserId(nextUser);
            newAdvertisementWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
            newAdvertisementWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
            newAdvertisementWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            newAdvertisementWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            newAdvertisementWorkFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            newAdvertisementWorkFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(newAdvertisementWorkFlowLevel.getHoardingApplicationMasterId().getId());
            return newAdvertisementWorkFlowLevelRepository.save(newAdvertisementWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

}

