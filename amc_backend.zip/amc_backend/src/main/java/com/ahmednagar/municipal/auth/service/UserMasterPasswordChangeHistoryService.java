package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.model.UserMasterPasswordChangeHistory;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserMasterPasswordChangeHistoryService {

    List<UserMasterPasswordChangeHistory> getHistoryByUserMasterId(Long userMasterId);

    List<UserMasterPasswordChangeHistory> getAllUserMasterPasswordChangeHistory();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    UserMasterPasswordChangeHistory createPasswordChangeHistory(UserMasterPasswordChangeHistory userMasterPasswordChangeHistory, HttpServletRequest request);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
