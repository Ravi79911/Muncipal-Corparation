package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorRate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;

@EnableJpaRepositories
public interface VendorRateRepository extends JpaRepository<VendorRate, Long> {

    List<VendorRate> findBySuspendedStatus(Integer suspendedStatus);

    @Query("SELECT vr FROM VendorRate vr " +
            "WHERE vr.vendorMasId.marketNameId.marketName = :vendorMarketName " +
            "AND LOWER(vr.vendorMasId.vendorNameEng) LIKE LOWER(CONCAT('%', :vendorNameEng, '%'))")
    List<VendorRate> findByVendorMarketNameAndVendorNameEng(
            @Param("vendorMarketName") String vendorMarketName,
            @Param("vendorNameEng") String vendorNameEng);

}
