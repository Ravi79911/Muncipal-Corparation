package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.NewLicenseWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.*;
import com.ahmednagar.municipal.auth.service.LicenseRolesDataFlowSetupService;
import com.ahmednagar.municipal.auth.service.NewLicenseWorkFlowLevelService;
import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class NewLicenseWorkFlowLevelServiceImpl implements NewLicenseWorkFlowLevelService {

    @Autowired
    private NewLicenseWorkFlowLevelRepository newLicenseWorkFlowLevelRepository;

    @Autowired
    private WorkFlowMasterRepository workFlowMasterRepository;

    @Autowired
    private ViewApplicationFromMasterRepository viewApplicationFromMasterRepository;

    @Autowired
    private ViewApplicationFirmDetailsRepository viewApplicationFirmDetailsRepository;

    @Autowired
    private UserMasterRepository userMasterRepository;

    @Autowired
    private LicenseRolesDataFlowSetupService licenseRolesDataFlowSetupService;

    @Autowired
    private RoleMasterRepository roleMasterRepository;

    @Autowired
    private CitizenSignUpRepository citizenSignUpRepository;

    @Autowired
    private ViewTradeApplicationTypeMastersRepository viewTradeApplicationTypeMastersRepository;

    @Autowired
    private ViewApplicationDocumentsDetailsRepository viewApplicationDocumentsDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    public UserMaster getLipikForCitizen(Long citizenId) {
        Long roleId = 1L; // Role ID for Lipik

        CitizenSignUpMaster citizen = citizenSignUpRepository.findById(citizenId)
                .orElseThrow(() -> new EntityNotFoundException("Citizen not found with ID: " + citizenId));

        // Fetch the first Lipik (UserMaster) matching Zone, Ward, Role
        return userMasterRepository.findFirstByZoneWardAndRole(citizen.getZoneId(), citizen.getWardId(), roleId)
                .orElseThrow(() -> new EntityNotFoundException("No Lipik found for Zone: " + citizen.getZoneId()
                        + " and Ward: " + citizen.getWardId()));
    }


    @Override
    public NewLicenseWorkFlowLevel createNewApplicationTransation(NewLicenseWorkFlowLevel newLicenseWorkFlowLevelRequest) {
        // Validate Application ID
//        ViewMunicipalPropertyMaster application = applicationRepository.findById(
//                        newLicenseWorkFlowLevelRequest.getApplicationId().getId())
//                .orElseThrow(() -> new RuntimeException("Application not found"));

        UserMaster newApplicationLipik = getLipikForCitizen(newLicenseWorkFlowLevelRequest.getCitizenId().getId());

        // Fetch next role dynamically (e.g., based on workflow or hardcoded logic)
        RoleMaster currentRole = roleMasterRepository.findByRoleName("CITIZEN")
                .orElseThrow(() -> new RuntimeException("Role 'CITIZEN' not found"));

        // Fetch next role (e.g., LIPIK)
        RoleMaster nextRole = roleMasterRepository.findByRoleName("LIPIK")
                .orElseThrow(() -> new RuntimeException("Role 'LIPIK' not found"));

        // Validate WorkFlow Master
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newLicenseWorkFlowLevelRequest.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Master not found"));

        ViewApplicationFromMaster existingApplication = viewApplicationFromMasterRepository.findById(newLicenseWorkFlowLevelRequest.getApplicationMasterId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newLicenseWorkFlowLevelRequest.getApplicationMasterId().getId()));

        ViewApplicationFirmDetails existingApplicationFirmDetails = (ViewApplicationFirmDetails) viewApplicationFirmDetailsRepository.findByViewApplicationFromMaster(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Consumer Property Details not found with ID: " + newLicenseWorkFlowLevelRequest.getApplicationMasterId().getId()));

        // Build WorkFlowLevel Object with Defaults
        NewLicenseWorkFlowLevel newWorkFlow = NewLicenseWorkFlowLevel.builder()
                .applicationMasterId(newLicenseWorkFlowLevelRequest.getApplicationMasterId())
                .applicationTypeId(newLicenseWorkFlowLevelRequest.getApplicationTypeId())
                .temporaryLicensePaymentId(newLicenseWorkFlowLevelRequest.getTemporaryLicensePaymentId())
                .currentUserId(null)
                .nextUserId(newApplicationLipik)
                .workFlowMasterId(workFlowMaster)
                .status("NEW") // Default status for new applications
                .currentRoleId(currentRole)
                .nextRoleId(nextRole)
                .statusCode(1000L) // Example status code
                .createdBy(newLicenseWorkFlowLevelRequest.getCreatedBy())
                .createdDate(LocalDateTime.now())
                //.mailStatus(newLicenseWorkFlowLevelRequest.getMailStatus())
                .mailStatus(1)
                .remarks(newLicenseWorkFlowLevelRequest.getRemarks())
                .municipalId(newLicenseWorkFlowLevelRequest.getMunicipalId())
                .wardId(existingApplicationFirmDetails.getWardId().getId())
                .zoneId(existingApplicationFirmDetails.getZoneId().getId())
                .citizenId(newLicenseWorkFlowLevelRequest.getCitizenId())
                .build();
        updateApprovedStatus(newLicenseWorkFlowLevelRequest.getApplicationMasterId().getId());
        newWorkFlow.setMailStatus(1);

        // Save Workflow to Database
        return newLicenseWorkFlowLevelRepository.save(newWorkFlow);
    }

    @Override
    public List<NewLicenseWorkFlowLevelDto> getAllNewWaterWorkFlowLevel() {
        List<NewLicenseWorkFlowLevel> workFlows = newLicenseWorkFlowLevelRepository.findAll();

        return workFlows.stream().map(workflow -> {
            NewLicenseWorkFlowLevelDto dto = modelMapper.map(workflow, NewLicenseWorkFlowLevelDto.class);

            // Manually map UserMaster to UserMasterDTO
            if (workflow.getCurrentUserId() != null) {
                dto.setCurrentUserId(modelMapper.map(workflow.getCurrentUserId(), UserMasterDTO.class));
            }
//            if (workflow.getNextUserId() != null) {
//                dto.setNextUserId(modelMapper.map(workflow.getNextUserId(), UserMasterDTO.class));
//            }
            return dto;
        }).collect(Collectors.toList());
    }

    public UserMaster getNextRoleForApplication(ViewApplicationFirmDetails existingApplication, RoleMaster nextRoleId) {

        Long roleId = nextRoleId.getId(); // Role ID for Lipik

//        ViewFormsPropertyMaster existingApplication = propertyMasterRepository.findById(applicationId)
//                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + applicationId));

        // Fetch the first UserId matching with Zone, Ward, Role provided
        return userMasterRepository.findFirstByZoneWardAndRole(existingApplication.getZoneId().getId(), existingApplication.getWardId().getId(), roleId)
                .orElseThrow(() -> new EntityNotFoundException("No "+ nextRoleId.getRoleName() +" found for Zone: " + existingApplication.getZoneId().getId() + " and Ward: " + existingApplication.getWardId().getId()));


//        // Fetch the first UserId matching with Zone, Ward, Role provided
//        return userMasterRepository.findFirstByZoneWardAndRole(existingApplication.getZoneId().getId(), existingApplication.getWardId().getId(), roleId)
//                .orElseThrow(() -> new EntityNotFoundException("No "+ nextRoleId.getRoleName() +" found for Zone: " + existingApplication.getZoneId()+ " and Ward: " + existingApplication.getWardId()));
    }

    private RoleMaster loadRoleOrThrow(RoleMaster role, String label) {                                                 // check if role exists
        if (role == null || role.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return roleMasterRepository.findById(role.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + role.getId() + " not found"));
    }

    private UserMaster loadUserOrThrow(UserMaster user, String label) {                                                  // check if user exists
        if (user == null || user.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return userMasterRepository.findById(user.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + user.getId() + " not found"));
    }

    private WorkFlowMaster loadWorkflowMasterOrThrow(WorkFlowMaster workflow, String label) {                           // check if workflow exists
        if (workflow == null || workflow.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return workFlowMasterRepository.findById(workflow.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + workflow.getId() + " not found"));
    }

    private void validateNoTerminalStateExists(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel) {                                     //check application "Accept or "Reject" status
        List<NewLicenseWorkFlowLevel> existingWorkflows =
                newLicenseWorkFlowLevelRepository.findByApplicationMasterId(newLicenseWorkFlowLevel.getApplicationMasterId());

        for (NewLicenseWorkFlowLevel wf : existingWorkflows) {
            if (wf.getStatusCode() == null) continue;

            switch (wf.getStatusCode().intValue()) {
                case 1002 -> throw new IllegalStateException("This application has already been Accepted.");
                case 1003 -> throw new IllegalStateException("This application has already been Rejected.");
            }
        }
    }


    @Override
    public NewLicenseWorkFlowLevel handleWorkFlowsTransition(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel) {
        // 1. Validate and Load Current Role
        RoleMaster currentRole = loadRoleOrThrow(
                newLicenseWorkFlowLevel.getCurrentRoleId(), "Current Role");

        // 2. Optionally Load Next Role
        RoleMaster nextRole = null;
        if (newLicenseWorkFlowLevel.getNextRoleId() != null && newLicenseWorkFlowLevel.getNextRoleId().getId() != null) {
            nextRole = loadRoleOrThrow(newLicenseWorkFlowLevel.getNextRoleId(), "Next Role");
        }

        // 3. Load Current User
        UserMaster currentUser = loadUserOrThrow(
                newLicenseWorkFlowLevel.getCurrentUserId(), "Current User");

        List<Long> rejectedDocumentIds = newLicenseWorkFlowLevel.getRejectedDocumentIds();

        // 4. Prevent redundant transitions
        validateNoTerminalStateExists(newLicenseWorkFlowLevel);

        // 5. Load Workflow Status
        WorkFlowMaster currentStatus = loadWorkflowMasterOrThrow(
                newLicenseWorkFlowLevel.getWorkFlowMasterId(), "Workflow Master");

        // 6. Handle transition based on status
        return switch (currentStatus.getStatus().toUpperCase()) {
            case "FORWARDED" -> forward(newLicenseWorkFlowLevel, currentStatus, currentRole, currentUser);

            case "BACKWARD" -> handleBackward(newLicenseWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser);

            case "ACCEPT" -> handleAcceptStatus(newLicenseWorkFlowLevel, currentRole, currentUser);

            case "REJECT" -> handleRejectStatus(newLicenseWorkFlowLevel, currentRole, currentUser);

            case "BACK TO CITIZEN" -> handleBackToCitizenStatus(newLicenseWorkFlowLevel, currentRole);

            case "BACK TO BACK OFFICE" -> handleBackToBackOfficeStatus(newLicenseWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser);

            case "DOCUMENT VERIFICATION ACCEPT" -> handleDocumentVerificationAccept(newLicenseWorkFlowLevel, currentStatus, currentRole, currentUser);

            case "DOCUMENT VERIFICATION REJECT" -> handleDocumentVerificationReject(newLicenseWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser, rejectedDocumentIds);

            default -> throw new IllegalArgumentException("Unsupported workflow status: " + currentStatus.getStatus());
        };
    }
    private NewLicenseWorkFlowLevel forward(NewLicenseWorkFlowLevel workFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (workFlowLevel.getStatusCode() == 1001) {
            return forwardFromBackWard(workFlowLevel);
        } else if (workFlowLevel.getStatusCode() == 1007) {
            return forwardFromBackOffice(workFlowLevel);
        } else if (workFlowLevel.getStatusCode() == 1004) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromCitizen(workFlowLevel);
        } else {

            if (currentRole == null) {
                throw new IllegalStateException("Current role is required for forward action.");
            }

            if (currentUser == null || currentUser.getRoleMaster() == null) {
                throw new IllegalStateException("Current user or user's role is missing.");
            }

            if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
                String username = currentUser.getUsername();
                throw new SecurityException("User '" + username + "' is not authorized to perform forward action.");
            }

            LicenseRolesDataFlowSetup NextRoleSetUpForForward = licenseRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

            if (NextRoleSetUpForForward == null || NextRoleSetUpForForward.getNextRoleId() == null) {
                throw new IllegalStateException("No next role found for forward action.");
            }

            RoleMaster nextRole = roleMasterRepository.findById(NextRoleSetUpForForward.getNextRoleId())
                    .orElseThrow(() -> new RuntimeException("Next role not found for forward action."));

            ViewApplicationFromMaster existingApplication = viewApplicationFromMasterRepository.findById(workFlowLevel.getApplicationMasterId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + workFlowLevel.getApplicationMasterId().getId()));

            ViewApplicationFirmDetails existingApplicationFirmDetails = (ViewApplicationFirmDetails) viewApplicationFirmDetailsRepository.findByViewApplicationFromMaster(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Firm Details not found with ID: " + workFlowLevel.getApplicationMasterId().getId()));

            UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, nextRole);

            workFlowLevel.setNextUserId(nextUser);
            workFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
            workFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
            workFlowLevel.setNextRoleId(nextRole);
            workFlowLevel.setCreatedDate(LocalDateTime.now());
            workFlowLevel.setStatusCode(currentStatus.getStatusCode());
            workFlowLevel.setStatus(currentStatus.getStatus());
            workFlowLevel.setMailStatus(1);

            return newLicenseWorkFlowLevelRepository.save(workFlowLevel);
        }
    }

    private NewLicenseWorkFlowLevel handleBackward(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newLicenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }

        List<LicenseRolesDataFlowSetup> validNextRoles = licenseRolesDataFlowSetupService.getNextRoleListForListSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);
        boolean isValidNextRole = validNextRoles.stream()
                .anyMatch(role -> role.getNextRoleId().equals(nextRole.getId()));

        if (!isValidNextRole) {
            throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() + ") is not valid for backward action from currentRoleId (" + currentRole.getId() + ")");
        }

        List<Long> roleIds = validNextRoles.stream()
                .map(LicenseRolesDataFlowSetup::getNextRoleId)
                .collect(Collectors.toList());

        List<RoleMaster> nextRoles = roleMasterRepository.findAllById(roleIds);

        ViewApplicationFromMaster existingApplication = viewApplicationFromMasterRepository.findById(newLicenseWorkFlowLevel.getApplicationMasterId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));

        ViewApplicationFirmDetails existingApplicationFirmDetails = (ViewApplicationFirmDetails) viewApplicationFirmDetailsRepository.findByViewApplicationFromMaster(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Firm Details not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));

        UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, nextRole);

        // Validate previousRole
        if (nextRoles == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }
        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
        if (newLicenseWorkFlowLevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            newLicenseWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

            //updateRejectStatus(licenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);

            return handleBackToCitizenStatus(newLicenseWorkFlowLevel, nextRole);  // Handle transition to citizen
        }

        newLicenseWorkFlowLevel.setNextUserId(nextUser);
        newLicenseWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
        newLicenseWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
        newLicenseWorkFlowLevel.setNextRoleId(nextRole);
        newLicenseWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        newLicenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        newLicenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newLicenseWorkFlowLevel.setMailStatus(2);

        return newLicenseWorkFlowLevelRepository.save(newLicenseWorkFlowLevel);
    }

    private NewLicenseWorkFlowLevel handleAcceptStatus(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel, RoleMaster currentRole,UserMaster currentUser) {

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Accept action.");
        }

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newLicenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (workFlowMaster.getId().equals(3L)) {  // Accept
            newLicenseWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            newLicenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        }

        // Ensure only TS can accept
        if (!"Deputy Municipal Commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only Deputy Municipal Commissioner can accept the application.");
        }

        newLicenseWorkFlowLevel.setNextRoleId(null); // No further forwarding
        newLicenseWorkFlowLevel.setMailStatus(0);
        //newLicenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUser));
        newLicenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return newLicenseWorkFlowLevelRepository.save(newLicenseWorkFlowLevel);
    }

    private NewLicenseWorkFlowLevel handleRejectStatus(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel, RoleMaster currentRole,UserMaster currentUser) {

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Accept action.");
        }

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newLicenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));


        if (workFlowMaster.getId().equals(4L)) {  // Accept
            newLicenseWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            newLicenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        }

        // Ensure only TS can accept
        if (!"Deputy Municipal Commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only Deputy Municipal Commissioner can accept the application.");
        }

        // Update status to "Rejected"
        newLicenseWorkFlowLevel.setNextRoleId(null); // No further forwarding
        newLicenseWorkFlowLevel.setMailStatus(0);
        newLicenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        //newLicenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
        newLicenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        // Mark application as inactive or non-processable
        ViewApplicationFromMaster application = viewApplicationFromMasterRepository.findById(newLicenseWorkFlowLevel.getApplicationMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Application not found"));

        //application.setActive(false); // Mark application as inactive
        viewApplicationFromMasterRepository.save(application);

        return newLicenseWorkFlowLevelRepository.save(newLicenseWorkFlowLevel);
    }

    private NewLicenseWorkFlowLevel handleBackToBackOfficeStatus(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newLicenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }


        // 5. ✅ Call service method correctly (only one result expected)
        LicenseRolesDataFlowSetup validNextRole = licenseRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

        if (!validNextRole.getNextRoleId().equals(nextRole.getId())) {
            throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() +
                    ") is not valid for backward action from currentRoleId (" + currentRole.getId() + ")");
        }

        newLicenseWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        newLicenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        newLicenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newLicenseWorkFlowLevel.setMailStatus(2);

        return newLicenseWorkFlowLevelRepository.save(newLicenseWorkFlowLevel);
    }

    private NewLicenseWorkFlowLevel handleDocumentVerificationAccept(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newLicenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform forward action.");
        }

        LicenseRolesDataFlowSetup NextRoleSetUpForDocumentVerificationAccept = licenseRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

        if (NextRoleSetUpForDocumentVerificationAccept == null || NextRoleSetUpForDocumentVerificationAccept.getNextRoleId() == null) {
            throw new IllegalStateException("No next role found for forward action.");
        }

        RoleMaster nextRole = roleMasterRepository.findById(NextRoleSetUpForDocumentVerificationAccept.getNextRoleId())
                .orElseThrow(() -> new RuntimeException("Next role not found for forward action."));

        ViewApplicationFromMaster existingApplication = viewApplicationFromMasterRepository.findById(newLicenseWorkFlowLevel.getApplicationMasterId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));

        ViewApplicationFirmDetails existingApplicationFirmDetails = (ViewApplicationFirmDetails) viewApplicationFirmDetailsRepository.findByViewApplicationFromMaster(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Firm Details not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));


        UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, nextRole);

        newLicenseWorkFlowLevel.setNextUserId(nextUser);
        newLicenseWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
        newLicenseWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
        newLicenseWorkFlowLevel.setNextRoleId(nextRole);
        newLicenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newLicenseWorkFlowLevel.setStatusCode(currentStatus.getStatusCode());
        newLicenseWorkFlowLevel.setStatus(currentStatus.getStatus());
        newLicenseWorkFlowLevel.setMailStatus(0);
        // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
        updateApprovedStatus(newLicenseWorkFlowLevel.getApplicationMasterId().getId());

        return newLicenseWorkFlowLevelRepository.save(newLicenseWorkFlowLevel);
    }

    private void updateApprovedStatus(Long applicationMasterId) {
        List<ViewApplicationDocumentsDetails> documentDetails =
                viewApplicationDocumentsDetailsRepository.findByviewApplicationFromMaster_Id(applicationMasterId);

        for (ViewApplicationDocumentsDetails details : documentDetails) {

            details.setApprovedStatus(1f); // Set approved_status to 1
            viewApplicationDocumentsDetailsRepository.save(details);
        }
    }

    private NewLicenseWorkFlowLevel handleDocumentVerificationReject(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser,List<Long> rejectDocumentIds) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newLicenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (nextRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }

        List<LicenseRolesDataFlowSetup> validNextRoles = licenseRolesDataFlowSetupService.getNextRoleListForListSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);
        boolean isValidNextRole = validNextRoles.stream()
                .anyMatch(role -> role.getNextRoleId().equals(nextRole.getId()));

        if (!isValidNextRole) {
            throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() + ") is not valid for backward action from currentRoleId (" + currentRole.getId() + ")");
        }

        List<Long> roleIds = validNextRoles.stream()
                .map(LicenseRolesDataFlowSetup::getNextRoleId)
                .collect(Collectors.toList());

        List<RoleMaster> nextRoles = roleMasterRepository.findAllById(roleIds);

//        RoleMaster nextRole = roleMasterRepository.findById(NextRoleSetUpForDocumentVerificationAccept.getNextRoleId())
//                .orElseThrow(() -> new RuntimeException("Next role not found for forward action."));

        ViewApplicationFromMaster existingApplication = viewApplicationFromMasterRepository.findById(newLicenseWorkFlowLevel.getApplicationMasterId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));

        ViewApplicationFirmDetails existingApplicationFirmDetails = (ViewApplicationFirmDetails) viewApplicationFirmDetailsRepository.findByViewApplicationFromMaster(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Firm Details not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));


        UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, nextRole);

        // Validate previousRole
        if (nextRole == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }

        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
        if (newLicenseWorkFlowLevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            newLicenseWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

            updateRejectStatus(newLicenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIds);

            return handleBackToCitizenStatus(newLicenseWorkFlowLevel, currentRole);  // Handle transition to citizen
        }

        newLicenseWorkFlowLevel.setNextUserId(nextUser);
        newLicenseWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
        newLicenseWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
        newLicenseWorkFlowLevel.setNextRoleId(nextRole);
        newLicenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newLicenseWorkFlowLevel.setStatusCode(currentStatus.getStatusCode());
        newLicenseWorkFlowLevel.setStatus(currentStatus.getStatus());
        newLicenseWorkFlowLevel.setMailStatus(2);

        updateRejectStatus(newLicenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIds);

        return newLicenseWorkFlowLevelRepository.save(newLicenseWorkFlowLevel);
    }

    /**
     * Update approved_status to 0 for rejected documents
     */
    private void updateRejectStatus(Long applicationId, List<Long> rejectDocumentIds) {
        if (rejectDocumentIds == null || rejectDocumentIds.isEmpty()) {
            System.out.println("No documents to update for rejection.");
            return;
        }

        List<ViewApplicationDocumentsDetails> documentDetails =
                viewApplicationDocumentsDetailsRepository.findAllById(rejectDocumentIds);

        if (documentDetails.isEmpty()) {
            System.out.println("No matching documents found for rejection.");
            return;
        }

        documentDetails.forEach(details -> details.setApprovedStatus(0f)); // Set approved_status to 0

        // Save all updates in batch
        viewApplicationDocumentsDetailsRepository.saveAll(documentDetails);

        System.out.println("Updated " + documentDetails.size() + " documents to rejected status.");
    }


    private NewLicenseWorkFlowLevel handleBackToCitizenStatus(NewLicenseWorkFlowLevel workFlow, RoleMaster currentRole) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        ViewApplicationFromMaster    existingApplication = viewApplicationFromMasterRepository.findById(workFlow.getApplicationMasterId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + workFlow.getApplicationMasterId().getId()));

        ViewApplicationFirmDetails existingApplicationFirmDetails = (ViewApplicationFirmDetails) viewApplicationFirmDetailsRepository.findByViewApplicationFromMaster(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Firm Details not found with ID: " + workFlow.getApplicationMasterId().getId()));


//        Long nextUserId = workFlow.getNextUserId().getId();
        Long currentUserId = workFlow.getCurrentUserId().getId();

        Long nextRoleId = workFlow.getNextRoleId() != null ? workFlow.getNextRoleId().getId() : null;

        if (workFlowMaster.getId().equals(5L)) {
            workFlow.setStatus(workFlowMaster.getStatus());
            workFlow.setStatusCode(workFlowMaster.getStatusCode());

            workFlow.setWardId(existingApplicationFirmDetails.getWardId().getId());
            workFlow.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
            workFlow.setNextUserId(null);
            workFlow.setNextRoleId(null);
            workFlow.setCurrentRoleId(workFlow.getCurrentRoleId());
            //workFlow.setNextRoleId(workFlow.getNextRoleId());
            workFlow.setCurrentUserId(workFlow.getCurrentUserId());
            workFlow.setCitizenId(workFlow.getCitizenId());
        }
        workFlow.setMailStatus(1);
        workFlow.setCreatedDate(LocalDateTime.now());
        return newLicenseWorkFlowLevelRepository.save(workFlow);
    }

    private NewLicenseWorkFlowLevel forwardFromBackWard(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel) {

        Long currentRoleId = newLicenseWorkFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));
        Long applicationId = newLicenseWorkFlowLevel.getApplicationMasterId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = newLicenseWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewLicenseWorkFlowLevel latestWorkFlow = newLicenseWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1001) {

            newLicenseWorkFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newLicenseWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewApplicationFromMaster existingApplication = viewApplicationFromMasterRepository.findById(newLicenseWorkFlowLevel.getApplicationMasterId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));

            ViewApplicationFirmDetails existingApplicationFirmDetails = (ViewApplicationFirmDetails) viewApplicationFirmDetailsRepository.findByViewApplicationFromMaster(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Firm Details not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));



            UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, newLicenseWorkFlowLevel.getNextRoleId());

            newLicenseWorkFlowLevel.setNextUserId(nextUser);
            newLicenseWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
            newLicenseWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
            newLicenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            newLicenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            newLicenseWorkFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            newLicenseWorkFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(newLicenseWorkFlowLevel.getApplicationMasterId().getId());
            return newLicenseWorkFlowLevelRepository.save(newLicenseWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private NewLicenseWorkFlowLevel forwardFromBackOffice(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel) {

        Long currentRoleId = newLicenseWorkFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));
        Long applicationId = newLicenseWorkFlowLevel.getApplicationMasterId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = newLicenseWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewLicenseWorkFlowLevel latestWorkFlow = newLicenseWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1007) {

            newLicenseWorkFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newLicenseWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewApplicationFromMaster existingApplication = viewApplicationFromMasterRepository.findById(newLicenseWorkFlowLevel.getApplicationMasterId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));

            ViewApplicationFirmDetails existingApplicationFirmDetails = (ViewApplicationFirmDetails) viewApplicationFirmDetailsRepository.findByViewApplicationFromMaster(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Firm Details not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));



            UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, newLicenseWorkFlowLevel.getNextRoleId());

            newLicenseWorkFlowLevel.setNextUserId(nextUser);
            newLicenseWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
            newLicenseWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
            newLicenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            newLicenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            newLicenseWorkFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            newLicenseWorkFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(newLicenseWorkFlowLevel.getApplicationMasterId().getId());
            return newLicenseWorkFlowLevelRepository.save(newLicenseWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private NewLicenseWorkFlowLevel forwardFromCitizen(NewLicenseWorkFlowLevel newLicenseWorkFlowLevel) {

        Long currentRoleId = newLicenseWorkFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));
        Long applicationId = newLicenseWorkFlowLevel.getApplicationMasterId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = newLicenseWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewLicenseWorkFlowLevel latestWorkFlow = newLicenseWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1004) {

            newLicenseWorkFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newLicenseWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewApplicationFromMaster existingApplication = viewApplicationFromMasterRepository.findById(newLicenseWorkFlowLevel.getApplicationMasterId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));

            ViewApplicationFirmDetails existingApplicationFirmDetails = (ViewApplicationFirmDetails) viewApplicationFirmDetailsRepository.findByViewApplicationFromMaster(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Firm Details not found with ID: " + newLicenseWorkFlowLevel.getApplicationMasterId().getId()));



            UserMaster nextUser = getNextRoleForApplication(existingApplicationFirmDetails, newLicenseWorkFlowLevel.getNextRoleId());

            newLicenseWorkFlowLevel.setNextUserId(nextUser);
            newLicenseWorkFlowLevel.setWardId(existingApplicationFirmDetails.getWardId().getId());
            newLicenseWorkFlowLevel.setZoneId(existingApplicationFirmDetails.getZoneId().getId());
            newLicenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            newLicenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            newLicenseWorkFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            newLicenseWorkFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(newLicenseWorkFlowLevel.getApplicationMasterId().getId());
            return newLicenseWorkFlowLevelRepository.save(newLicenseWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

}
