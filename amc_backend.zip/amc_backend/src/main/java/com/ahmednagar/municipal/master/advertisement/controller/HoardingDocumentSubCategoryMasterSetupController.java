package com.ahmednagar.municipal.master.advertisement.controller;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingDocumentSubCategoryMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingDocumentSubCategoryMasterSetup;
import com.ahmednagar.municipal.master.advertisement.service.HoardingDocumentSubCategoryMasterSetupService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/advertisement/hoarding/document/sub/category/master/setup")
@Validated
@CrossOrigin
public class HoardingDocumentSubCategoryMasterSetupController {
    @Autowired
    private HoardingDocumentSubCategoryMasterSetupService hoardingDocumentSubCategoryMasterSetupService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingDocumentSubCategoryMasterSetup> createHoardingDocumentSubCategoryMasterSetup(@Valid @RequestBody HoardingDocumentSubCategoryMasterSetup hoardingDocumentSubCategoryMasterSetup){
        HoardingDocumentSubCategoryMasterSetup savedHoardingDocumentSubCategoryMasterSetup=hoardingDocumentSubCategoryMasterSetupService.saveHoardingDocumentSubCategoryMasterSetup(hoardingDocumentSubCategoryMasterSetup);
        return ResponseEntity.status(201).body(savedHoardingDocumentSubCategoryMasterSetup);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingDocumentSubCategoryMasterSetupDto>> getAllHoardingDocumentSubCategoryMasterSetup(){
        List<HoardingDocumentSubCategoryMasterSetupDto> hoardingDocumentSubCategoryMasterSetup=hoardingDocumentSubCategoryMasterSetupService.findAllHoardingDocumentSubCategoryMasterSetup();
        return ResponseEntity.ok(hoardingDocumentSubCategoryMasterSetup);

    }

    //for single user by Id
    @GetMapping("/getMlBusinessNatureById/{id}")
    public ResponseEntity<HoardingDocumentSubCategoryMasterSetup> getHoardingDocumentSubCategoryMasterSetupById(@PathVariable Long id){
        HoardingDocumentSubCategoryMasterSetup hoardingDocumentSubCategoryMasterSetup=hoardingDocumentSubCategoryMasterSetupService.findById(id);
        return ResponseEntity.ok(hoardingDocumentSubCategoryMasterSetup);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingDocumentSubCategoryMasterSetupByMunicipalId(@PathVariable int municipalId){
        List<HoardingDocumentSubCategoryMasterSetup> hoardingDocumentSubCategoryMasterSetups = hoardingDocumentSubCategoryMasterSetupService.findAllByMunicipalId(municipalId);
        if (hoardingDocumentSubCategoryMasterSetups.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingDocumentSubCategoryMasterSetup found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingDocumentSubCategoryMasterSetups);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingDocumentSubCategoryMasterSetup> updateHoardingDocumentSubCategoryMasterSetup(@PathVariable("id") Long id, @RequestBody HoardingDocumentSubCategoryMasterSetup updatedHoardingDocumentSubCategoryMasterSetup){
        try{
            HoardingDocumentSubCategoryMasterSetup updated=hoardingDocumentSubCategoryMasterSetupService.updateHoardingDocumentSubCategoryMasterSetup(id,updatedHoardingDocumentSubCategoryMasterSetup,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingDocumentSubCategoryMasterSetupService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }
}

