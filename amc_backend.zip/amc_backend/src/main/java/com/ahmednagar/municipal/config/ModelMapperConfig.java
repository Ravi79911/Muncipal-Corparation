package com.ahmednagar.municipal.config;

import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.model.UserMaster;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ModelMapperConfig {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.addMappings(new PropertyMap<UserMaster, UserMasterDTO>() {
            @Override
            protected void configure() {
                // Explicitly map only one of the properties
                map().setRoleName(source.getRoleMaster().getRoleName());
            }
        });

        return modelMapper;
    }
}