package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_user_master_password_change_history")
public class UserMasterPasswordChangeHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "last password change can't be blank")
    @Column(name = "last_pwdchange", nullable = false)
    private String lastPwdChange;

    @Column(name = "pwd_changed_datetime", nullable = false)
    private LocalDateTime pwdChangedDateTime;

//    @NotBlank(message = "ip address can't be blank")
    @Size(max = 150, message = "ip address must not exceed 150 characters")
    @Column(name = "ip_address", length = 150, nullable = false)
    private String ipAddress;

    @NotNull(message = "created by can't be null")
    @Column(name = "created_by", nullable = false)
    private int createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

    @NotNull(message = "user master id is required")
    @Column(name = "user_master_id", nullable = false)
    private Long userMasterId;

//    @ManyToOne
//    @JoinColumn(name = "user_master_id", referencedColumnName = "id", insertable = false, updatable = false)
//    private UserMaster userMaster;

}

