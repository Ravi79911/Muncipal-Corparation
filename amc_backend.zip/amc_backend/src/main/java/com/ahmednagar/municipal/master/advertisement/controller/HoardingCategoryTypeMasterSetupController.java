package com.ahmednagar.municipal.master.advertisement.controller;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingCategoryTypeMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingCategoryTypeMasterSetup;
import com.ahmednagar.municipal.master.advertisement.service.HoardingCategoryTypeMasterSetupService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/advertisement/hoardingcategory/typemaster/setup")
@Validated
@CrossOrigin
public class HoardingCategoryTypeMasterSetupController {
    @Autowired
    private HoardingCategoryTypeMasterSetupService hoardingCategoryTypeMasterSetupService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingCategoryTypeMasterSetup> createHoardingCategoryTypeMasterSetup(@Valid @RequestBody HoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterSetup){
        HoardingCategoryTypeMasterSetup savedHoardingCategoryTypeMasterSetup=hoardingCategoryTypeMasterSetupService.saveHoardingCategoryTypeMasterSetup(hoardingCategoryTypeMasterSetup);
        return ResponseEntity.status(201).body(savedHoardingCategoryTypeMasterSetup);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingCategoryTypeMasterSetupDto>> getAllHoardingCategoryTypeMasterSetup(){
        List<HoardingCategoryTypeMasterSetupDto> hoardingCategoryTypeMasterSetup=hoardingCategoryTypeMasterSetupService.findAllHoardingCategoryTypeMasterSetup();
        return ResponseEntity.ok(hoardingCategoryTypeMasterSetup);

    }

    //for single user by Id
    @GetMapping("/getMlBusinessNatureById/{id}")
    public ResponseEntity<HoardingCategoryTypeMasterSetup> getHoardingCategoryTypeMasterSetupById(@PathVariable Long id){
        HoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterSetup=hoardingCategoryTypeMasterSetupService.findById(id);
        return ResponseEntity.ok(hoardingCategoryTypeMasterSetup);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingCategoryTypeMasterSetupByMunicipalId(@PathVariable int municipalId){
        List<HoardingCategoryTypeMasterSetup> hoardingCategoryTypeMasterSetups = hoardingCategoryTypeMasterSetupService.findAllByMunicipalId(municipalId);
        if (hoardingCategoryTypeMasterSetups.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingCategoryTypeMasterSetup found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingCategoryTypeMasterSetups);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingCategoryTypeMasterSetup> updateHoardingCategoryTypeMasterSetup(@PathVariable("id") Long id, @RequestBody HoardingCategoryTypeMasterSetup updatedHoardingCategoryTypeMasterSetup){
        try{
            HoardingCategoryTypeMasterSetup updated=hoardingCategoryTypeMasterSetupService.updateHoardingCategoryTypeMasterSetup(id,updatedHoardingCategoryTypeMasterSetup,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingCategoryTypeMasterSetupService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }

}
