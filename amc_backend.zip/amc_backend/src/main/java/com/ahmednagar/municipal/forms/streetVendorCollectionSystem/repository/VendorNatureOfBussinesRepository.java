package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorNatureOfBussines;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface VendorNatureOfBussinesRepository extends JpaRepository<VendorNatureOfBussines, Long> {

    List<VendorNatureOfBussines> findBySuspendedStatus(Integer suspendedStatus);
}
