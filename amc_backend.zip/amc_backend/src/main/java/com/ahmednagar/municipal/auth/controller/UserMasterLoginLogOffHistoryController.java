package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.UserMasterLoginLogOffHistoryDto;
import com.ahmednagar.municipal.auth.model.UserMasterLoginLogOffHistory;
import com.ahmednagar.municipal.auth.service.UserMasterLoginLogOffHistoryService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("user/login/logoff/history")
public class UserMasterLoginLogOffHistoryController {

    @Autowired
    UserMasterLoginLogOffHistoryService userMasterLoginLogoffHistoryService;

    @PostMapping("/createUserMasterLoginLogoffHistory")
    public ResponseEntity<UserMasterLoginLogOffHistory> createUserLoginLogoffHistory(@Valid @RequestBody UserMasterLoginLogOffHistory userMasterLoginLogOffHistory) {
        UserMasterLoginLogOffHistory createdUserMasterLoginLogOffHistory = userMasterLoginLogoffHistoryService.savedUserLoginLogoffHistory(userMasterLoginLogOffHistory);
        if (createdUserMasterLoginLogOffHistory == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdUserMasterLoginLogOffHistory);
    }

    @GetMapping("getAllUserMasterLoginLogoffHistory")
    public ResponseEntity<List<UserMasterLoginLogOffHistoryDto>> getAllUserLoginLogoffHistory() {
        List<UserMasterLoginLogOffHistoryDto> userLoginLogoffHistory = userMasterLoginLogoffHistoryService.findAllUserLoginLogoffHistory();
        return ResponseEntity.ok(userLoginLogoffHistory);
    }

    @GetMapping("/getUserMasterLoginLogoffHistoryByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllUserLoginLogoffHistoryMunicipalId(@PathVariable Long municipalId) {
        List<UserMasterLoginLogOffHistoryDto> userLoginLogoffHistory = userMasterLoginLogoffHistoryService.findAllUserLoginLogoffHistoryByMunicipalId(municipalId);
        if (userLoginLogoffHistory.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No UserLoginLogoffHistory found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(userLoginLogoffHistory);
    }

    @PutMapping("/userMasterLoginLogoffHistory/update/{id}")
    public ResponseEntity<UserMasterLoginLogOffHistory> updateUserLoginLogoffHistory(@PathVariable("id") Long id, @RequestBody UserMasterLoginLogOffHistory updatedUserMasterLoginLogOffHistory) {
        try {
            UserMasterLoginLogOffHistory updated = userMasterLoginLogoffHistoryService.updateUserLoginLogoffHistory(id, updatedUserMasterLoginLogOffHistory);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/userMasterLoginLogoffHistory/suspendedStatus/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status) {
        userMasterLoginLogoffHistoryService.changeStatus(id, status, 1);
        return ResponseEntity.ok().build();
    }

}
