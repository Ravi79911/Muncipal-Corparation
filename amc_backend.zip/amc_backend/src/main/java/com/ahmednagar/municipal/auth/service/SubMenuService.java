package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.SubMenuDto;
import com.ahmednagar.municipal.auth.model.SubMenu;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface SubMenuService {
    SubMenu saveSubMenu(SubMenu subMenu);

    List<SubMenuDto> findAllSubMenu();

    List<SubMenuDto> findAllSubMenuByMunicipalId(Long municipalId);

    SubMenu updateSubMenu(Long id, SubMenu updatedSubMenu);

    SubMenu changeSuspendedStatus(Long id, int status);
}
