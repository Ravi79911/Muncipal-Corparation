package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseApplicationWorkflow;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.LicenseApplicationWorkflowService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@CrossOrigin
@RestController
@RequestMapping("/license/label/application/workflow")
public class LicenseApplicationWorkflowController {
    @Autowired
    private LicenseApplicationWorkflowService licenseApplicationWorkflowService;

    @PostMapping
    public LicenseApplicationWorkflow createLicenseApplicationWorkflow(@Valid @RequestBody LicenseApplicationWorkflow licenseApplicationWorkflow) {
        return licenseApplicationWorkflowService.createWorkflow(licenseApplicationWorkflow);
    }

//    //  to get the Application Form by id for user
//    @GetMapping("/get/{id}")
//    public ResponseEntity<Optional<LicenseApplicationWorkflow>> getLicenseApplicationWorkflowById(@PathVariable Long id) {
//        Optional<LicenseApplicationWorkflow> licenseApplicationWorkflow = licenseApplicationWorkflowService.getWorkflowById(id);
//        return ResponseEntity.ok(licenseApplicationWorkflow);
//    }
//
//    @PutMapping("/updateStatus/{id}")
//    public ResponseEntity<LicenseApplicationWorkflow> updateStatus(@PathVariable Long id,
//                                                                   @RequestParam String status,
//                                                                   @RequestParam String updatedBy) {
//        LicenseApplicationWorkflow updatedWorkflow = licenseApplicationWorkflowService.updateWorkflowStatus(id, status, updatedBy);
//        return updatedWorkflow != null ? ResponseEntity.ok(updatedWorkflow) : ResponseEntity.badRequest().build();
//    }
//    @PutMapping("/rejectDocument/{id}")
//    public ResponseEntity<LicenseApplicationWorkflow> rejectDocument(@PathVariable Long id, @RequestParam String updatedBy) {
//        LicenseApplicationWorkflow updatedWorkflow = licenseApplicationWorkflowService.processDocumentRejection(id, updatedBy);
//        return updatedWorkflow != null ? ResponseEntity.ok(updatedWorkflow) : ResponseEntity.badRequest().build();
//    }
//
//    @PutMapping("/approveDocument/{id}")
//    public ResponseEntity<LicenseApplicationWorkflow> approveDocument(@PathVariable Long id, @RequestParam String updatedBy) {
//        LicenseApplicationWorkflow updatedWorkflow = licenseApplicationWorkflowService.processDocumentApproval(id, updatedBy);
//        return updatedWorkflow != null ? ResponseEntity.ok(updatedWorkflow) : ResponseEntity.badRequest().build();
//    }
    @PostMapping("/process/{workflowId}")
    public ResponseEntity<LicenseApplicationWorkflow> processDocumentApproval(
            @PathVariable Long workflowId,
            @RequestParam boolean isApproved,
            @RequestParam String actionBy,
            @RequestParam String comment) {

        // Dynamically process the document approval based on the current stage
        LicenseApplicationWorkflow workflow = licenseApplicationWorkflowService.processDocumentApproval(workflowId, isApproved, actionBy, comment);
        return ResponseEntity.ok(workflow);
    }
}

