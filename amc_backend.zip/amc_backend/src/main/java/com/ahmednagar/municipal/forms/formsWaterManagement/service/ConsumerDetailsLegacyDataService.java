package com.ahmednagar.municipal.forms.formsWaterManagement.service;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerDetailsLegacyData;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public interface ConsumerDetailsLegacyDataService {

    Optional<ConsumerDetailsLegacyData> getConsumerDetailsLegacyData(String consumerNumber);

    ConsumerDetailsLegacyData createConsumerDetailsLegacyData(ConsumerDetailsLegacyData consumerDetailsLegacyData);

}
