package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandTransactionDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyDemandTransactionDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/forms")
public class PropertyDemandTransactionDetailsController {

    @Autowired
    PropertyDemandTransactionDetailsService propertyDemandTransactionDetailsService;

    @RequestMapping("/createPropertyDemandTransactionDetails")
    public ResponseEntity<PropertyDemandTransactionDetails> createPropertyDemandTransactionDetail(@Valid @RequestBody PropertyDemandTransactionDetails propertyDemandTransactionDetails) {
        PropertyDemandTransactionDetails newPropertyDemandTransactionDetails = propertyDemandTransactionDetailsService.createPropertyDemandTransactionDetails(propertyDemandTransactionDetails);
        return ResponseEntity.ok(newPropertyDemandTransactionDetails);
    }

    @GetMapping("/getAllPropertyDemandTransactionDetails")
    public ResponseEntity<List<PropertyDemandTransactionDetails>> getAllPropertyDemandTransactionDetail() {
        return ResponseEntity.ok(propertyDemandTransactionDetailsService.getAllPropertyDemandTransactionDetails());
    }

    @GetMapping("/propertyDemandTransactionDetails/{id}")
    public ResponseEntity<Object> getPropertyDemandTransactionDetailById(@PathVariable Long id) {
        Optional<PropertyDemandTransactionDetails> propertyDemandTransactionDetails = propertyDemandTransactionDetailsService.getPropertyDemandTransactionDetailsById(id);
        if (propertyDemandTransactionDetails.isPresent()) {
            return ResponseEntity.ok(propertyDemandTransactionDetails.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getPropertyDemandTransactionDetailsByMunicipalId/{municipalId}")
    public List<PropertyDemandTransactionDetails> getPropertyDemandTransactionDetailByMunicipalId(@PathVariable int municipalId) {
        return propertyDemandTransactionDetailsService.getPropertyDemandTransactionDetailsByMunicipalId(municipalId);
    }

    @PatchMapping("/propertyDemandTransactionDetails/suspendedStatus/{id}")
    public ResponseEntity<PropertyDemandTransactionDetails> patchPropertyDemandTransactionDetailSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        PropertyDemandTransactionDetails patchedPropertyDemandTransactionDetails = propertyDemandTransactionDetailsService.patchPropertyDemandTransactionDetailsSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedPropertyDemandTransactionDetails);
    }

}
