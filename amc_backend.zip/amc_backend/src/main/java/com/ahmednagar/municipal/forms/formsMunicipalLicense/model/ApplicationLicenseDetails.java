package com.ahmednagar.municipal.forms.formsMunicipalLicense.model;

import com.ahmednagar.municipal.master.municipalLicence.model.TradeApplicationType;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_application_license_details")
public class ApplicationLicenseDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "license_no", length = 50, nullable = false)
    private String licenseNo;

    @NotBlank(message = "License holder name cannot be blank")
    @Size(max = 255, message = "License holder name cannot exceed 255 characters")
    @Column(name = "license_holder_name", nullable = false)
    private String licenseHolderName;

    @NotBlank(message = "License type cannot be blank")
    @Size(max = 100, message = "License type cannot exceed 100 characters")
    @Column(name = "license_type", nullable = false)
    private String licenseType;

    @NotNull
    @Column(name = "generation_date", nullable = false)
    private Date generationDate;

    @NotNull(message = "Expiry date cannot be null")
    @Future(message = "Expiry date must be in the future")
    @Column(name = "expiry_date", nullable = false)
    private Date expiryDate;

    @Column(name = "rent_agreement_date")
    private Date rentAgreementDate;

    @Size(max = 150)
    @Column(name = "aggrement_no", length = 150)
    private String agreementNo;

    @Column(name = "agreement_valid_from")
    private Date agreementValidFrom;

    @Column(name = "agreement_valid_upto")
    private Date agreementValidUpto;

    @Column(name = "is_license_active")
    private Boolean isLicenseActive;

    @NotNull
    @Column(name = "created_by", nullable = false)
    private int createdBy;

    @NotNull
    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @NotNull
    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @NotNull
    @Column(name = "municipal_id", nullable = false)
    private Long municipalId;

    @OneToMany(mappedBy = "municipalLicenseId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<MunicipalLicensePaymentDetails> municipalLicensePaymentDetails;

    @ManyToOne
    @JoinColumn(name = "application_master_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ApplicationFromMaster applicationMasterId;

    @ManyToOne
    @JoinColumn(name = "application_type_id", nullable = false, referencedColumnName = "id")
    private TradeApplicationType applicationTypeId;

}
