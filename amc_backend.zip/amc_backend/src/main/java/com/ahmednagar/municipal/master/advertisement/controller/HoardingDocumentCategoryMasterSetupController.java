package com.ahmednagar.municipal.master.advertisement.controller;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingDocumentCategoryMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingDocumentCategoryMasterSetup;
import com.ahmednagar.municipal.master.advertisement.service.HoardingDocumentCategoryMasterSetupService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/advertisement/hoarding/documentcategory/master/setup")
@Validated
@CrossOrigin
public class HoardingDocumentCategoryMasterSetupController {
    @Autowired
    private HoardingDocumentCategoryMasterSetupService hoardingDocumentCategoryMasterSetupService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingDocumentCategoryMasterSetup> createHoardingDocumentCategoryMasterSetup(@Valid @RequestBody HoardingDocumentCategoryMasterSetup hoardingDocumentCategoryMasterSetup){
        HoardingDocumentCategoryMasterSetup savedHoardingDocumentCategoryMasterSetup=hoardingDocumentCategoryMasterSetupService.saveHoardingDocumentCategoryMasterSetup(hoardingDocumentCategoryMasterSetup);
        return ResponseEntity.status(201).body(savedHoardingDocumentCategoryMasterSetup);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingDocumentCategoryMasterSetupDto>> getAllHoardingDocumentCategoryMasterSetup(){
        List<HoardingDocumentCategoryMasterSetupDto> hoardingDocumentCategoryMasterSetup=hoardingDocumentCategoryMasterSetupService.findAllHoardingDocumentCategoryMasterSetup();
        return ResponseEntity.ok(hoardingDocumentCategoryMasterSetup);

    }

    //for single user by Id
    @GetMapping("/getMlBusinessNatureById/{id}")
    public ResponseEntity<HoardingDocumentCategoryMasterSetup> getHoardingDocumentCategoryMasterSetupById(@PathVariable Long id){
        HoardingDocumentCategoryMasterSetup hoardingDocumentCategoryMasterSetup=hoardingDocumentCategoryMasterSetupService.findById(id);
        return ResponseEntity.ok(hoardingDocumentCategoryMasterSetup);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingDocumentCategoryMasterSetupByMunicipalId(@PathVariable int municipalId){
        List<HoardingDocumentCategoryMasterSetup> hoardingDocumentCategoryMasterSetups = hoardingDocumentCategoryMasterSetupService.findAllByMunicipalId(municipalId);
        if (hoardingDocumentCategoryMasterSetups.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingDocumentCategoryMasterSetup found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingDocumentCategoryMasterSetups);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingDocumentCategoryMasterSetup> updateHoardingDocumentCategoryMasterSetup(@PathVariable("id") Long id, @RequestBody HoardingDocumentCategoryMasterSetup updatedHoardingDocumentCategoryMasterSetup){
        try{
            HoardingDocumentCategoryMasterSetup updated=hoardingDocumentCategoryMasterSetupService.updateHoardingDocumentCategoryMasterSetup(id,updatedHoardingDocumentCategoryMasterSetup,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingDocumentCategoryMasterSetupService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }

}

