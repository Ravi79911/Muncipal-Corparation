package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.NewLicenseWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.NewLicenseWorkFlowLevel;
import com.ahmednagar.municipal.auth.service.NewLicenseWorkFlowLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/license/work/new-flow/level")
public class NewLicenseWorkFlowLevelController {

    @Autowired
    private NewLicenseWorkFlowLevelService newLicenseWorkFlowLevelService;

    @PostMapping("/new-transition")
    public ResponseEntity<NewLicenseWorkFlowLevel> handleWorkFlowsTransition(@RequestBody NewLicenseWorkFlowLevel newLicenseWorkFlowLevel) {
        NewLicenseWorkFlowLevel updatedNewLicenseWorkFlowLevel = newLicenseWorkFlowLevelService.handleWorkFlowsTransition(newLicenseWorkFlowLevel);
        return ResponseEntity.ok(updatedNewLicenseWorkFlowLevel);
    }

    @PostMapping("/new-application")
    public ResponseEntity<NewLicenseWorkFlowLevel> createNewWorkflow(@RequestBody NewLicenseWorkFlowLevel newLicenseWorkFlowLevel) {
        NewLicenseWorkFlowLevel savedWorkflow = newLicenseWorkFlowLevelService.createNewApplicationTransation(newLicenseWorkFlowLevel);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedWorkflow);
    }

    @GetMapping("/getAllNewWorkFlowsList")
    public ResponseEntity<List<NewLicenseWorkFlowLevelDto>> getAllNewWaterWorkFlowLevelList() {
        List<NewLicenseWorkFlowLevelDto> workFlows = newLicenseWorkFlowLevelService.getAllNewWaterWorkFlowLevel();
        return ResponseEntity.ok(workFlows);
    }

}
