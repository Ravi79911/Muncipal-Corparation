package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorFinacialYears;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorFinacialYearsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorFinacialYearsController {

    @Autowired
    private VendorFinacialYearsService vendorFinacialYearsService;

    @PostMapping("/saveVendorFinacialYearsMaster")
    public ResponseEntity<VendorFinacialYears> saveVendorFinacialYearsMaster(@RequestBody VendorFinacialYears vendorFinacialYears) {
        return ResponseEntity.ok(vendorFinacialYearsService.saveVendorFinacialYears(vendorFinacialYears));
    }

    @GetMapping("/getAllVendorFinacialYearsMaster")
    public ResponseEntity<List<VendorFinacialYears>> getAllVendorFinacialYearsMaster() {
        return ResponseEntity.ok(vendorFinacialYearsService.getAllVendorFinacialYears());
    }
}
