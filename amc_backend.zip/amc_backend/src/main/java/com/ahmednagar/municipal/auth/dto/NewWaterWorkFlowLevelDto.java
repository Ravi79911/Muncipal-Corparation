package com.ahmednagar.municipal.auth.dto;

import com.ahmednagar.municipal.auth.model.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class NewWaterWorkFlowLevelDto {

    private Long id;
    private Long zoneId;
    private Long wardId;
    private String status;
    private Long statusCode;
    private Float mailStatus;
    private String remarks;
    private Integer createdBy;
    private LocalDateTime createdDate;
    private Long municipalId;
    private ViewNewWaterConnectionFormMaster waterApplicationId;
    private RoleDto currentRoleId;
    private UserMasterDTO currentUserId;
    private UserMasterDTO nextUserId;
    private RoleDto nextRoleId;
    private WorkFlowMaster workFlowMasterId;
    private CitizenSignUpMaster citizenId;

}
