package com.ahmednagar.municipal.master.advertisement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingTypeMasterSetupDto {
    private Long id;
    private HoardingCategoryTypeMasterSetupDto hoardingCategoryTypeMasterId;
    private String hoardingTypeName;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
