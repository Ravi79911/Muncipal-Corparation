package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationFromMasterDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFromMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ApplicationFromMasterService {

    ApplicationFromMaster saveapplicationFromMasterService(ApplicationFromMaster applicationFromMaster, int createdBy);

//    List<ApplicationFromMasterDto> findAllApplicationFromMaster();
//
//    List<ApplicationFromMaster> findAllActiveApplicationFromMaster(Integer status);

    ApplicationFromMaster findApplicationFromMasterById(Long id);

    List<ApplicationFromMasterDto> findAllApplicationFromMasterByMunicipalId(int municipalId);

    ApplicationFromMaster updateApplicationFromMaster(Long id, ApplicationFromMaster updatedApplicationFromMaster, int updatedBy);

    ApplicationFromMaster changeSuspendedStatus(Long id, int status, int updatedBy);

}
