package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorMarketMaster;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorMarketMasterRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorMarketMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VendorMarketMasterServiceImpl implements VendorMarketMasterService {

    @Autowired
    private VendorMarketMasterRepository vendorMarketMasterRepository;

    @Override
    public VendorMarketMaster saveVendorMarketMaster(VendorMarketMaster vendorMarketMaster) {
        vendorMarketMaster.setCreatedDate(LocalDateTime.now());
        vendorMarketMaster.setSuspendedStatus(0);
        return vendorMarketMasterRepository.saveAndFlush(vendorMarketMaster);
    }

    @Override
    public Optional<VendorMarketMaster> getVendorMarketMasterById(Long id) {
        return vendorMarketMasterRepository.findById(id);
    }

    @Override
    public List<VendorMarketMaster> getAllVendorMarketMasters() {
        return vendorMarketMasterRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<VendorMarketMaster> updateVendorMarketMaster(Long id, VendorMarketMaster vendorMarketMaster) {
        Optional<VendorMarketMaster> existingVendorMarketMaster = vendorMarketMasterRepository.findById(id);
        if (existingVendorMarketMaster.isPresent()) {
            VendorMarketMaster updatedVendorMarketMaster = existingVendorMarketMaster.get();
            updatedVendorMarketMaster.setMarketName(vendorMarketMaster.getMarketName());
            updatedVendorMarketMaster.setEffectiveDate(vendorMarketMaster.getEffectiveDate());
            updatedVendorMarketMaster.setIsActive(vendorMarketMaster.getIsActive());
            updatedVendorMarketMaster.setUpdatedBy(vendorMarketMaster.getUpdatedBy());
            updatedVendorMarketMaster.setUpdatedDate(LocalDateTime.now());
            return Optional.of(vendorMarketMasterRepository.save(updatedVendorMarketMaster));
        }
        return Optional.empty();
    }

    @Override
    public Optional<VendorMarketMaster> deleteVendorMarketMaster(Long id) {
        Optional<VendorMarketMaster> existingVendorMarketMaster = vendorMarketMasterRepository.findById(id);
        if (existingVendorMarketMaster.isPresent()) {
            VendorMarketMaster deletedVendorMarketMaster = existingVendorMarketMaster.get();
            deletedVendorMarketMaster.setSuspendedStatus(1);
            return Optional.of(vendorMarketMasterRepository.save(deletedVendorMarketMaster));
        }
        return Optional.empty();
    }
}
