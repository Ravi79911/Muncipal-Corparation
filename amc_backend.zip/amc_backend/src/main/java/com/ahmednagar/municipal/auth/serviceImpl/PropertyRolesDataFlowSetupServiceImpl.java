package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.PropertyRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.PropertyRolesDataFlowSetup;
import com.ahmednagar.municipal.auth.repository.PropertyRolesDataFlowSetupRepository;
import com.ahmednagar.municipal.auth.service.PropertyRolesDataFlowSetupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PropertyRolesDataFlowSetupServiceImpl implements PropertyRolesDataFlowSetupService {

    @Autowired
    private PropertyRolesDataFlowSetupRepository propertyRolesDataFlowSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<PropertyRolesDataFlowSetupDto> findAllRolesDataFlowSetup() {
        List<PropertyRolesDataFlowSetup> roles = propertyRolesDataFlowSetupRepository.findAll();
        return roles.stream()
                .map(role -> modelMapper.map(role, PropertyRolesDataFlowSetupDto.class))
                .collect(Collectors.toList());
    }

//    @Override
//    public RolesDataFlowSetup getNextRoleIdForForward(Long currentRoleId) {
//        return rolesDataFlowSetupRepository.findByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId, 1000L, 1)
//                .orElseThrow(() -> new RuntimeException("No next role found for current role ID: " + currentRoleId + " and status code: " + 1000L+"(Forward)"));
//    }
//
//    @Override
//    public List<RolesDataFlowSetup> getNextRoleListForBackWard(Long currentRoleId) {
//        List<RolesDataFlowSetup> list = rolesDataFlowSetupRepository
//                .findAllByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId, 1001L, 1.0);
//        if (list.isEmpty()) {
//            throw new RuntimeException("No next roles found for currentRoleId: " + currentRoleId + " and status code: " + 1001L+"(Backward)");
//        }
//        return list;
//    }
//
//    @Override
//    public RolesDataFlowSetup getNextRoleIdForDocumentVerificationAccept(Long currentRoleId) {
//        return rolesDataFlowSetupRepository.findByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId, 1006L, 1)
//                .orElseThrow(() -> new RuntimeException("No next role found for current role ID: " + currentRoleId + " and status code: " + 1006L+"(DocumentVerificationAccept)"));
//    }

    @Override
    public List<PropertyRolesDataFlowSetup> getNextRoleListForListSelection(Long currentRoleId, Long statusCode, Integer isActive) {
        List<PropertyRolesDataFlowSetup> list = propertyRolesDataFlowSetupRepository
                .findAllByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId,statusCode, isActive);
        if (list.isEmpty()) {
            throw new RuntimeException("No next roles found for currentRoleId: " + currentRoleId + " and status code: " + 1007L+"(DocumentVerificationReject)");
        }
        return list;
    }

    @Override
    public PropertyRolesDataFlowSetup getNextRoleForSingleSelection(Long currentRoleId, Long statusCode, Integer isActive) {
        return propertyRolesDataFlowSetupRepository
                .findByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId, statusCode, isActive)
                .orElseThrow(() -> new RuntimeException(
                        "No next role found for currentRoleId: " + currentRoleId +
                                ", statusCode: " + statusCode + ", isActive: " + isActive));
    }

}
