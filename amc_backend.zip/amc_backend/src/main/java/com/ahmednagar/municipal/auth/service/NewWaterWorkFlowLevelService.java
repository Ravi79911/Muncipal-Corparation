package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.NewWaterWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.NewWaterWorkFlowLevel;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface NewWaterWorkFlowLevelService {

    NewWaterWorkFlowLevel handleWorkFlowsTransition(NewWaterWorkFlowLevel newWaterWorkFlowLevel);

    List<NewWaterWorkFlowLevelDto> getAllNewWaterWorkFlowLevel();

    NewWaterWorkFlowLevel createNewApplicationTransation(NewWaterWorkFlowLevel newWaterWorkFlowLevelRequest);

}
