package com.ahmednagar.municipal.master.advertisement.service;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingTypeSizeMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeSizeMasterSetup;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingTypeSizeMasterSetupService {
    HoardingTypeSizeMasterSetup saveHoardingTypeSizeMasterSetup(HoardingTypeSizeMasterSetup hoardingTypeSizeMasterSetup);

    List<HoardingTypeSizeMasterSetupDto> findAllHoardingTypeSizeMasterSetup();

    HoardingTypeSizeMasterSetup findById(Long id);

    List<HoardingTypeSizeMasterSetup> findAllByMunicipalId(int municipalId);

    HoardingTypeSizeMasterSetup updateHoardingTypeSizeMasterSetup(Long id, HoardingTypeSizeMasterSetup updatedHoardingTypeSizeMasterSetup,int updatedBy);

    HoardingTypeSizeMasterSetup changeStatus(Long id, Integer status,int updatedBy);

}
