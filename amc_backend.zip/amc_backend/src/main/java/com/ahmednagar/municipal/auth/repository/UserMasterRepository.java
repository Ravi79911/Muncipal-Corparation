package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.AuthWardMaster;
import com.ahmednagar.municipal.auth.model.AuthZoneMaster;
import com.ahmednagar.municipal.auth.model.RoleMaster;
import com.ahmednagar.municipal.auth.model.UserMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface UserMasterRepository extends JpaRepository<UserMaster, Long> {

    boolean existsByEmail(String email);

    boolean existsByMobileNo(String mobileNo);

    boolean existsByUserName(String userName);

    Optional<UserMaster> findByEmail(String email);

    Optional<UserMaster> findByMobileNo(String mobileNo);

    Optional<UserMaster> findByToken(String token);

    @Query("SELECT u FROM UserMaster u " +
            "LEFT JOIN FETCH u.userMasterZoneWardAllocations uwz " +
            "LEFT JOIN FETCH uwz.zoneMaster zm " +
            "LEFT JOIN FETCH uwz.wardMaster wm")
    List<UserMaster> findAllWithZoneAndWardAllocations();

    Optional<UserMaster> findFirstByRoleMaster(RoleMaster roleMaster);

    Optional<UserMaster> findFirstByRoleMasterAndId(RoleMaster roleMaster, Long id);

//
//@Query("SELECT u FROM UserMaster u " +
//        "JOIN UserMasterZoneWardAllocation uzw ON u.id = uzw.userMaster.id " +
//        "WHERE u.roleMaster.id = :roleId " +
//        "AND uzw.zoneMaster.id = :zoneId " +
//        "AND uzw.wardMaster.id = :wardId " +
//        "AND u.isVerified = true")
//    UserMaster findUsersByZoneWardAndRole(@Param("zoneId") Long zoneId,
//                                                @Param("wardId") Long wardId,
//                                                @Param("roleId") Long roleId);

    @Query("SELECT u FROM UserMaster u JOIN UserMasterZoneWardAllocation zw ON u.id = zw.userMaster.id " +
            "WHERE zw.zoneMaster.id = :zoneId AND zw.wardMaster.id = :wardId AND u.roleMaster.id = :roleId " +
            "AND u.isVerified = true")
    Optional<UserMaster> findFirstByZoneWardAndRole(@Param("zoneId") Long zoneId,
                                                    @Param("wardId") Long wardId,
                                                    @Param("roleId") Long roleId);


//    @Query("SELECT u FROM UserMaster u " +
//            "JOIN u.userMasterZoneWardAllocations zw " +
//            "WHERE zw.zoneMaster.zoneName = :zoneName " +
//            "AND zw.wardMaster.wardNo = :wardName " +
//            "AND u.roleMaster.id = :roleId " +
//            "AND u.isVerified = true")
//    Optional<UserMaster> findFirstByZoneWardAndRoles(
//            @Param("zoneName") Long zoneName,
//            @Param("wardName") Long wardName,
//            @Param("roleId") Long roleId
//    );

}
