package com.ahmednagar.municipal.forms.formsWaterManagement.model;

import com.ahmednagar.municipal.master.waterManagement.modal.DDMeterStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbl_water_demand_details")
public class ConsumerDemandDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

//    @Column(name = "consumer_id", nullable = false)
//    private Long consumerId;

    @Column(name = "bill_num", nullable = false, length = 50)
    @Size(max = 50, message = "Bill number cannot exceed 50 characters")
    private String billNum;

    @Column(name = "billing_month", nullable = false)
    private LocalDate billingMonth;

    @Column(name = "previous_reading", nullable = false)
    private int previousReading;

    @Column(name = "current_reading", nullable = false)
    private int currentReading;

    @Column(name = "consumption_unit", nullable = false)
    private int consumptionUnit;

    @Column(name = "per_unit_charges", nullable = false)
    private Long perUnitCharges;

    @Column(name = "due_date", nullable = false)
    private LocalDate dueDate;

    @Column(name = "generated_date", nullable = false)
    private LocalDate generatedDate;

    @Column(name = "bill_amount", nullable = false, precision = 18, scale = 3)
    private BigDecimal billAmount;

    @Column(name = "status", nullable = false, length = 50)
    private String status;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "created_by", nullable = false)
    private Integer createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @Column(name = "municipal_id", nullable = false)
    private Long municipalId;

    @ManyToOne
    @JoinColumn(name = "consumer_id", referencedColumnName = "id", nullable = false)
    private ConsumerDetailsLegacyData consumerDetailsLegacyDataId;

    @ManyToOne
    @JoinColumn(name = "meter_status_id", referencedColumnName = "id", nullable = false)
    private DDMeterStatus meterStatusId;

}
