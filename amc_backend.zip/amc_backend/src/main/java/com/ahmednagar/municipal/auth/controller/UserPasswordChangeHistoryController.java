package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.UserPasswordChangeHistoryDto;
import com.ahmednagar.municipal.auth.model.UserPasswordChangeHistory;
import com.ahmednagar.municipal.auth.service.UserPasswordChangeHistoryService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/user/password/change/history")
public class UserPasswordChangeHistoryController {
    @Autowired
    private UserPasswordChangeHistoryService userPasswordChangeHistoryService;

    @PostMapping("/create")
    public ResponseEntity<UserPasswordChangeHistory> createUserPasswordChangeHistory(@Valid @RequestBody UserPasswordChangeHistory userPasswordChangeHistory){
        UserPasswordChangeHistory createdUserPasswordChangeHistory=userPasswordChangeHistoryService.savedUserPasswordChangeHistory(userPasswordChangeHistory);
        if(createdUserPasswordChangeHistory==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdUserPasswordChangeHistory);
    }
    @GetMapping("all")
    public ResponseEntity<List<UserPasswordChangeHistoryDto>> getAllUserPasswordChangeHistory(){
        List<UserPasswordChangeHistoryDto> userPasswordChangeHistory=userPasswordChangeHistoryService.findAllUserPasswordChangeHistory();
        return ResponseEntity.ok(userPasswordChangeHistory);
    }
    //get sub menu By MunicipalId
    @GetMapping("/MunicipalSubMenu/{municipalId}")
    public ResponseEntity<?> getAllUserPasswordChangeHistoryByMunicipalId(@PathVariable Long municipalId){
        List<UserPasswordChangeHistoryDto> userPasswordChangeHistory=userPasswordChangeHistoryService.findAllUserPasswordChangeHistoryByMunicipalId(municipalId);
        if (userPasswordChangeHistory.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No UserPasswordChangeHistory found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(userPasswordChangeHistory);
    }
    //     Update for admin
    @PutMapping("/updatedUserPasswordChangeHistory/{id}")
    public ResponseEntity<UserPasswordChangeHistory> updateUserPasswordChangeHistory(@PathVariable("id") Long id, @RequestBody UserPasswordChangeHistory updatedUserPasswordChangeHistory){
        try{
            UserPasswordChangeHistory updated=userPasswordChangeHistoryService.updateUserPasswordChangeHistory(id,updatedUserPasswordChangeHistory);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status for admin
    @PatchMapping("/deleteUserPasswordChangeHistory/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false) Integer status){
        userPasswordChangeHistoryService.changeStatus(id,status);
        return ResponseEntity.ok().build();

    }

}
