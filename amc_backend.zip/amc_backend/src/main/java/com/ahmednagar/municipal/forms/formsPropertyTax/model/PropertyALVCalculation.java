package com.ahmednagar.municipal.forms.formsPropertyTax.model;

import jakarta.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class PropertyALVCalculation {

    @Id
    private Long id;

    private BigDecimal floorBuildupAreaSqft;

    private BigDecimal floorBuildupAreaSqMtr;

    private BigDecimal carpetAreaSqft;

    private BigDecimal carpetAreaSqMtr;

    private BigDecimal alvRateValue;

    private BigDecimal floorAlpValue;

    private BigDecimal buildingMaintenanceRate;

    private BigDecimal floorRateableValue;

    private BigDecimal totalAnnualTax;

    private BigDecimal totalStateTax;

    private BigDecimal totalPayableTax;

    private BigDecimal rentValueAmount;

    private LocalDate rentCalculatedFrom;

    private LocalDate rentCalculatedFromUpTo;

    private Long floorUsageType;

    private Long occupancyTypeId;

    private Long roadTypeId;

    private Long constructionTypeId;

    private Long ageOfBuildingId;

    private int municipalId;

}
