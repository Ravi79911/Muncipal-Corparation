package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.service.CitizenSignUpService;
import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.exception.MailSendingException;
import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Collections;

@Slf4j
@RestController
@RequestMapping("/auth/citizen")
public class CitizenSignUpController {

    @Autowired
    CitizenSignUpService citizenSignUpService;

    @PostMapping(value = "/signup", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse> signUpCitizen(@Valid @RequestParam(value = "profilePic", required = false) MultipartFile profilePic,
                                                     @RequestParam("citizenName") String citizenName,
                                                     @RequestParam("fatherMotherHusbandName") String fatherMotherHusbandName,
                                                     @RequestParam("relationship") String relationship,
                                                     @RequestParam("zoneId") Long zoneId,
                                                     @RequestParam("wardId") Long wardId,
                                                     @RequestParam("email") String email,
                                                     @RequestParam("userName") String userName,
                                                     @RequestParam("mobileNo") String mobileNo,
                                                     @RequestParam(value = "gender", required = false) String gender,
                                                     @RequestParam(value = "maritalStatus", required = false) String maritalStatus,
                                                     @RequestParam("dob") LocalDate dob,
                                                     @RequestParam("password") String password,
                                                     @RequestParam("permanentAddress") String permanentAddress,
                                                     @RequestParam("p_City") String pCity,
                                                     @RequestParam("p_State") String pState,
                                                     @RequestParam("p_Pincode") Long pPincode,
                                                     @RequestParam("correspondingAddress") String correspondingAddress,
                                                     @RequestParam("c_City") String cCity,
                                                     @RequestParam("c_State") String cState,
                                                     @RequestParam("c_Pincode") Long cPincode,
                                                     @RequestParam(value = "isPropertyExist", required = false) Boolean isPropertyExist,
                                                     @RequestParam(value = "holdingNo", required = false) String holdingNo,
                                                     @RequestParam(value = "isWaterConnectionExist", required = false) Boolean isWaterConnectionExist,
                                                     @RequestParam(value = "consumerNum", required = false) String consumerNum,
                                                     @RequestParam(value = "isTradeLicenseExist", required = false) Boolean isTradeLicenseExist,
                                                     @RequestParam(value = "licenceNum", required = false) String licenceNum,
                                                     @RequestParam(value = "isAdvertismentExist", required = false) Boolean isAdvertismentExist,
                                                     @RequestParam(value = "advertisementApplicationNo", required = false) String advertisementApplicationNo,
                                                     @RequestParam("municipalId") Integer municipalId,
                                                     @RequestParam("suspendedStatus") Integer suspendedStatus,
                                                     HttpServletRequest request
    ) {
        CitizenSignUpMaster citizenSignUpMaster = new CitizenSignUpMaster();
        citizenSignUpMaster.setCitizenName(citizenName);
        citizenSignUpMaster.setFatherMotherHusbandName(fatherMotherHusbandName);
        citizenSignUpMaster.setRelationship(relationship);
        citizenSignUpMaster.setZoneId(zoneId);
        citizenSignUpMaster.setWardId(wardId);
        citizenSignUpMaster.setEmail(email);
        citizenSignUpMaster.setUserName(userName);
        citizenSignUpMaster.setMobileNo(mobileNo);
        citizenSignUpMaster.setGender(gender);
        citizenSignUpMaster.setMaritalStatus(maritalStatus);
        citizenSignUpMaster.setDob(dob);
        citizenSignUpMaster.setPassword(password);
        citizenSignUpMaster.setPermanentAddress(permanentAddress);
        citizenSignUpMaster.setP_City(pCity);
        citizenSignUpMaster.setP_State(pState);
        citizenSignUpMaster.setP_Pincode(pPincode);
        citizenSignUpMaster.setCorrespondingAddress(correspondingAddress);
        citizenSignUpMaster.setC_City(cCity);
        citizenSignUpMaster.setC_State(cState);
        citizenSignUpMaster.setC_Pincode(cPincode);
        citizenSignUpMaster.setIsPropertyExist(isPropertyExist);
        citizenSignUpMaster.setHoldingNo(holdingNo);
        citizenSignUpMaster.setIsWaterConnectionExist(isWaterConnectionExist);
        citizenSignUpMaster.setConsumerNum(consumerNum);
        citizenSignUpMaster.setIsTradeLicenseExist(isTradeLicenseExist);
        citizenSignUpMaster.setLicenceNum(licenceNum);
        citizenSignUpMaster.setIsAdvertismentExist(isAdvertismentExist);
        citizenSignUpMaster.setAdvertisementApplicationNo(advertisementApplicationNo);
        citizenSignUpMaster.setMunicipalId(municipalId);
        citizenSignUpMaster.setSuspendedStatus(suspendedStatus);

        CitizenSignUpMaster registeredCitizen = citizenSignUpService.registerCitizen(citizenSignUpMaster, profilePic, request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Citizen registered successfully. OTP has been sent.", registeredCitizen));
    }

    @PostMapping(value = "/updateProfile", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse> updateCitizenProfile(@RequestHeader("Authorization") String jwt,
                                                            @RequestParam(value = "imageFile", required = false) MultipartFile imageFile,
                                                            @RequestParam(value = "fatherMotherHusbandName", required = false) String fatherMotherHusbandName,
                                                            @RequestParam(value = "relationship", required = false) String relationship,
                                                            @RequestParam(value = "gender", required = false) String gender,
                                                            @RequestParam(value = "maritalStatus", required = false) String maritalStatus,
                                                            @RequestParam(value = "zoneId", required = false) Long zoneId,
                                                            @RequestParam(value = "wardId", required = false) Long wardId,
                                                            @RequestParam(value = "correspondingAddress", required = false) String correspondingAddress,
                                                            @RequestParam(value = "c_City", required = false) String cCity,
                                                            @RequestParam(value = "c_State", required = false) String cState,
                                                            @RequestParam(value = "c_Pincode", required = false) Long cPincode,
                                                            @RequestParam(value = "isPropertyExist", required = false) Boolean isPropertyExist,
                                                            @RequestParam(value = "holdingNo", required = false) String holdingNo,
                                                            @RequestParam(value = "isWaterConnectionExist", required = false) Boolean isWaterConnectionExist,
                                                            @RequestParam(value = "consumerNum", required = false) String consumerNum,
                                                            @RequestParam(value = "isTradeLicenseExist", required = false) Boolean isTradeLicenseExist,
                                                            @RequestParam(value = "licenceNum", required = false) String licenceNum,
                                                            @RequestParam(value = "isAdvertismentExist", required = false) Boolean isAdvertismentExist,
                                                            @RequestParam(value = "advertisementApplicationNo", required = false) String advertisementApplicationNo,
                                                            @RequestParam(value = "updatedBy", required = false) Integer updatedBy) {
        try {

            // remove Bearer prefix
            if (jwt != null && jwt.startsWith("Bearer ")) {
                jwt = jwt.substring(7);
            }

            // get the current citizen profile from the database
            CitizenSignUpMaster citizenSignUpMaster = citizenSignUpService.findCitizenProfileByJwt(jwt);

            // only update the fields that are provided in the request
            if (fatherMotherHusbandName != null)
                citizenSignUpMaster.setFatherMotherHusbandName(fatherMotherHusbandName);
            if (relationship != null) citizenSignUpMaster.setRelationship(relationship);
            if (gender != null) citizenSignUpMaster.setGender(gender);
            if (maritalStatus != null) citizenSignUpMaster.setMaritalStatus(maritalStatus);
            if (zoneId != null) citizenSignUpMaster.setZoneId(zoneId);
            if (wardId != null) citizenSignUpMaster.setWardId(wardId);
            if (correspondingAddress != null) citizenSignUpMaster.setCorrespondingAddress(correspondingAddress);
            if (cCity != null) citizenSignUpMaster.setC_City(cCity);
            if (cState != null) citizenSignUpMaster.setC_State(cState);
            if (cPincode != null) citizenSignUpMaster.setC_Pincode(cPincode);
            if (isPropertyExist != null) citizenSignUpMaster.setIsPropertyExist(isPropertyExist);
            if (holdingNo != null) citizenSignUpMaster.setHoldingNo(holdingNo);
            if (isWaterConnectionExist != null) citizenSignUpMaster.setIsWaterConnectionExist(isWaterConnectionExist);
            if (consumerNum != null) citizenSignUpMaster.setConsumerNum(consumerNum);
            if (isTradeLicenseExist != null) citizenSignUpMaster.setIsTradeLicenseExist(isTradeLicenseExist);
            if (licenceNum != null) citizenSignUpMaster.setLicenceNum(licenceNum);
            if (isAdvertismentExist != null) citizenSignUpMaster.setIsAdvertismentExist(isAdvertismentExist);
            if (advertisementApplicationNo != null)
                citizenSignUpMaster.setAdvertisementApplicationNo(advertisementApplicationNo);
            if (updatedBy != null) citizenSignUpMaster.setUpdateBy(updatedBy);

            // save the updated citizen profile
            CitizenSignUpMaster updatedCitizen = citizenSignUpService.updateCitizenProfile(citizenSignUpMaster, imageFile);
            return ResponseEntity.ok(ApiResponse.success("Profile updated successfully", updatedCitizen));

        } catch (MailSendingException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.failure("Email sending failed: " + e.getMessage(), "EMAIL_SENDING_ERROR"));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.failure("Validation error: " + e.getMessage(), "VALIDATION_ERROR"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.failure("Unexpected error: " + e.getMessage(), "INTERNAL_SERVER_ERROR"));
        }
    }

    @GetMapping("/getProfilePicURL")
    public ResponseEntity<ApiResponse> getProfilePicUrl(@RequestHeader("Authorization") String token) {
        String url = citizenSignUpService.getProfilePicUrlFromToken(token);
        return ResponseEntity.ok(ApiResponse.success("Profile picture URL fetched successfully.", Collections.singletonMap("profilePicUrl", url)));
    }

//    @GetMapping("/getProfilePic/{citizenId}")
//    public ResponseEntity<Resource> getCitizenProfilePic(@PathVariable Long citizenId) {
//        try {
//            Resource file = citizenSignUpService.getCitizenProfilePicByCitizenId(citizenId);
//            return ResponseEntity.ok()
//                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
//                    .body(file);
//        } catch (IOException e) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
//        }
//    }

    @GetMapping("/profile")
    public ResponseEntity<?> getCitizenProfile(@RequestHeader("Authorization") String jwt) {
        try {
            if (jwt == null || !jwt.startsWith("Bearer ")) {
                throw new IllegalArgumentException("Invalid JWT token format");
            }

            String token = jwt.substring(7);
            CitizenSignUpMaster citizenSignUpMaster = citizenSignUpService.findCitizenProfileByJwt(token);
            return new ResponseEntity<>(citizenSignUpMaster, HttpStatus.OK);

        } catch (IllegalArgumentException ex) {
            log.error("Invalid JWT token: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (ResourceNotFoundException ex) {
            log.error("Citizen not found: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            log.error("An error occurred while fetching the citizen profile", ex);
            return new ResponseEntity<>(new ApiResponse("An error occurred while fetching the citizen profile", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/checkEmailIdExists")
    public ResponseEntity<Boolean> checkEmailIdExists(@RequestParam String email) {
        boolean emailExist = citizenSignUpService.isEmailExists(email);
        return ResponseEntity.ok(emailExist);
    }

    @GetMapping("/checkUserNameExists")
    public ResponseEntity<Boolean> checkUserNameExists(@RequestParam String userName) {
        boolean userNameExist = citizenSignUpService.isUserNameExists(userName);
        return ResponseEntity.ok(userNameExist);
    }

    @PostMapping("/sendOtpForMobileLogin")
    public ResponseEntity<String> sendOtpForMobileLogin(@RequestParam String mobileNo) {
        String result = citizenSignUpService.sendOtpForMobileLogin(mobileNo);
        if (result.equals("OTP sent successfully")) {
            return new ResponseEntity<>(result, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(result, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/validateEmailOtp")
    public ResponseEntity<String> validateEmailOtp(@RequestParam("citizenId") Long citizenId, @RequestParam("otp") String otp) {
        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpService.findByCitizenId(citizenId);

        if (citizenSignUpMaster != null && citizenSignUpService.validateEmailOtp(citizenSignUpMaster, otp)) {
            return ResponseEntity.ok("email otp validated successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid or expired email otp");
        }
    }

    @PostMapping("/validateMobileOtp")
    public ResponseEntity<String> validateMobileOtp(@RequestParam("citizenId") Long citizenId, @RequestParam("otp") String otp) {
        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpService.findByCitizenId(citizenId);

        if (citizenSignUpMaster != null && citizenSignUpService.validateMobileOtp(citizenSignUpMaster, otp)) {
            return ResponseEntity.ok("mobile otp validated successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid or expired mobile otp");
        }
    }

    @PostMapping("/resendEmailOtp")
    public ResponseEntity<String> resendEmailOtp(@RequestParam("citizenId") Long citizenId) {
        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpService.findByCitizenId(citizenId);

        if (citizenSignUpMaster != null) {
            citizenSignUpService.resendEmailOtp(citizenSignUpMaster);
            return ResponseEntity.ok("email otp has been resent successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("citizen not found.");
        }
    }

    @PostMapping("/resendMobileOtp")
    public ResponseEntity<String> resendMobileOtp(@RequestParam("citizenId") Long citizenId) {
        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpService.findByCitizenId(citizenId);

        if (citizenSignUpMaster != null) {
            citizenSignUpService.resendMobileOtp(citizenSignUpMaster);
            return ResponseEntity.ok("mobile otp has been resent successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("user not found.");
        }
    }

    @PostMapping("/validateForgotUserNameOtp")
    public ResponseEntity<String> validateForgotUserNameOtp(@RequestParam Long citizenId,
                                                            @RequestParam String emailOtp,
                                                            @RequestParam String mobileOtp) {
        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpService.findByCitizenId(citizenId);
        try {
            String response = citizenSignUpService.validateForgotUsernameOtp(citizenSignUpMaster, emailOtp, mobileOtp);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/requestForgotUserName")
    public ResponseEntity<String> forgotUserName(@RequestBody ForgotUserNameRequest forgotUserNameRequest) {
        try {
            String response = citizenSignUpService.forgotUsername(forgotUserNameRequest);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/requestChangeEmailOrMobile/{citizenId}")
    public ResponseEntity<String> requestEmailOrMobileChange(
            @PathVariable("citizenId") Long citizenId,
            @Valid @RequestBody ChangeEmailMobileRequest changeEmailMobileRequest) {

        try {
            String response = citizenSignUpService.requestChangeEmailOrMobile(citizenId, changeEmailMobileRequest);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/validateChangeEmailOrMobileOtp/{citizenId}")
    public ResponseEntity<String> validateEmailOrMobileOtp(
            @PathVariable("citizenId") Long citizenId,
            @RequestParam("otp") String otp,
            @RequestBody ChangeEmailMobileRequest changeEmailMobileRequest) {

        try {
            boolean isUpdated = citizenSignUpService.validateChangeEmailOrMobileOtp(citizenId, otp, changeEmailMobileRequest);

            if (isUpdated) {
                return ResponseEntity.ok("Email or mobile number successfully updated.");
            } else {
                return ResponseEntity.badRequest().body("OTP validation failed or expired.");
            }
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/changePassword/{citizenId}")
    public ResponseEntity<ApiResponse> changePasswords(@PathVariable Long citizenId, @RequestBody ChangePasswordRequest changePasswordRequest) {
        String message = citizenSignUpService.changePassword(citizenId, changePasswordRequest);
        return ResponseEntity.ok(new ApiResponse(message, true));
    }

    @PostMapping("/forgotPassword")
    public ResponseEntity<String> forgotPasswords(@RequestParam String email) {
        String message = citizenSignUpService.forgotPassword(email);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

    @PutMapping("/resetPassword")
    public ResponseEntity<String> resetPasswords(@RequestParam String token, @RequestBody ForgotPassword forgotPassword) {
        String message = citizenSignUpService.resetPassword(token, forgotPassword);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

}
