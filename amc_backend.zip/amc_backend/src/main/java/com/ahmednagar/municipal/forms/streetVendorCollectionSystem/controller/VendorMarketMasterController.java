package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorMarketMaster;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorMarketMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorMarketMasterController {

    @Autowired
    private VendorMarketMasterService vendorMarketMasterService;

    @PostMapping("/saveVendorMarketMaster")
    public ResponseEntity<VendorMarketMaster> createVendorMarketMaster(@RequestBody VendorMarketMaster vendorMarketMaster) {
        return ResponseEntity.ok(vendorMarketMasterService.saveVendorMarketMaster(vendorMarketMaster));
    }

    @GetMapping("/getVendorMarketMasterById/{id}")
    public ResponseEntity<Optional<VendorMarketMaster>> getVendorMarketMasterById(@PathVariable Long id) {
        return ResponseEntity.ok(vendorMarketMasterService.getVendorMarketMasterById(id));
    }

    @GetMapping("/getAllVendorMarketMasters")
    public ResponseEntity<Iterable<VendorMarketMaster>> getAllVendorMarketMasters() {
        return ResponseEntity.ok(vendorMarketMasterService.getAllVendorMarketMasters());
    }

    @PatchMapping("/updateVendorMarketMaster/{id}")
    public ResponseEntity<Optional<VendorMarketMaster>> updateVendorMarketMaster(@PathVariable Long id, @RequestBody VendorMarketMaster vendorMarketMaster) {
        return ResponseEntity.ok(vendorMarketMasterService.updateVendorMarketMaster(id, vendorMarketMaster));
    }

    @PatchMapping("/deleteVendorMarketMaster/{id}")
    public ResponseEntity<Optional<VendorMarketMaster>> deleteVendorMarketMaster(@PathVariable Long id) {
        return ResponseEntity.ok(vendorMarketMasterService.deleteVendorMarketMaster(id));
    }
}
