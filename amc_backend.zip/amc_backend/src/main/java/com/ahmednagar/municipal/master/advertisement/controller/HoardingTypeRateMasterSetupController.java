package com.ahmednagar.municipal.master.advertisement.controller;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingTypeRateMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeRateMasterSetup;
import com.ahmednagar.municipal.master.advertisement.service.HoardingTypeRateMasterSetupService;
import com.ahmednagar.municipal.master.municipalLicence.model.MlBusinessNature;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/advertisement/hoardingtype/ratemaster/setup")
@Validated
@CrossOrigin
public class HoardingTypeRateMasterSetupController {
    @Autowired
    private HoardingTypeRateMasterSetupService hoardingTypeRateMasterSetupService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingTypeRateMasterSetup> createHoardingTypeRateMasterSetup(@Valid @RequestBody HoardingTypeRateMasterSetup hoardingTypeRateMasterSetup){
        HoardingTypeRateMasterSetup savedHoardingTypeRateMasterSetup=hoardingTypeRateMasterSetupService.saveHoardingTypeRateMasterSetup(hoardingTypeRateMasterSetup);
        return ResponseEntity.status(201).body(savedHoardingTypeRateMasterSetup);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingTypeRateMasterSetupDto>> getAllHoardingTypeRateMasterSetup(){
        List<HoardingTypeRateMasterSetupDto> hoardingTypeRateMasterSetup=hoardingTypeRateMasterSetupService.findAllHoardingTypeRateMasterSetup();
        return ResponseEntity.ok(hoardingTypeRateMasterSetup);

    }
    //for single user by Id
    @GetMapping("/getMlBusinessNatureById/{id}")
    public ResponseEntity<HoardingTypeRateMasterSetup> getHoardingTypeRateMasterSetupById(@PathVariable Long id){
        HoardingTypeRateMasterSetup hoardingTypeRateMasterSetup=hoardingTypeRateMasterSetupService.findById(id);
        return ResponseEntity.ok(hoardingTypeRateMasterSetup);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingTypeRateMasterSetupByMunicipalId(@PathVariable int municipalId){
        List<HoardingTypeRateMasterSetup> hoardingTypeRateMasterSetups = hoardingTypeRateMasterSetupService.findAllByMunicipalId(municipalId);
        if (hoardingTypeRateMasterSetups.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingTypeRateMasterSetup found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingTypeRateMasterSetups);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingTypeRateMasterSetup> updateHoardingTypeRateMasterSetup(@PathVariable("id") Long id, @RequestBody HoardingTypeRateMasterSetup updatedHoardingTypeRateMasterSetup){
        try{
            HoardingTypeRateMasterSetup updated=hoardingTypeRateMasterSetupService.updateHoardingTypeRateMasterSetup(id,updatedHoardingTypeRateMasterSetup,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingTypeRateMasterSetupService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }

}

