package com.ahmednagar.municipal.forms.formsAdvertisement.service;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingPaymentCollectionDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingPaymentCollectionDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingPaymentCollectionDetailsService {
    HoardingPaymentCollectionDetails saveHoardingPaymentCollectionDetails(HoardingPaymentCollectionDetails hoardingPaymentCollectionDetails);

    List<HoardingPaymentCollectionDetailsDto> findAllHoardingPaymentCollectionDetails();

    HoardingPaymentCollectionDetails findById(Long id);

    List<HoardingPaymentCollectionDetails> findAllByMunicipalId(int municipalId);

    HoardingPaymentCollectionDetails updateHoardingPaymentCollectionDetails(Long id, HoardingPaymentCollectionDetails updatedHoardingPaymentCollectionDetails, int updatedBy);

    HoardingPaymentCollectionDetails changeStatus(Long id, Integer status, int updatedBy);
}
