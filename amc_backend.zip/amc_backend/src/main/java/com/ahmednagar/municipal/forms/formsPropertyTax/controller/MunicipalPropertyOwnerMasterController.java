package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyOwnerMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.MunicipalPropertyOwnerMasterService;
import com.ahmednagar.municipal.master.propertyTax.repository.OwnerShipRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/forms")
public class MunicipalPropertyOwnerMasterController {

    @Autowired
    MunicipalPropertyMasterRepository municipalPropertyMasterRepository;

    @Autowired
    OwnerShipRepository ownerShipRepository;

    @Autowired
    MunicipalPropertyOwnerMasterService municipalPropertyOwnerMasterService;

    @PostMapping(value = "/createPropertyOwnerMasterList", consumes = "multipart/form-data")
    public ResponseEntity<List<MunicipalPropertyOwnerMaster>> createMunicipalPropertyOwnerMaster(
            @RequestPart("propertyOwnerDetails") List<MunicipalPropertyOwnerMaster> municipalPropertyOwnerMasters,
            @RequestPart(value = "ownerPhotographUpload", required = false) List<MultipartFile> ownerPhotographUpload) {
        List<MunicipalPropertyOwnerMaster> savedMasters = municipalPropertyOwnerMasterService.createMunicipalPropertyOwnerMasterList(municipalPropertyOwnerMasters, ownerPhotographUpload);
        return ResponseEntity.ok(savedMasters);
    }

//    @PostMapping("/createPropertyOwnerMaster")
//    public ResponseEntity<MunicipalPropertyOwnerMaster> createMunicipalMaster(@Valid @RequestParam(value = "ownerPhotographUpload", required = false)
//                                                                              MultipartFile ownerPhotographUpload,
//                                                                              @RequestParam("propertyMasId") Long propertyMasId,
//                                                                              @RequestParam("ownershipTypeName") Long ownershipTypeName,
//                                                                              @RequestParam("ownerName") String ownerName,
//                                                                              @RequestParam("ownerFatherHusbName") String ownerFatherHusbName,
//                                                                              @RequestParam("ownerRelation") String ownerRelation,
//                                                                              @RequestParam("ownerCurrentAddress") String ownerCurrentAddress,
//                                                                              @RequestParam("ownerMobileNo") String ownerMobileNo,
//                                                                              @RequestParam("ownerEmailId") String ownerEmailId,
//                                                                              @RequestParam("ownerGender") String ownerGender,
//                                                                              @RequestParam("ownerMartialStatus") String ownerMartialStatus,
//                                                                              @RequestParam("ownerOccupation") String ownerOccupation,
//                                                                              @RequestParam("ownerDob") LocalDate ownerDob,
//                                                                              @RequestParam("aadharNo") Long aadharNo,
//                                                                              @RequestParam("panNumber") String panNumber,
//                                                                              @RequestParam("isFromArmedForce") Boolean isFromArmedForce,
//                                                                              @RequestParam("isSpeciallyAbled") Boolean isSpeciallyAbled,
//                                                                              @RequestParam("municipalId") int municipalId,
//                                                                              @RequestParam("createdBy") int createdBy,
//                                                                              @RequestParam(value = "suspendedStatus", required = false, defaultValue = "0") int suspendedStatus) {
//
//        MunicipalPropertyOwnerMaster municipalPropertyOwnerMasterMaster = new MunicipalPropertyOwnerMaster();
//        municipalPropertyOwnerMasterMaster.setMunicipalPropertyMaster(municipalPropertyMasterRepository.findById(propertyMasId).get());
//        municipalPropertyOwnerMasterMaster.setOwnerShips(ownerShipRepository.findById(ownershipTypeName).get());
//        municipalPropertyOwnerMasterMaster.setOwnerName(ownerName);
//        municipalPropertyOwnerMasterMaster.setOwnerFatherHusbName(ownerFatherHusbName);
//        municipalPropertyOwnerMasterMaster.setOwnerRelation(ownerRelation);
//        municipalPropertyOwnerMasterMaster.setOwnerCurrentAddress(ownerCurrentAddress);
//        municipalPropertyOwnerMasterMaster.setOwnerMobileNo(ownerMobileNo);
//        municipalPropertyOwnerMasterMaster.setOwnerEmailId(ownerEmailId);
//        municipalPropertyOwnerMasterMaster.setOwnerGender(ownerGender);
//        municipalPropertyOwnerMasterMaster.setOwnerMartialStatus(ownerMartialStatus);
//        municipalPropertyOwnerMasterMaster.setOwnerOccupation(ownerOccupation);
//        municipalPropertyOwnerMasterMaster.setOwnerDob(ownerDob);
//        municipalPropertyOwnerMasterMaster.setAadharNo(aadharNo);
//        municipalPropertyOwnerMasterMaster.setPanNumber(panNumber);
//        municipalPropertyOwnerMasterMaster.setIsFromArmedForce(isFromArmedForce);
//        municipalPropertyOwnerMasterMaster.setIsSpeciallyAbled(isSpeciallyAbled);
//        municipalPropertyOwnerMasterMaster.setMunicipalId(municipalId);
//        municipalPropertyOwnerMasterMaster.setCreatedBy(createdBy);
//        municipalPropertyOwnerMasterMaster.setSuspendedStatus(suspendedStatus);
//
//        MunicipalPropertyOwnerMaster createMunicipalPropertyOwnerMaster = municipalPropertyOwnerMasterService
//                .createMunicipalPropertyOwnerMaster(municipalPropertyOwnerMasterMaster, ownerPhotographUpload);
//        return ResponseEntity.status(HttpStatus.CREATED).body(createMunicipalPropertyOwnerMaster);
//    }

    @GetMapping("/ownerPhotograph/{id}")
    public ResponseEntity<Resource> getOwnerPhotograph(@PathVariable int id) {
        try {
            Resource file = municipalPropertyOwnerMasterService.loadOwnerPhotograph(id);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
                    .body(file);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @GetMapping("/getAllMunicipalPropertyOwnerMaster")
    public ResponseEntity<List<MunicipalPropertyOwnerMaster>> getAllMunicipalPropertyOwnerMaster() {
        return ResponseEntity.ok(municipalPropertyOwnerMasterService.getAllMunicipalPropertyOwnerMaster());
    }

    @GetMapping("/municipalPropertyOwnerMaster/{id}")
    public ResponseEntity<Object> getMunicipalPropertyOwnerMasterById(@PathVariable int id) {
        Optional<MunicipalPropertyOwnerMaster> municipalPropertyOwnerMaster = municipalPropertyOwnerMasterService.getMunicipalPropertyOwnerMasterById(id);
        if (municipalPropertyOwnerMaster.isPresent()) {
            return ResponseEntity.ok(municipalPropertyOwnerMaster.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getMunicipalPropertyOwnerMasterByMunicipalId/{municipalId}")
    public List<MunicipalPropertyOwnerMaster> getMunicipalPropertyOwnerMasterByMunicipalId(@PathVariable int municipalId) {
        return municipalPropertyOwnerMasterService.getByMunicipalId(municipalId);
    }

    @PatchMapping("/municipalPropertyOwnerMaster/suspendedStatus/{id}")
    public ResponseEntity<MunicipalPropertyOwnerMaster> patchMunicipalPropertyOwnerMasterSuspendedStatus(@PathVariable int id, @RequestParam int suspendedStatus) {
        MunicipalPropertyOwnerMaster patchedMunicipalPropertyMaster = municipalPropertyOwnerMasterService.patchMunicipalPropertyOwnerMasterSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedMunicipalPropertyMaster);
    }

}
