package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "Tbl_collection_master")
public class VendorCollectionMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "from_date")
    private LocalDate fromDate;

    @Column(name = "to_date")
    private LocalDate toDate;

    @Column(name = "lattitude", length = 250)
    private String latitude;

    @Column(name = "longitude", length = 250)
    private String longitude;

    @Column(name = "municipal_id")
    private Long municipalId;

    @Column(name = "data_category", length = 150)
    private String dataCategory;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "vendor_mas_id", referencedColumnName = "id")
    private VendorMaster vendorMasId;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private VendorUser userId;

    @ManyToOne
    @JoinColumn(name = "zone_id", referencedColumnName = "id")
    private VendorZone zoneId;

    @ManyToOne
    @JoinColumn(name = "ward_id", referencedColumnName = "id")
    private VendorZoneWard wardId;

}
