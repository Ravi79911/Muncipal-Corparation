package com.ahmednagar.municipal.auth.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ChangeEmailMobileRequest {

    private String existingEmailMobile;
    private String newEmailMobile;

}
