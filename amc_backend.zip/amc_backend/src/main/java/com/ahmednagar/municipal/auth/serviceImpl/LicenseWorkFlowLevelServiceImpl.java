package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.LicenseWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.*;
import com.ahmednagar.municipal.auth.service.LicenseWorkFlowLevelService;
import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class LicenseWorkFlowLevelServiceImpl implements LicenseWorkFlowLevelService {

    @Autowired
    private LicenseWorkFlowLevelRepository licenseWorkFlowLevelRepository;

    @Autowired
    private RoleMasterRepository roleMasterRepository;

    @Autowired
    private WorkFlowMasterRepository workFlowMasterRepository;

    @Autowired
    private UserMasterRepository userMasterRepository;

    @Autowired
    private CitizenSignUpRepository citizenSignUpRepository;

    @Autowired
    private ViewTradeApplicationTypeMastersRepository viewTradeApplicationTypeMastersRepository;

    @Autowired
    private ViewApplicationDocumentsDetailsRepository viewApplicationDocumentsDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    public UserMaster getLipikForLicenseCitizen(Long citizenId) {
        Long roleId = 1L; // Role ID for Lipik

        CitizenSignUpMaster citizen = citizenSignUpRepository.findById(citizenId)
                .orElseThrow(() -> new EntityNotFoundException("Citizen not found with ID: " + citizenId));

        // Fetch the first Lipik (UserMaster) matching Zone, Ward, Role
        return userMasterRepository.findFirstByZoneWardAndRole(citizen.getZoneId(), citizen.getWardId(), roleId)
                .orElseThrow(() -> new EntityNotFoundException("No Lipik found for Zone: " + citizen.getZoneId()
                        + " and Ward: " + citizen.getWardId()));
    }

    @Override
    public LicenseWorkFlowLevel createNewApplicationTransation(LicenseWorkFlowLevel newApplicationLicenseWorkFlowRequest) {

        UserMaster newApplicationLipik = getLipikForLicenseCitizen(newApplicationLicenseWorkFlowRequest.getCitizenId().getId());
        // Validate WorkFlow Master
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newApplicationLicenseWorkFlowRequest.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Master not found"));

        // Build WorkFlowLevel Object with Defaults
        LicenseWorkFlowLevel newWorkFlow = LicenseWorkFlowLevel.builder()
                .applicationMasterId(newApplicationLicenseWorkFlowRequest.getApplicationMasterId())
                .applicationTypeId(newApplicationLicenseWorkFlowRequest.getApplicationTypeId())
                .temporaryLicensePaymentId(newApplicationLicenseWorkFlowRequest.getTemporaryLicensePaymentId())
                .currentUserId(null)
                .nextUserId(newApplicationLipik)
                .workFlowMasterId(workFlowMaster)
                .status("NEW") // Default status for new applications
                .statusCode(1000L) // Example status code
                .createdBy(newApplicationLicenseWorkFlowRequest.getCreatedBy())
                .createdDate(LocalDateTime.now())
                .mailStatus(newApplicationLicenseWorkFlowRequest.getMailStatus())
                .remarks(newApplicationLicenseWorkFlowRequest.getRemarks())
                .suspendedStatus(0) // Default
                .municipalId(newApplicationLicenseWorkFlowRequest.getMunicipalId())
                .citizenId(newApplicationLicenseWorkFlowRequest.getCitizenId())
                .build();
        updateApprovedStatus(newApplicationLicenseWorkFlowRequest.getApplicationMasterId().getId());

        // Save Workflow to Database
        return licenseWorkFlowLevelRepository.save(newWorkFlow);
    }

    @Override
    public List<LicenseWorkFlowLevelDto> findAllWorkFlow() {
        List<LicenseWorkFlowLevel> licenseWorkFlowLevels = licenseWorkFlowLevelRepository.findAll();

        return licenseWorkFlowLevels.stream().map(licenseWorkFlowLevel -> {
            LicenseWorkFlowLevelDto dto = modelMapper.map(licenseWorkFlowLevel, LicenseWorkFlowLevelDto.class);

            // Manually map UserMaster to UserMasterDTO
            if (licenseWorkFlowLevel.getCurrentUserId() != null) {
                dto.setCurrentUserId(modelMapper.map(licenseWorkFlowLevel.getCurrentUserId(), UserMasterDTO.class));
            }
            if (licenseWorkFlowLevel.getNextUserId() != null) {
                dto.setNextUserId(modelMapper.map(licenseWorkFlowLevel.getNextUserId(), UserMasterDTO.class));
            }

            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public LicenseWorkFlowLevel handleWorkFlowTransition(LicenseWorkFlowLevel licenseWorkFlowLevel) {
        licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        Long currentRoleMasterId = getCurrentRoleMasterId(licenseWorkFlowLevel);  // Get RoleMasterId for Current User
        Long nextRoleMasterId = getNextRoleMasterId(licenseWorkFlowLevel);       // Get RoleMasterId for Next User
        //Long nextRoleCitizenMasterId =getNextRoleCitizenMasterId(workFlowLevel);

         RoleMaster currentRole = roleMasterRepository.findById(currentRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));

        RoleMaster nextRole = roleMasterRepository.findById(nextRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Next Role not found"));

        //Optional<RoleMaster> citizenNextRole=roleMasterRepository.findById(nextRoleCitizenMasterId);

        // Dynamically fetch workflow status from WorkFlowMaster table
        WorkFlowMaster currentStatus = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Status not found"));

        List<Long> rejectDocumentIdes=licenseWorkFlowLevel.getRejectedDocumentIdes();

//        // Retrieve the application type from tradeApplicationTypeMaster
//        ViewTradeApplicationTypeMasters applicationType = viewTradeApplicationTypeMastersRepository
//                .findById(licenseWorkFlowLevel.getApplicationTypeId().getId())
//                .orElseThrow(() -> new RuntimeException("Application Type not found"));
//
//        // Ensure it's a Temporary Application (ID = 10)
//        if (!applicationType.getId().equals(10L)) {
//            throw new IllegalStateException("This workflow applies only to Temporary Applications (ID = 10).");
//        }


//        CitizenSignUpMaster citizenSignUpMaster=citizenSignUpRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("citizen not found"));

        // Fetch the current status of the application
        Optional<LicenseWorkFlowLevel> existingWorkflow = licenseWorkFlowLevelRepository
                .findTopByApplicationMasterIdOrderByCreatedDateDesc(licenseWorkFlowLevel.getApplicationMasterId());

        if (existingWorkflow.isPresent()) {
            Long existingStatusCode = existingWorkflow.get().getStatusCode();

            // Check if the application has already been accepted or rejected
            if (existingStatusCode.equals(1002L) || existingStatusCode.equals(1003L)) {
                throw new IllegalStateException("This application has already been " +
                        (existingStatusCode.equals(1002L) ? "Accepted" : "Rejected") +
                        " and cannot be processed further.");
            }
        }

        // Transition based on the current status and role
        switch (currentStatus.getStatus()) {

            case "FORWARDED":
                return handleForwardedStatus(licenseWorkFlowLevel, currentRole, nextRole);

            case "BACKWARD":
                return handleBackwardStatus(licenseWorkFlowLevel, currentRole, nextRole);

            case "ACCEPT":
                return handleAcceptStatus(licenseWorkFlowLevel, currentRole);

            case "REJECT":
                return handleRejectStatus(licenseWorkFlowLevel, currentRole, nextRole);

            case "BACK TO CITIZEN":
                return handleBackToCitizenStatus(licenseWorkFlowLevel, currentRole);

            case "BACK TO CITIZEN IN BACKWARD":
                return handleBackToCitizenInBackWardCaseStatus(licenseWorkFlowLevel, currentRole,nextRole);

            case "BACK TO BACK OFFICE":
                return handleBackToBackOfficeStatus(licenseWorkFlowLevel, currentRole, nextRole);

            case "DOCUMENT VERIFICATION ACCEPT":
                return handleDocumentVerificationAccept(licenseWorkFlowLevel, currentRole, nextRole);

            case "DOCUMENT VERIFICATION REJECT":
                return handleDocumentVerificationReject(licenseWorkFlowLevel, currentRole, nextRole,rejectDocumentIdes);

            default:
                throw new RuntimeException("Invalid Status: " + currentStatus.getStatus());
        }
    }


    private LicenseWorkFlowLevel handleForwardedStatus(LicenseWorkFlowLevel licenseWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole) {

        Long nextUserId = licenseWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = licenseWorkFlowLevel.getCurrentUserId().getId();

        // Check the status_code and call the corresponding forward methods
        if (licenseWorkFlowLevel.getStatusCode() == 1005) {
            // Call forwardFromBackOffice when status_code is 1005
            return forwardFromBackOffice(licenseWorkFlowLevel);

        } else if (licenseWorkFlowLevel.getStatusCode() == 1004) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromCitizen(licenseWorkFlowLevel);

        }else if (licenseWorkFlowLevel.getStatusCode() == 1001) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromBackWard(licenseWorkFlowLevel);
        }
        else {
            // Fetch the next role based on the workFlowMasterId from the database
            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
            licenseWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

            // Validate nextRole
            if (nextRole == null && !"deputy municipal commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Next role is required but not provided.");
            }

            // Logic based on the current role and next role
            //if (workFlowMaster.getId().equals(1L))
            if (workFlowMaster.getId().equals(licenseWorkFlowLevel.getWorkFlowMasterId().getId())) {  // Only handle Forwarded status (workFlowMasterId = 1)
                switch (currentRole.getRoleName().toLowerCase()) {
                    case "back office":
                        if (nextRole.getRoleName().equalsIgnoreCase("lipik")) {
                            licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));
                            licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            licenseWorkFlowLevel.setMailStatus(1);
                        } else {
                            throw new IllegalStateException("Back Office can only forward to Lipik.");
                        }
                        break;

                    case "lipik":
                        if (nextRole.getRoleName().equalsIgnoreCase("section head")) {
                            licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));
                            licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            licenseWorkFlowLevel.setMailStatus(1);
                        } else {
                            throw new IllegalStateException("Lipik can only forward to Section Head.");
                        }
                        break;

                    case "section head":
                        if (nextRole.getRoleName().equalsIgnoreCase("deputy municipal commissioner")) {
                            licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));
                            licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            licenseWorkFlowLevel.setMailStatus(1);
                        } else {
                            throw new IllegalStateException("Section Head can only forward to Deputy Municipal Commissioner.");
                        }
                        break;

                    case "deputy municipal commissioner":
                        licenseWorkFlowLevel.setNextUserId(null);
                        licenseWorkFlowLevel.setStatus("Application Successfully Approved");
                        licenseWorkFlowLevel.setStatusCode(1002L); // Status Code for "Accepted"
                        licenseWorkFlowLevel.setMailStatus(0);
                }
                if (nextRole == null) {
                    throw new IllegalStateException("Next role is required but not provided.");
                }
                //workFlow.setNextUserId(getUserMasterByRoleMaster(nextRole));
                licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
            }

            //workFlow.setMailStatus(1);
            licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            updateApprovedStatus(licenseWorkFlowLevel.getApplicationMasterId().getId());
            return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
        }
    }

//    private LicenseWorkFlowLevel handleBackwardStatus(LicenseWorkFlowLevel licenseWorkFlowLevel, RoleMaster currentRole, RoleMaster previousRole) {
//        // Fetch the WorkFlowMaster for validation
//        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));
//
//        System.out.println(" current role{}" + currentRole);
//        System.out.println(" previous role{}" + previousRole);
//
//        if (workFlowMaster.getId().equals(2L)) {  // Backward
//            licenseWorkFlowLevel.setStatus(workFlowMaster.getStatus()); // Set to Backward status
//            licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
//
//            // Validate previousRole
//            if (previousRole == null) {
//                throw new IllegalStateException("Previous role is required but not provided.");
//            }
//
//            WorkFlowMaster backOfficeMaster = workFlowMasterRepository.findById(6L)
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 6 not found"));
//
//            licenseWorkFlowLevel.setWorkFlowMasterId(backOfficeMaster);
//
//            LicenseWorkFlowLevel licenseWorkFlowLevel1 = handleBackToBackOfficeStatus(licenseWorkFlowLevel, currentRole, previousRole);
//            return licenseWorkFlowLevel1;
//        }
//        return null;
//
//    }

    private LicenseWorkFlowLevel handleBackwardStatus(LicenseWorkFlowLevel licenseWorkFlowLevel, RoleMaster currentRole, RoleMaster previousRole) {
        // Fetch the next role based on the workFlowMasterId from the database
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = licenseWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = licenseWorkFlowLevel.getCurrentUserId().getId();

        // Set the status from WorkFlowMaster to WorkFlow
        licenseWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        // Validate nextRole
        if (previousRole == null && !"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Next role is required but not provided.");
        }

        // Logic for backward status (WorkFlowMasterId = 8)
        if (workFlowMaster.getId().equals(licenseWorkFlowLevel.getWorkFlowMasterId().getId())) {
            switch (currentRole.getRoleName().toLowerCase()) {
                case "lipik":
                    // Lipik can only reject and return to Back Office
                    if ("back office".equalsIgnoreCase(previousRole.getRoleName())) {
                        licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(previousRole, nextUserId)); // Reject and return to Back Office
                        licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        licenseWorkFlowLevel.setStatus("Rejected by Lipik");
                    } else {
                        throw new IllegalStateException("Lipik can only reject and return to Back Office.");
                    }
                    break;
                case "section head":
                    // Section Head can reject to Lipik or Back Office
                    if (isValidRoleForSectionHead(previousRole)) {
                        licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(previousRole, nextUserId)); // Reject and return to the selected role
                        licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        licenseWorkFlowLevel.setStatus("Rejected by Section Head");
                    } else {
                        throw new IllegalStateException("Section Head can only reject to Lipik or Back Office.");
                    }
                    break;
                case "deputy municipal commissioner":
                    // DMC can reject to Section Head, Lipik, or Back Office
                    if (isValidRoleForDMC(previousRole)) {
                        licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(previousRole, nextUserId)); // Reject and return to the selected role
                        licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        licenseWorkFlowLevel.setStatus("Rejected by DMC");
                    } else {
                        throw new IllegalStateException("DMC can only reject to Section Head, Lipik, or Back Office.");
                    }
                    break;
                default:
                    throw new IllegalStateException("Invalid current role for Document Verification Reject: " + currentRole.getRoleName());
            }

            // Set mail status and created date for all cases except TS → ID Generation rejection
            if (!"deputy municipal commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
                licenseWorkFlowLevel.setMailStatus(0);  // Assuming 0 means mail sent for rejection
                licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            }

            // Update rejection status for the rejected documents
            //updateRejectStatus(licenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);
            licenseWorkFlowLevel.setMailStatus(2);
        }

        // Validate previousRole
        if (previousRole == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }
        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
        if (licenseWorkFlowLevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            licenseWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

            //updateRejectStatus(licenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);

            return handleBackToCitizenInBackWardCaseStatus(licenseWorkFlowLevel, currentRole,previousRole);  // Handle transition to citizen
        }

        return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
    }

    private LicenseWorkFlowLevel handleAcceptStatus(LicenseWorkFlowLevel licenseWorkFlowLevel, RoleMaster currentRole) {
        Long nextUserId = licenseWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = licenseWorkFlowLevel.getCurrentUserId().getId();

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        // Check if the application is already accepted or rejected
        Optional<LicenseWorkFlowLevel> existingStatus = licenseWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationMasterIdAndStatusCode(licenseWorkFlowLevel.getApplicationMasterId().getId(), 1002L);

        if (existingStatus.isPresent()) {
            throw new IllegalStateException("This application has already been accepted and cannot be processed again.");
        }

        // Ensure only WorkFlowMasterId = 3 is processed for acceptance
        if (!workFlowMaster.getId().equals(3L)) {
            throw new IllegalStateException("This workflow is not eligible for acceptance.");
        }

        // Ensure only DEPUTY MUNICIPAL COMMISSIONER can accept
        if (!"Deputy Municipal Commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only Deputy Municipal Commissioner can accept the application.");
        }

        // Update status to "Accepted"
        licenseWorkFlowLevel.setStatus("ACCEPT");
        licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        licenseWorkFlowLevel.setNextUserId(null); // No further forwarding
        licenseWorkFlowLevel.setMailStatus(0);
        licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
        licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
    }


    private LicenseWorkFlowLevel handleRejectStatus(LicenseWorkFlowLevel licenseWorkFlowLevel, RoleMaster currentRole, RoleMaster previousRole) {

        Long nextUserId = licenseWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = licenseWorkFlowLevel.getCurrentUserId().getId();

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        // Check if the application is already accepted or rejected
        Optional<LicenseWorkFlowLevel> existingStatus = licenseWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationMasterIdAndStatusCode(licenseWorkFlowLevel.getApplicationMasterId().getId(), 1003L);

        if (existingStatus.isPresent()) {
            throw new IllegalStateException("This application has already been rejected and cannot be processed again.");
        }

        // Ensure only WorkFlowMasterId = 4 is processed for rejection
        if (!workFlowMaster.getId().equals(4L)) {
            throw new IllegalStateException("This workflow is not eligible for rejection.");
        }

        // Ensure only DEPUTY MUNICIPAL COMMISSIONER can reject
        if (!"Deputy Municipal Commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only Deputy Municipal Commissioner can reject the application.");
        }

        // Update status to "Rejected"
        licenseWorkFlowLevel.setStatus("Application Rejected");
        licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        licenseWorkFlowLevel.setNextUserId(null); // No further forwarding
        licenseWorkFlowLevel.setMailStatus(2); // Set mail notification for rejection
        licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
        licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
    }

    private LicenseWorkFlowLevel handleBackToCitizenStatus(LicenseWorkFlowLevel licenseWorkFlowLevel, RoleMaster currentRole) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = licenseWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = licenseWorkFlowLevel.getCurrentUserId().getId();

        if (workFlowMaster.getId().equals(5L)) {
            licenseWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

            licenseWorkFlowLevel.setNextUserId(null);
            licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
            licenseWorkFlowLevel.setCitizenId(licenseWorkFlowLevel.getCitizenId());

        }
        licenseWorkFlowLevel.setMailStatus(1);
        licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
    }

    private LicenseWorkFlowLevel handleBackToCitizenInBackWardCaseStatus(LicenseWorkFlowLevel workFlow, RoleMaster currentRole, RoleMaster nextRole) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = workFlow.getNextUserId() != null ? workFlow.getNextUserId().getId() : null;
        Long currentUserId = workFlow.getCurrentUserId().getId();

        if (workFlowMaster.getId().equals(5L)) {  // Backward Flow for WorkFlowMasterId = 5 (Water Workflow)

            workFlow.setStatus(workFlowMaster.getStatus());
            workFlow.setStatusCode(workFlowMaster.getStatusCode());

            switch (currentRole.getRoleName().toLowerCase()) {
                case "lipik":
                    // Lipik can only go backward to "Back to Citizen"
                    workFlow.setNextUserId(null);
                    workFlow.setCitizenId(workFlow.getCitizenId());
                    workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                    workFlow.setStatus("Backward to Citizen");
                    break;

                case "section head":
                    // Section Head can go backward to "Lipik" and "Back to Citizen"
                    if (isValidRolesForSectionHead(nextRole)) {
                        workFlow.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to " + currentRole.getRoleName());
                    } else {
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                case "deputy municipal commissioner":
                    // Deputy Municipal Commissioner can go backward to "Section Head", "Lipik", or "Back to Citizen"
                    if (isValidRolesForDeputyMunicipalCommissioner(nextRole)) {
                        workFlow.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to " + currentRole.getRoleName());
                    } else {
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                default:
                    throw new IllegalStateException("Invalid current role for Backward Flow: " + currentRole.getRoleName());
            }
        }

        // Set the mail status and created date after the operation
        workFlow.setMailStatus(1);  // Assuming 1 means mail sent for rejection
        workFlow.setCreatedDate(LocalDateTime.now());

        return licenseWorkFlowLevelRepository.save(workFlow);
    }

    private boolean isValidRolesForSectionHead(RoleMaster nextRole) {
        // Section Head can go back to "Lipik" and "Back to Citizen"
        return "lipik".equalsIgnoreCase(nextRole.getRoleName()) ||
                "back to citizen".equalsIgnoreCase(nextRole.getRoleName());
    }

    private boolean isValidRolesForDeputyMunicipalCommissioner(RoleMaster nextRole) {
        // Deputy Municipal Commissioner can go back to "Section Head", "Lipik", or "Back to Citizen"
        return "section head".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName()) ||
                "back to citizen".equalsIgnoreCase(nextRole.getRoleName());
    }


    private LicenseWorkFlowLevel handleBackToBackOfficeStatus(LicenseWorkFlowLevel licenseWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole) {
        // Fetch WorkFlowMaster for validation
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = licenseWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = licenseWorkFlowLevel.getCurrentUserId().getId();

        if (!workFlowMaster.getId().equals(6L)) {
            throw new IllegalStateException("Invalid workflow operation. Expected 'Back to Back Office' status.");
        }

        licenseWorkFlowLevel.setStatus(workFlowMaster.getStatus()); // Set status to Backward
        licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        // Validate nextRole (must be "Back Office")
        if (nextRole == null || !"back office".equalsIgnoreCase(nextRole.getRoleName())) {
            throw new IllegalStateException(currentRole.getRoleName() + " can only backward to Back Office.");
        }

        // Only allow Backward movement to Back Office
        switch (currentRole.getRoleName().toLowerCase()) {
            case "lipik":
            case "section head":
            case "deputy municipal commissioner":
                // Set workflow details
                licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));  // Back to Back Office
                licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                break;

            default:
                throw new IllegalStateException(currentRole.getRoleName() + " is not allowed to perform this Backward action.");
        }

        // Set mail status and created date
        licenseWorkFlowLevel.setMailStatus(1); // Notify user
        licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
    }


    private LicenseWorkFlowLevel handleDocumentVerificationAccept(LicenseWorkFlowLevel licenseWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole) {
        // Fetch the next role based on the workFlowMasterId from the database
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = licenseWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = licenseWorkFlowLevel.getCurrentUserId().getId();

        // Set the status and status code from WorkFlowMaster
        licenseWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        // Validate nextRole
        if (nextRole == null && !"deputy municipal commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Next role is required but not provided.");
        }

        // Process only if workFlowMasterId is 7 (Document Verification Accept)
        if (workFlowMaster.getId().equals(7L)) {
            switch (currentRole.getRoleName().toLowerCase()) {
                case "back office":
                    if (nextRole.getRoleName().equalsIgnoreCase("lipik")) {
                        licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to Lipik
                        licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    } else {
                        throw new IllegalStateException("Invalid next role for Back Office.");
                    }
                    break;

                case "lipik":
                    if (nextRole.getRoleName().equalsIgnoreCase("section head")) {
                        licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));  // Forward to Section Head
                        licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    } else {
                        throw new IllegalStateException("Invalid next role for Lipik.");
                    }
                    break;

                case "section head":
                    if (nextRole.getRoleName().equalsIgnoreCase("deputy municipal commissioner")) {
                        licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to Deputy Municipal Commissioner
                        licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    } else {
                        throw new IllegalStateException("Invalid next role for Section Head.");
                    }
                    break;

                case "deputy municipal commissioner":
                    licenseWorkFlowLevel.setStatus("Application Document Successfully Accepted");
                    licenseWorkFlowLevel.setStatusCode(1002L); // Status Code for "Accepted"
                    licenseWorkFlowLevel.setNextUserId(null); // No further processing
                    licenseWorkFlowLevel.setMailStatus(0);
                    System.out.println("appoved status +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                    if (nextRole == null) {
                        throw new IllegalStateException("Next role is required but not provided.");
                    }

                    licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());

            }
            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(licenseWorkFlowLevel.getApplicationMasterId().getId());

        }

        return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
    }
    private void updateApprovedStatus(Long applicationId) {
        List<ViewApplicationDocumentsDetails> documentDetails =
                viewApplicationDocumentsDetailsRepository.findByViewApplicationFromMaster_Id(applicationId);

        for(ViewApplicationDocumentsDetails details : documentDetails){

            details.setApprovedStatus(1f); // Set approved_status to 1
            viewApplicationDocumentsDetailsRepository.save(details);
        };
    }


    private LicenseWorkFlowLevel handleDocumentVerificationReject(LicenseWorkFlowLevel licenseWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole,List<Long> rejectDocumentIdes) {
        // Fetch the next role based on the workFlowMasterId from the database
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        System.out.println("Current role: " + currentRole);
        System.out.println("Previous role: " + nextRole);

        if (workFlowMaster.getId().equals(8L)) {  // Backward
            licenseWorkFlowLevel.setStatus(workFlowMaster.getStatus()); // Set to Backward status
            licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

            // Validate previousRole
            if (nextRole == null) {
                throw new IllegalStateException("Previous role is required but not provided.");
            }

            // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
            if (licenseWorkFlowLevel.getCitizenId() != null) {
                WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                        .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

                licenseWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

                updateRejectStatus(licenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);

                return handleBackToCitizenStatus(licenseWorkFlowLevel, currentRole);  // Handle transition to citizen
            }

            WorkFlowMaster backOfficeMaster = workFlowMasterRepository.findById(6L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 6 not found"));

            licenseWorkFlowLevel.setWorkFlowMasterId(backOfficeMaster);

            // Call handleBackToBackOfficeStatus for BackOffice rejections
            LicenseWorkFlowLevel workFlowLevel1 = handleBackToBackOfficeStatus(licenseWorkFlowLevel, currentRole, nextRole);


            // Update reject status after returning to back office
            updateRejectStatus(licenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);

            return workFlowLevel1;
        }

        // Update rejected documents for all other roles
        updateRejectStatus(licenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);
        licenseWorkFlowLevel.setMailStatus(2);

        return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
    }

    /**
     * Update approved_status to 0 for rejected documents
     */
    private void updateRejectStatus(Long applicationMasterId, List<Long> rejectDocumentIdes) {
        if (rejectDocumentIdes == null || rejectDocumentIdes.isEmpty()) {
            System.out.println("No documents to update for rejection.");
            return;
        }

        List<ViewApplicationDocumentsDetails> documentDetails =
                viewApplicationDocumentsDetailsRepository.findAllById(rejectDocumentIdes);

        if (documentDetails.isEmpty()) {
            System.out.println("No matching documents found for rejection.");
            return;
        }

        documentDetails.forEach(details -> details.setApprovedStatus(0f)); // Set approved_status to 0

        // Save all updates in batch
        viewApplicationDocumentsDetailsRepository.saveAll(documentDetails);

        System.out.println("Updated " + documentDetails.size() + " documents to rejected status.");
    }

//    private LicenseWorkFlowLevel handleDocumentVerificationReject(LicenseWorkFlowLevel licenseWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole,List<Long> rejectDocumentIdes) {
//        // Fetch the next role based on the workFlowMasterId from the database
//        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));
//
//        Long nextUserId = licenseWorkFlowLevel.getNextUserId().getId();
//        Long currentUserId = licenseWorkFlowLevel.getCurrentUserId().getId();
//
//        // Set the status from WorkFlowMaster to WorkFlow
//        licenseWorkFlowLevel.setStatus(workFlowMaster.getStatus());
//        licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
//
//        // Validate nextRole
//        if (nextRole == null && !"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
//            throw new IllegalStateException("Next role is required but not provided.");
//        }
//
//        // Logic for backward status (WorkFlowMasterId = 8)
//        if (workFlowMaster.getId().equals(licenseWorkFlowLevel.getWorkFlowMasterId().getId())) {
//            switch (currentRole.getRoleName().toLowerCase()) {
//                case "lipik":
//                    // Lipik can only reject and return to Back Office
//                    if ("back office".equalsIgnoreCase(nextRole.getRoleName())) {
//                        licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId)); // Reject and return to Back Office
//                        licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
//                        licenseWorkFlowLevel.setStatus("Rejected by Lipik");
//                    } else {
//                        throw new IllegalStateException("Lipik can only reject and return to Back Office.");
//                    }
//                    break;
//                case "section head":
//                    // Section Head can reject to Lipik or Back Office
//                    if (isValidRoleForSectionHead(nextRole)) {
//                        licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId)); // Reject and return to the selected role
//                        licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
//                        licenseWorkFlowLevel.setStatus("Rejected by Section Head");
//                    } else {
//                        throw new IllegalStateException("Section Head can only reject to Lipik or Back Office.");
//                    }
//                    break;
//                case "deputy municipal commissioner":
//                    // DMC can reject to Section Head, Lipik, or Back Office
//                    if (isValidRoleForDMC(nextRole)) {
//                        licenseWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId)); // Reject and return to the selected role
//                        licenseWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
//                        licenseWorkFlowLevel.setStatus("Rejected by DMC");
//                    } else {
//                        throw new IllegalStateException("DMC can only reject to Section Head, Lipik, or Back Office.");
//                    }
//                    break;
//                default:
//                    throw new IllegalStateException("Invalid current role for Document Verification Reject: " + currentRole.getRoleName());
//            }
//
//            // Set mail status and created date for all cases except TS → ID Generation rejection
//            if (!"deputy municipal commissioner".equalsIgnoreCase(currentRole.getRoleName())) {
//                licenseWorkFlowLevel.setMailStatus(0);  // Assuming 0 means mail sent for rejection
//                licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
//            }
//
//            // Update rejection status for the rejected documents
//            updateRejectStatus(licenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);
//            licenseWorkFlowLevel.setMailStatus(2);
//        }
//
//        // Validate previousRole
//        if (nextRole == null) {
//            throw new IllegalStateException("Previous role is required but not provided.");
//        }
//        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
//        if (licenseWorkFlowLevel.getCitizenId() != null) {
//            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));
//
//            licenseWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);
//
//            updateRejectStatus(licenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);
//
//            return handleBackToCitizenStatus(licenseWorkFlowLevel, currentRole,nextRole);  // Handle transition to citizen
//        }
//
//        return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
//    }

    private boolean isValidRoleForSectionHead(RoleMaster nextRole) {
        // Section Head can go back to Lipik or Back Office
        return "lipik".equalsIgnoreCase(nextRole.getRoleName()) || "back office".equalsIgnoreCase(nextRole.getRoleName());
    }

    private boolean isValidRoleForDMC(RoleMaster nextRole) {
        // DMC can go back to Section Head, Lipik, or Back Office
        return "section head".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName()) ||
                "back office".equalsIgnoreCase(nextRole.getRoleName());
    }

//    private void updateRejectStatus(Long applicationId, List<Long> rejectDocumentIds) {
//        if (rejectDocumentIds == null || rejectDocumentIds.isEmpty()) {
//            System.out.println("No documents to update for rejection.");
//            return;
//        }
//        // Update the reject status for the provided document IDs
//        List<ViewApplicationDocumentsDetails> documentDetails =
//                viewApplicationDocumentsDetailsRepository.findAllById(rejectDocumentIds);
//
//        for (ViewApplicationDocumentsDetails details : documentDetails) {
//            details.setApprovedStatus(0f); // Set approved_status to 0 (rejected)
//            viewApplicationDocumentsDetailsRepository.save(details);
//        }
//    }



//    public Long getCurrentRoleCitizenMasterId(LicenseWorkFlowLevel licenseWorkFlowLevel) {
//        if (licenseWorkFlowLevel == null || licenseWorkFlowLevel.getCurrentUserId() == null) {
//            throw new IllegalArgumentException("WorkFlow or CurrentUserId cannot be null");
//        }
//        // Fetch CitizenSignUpMaster based on currentUserId
//        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpRepository.findById(licenseWorkFlowLevel.getCurrentUserId().getId())
//                .orElseThrow(() -> new RuntimeException("Citizen not found for User ID: " + licenseWorkFlowLevel.getCurrentUserId().getId()));
//        // Extract RoleMaster from CitizenSignUpMaster and get the RoleMaster ID
//        RoleMaster roleMaster = citizenSignUpMaster.getRoleMaster();
//        if (roleMaster == null) {
//            throw new RuntimeException("RoleMaster not found for Citizen ID: " + citizenSignUpMaster.getId());
//        }
//        return roleMaster.getId();  // Return the RoleMaster ID
//    }

    public Long getCurrentRoleMasterId(LicenseWorkFlowLevel licenseWorkFlowLevel) {
        if (licenseWorkFlowLevel == null || licenseWorkFlowLevel.getCurrentUserId() == null) {
            throw new IllegalArgumentException("WorkFlow or CurrentUserId cannot be null");
        }
        return userMasterRepository.findById(licenseWorkFlowLevel.getCurrentUserId().getId())
                .map(UserMaster::getRoleMaster)  // Get RoleMaster directly
                .map(RoleMaster::getId)         // Extract RoleMaster ID
                .orElseThrow(() -> new RuntimeException("RoleMaster not found for User ID: " + licenseWorkFlowLevel.getCurrentUserId().getId()));
    }


    public Long getNextRoleMasterId(LicenseWorkFlowLevel licenseWorkFlowLevel) {
        if (licenseWorkFlowLevel == null || licenseWorkFlowLevel.getNextUserId() == null) {
            throw new IllegalArgumentException("WorkFlow or NextUserId cannot be null");
        }
        UserMaster nextUserId = userMasterRepository.findById(licenseWorkFlowLevel.getNextUserId().getId())
                .orElseThrow(() -> new RuntimeException("next User not found"));
        Long NextRoleId = nextUserId.getRoleMaster().getId();
        RoleMaster roleMaster = roleMasterRepository.findById(NextRoleId)
                .orElseThrow(() -> new RuntimeException("next Role not found"));
        if (roleMaster == null) {
            throw new RuntimeException("RoleMaster not found for NextUser ID: " + licenseWorkFlowLevel.getNextUserId().getId());
        }
        return roleMaster.getId();
    }

    public UserMaster getUserMasterByRoleMaster(RoleMaster roleMaster,Long userId) {
        if (roleMaster == null || roleMaster.getId() == null) {
            throw new IllegalArgumentException("RoleMaster or RoleMasterId cannot be null");
        }
//        return userMasterRepository.findFirstByRoleMaster(roleMaster)
//                .orElseThrow(() -> new RuntimeException("No UserMaster found for RoleMaster: " + roleMaster.getRoleName()));
        return userMasterRepository.findFirstByRoleMasterAndId(roleMaster, userId)
                .orElseThrow(() -> new RuntimeException(
                        "No UserMaster found for RoleMaster: " + roleMaster.getRoleName() + " and User ID: " + userId));
    }


    private LicenseWorkFlowLevel forwardFromBackOffice(LicenseWorkFlowLevel licenseWorkFlowLevel) {

        Long currentRoleMasterId = getCurrentRoleMasterId(licenseWorkFlowLevel);  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));
        Long applicationMasterId = licenseWorkFlowLevel.getApplicationMasterId().getId();
        if (applicationMasterId == null) {
            throw new IllegalArgumentException("licenseDetailsId ID cannot be null");
        }
        Long statusCode = licenseWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        LicenseWorkFlowLevel latestWorkFlow = licenseWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationMasterIdAndStatusCode(applicationMasterId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for licenseDetails ID: " + applicationMasterId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1005) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            licenseWorkFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            licenseWorkFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
//        workFlowLevel.setStatus(workFlowMaster.getStatus());
            licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            licenseWorkFlowLevel.setStatus("Forwarded from "+ currentRole.getRoleName());
            licenseWorkFlowLevel.setMailStatus(1);
            licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            updateApprovedStatus(licenseWorkFlowLevel.getApplicationMasterId().getId());

            return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private LicenseWorkFlowLevel forwardFromBackWard(LicenseWorkFlowLevel licenseWorkFlowLevel) {
        Long currentRoleMasterId = getCurrentRoleMasterId(licenseWorkFlowLevel);  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));
        Long applicationMasterId = licenseWorkFlowLevel.getApplicationMasterId().getId();
        if (applicationMasterId == null) {
            throw new IllegalArgumentException("licenseDetailsId ID cannot be null");
        }
        Long statusCode = licenseWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        LicenseWorkFlowLevel latestWorkFlow = licenseWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationMasterIdAndStatusCode(applicationMasterId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for licenseDetails ID: " + applicationMasterId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1001) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            licenseWorkFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            licenseWorkFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
//        workFlowLevel.setStatus(workFlowMaster.getStatus());
            licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            licenseWorkFlowLevel.setStatus("Forwarded from "+currentRole.getRoleName());
            licenseWorkFlowLevel.setMailStatus(1);
            licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            updateApprovedStatus(licenseWorkFlowLevel.getApplicationMasterId().getId());

            return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }
    
    private LicenseWorkFlowLevel forwardFromCitizen(LicenseWorkFlowLevel licenseWorkFlowLevel) {

        Long applicationMasterId = licenseWorkFlowLevel.getApplicationMasterId().getId();
        if (applicationMasterId == null) {
            throw new IllegalArgumentException("licenseDetailsId ID cannot be null");
        }
        Long statusCode = licenseWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        LicenseWorkFlowLevel latestWorkFlow = licenseWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationMasterIdAndStatusCode(applicationMasterId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for licenseDetails ID: " + applicationMasterId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1004) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            licenseWorkFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            licenseWorkFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
//        workFlowLevel.setStatus(workFlowMaster.getStatus());
            licenseWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            licenseWorkFlowLevel.setStatus("Forwarded from Citizen");
            licenseWorkFlowLevel.setMailStatus(1);
            licenseWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            updateApprovedStatus(licenseWorkFlowLevel.getApplicationMasterId().getId());

            return licenseWorkFlowLevelRepository.save(licenseWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    @Override
    public List<RemarksDto> getRemarksByApplicationId(Long applicationId) {
        return licenseWorkFlowLevelRepository.findByApplicationMasterId_Id(applicationId).stream()
                .filter(level -> level.getRemarks() != null)
                .sorted(Comparator.comparing(LicenseWorkFlowLevel::getCreatedDate).reversed())
                .map(level -> new RemarksDto(
                        level.getRemarks() != null ? level.getRemarks(): "No remarks provided",
                        level.getCreatedDate(),
                        level.getCurrentUserId() != null ? level.getCurrentUserId().getRoleMaster().getRoleName(): "UNKNOWN",
                        level.getCurrentUserId() != null ? level.getCurrentUserId().getNameOfUser(): "UNKNOWN",
                        level.getNextUserId() != null ? level.getNextUserId().getRoleMaster().getRoleName(): "UNKNOWN",
                        level.getNextUserId() != null ? level.getNextUserId().getNameOfUser(): "UNKNOWN"
                ))
                .collect(Collectors.toList());
    }
}
