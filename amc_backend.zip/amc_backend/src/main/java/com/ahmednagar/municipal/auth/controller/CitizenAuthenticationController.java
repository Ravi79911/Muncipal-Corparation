package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.jwt.JwtHelper;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.CitizenSignUpRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@CrossOrigin
@RestController
@RequestMapping("/auth")
public class CitizenAuthenticationController {

    @Autowired
    AuthenticationManager manager;

    @Autowired
    CitizenSignUpRepository citizenSignUpRepository;

    @Autowired
    JwtHelper jwtHelper;

    @PostMapping("/citizen/authenticate")
    public ResponseEntity<?> login(@RequestBody JwtRequest request) {

        String usernameOrMobile = request.getEmail();  // this can be email or mobile number
        String password = request.getPassword();

        // authenticate the citizen
        this.doAuthenticate(usernameOrMobile, password);

        // load citizen details
        CitizenSignUpMaster citizen = citizenSignUpRepository.findByEmail(usernameOrMobile).orElse(null);
        if (citizen == null) {
            return new ResponseEntity<>("Citizen not found", HttpStatus.BAD_REQUEST);
        }

        // check OTP and verification status
        if (!citizen.isMobileVerified()) {
            LoginResponse loginResponse = new LoginResponse("Please verify with mobile OTP", citizen.getId(), citizen.getEmail(),
                    citizen.getMobileNo(), citizen.getRoleMaster().getRoleName(), citizen.getRoleMaster().getGroupName());
            return new ResponseEntity<>(loginResponse, HttpStatus.BAD_REQUEST);
        }

        if (!citizen.isEmailVerified()) {
            LoginResponse loginResponse = new LoginResponse("Please verify with email OTP", citizen.getId(), citizen.getEmail(),
                    citizen.getMobileNo(), citizen.getRoleMaster().getRoleName(), citizen.getRoleMaster().getGroupName());
            return new ResponseEntity<>(loginResponse, HttpStatus.BAD_REQUEST);
        }

        if (!citizen.isVerified()) {
            LoginResponse loginResponse = new LoginResponse("Account not fully verified yet", citizen.getId(), citizen.getEmail(),
                    citizen.getMobileNo(), citizen.getRoleMaster().getRoleName(), citizen.getRoleMaster().getGroupName());
            return new ResponseEntity<>(loginResponse, HttpStatus.BAD_REQUEST);
        }

        // generate JWT tokens
        String accessToken = jwtHelper.generateAccessToken(citizen);
        String refreshToken = jwtHelper.generateRefreshToken(citizen);

        // return response with tokens
        JwtResponse response = JwtResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken) // include refresh token in the response
                .username(citizen.getEmail())
                .mobileNumber(citizen.getMobileNo())
                .userId(citizen.getId())
                .role(citizen.getRoleMaster().getRoleName())
                .groupName(citizen.getRoleMaster().getGroupName())
                .build();

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // authentication for mobile number with OTP
    @PostMapping("/citizen/authenticateWithMobileOtp")
    public ResponseEntity<?> verifyMobileOtpAndLogin(@RequestBody MobileOtpLoginRequest mobileOtpLoginRequest) {

        // load citizen details by mobile number
        CitizenSignUpMaster citizen = citizenSignUpRepository.findByMobileNo(mobileOtpLoginRequest.getMobileNumber()).orElse(null);

        if (citizen == null) {
            return new ResponseEntity<>("Mobile number not registered", HttpStatus.BAD_REQUEST);
        }

        // verify OTP
        if (!isOtpValid(citizen, mobileOtpLoginRequest.getOtp())) {
            return new ResponseEntity<>("Invalid or expired OTP", HttpStatus.BAD_REQUEST);
        }

        // if OTP is valid, mark mobile as verified
        citizen.setMobileVerified(true);
        citizen.setMobileOtp(null);  // clear OTP
        citizen.setMobileOtpTimestamp(null);  // clear expiration time
        citizenSignUpRepository.save(citizen);

        // generate JWT tokens
        String accessToken = jwtHelper.generateAccessToken(citizen);
        String refreshToken = jwtHelper.generateRefreshToken(citizen);

        // return response with tokens
        JwtResponse response = JwtResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken) // include refresh token in the response
                .username(citizen.getEmail())
                .mobileNumber(citizen.getMobileNo())
                .userId(citizen.getId())
                .role(citizen.getRoleMaster().getRoleName())
                .groupName(citizen.getRoleMaster().getGroupName())
                .build();

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/citizen/refreshToken")
    public ResponseEntity<?> refreshToken(@RequestBody RefreshTokenRequest refreshTokenRequest) {

        String refreshToken = refreshTokenRequest.getRefreshToken();
        String username = null;

        // extract the username from the refresh token
        try {
            username = jwtHelper.getUsernameFromToken(refreshToken);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("invalid or expired refresh token");
        }

        // load citizen details using the username
        CitizenSignUpMaster citizen = citizenSignUpRepository.findByEmail(username).orElse(null);
        if (citizen == null) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("citizen not found");
        }

        // validate the refresh token
        if (jwtHelper.validateToken(refreshToken, citizen)) {
            // generate a new access token and refresh token
            String newAccessToken = jwtHelper.generateAccessToken(citizen);
            String newRefreshToken = jwtHelper.generateRefreshToken(citizen);

            // return new tokens
            JwtResponse response = JwtResponse.builder()
                    .accessToken(newAccessToken)
                    .refreshToken(newRefreshToken) // include refresh token in the response
                    .username(citizen.getEmail())
                    .mobileNumber(citizen.getMobileNo())
                    .userId(citizen.getId())
                    .role(citizen.getRoleMaster().getRoleName())
                    .groupName(citizen.getRoleMaster().getGroupName())
                    .build();

            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("invalid or expired refresh token");
        }
    }

    private boolean isOtpValid(CitizenSignUpMaster citizenSignUpMaster, String otp) {
        // check if OTP exists and if it is not expired
        return citizenSignUpMaster.getMobileOtp() != null && citizenSignUpMaster.getMobileOtp().equals(otp) &&
                citizenSignUpMaster.getMobileOtpTimestamp() != null && citizenSignUpMaster.getMobileOtpTimestamp().isAfter(LocalDateTime.now());
    } // end of isOtpValid & verifyMobileOtpAndLogin

    private void doAuthenticate(String usernameOrMobile, String password) {
        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(usernameOrMobile, password);
        try {
            manager.authenticate(authentication);
        } catch (BadCredentialsException e) {
            throw new BadCredentialsException("Invalid credentials, please check your username or password");
        }
    }

}
