package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationPermisesDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationPermisesDetails;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface ApplicationPermisesDetailsService {
    ApplicationPermisesDetails saveApplicationPermisesDetails(ApplicationPermisesDetails applicationPermisesDetails, int createdBy);

//    List<ApplicationPermisesDetailsDto> findAllApplicationPermisesDetails();
//
//    List<ApplicationPermisesDetails> findAllActiveApplicationPermisesDetails(Integer status);

    ApplicationPermisesDetails findAppApplicationPermisesDetailsById(Long id);

    List<ApplicationPermisesDetailsDto> findAllApplicationPermisesDetailsByMunicipalId(int municipalId);

    ApplicationPermisesDetails updateApplicationPermisesDetails(Long id, ApplicationPermisesDetails updatedApplicationPermisesDetails,int updatedBy);

    ApplicationPermisesDetails changeSuspendedStatus(Long id, int status,int updatedBy);

    void deleteApplicationPermisesDetailsByApplicationMasterId(Long applicationMasterId);
}
