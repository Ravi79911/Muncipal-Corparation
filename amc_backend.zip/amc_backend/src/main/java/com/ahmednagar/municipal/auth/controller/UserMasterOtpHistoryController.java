package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.UserMasterOtpHistory;
import com.ahmednagar.municipal.auth.service.UserMasterOtpHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/auth")
public class UserMasterOtpHistoryController {

    @Autowired
    UserMasterOtpHistoryService userMasterOtpHistoryService;

    @GetMapping("/getAllUserMasterOtpHistory")
    public List<UserMasterOtpHistory> getAllUserMasterOtpHistory() {
        return userMasterOtpHistoryService.getAllUserMasterOtpHistory();
    }

}
