package com.ahmednagar.municipal.auth.model;

import com.ahmednagar.municipal.master.municipalLicence.model.MlDocumentsMaster;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_view_ml_document_group_master")
public class ViewMlDocumentGroupMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "Document group must not be null")
    @Size(max = 50, message = "Document group must be at most 50 characters long")
    @Column(name = "document_group")
    private String documentGroup;

    @Column(name = "updated_by")
    private int updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID must not be null")
    @Column(name = "municipal_id")
    private int municipalId;

//    @OneToMany(mappedBy = "mlDocumentGroupMasId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<MlDocumentsMaster> mlDocumentsMasters;

}
