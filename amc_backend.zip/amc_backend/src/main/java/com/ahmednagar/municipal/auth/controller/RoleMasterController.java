package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.RoleDto;
import com.ahmednagar.municipal.auth.model.RoleMaster;
import com.ahmednagar.municipal.auth.service.RoleMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class RoleMasterController {

    @Autowired
    private RoleMasterService roleMasterService;

    //create role
    @PostMapping("/createRole")
    public ResponseEntity<RoleMaster> createRoles(@Valid @RequestBody RoleMaster role) {
        RoleMaster createdRole = roleMasterService.createRole(role);
        if (createdRole == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdRole);
    }

    //for all admin users
    @GetMapping("/allRole")
    public ResponseEntity<List<RoleDto>> getAllRoles() {
        List<RoleDto> role = roleMasterService.findAllRole();
        return ResponseEntity.ok(role);
    }

    //get role By MunicipalId
    @GetMapping("/MunicipalRole/{municipalId}")
    public ResponseEntity<?> getAllRolesByMunicipalId(@PathVariable int municipalId) {
        List<RoleDto> role = roleMasterService.findAllRoleByMunicipalId(municipalId);
        if (role.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No role found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(role);
    }

    //     Update role for admin
    @PutMapping("/updatedRole/{id}")
    public ResponseEntity<RoleMaster> updateRoles(@PathVariable("id") Long id, @RequestBody RoleMaster updatedRole) {
        try {
            RoleMaster updated = roleMasterService.updateRole(id, updatedRole);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    //delete fileUrl for admin
    @PatchMapping("/deleteRole/{id}")
    public ResponseEntity<RoleMaster> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        RoleMaster updatedRole = roleMasterService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedRole == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedRole);
    }

}
