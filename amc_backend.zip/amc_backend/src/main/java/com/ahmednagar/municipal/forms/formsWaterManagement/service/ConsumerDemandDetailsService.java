package com.ahmednagar.municipal.forms.formsWaterManagement.service;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerDemandDetails;
import org.springframework.stereotype.Service;

@Service
public interface ConsumerDemandDetailsService {

    ConsumerDemandDetails createDemandDetail(ConsumerDemandDetails consumerDemandDetails);

//    ConsumerDemandDetails getLatestBillByConsumerId(Long consumerId);

    int getCurrentReadingOfLatestBill(String consumerNo);
}
