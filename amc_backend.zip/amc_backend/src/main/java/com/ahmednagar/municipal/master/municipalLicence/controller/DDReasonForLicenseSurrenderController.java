package com.ahmednagar.municipal.master.municipalLicence.controller;

import com.ahmednagar.municipal.master.municipalLicence.model.DDReasonForLicenseSurrender;
import com.ahmednagar.municipal.master.municipalLicence.service.DDReasonForLicenseSurrenderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/dd")
public class DDReasonForLicenseSurrenderController {

    @Autowired
    DDReasonForLicenseSurrenderService ddReasonForLicenseSurrenderService;

    @GetMapping("/getAllDDReasonForLicenseSurrender")
    public ResponseEntity<List<DDReasonForLicenseSurrender>> getAllDDReasonForLicenseSurrender() {
        return ResponseEntity.ok(ddReasonForLicenseSurrenderService.getAllDDReasonForLicenseSurrender());
    }

}
