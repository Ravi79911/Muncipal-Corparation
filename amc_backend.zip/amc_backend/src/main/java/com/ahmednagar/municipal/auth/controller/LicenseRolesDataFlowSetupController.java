package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.LicenseRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.LicenseRolesDataFlowSetup;
import com.ahmednagar.municipal.auth.service.LicenseRolesDataFlowSetupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/license/roles/data/flow/setup")
public class LicenseRolesDataFlowSetupController {

    @Autowired
    private LicenseRolesDataFlowSetupService licenseRolesDataFlowSetupService;

    @GetMapping("/getAllRole")
    public ResponseEntity<List<LicenseRolesDataFlowSetupDto>> getAllRolesDataFlowSetup() {
        List<LicenseRolesDataFlowSetupDto> role = licenseRolesDataFlowSetupService.findAllRolesDataFlowSetup();
        return ResponseEntity.ok(role);
    }

    @GetMapping("/document/verification/accept/next-role")
    public ResponseEntity<?> getNextRoleIdForDocumentVerificationAccept(@RequestParam Long currentRoleId,@RequestParam Long statusCode, @RequestParam Integer isActive) {
        LicenseRolesDataFlowSetup licenseRolesDataFlowSetup = licenseRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRoleId, statusCode, isActive);
        return ResponseEntity.ok(licenseRolesDataFlowSetup);

    }

    @GetMapping("/document/verification/reject/next-role")
    public ResponseEntity<List<LicenseRolesDataFlowSetup>> getNextRoleIdForDocumentVerificationReject(@RequestParam Long currentRoleId, @RequestParam Long statusCode, @RequestParam Integer isActive) {
        List<LicenseRolesDataFlowSetup> nextRoles = licenseRolesDataFlowSetupService.getNextRoleListForListSelection(currentRoleId, statusCode, isActive);
        return ResponseEntity.ok(nextRoles);
    }

}
