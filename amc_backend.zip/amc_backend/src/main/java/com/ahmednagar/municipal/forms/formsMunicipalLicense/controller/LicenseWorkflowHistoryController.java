package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFromMaster;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseWorkflowHistory;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.LicenseWorkflowHistoryRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.LicenseWorkflowHistoryService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/license/label/work/flow/history")
public class LicenseWorkflowHistoryController {
    @Autowired
    private LicenseWorkflowHistoryService licenseWorkflowHistoryService;

    @Autowired
    private LicenseWorkflowHistoryRepository licenseWorkflowHistoryRepository;

    @PostMapping("/create")
    public ResponseEntity<LicenseWorkflowHistory> createLicenseWorkflowHistory(@Valid @RequestBody LicenseWorkflowHistory licenseWorkflowHistory) {
        LicenseWorkflowHistory createdLicenseWorkflowHistory = licenseWorkflowHistoryService.saveLicenseWorkflowHistory(licenseWorkflowHistory);
        return ResponseEntity.status(201).body(createdLicenseWorkflowHistory);
    }

}
