package com.ahmednagar.municipal.forms.formsMunicipalLicense.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_application_fee_pay_master")
public class ApplicationFeePayMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    //@NotNull(message = "Start date is required")
    @Column(name = "start_date")
    private LocalDate startDate;

    //@NotNull(message = "End date is required")
    @Column(name = "end_date")
    private LocalDate endDate;

    //@NotNull(message = "Number of days is required")
    //@Min(value = 1, message = "Number of days must be at least 1")
    @Column(name = "no_of_days")
    private int noOfDays;

    @Column(name = "license_applied_for_years")
    @NotNull(message = "License applied for years is required")
    private int licenseAppliedForYears;

    @Column(name = "application_fee")
    @NotNull(message = "Application fee is required")
    private BigDecimal applicationFee;

    @Column(name = "penalty")
    @NotNull(message = "Penalty is required")
    private BigDecimal penalty;

    @Column(name = "denial_arrear_amount")
    @NotNull(message = "Denial arrear amount is required")
    private BigDecimal denialArrearAmount;

    @Column(name = "total_fee_paid")
    @NotNull(message = "Total fee paid is required")
    private BigDecimal totalFeePaid;

    @Column(name = "fee_payment_mode")
    @NotNull(message = "Fee payment mode is required")
    private String feePaymentMode;

    @Column(name = "transaction_no")
    @NotNull(message = "Transaction number is required")
    @Size(max = 80, message = "Transaction number cannot exceed 80 characters")
    private String transactionNo;

    @Column(name = "transaction_date")
    @NotNull(message = "Transaction date is required")
    private Date transactionDate;

    @Column(name = "payment_mode")
    @NotNull(message = "Payment mode is required")
    @Size(max = 150, message = "Payment mode cannot exceed 150 characters")
    private String paymentMode;

    @Column(name = "cheque_no_online_transaction_no")
    @NotNull(message = "Cheque number/online transaction number is required")
    @Size(max = 150, message = "Cheque number/online transaction number cannot exceed 150 characters")
    private String chequeNoOnlineTransactionNo;

    @Column(name = "cheque_date_online_transaction_date")
    @NotNull(message = "Cheque date/online transaction date is required")
    private Date chequeDateOnlineTransactionDate;

    @Column(name = "bank_name")
    @NotNull(message = "Bank name is required")
    @Size(max = 150, message = "Bank name cannot exceed 150 characters")
    private String bankName;

    @Column(name = "bank_branch")
    @NotNull(message = "Bank branch is required")
    @Size(max = 150, message = "Bank branch cannot exceed 150 characters")
    private String bankBranch;

    @Column(name = "ifsc_code")
    @NotNull(message = "IFSC code is required")
    @Size(max = 80, message = "IFSC code cannot exceed 80 characters")
    private String ifscCode;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "application_master_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ApplicationFromMaster applicationMasterId;

}
