package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;


import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserLoginMaster;
import org.springframework.stereotype.Service;

@Service
public interface VendorUserLoginService {

    VendorUserLoginMaster login(String userName, String password);
    VendorUserLoginMaster createUser(VendorUserLoginMaster user);
    void updateUserPassword(Long userId, String oldPassword, String newPassword);
}
