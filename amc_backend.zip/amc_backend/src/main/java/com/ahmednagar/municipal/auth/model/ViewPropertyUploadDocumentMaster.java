package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name = "tbl_view_property_upload_document_master")
public class ViewPropertyUploadDocumentMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "document name is required")
    @Size(max = 50, message = "document name can't exceed 50 characters")
    @Column(name = "document_name", nullable = false, length = 50)
    private String documentName;

    @NotNull(message = "created by is required")
    @Column(name = "created_by", nullable = false)
    private Integer createdBy;

    @Column(name = "updated_by", nullable = false)
    private Integer updatedBy;

    @Column(name = "created_date", nullable = false)
    private LocalDate createdDate;

    @Column(name = "updated_date", nullable = false)
    private LocalDate updatedDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

    @Column(name = "assisment_type")
    private Long propertyAssismentType;

//    @Column(name = "document_group_mas_id")
//    private Long propertyDocumentGroupMaster;

//    @ManyToOne
//    @JoinColumn(name = "document_group_mas_id", referencedColumnName = "id", nullable = false)
//    @JsonBackReference
//    private ViewPropertyDocumentGroupMaster viewPropertyDocumentGroupMaster;

    @ManyToOne
    @JoinColumn(name = "document_group_mas_id", referencedColumnName = "id", nullable = false)
    private ViewPropertyDocumentGroupMaster viewPropertyDocumentGroupMaster;

//    @OneToMany(mappedBy = "viewPropertyUploadDocumentMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
//    @JsonManagedReference
//    private List<ViewMunicipalPropertyDocumentUploadDetails> viewMunicipalPropertyDocumentUploadDetails = null;

}
