package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.forms.formsPropertyTax.dto.PropertyCalculationDetailsEduCessDto;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyCalculationDetailsEduCess;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyCalculationDetailsEduCessService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/forms")
public class PropertyCalculationDetailsEduCessController {

    @Autowired
    PropertyCalculationDetailsEduCessService propertyCalculationDetailsEduCessService;

    @PostMapping("/createPropertyCalculationDetailsEduCess")
    public ResponseEntity<PropertyCalculationDetailsEduCess> createPropertyCalculationDetailsEduCess(@Valid @RequestBody PropertyCalculationDetailsEduCess propertyCalculationDetailsEducess) {
        PropertyCalculationDetailsEduCess createdPropertyCalculationDetailsEduCess = propertyCalculationDetailsEduCessService.createPropertyCalculationDetailsEduCess(propertyCalculationDetailsEducess);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdPropertyCalculationDetailsEduCess);
    }

    @GetMapping("/getPropertyCalculationDetailsEduCess/{id}")
    public ResponseEntity<PropertyCalculationDetailsEduCess> getPropertyCalculationDetailsEduCessById(@PathVariable Long id) {
        PropertyCalculationDetailsEduCess propertyCalculationDetailsEducess = propertyCalculationDetailsEduCessService.findPropertyCalculationDetailsEduCessById(id);
        return ResponseEntity.ok(propertyCalculationDetailsEducess);
    }

    @GetMapping("/getPropertyCalculationDetailsEduCessByMunicipalId/{municipalId}")
    public ResponseEntity<?> getPropertyCalculationDetailsEduCessByMunicipalId(@PathVariable int municipalId) {
        List<PropertyCalculationDetailsEduCessDto> propertyCalculationDetailsEduCess = propertyCalculationDetailsEduCessService.findAllPropertyCalculationDetailsEduCessByMunicipalId(municipalId);
        if (propertyCalculationDetailsEduCess.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("no property calculation details edu cess found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(propertyCalculationDetailsEduCess);
    }

    @PutMapping("/updatePropertyCalculationDetailsEduCess/{id}")
    public ResponseEntity<PropertyCalculationDetailsEduCess> updatePropertyCalculationDetailsEduCess(@PathVariable("id") Long id, @RequestBody PropertyCalculationDetailsEduCess updatedPropertyCalculationDetailsEduCess) {
        try {
            PropertyCalculationDetailsEduCess propertyCalculationDetailsEduCess = propertyCalculationDetailsEduCessService.updatePropertyCalculationDetailsEduCess(id, updatedPropertyCalculationDetailsEduCess, 1);
            return ResponseEntity.ok(propertyCalculationDetailsEduCess);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/propertyCalculationDetailsEduCessSuspendedStatus/{id}")
    public ResponseEntity<PropertyCalculationDetailsEduCess> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        PropertyCalculationDetailsEduCess updatedPropertyCalculationDetailsEduCess = propertyCalculationDetailsEduCessService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedPropertyCalculationDetailsEduCess == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedPropertyCalculationDetailsEduCess);
    }

}

