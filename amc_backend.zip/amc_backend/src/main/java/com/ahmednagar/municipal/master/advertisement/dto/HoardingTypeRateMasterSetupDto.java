package com.ahmednagar.municipal.master.advertisement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingTypeRateMasterSetupDto {
    private Long id;
    private HoardingTypeMasterSetupDto hoardingTypeMasterId;
    private Long usageTypeId;
    private BigDecimal rateInSqft;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
