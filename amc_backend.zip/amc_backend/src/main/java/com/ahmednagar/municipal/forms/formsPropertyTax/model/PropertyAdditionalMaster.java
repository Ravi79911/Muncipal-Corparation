//package com.ahmednagar.municipal.forms.formsPropertyTax.model;
//
//import jakarta.persistence.*;
//import jakarta.validation.constraints.Max;
//import jakarta.validation.constraints.Min;
//import jakarta.validation.constraints.NotNull;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//import java.time.LocalDate;
//import java.util.Set;
//
//@AllArgsConstructor
//@NoArgsConstructor
//@Data
//@Entity
//@Table(name = "tbl_muni_property_additional_master")
//public class PropertyAdditionalMaster {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name = "id")
//    private Long id;
//
//    @NotNull(message = "has water tank flag is required")
//    @Column(name = "has_mobile_tower_flag")
//    private boolean hasMobileTowerFlag;
//
//    @NotNull(message = "has hoarding board flag is required")
//    @Column(name = "has_hoarding_board_flag")
//    private boolean hasHoardingBoardFlag;
//
//    @NotNull(message = "has petrol pump flag is required")
//    @Column(name = "has_petrol_pump_flag")
//    private boolean hasPetrolPumpFlag;
//
//    @NotNull(message = "has rain harvesting provision flag is required")
//    @Column(name = "has_rain_harvesting_provision_flag")
//    private boolean hasRainHarvestingProvisionFlag;
//
//    @NotNull(message = "municipal id is required")
//    @Column(name = "municipal_id")
//    private int municipalId;
//
//    @NotNull(message = "created By is required")
//    @Column(name = "created_by")
//    private int createdBy;
//
//    @Column(name = "created_date")
//    private LocalDate createdDate;
//
//    @Min(value = 0, message = "suspended status must be 0 (inactive) or 1 (active)")
//    @Max(value = 1, message = "suspended status must be 0 (inactive) or 1 (active)")
//    @Column(name = "suspended_status")
//    private int suspendedStatus;
//
//    @ManyToOne
//    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
//    private MunicipalPropertyMaster municipalPropertyMaster;
//
//}
