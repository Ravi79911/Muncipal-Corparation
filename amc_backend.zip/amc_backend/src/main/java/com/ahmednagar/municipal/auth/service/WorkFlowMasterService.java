package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.model.WorkFlowMaster;
import org.springframework.stereotype.Service;

@Service
public interface WorkFlowMasterService {

    WorkFlowMaster saveWorkFlowMaster(WorkFlowMaster workFlowMaster);

    WorkFlowMaster findById(Long id);
}
