package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class VendorReceiptNumberGenerator {

    private static int sequenceNumber = 0;

    // Method to generate the receipt number
    public static synchronized String generateReceiptNumber() {
        // Step 1: Get the current date and time in the required format
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String currentDateTime = dateFormat.format(new Date());

        // Step 2: Generate the sequential 7-digit number
        sequenceNumber++;  // Increment the sequence number
        String sequentialNumber = String.format("%07d", sequenceNumber);  // Ensure it's always 7 digits

        // Step 3: Combine the date-time and the sequential number
        String receiptNumber = currentDateTime + sequentialNumber;

        return receiptNumber;
    }
}
