package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.FilePermissionDto;
import com.ahmednagar.municipal.auth.model.FilePermission;
import com.ahmednagar.municipal.auth.repository.FilePermissionRepository;
import com.ahmednagar.municipal.auth.service.FilePermissionService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FilePermissionServiceImpl implements FilePermissionService {
    @Autowired
    private FilePermissionRepository filePermissionRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public FilePermission saveFilePermissionService(FilePermission filePermission) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        filePermission.setCreatedDate(currentDateTime);
        filePermission.setUpdatedDate(LocalDateTime.now());
        filePermission.setUpdatedBy(filePermission.getUpdatedBy() != null ? filePermission.getUpdatedBy() : 0);
        filePermission.setSuspendedStatus(filePermission.getSuspendedStatus() != null ? filePermission.getSuspendedStatus() : 0);      // 0 means active// 1 means admin
        return filePermissionRepository.saveAndFlush(filePermission);
    }

    @Override
    public List<FilePermissionDto> findAllFilePermission() {
        List<FilePermission> filePermissions = filePermissionRepository.findAll();
        return filePermissions.stream()
                .map(filePermission -> modelMapper.map(filePermission, FilePermissionDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<FilePermissionDto> findAllFilePermissionByMunicipalId(Long municipalId) {
        List<FilePermission> filePermissions = filePermissionRepository.findByMunicipalId(municipalId);
        return filePermissions.stream()
                .map(filePermission -> modelMapper.map(filePermission, FilePermissionDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public FilePermission updateFilePermission(Long id, FilePermission updatedFilePermission) {
        Optional<FilePermission> filePermissionOptional = filePermissionRepository.findById(id);
        if (filePermissionOptional.isPresent()) {
            FilePermission existingFilePermission = filePermissionOptional.get();
            existingFilePermission.setSuspendedStatus(updatedFilePermission.getSuspendedStatus());
            existingFilePermission.setMunicipalId(updatedFilePermission.getMunicipalId());

            return filePermissionRepository.saveAndFlush(existingFilePermission);
        } else {
            throw new RuntimeException("FilePermission not found with id: " + id);
        }
    }

    @Override
    public FilePermission changeSuspendedStatus(Long id, int status) {
        Optional<FilePermission> filePermissionOptional = filePermissionRepository.findById(id);
        if (filePermissionOptional.isPresent()) {
            FilePermission filePermission = filePermissionOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            filePermission.setUpdatedDate(currentDateTime);
            filePermission.setSuspendedStatus(status);      // 1 means suspended
            filePermission.setUpdatedBy(filePermission.getUpdatedBy());
            return filePermissionRepository.saveAndFlush(filePermission);
        }
        return null;
    }
}
