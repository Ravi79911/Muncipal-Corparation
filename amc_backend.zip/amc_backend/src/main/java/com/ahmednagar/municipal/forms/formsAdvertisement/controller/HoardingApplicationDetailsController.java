package com.ahmednagar.municipal.forms.formsAdvertisement.controller;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingApplicationDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingApplicationDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/advertisement/hoarding/application/details/form")
@Validated
@CrossOrigin
public class HoardingApplicationDetailsController {
    @Autowired
    private HoardingApplicationDetailsService hoardingApplicationDetailsService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingApplicationDetails> createHoardingApplicationDetails(@Valid @RequestBody HoardingApplicationDetails hoardingApplicationDetails){
        HoardingApplicationDetails savedHoardingApplicationDetails=hoardingApplicationDetailsService.saveHoardingApplicationDetails(hoardingApplicationDetails);
        return ResponseEntity.status(201).body(savedHoardingApplicationDetails);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingApplicationDetailsDto>> getAllHoardingApplicationDetails(){
        List<HoardingApplicationDetailsDto> hoardingApplicationDetails=hoardingApplicationDetailsService.findAllHoardingApplicationDetails();
        return ResponseEntity.ok(hoardingApplicationDetails);

    }

    //for single user by Id
    @GetMapping("/getMlBusinessNatureById/{id}")
    public ResponseEntity<HoardingApplicationDetails> getHoardingApplicationDetailsById(@PathVariable Long id){
        HoardingApplicationDetails hoardingApplicationDetails=hoardingApplicationDetailsService.findById(id);
        return ResponseEntity.ok(hoardingApplicationDetails);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingApplicationDetailsByMunicipalId(@PathVariable int municipalId){
        List<HoardingApplicationDetails> hoardingApplicationDetails = hoardingApplicationDetailsService.findAllByMunicipalId(municipalId);
        if (hoardingApplicationDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingApplicationDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingApplicationDetails);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingApplicationDetails> updateHoardingApplicationDetails(@PathVariable("id") Long id, @RequestBody HoardingApplicationDetails updatedHoardingApplicationDetails){
        try{
            HoardingApplicationDetails updated=hoardingApplicationDetailsService.updateHoardingApplicationDetails(id,updatedHoardingApplicationDetails,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingApplicationDetailsService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }
}

