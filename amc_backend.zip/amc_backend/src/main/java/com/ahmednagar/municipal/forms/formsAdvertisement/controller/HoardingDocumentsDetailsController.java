package com.ahmednagar.municipal.forms.formsAdvertisement.controller;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingDocumentsDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingDocumentsDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingDocumentsDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/advertisement/hoarding/documents/details/form")
@Validated
@CrossOrigin
public class HoardingDocumentsDetailsController {
    @Autowired
    private HoardingDocumentsDetailsService hoardingDocumentsDetailsService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingDocumentsDetails> createHoardingDocumentsDetails(@Valid @RequestBody HoardingDocumentsDetails hoardingDocumentsDetails){
        HoardingDocumentsDetails savedHoardingDocumentsDetails=hoardingDocumentsDetailsService.saveHoardingDocumentsDetails(hoardingDocumentsDetails);
        return ResponseEntity.status(201).body(savedHoardingDocumentsDetails);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingDocumentsDetailsDto>> getAllHoardingDocumentsDetails(){
        List<HoardingDocumentsDetailsDto> hoardingDocumentsDetails=hoardingDocumentsDetailsService.findAllHoardingDocumentsDetails();
        return ResponseEntity.ok(hoardingDocumentsDetails);

    }

    //for single user by Id
    @GetMapping("/getMlBusinessNatureById/{id}")
    public ResponseEntity<HoardingDocumentsDetails> getHoardingDocumentsDetailsById(@PathVariable Long id){
        HoardingDocumentsDetails hoardingDocumentsDetails=hoardingDocumentsDetailsService.findById(id);
        return ResponseEntity.ok(hoardingDocumentsDetails);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingDocumentsDetailsByMunicipalId(@PathVariable int municipalId){
        List<HoardingDocumentsDetails> hoardingDocumentsDetails = hoardingDocumentsDetailsService.findAllByMunicipalId(municipalId);
        if (hoardingDocumentsDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingDocumentsDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingDocumentsDetails);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingDocumentsDetails> updateHoardingDocumentsDetails(@PathVariable("id") Long id, @RequestBody HoardingDocumentsDetails updatedHoardingDocumentsDetails){
        try{
            HoardingDocumentsDetails updated=hoardingDocumentsDetailsService.updateHoardingDocumentsDetails(id,updatedHoardingDocumentsDetails,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingDocumentsDetailsService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }
}

