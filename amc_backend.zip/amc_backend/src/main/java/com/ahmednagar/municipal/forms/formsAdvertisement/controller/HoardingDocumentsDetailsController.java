package com.ahmednagar.municipal.forms.formsAdvertisement.controller;

import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingDocumentsDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingDocumentsDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingDocumentsDetailsService;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationDocumentsDetails;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/advertisement/hoarding/documents/details/form")
@Validated
@CrossOrigin
public class HoardingDocumentsDetailsController {
    @Autowired
    private HoardingDocumentsDetailsService hoardingDocumentsDetailsService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingDocumentsDetails> createHoardingDocumentsDetails(@Valid @RequestBody HoardingDocumentsDetails hoardingDocumentsDetails) {
        HoardingDocumentsDetails savedHoardingDocumentsDetails = hoardingDocumentsDetailsService.saveHoardingDocumentsDetails(hoardingDocumentsDetails);
        return ResponseEntity.status(201).body(savedHoardingDocumentsDetails);

    }

    @PostMapping("/upload")
    public ResponseEntity<?> uploadDocument(@Valid @RequestParam("documentFileName") MultipartFile file,
                                            @RequestParam("createdBy") int createdBy,
                                            @RequestParam("suspendedStatus") @DefaultValue("0") int suspendedStatus,
                                            @RequestParam("municipalId") int municipalId,
                                            @RequestParam("hoardingApplicationMasterId") Long hoardingApplicationMasterId,
                                            @RequestParam("hoardingDocumentsSubCategoryMasterId") int hoardingDocumentsSubCategoryMasterId)
    {

        try {
            HoardingDocumentsDetails result = hoardingDocumentsDetailsService.uploadDocument(file, createdBy, suspendedStatus, municipalId, hoardingApplicationMasterId, hoardingDocumentsSubCategoryMasterId);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingDocumentsDetailsDto>> getAllHoardingDocumentsDetails() {
        List<HoardingDocumentsDetailsDto> hoardingDocumentsDetails = hoardingDocumentsDetailsService.findAllHoardingDocumentsDetails();
        return ResponseEntity.ok(hoardingDocumentsDetails);

    }

    //for single user by Id
    @GetMapping("/getHoardingDocumentsDetailsById/{id}")
    public ResponseEntity<HoardingDocumentsDetails> getHoardingDocumentsDetailsById(@PathVariable Long id) {
        HoardingDocumentsDetails hoardingDocumentsDetails = hoardingDocumentsDetailsService.findById(id);
        return ResponseEntity.ok(hoardingDocumentsDetails);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingDocumentsDetailsByMunicipalId(@PathVariable int municipalId) {
        List<HoardingDocumentsDetails> hoardingDocumentsDetails = hoardingDocumentsDetailsService.findAllByMunicipalId(municipalId);
        if (hoardingDocumentsDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingDocumentsDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingDocumentsDetails);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/update/{id}")
    public ResponseEntity<HoardingDocumentsDetails> updateHoardingDocumentsDetails(@PathVariable("id") Long id, @RequestBody HoardingDocumentsDetails updatedHoardingDocumentsDetails) {
        try {
            HoardingDocumentsDetails updated = hoardingDocumentsDetailsService.updateHoardingDocumentsDetails(id, updatedHoardingDocumentsDetails, 1);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //     Update AppApplication Details From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<ApiResponse> updateHoardingDocumentsUploadDetails(@PathVariable Long id,
                                                                           @RequestParam("documentUrl") MultipartFile documentUrl) {
        try {
            HoardingDocumentsDetails updatedDetails = hoardingDocumentsDetailsService.updateHoardingDocumentsDetailsById(id, documentUrl);
            return ResponseEntity.ok(new ApiResponse("Document updated successfully.", true, updatedDetails));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An internal error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status) {
        hoardingDocumentsDetailsService.changeStatus(id, status, 1);
        return ResponseEntity.ok().build();

    }

    @GetMapping("/getAllURLsByHoardingApplicationMasterIdWithAllData/{hoardingMasterId}")
    public ResponseEntity<ApiResponse> getApplicationDocumentsDetailsByHoardingMasterId(@PathVariable("hoardingMasterId") Long hoardingMasterId) {
        try {
            List<HoardingDocumentsDetails> documentDetails = hoardingDocumentsDetailsService.getAllDetailsByHoardingMasterId(hoardingMasterId);
            return ResponseEntity.ok(new ApiResponse("Document details retrieved successfully.", true, documentDetails));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An unexpected error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

