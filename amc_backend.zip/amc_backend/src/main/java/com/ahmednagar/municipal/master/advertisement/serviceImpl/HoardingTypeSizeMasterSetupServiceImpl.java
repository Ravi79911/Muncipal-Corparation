package com.ahmednagar.municipal.master.advertisement.serviceImpl;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingTypeSizeMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeSizeMasterSetup;
import com.ahmednagar.municipal.master.advertisement.repository.HoardingTypeSizeMasterSetupRepository;
import com.ahmednagar.municipal.master.advertisement.service.HoardingTypeSizeMasterSetupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingTypeSizeMasterSetupServiceImpl implements HoardingTypeSizeMasterSetupService {
    @Autowired
    private HoardingTypeSizeMasterSetupRepository hoardingTypeSizeMasterSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingTypeSizeMasterSetup saveHoardingTypeSizeMasterSetup(HoardingTypeSizeMasterSetup hoardingTypeSizeMasterSetup) {
        hoardingTypeSizeMasterSetup.setCreatedDate(LocalDateTime.now());
        hoardingTypeSizeMasterSetup.setUpdatedDate(LocalDateTime.now());
        hoardingTypeSizeMasterSetup.setUpdatedBy(hoardingTypeSizeMasterSetup.getUpdatedBy() != null ? hoardingTypeSizeMasterSetup.getUpdatedBy() : 0);
        hoardingTypeSizeMasterSetup.setSuspendedStatus(hoardingTypeSizeMasterSetup.getSuspendedStatus() != null ? hoardingTypeSizeMasterSetup.getSuspendedStatus() : 0);

        return hoardingTypeSizeMasterSetupRepository.save(hoardingTypeSizeMasterSetup);

    }

    @Override
    public List<HoardingTypeSizeMasterSetupDto> findAllHoardingTypeSizeMasterSetup() {
        List<HoardingTypeSizeMasterSetup> hoardingTypeSizeMasterSetups = hoardingTypeSizeMasterSetupRepository.findAll();
        return hoardingTypeSizeMasterSetups.stream()
                .map(hoardingTypeSizeMasterSetup -> modelMapper.map(hoardingTypeSizeMasterSetup, HoardingTypeSizeMasterSetupDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingTypeSizeMasterSetup findById(Long id) {
        Optional<HoardingTypeSizeMasterSetup> hoardingTypeSizeMasterSetup=hoardingTypeSizeMasterSetupRepository.findById(id);
        return hoardingTypeSizeMasterSetup.orElse(null);

    }

    @Override
    public List<HoardingTypeSizeMasterSetup> findAllByMunicipalId(int municipalId) {
        return hoardingTypeSizeMasterSetupRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingTypeSizeMasterSetup updateHoardingTypeSizeMasterSetup(Long id, HoardingTypeSizeMasterSetup updatedHoardingTypeSizeMasterSetup, int updatedBy) {
        Optional<HoardingTypeSizeMasterSetup> hoardingTypeSizeMasterSetupOptional = hoardingTypeSizeMasterSetupRepository.findById(id);
        if (hoardingTypeSizeMasterSetupOptional.isPresent()) {
            HoardingTypeSizeMasterSetup existingHoardingTypeSizeMasterSetup = hoardingTypeSizeMasterSetupOptional.get();
            existingHoardingTypeSizeMasterSetup.setUpdatedBy(updatedBy);
            existingHoardingTypeSizeMasterSetup.setUpdatedDate(LocalDateTime.now());

            return hoardingTypeSizeMasterSetupRepository.saveAndFlush(existingHoardingTypeSizeMasterSetup);
        } else {
            throw new RuntimeException("HoardingTypeSizeMasterSetup not found with id: " + id);
        }
    }

    @Override
    public HoardingTypeSizeMasterSetup changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingTypeSizeMasterSetup> hoardingTypeSizeMasterSetupOpt = hoardingTypeSizeMasterSetupRepository.findById(id);
        if (hoardingTypeSizeMasterSetupOpt.isPresent()) {
            HoardingTypeSizeMasterSetup hoardingTypeSizeMasterSetup = hoardingTypeSizeMasterSetupOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingTypeSizeMasterSetup.setUpdatedDate(currentDateTime);
            hoardingTypeSizeMasterSetup.setSuspendedStatus(status);      // 1 means suspended
            hoardingTypeSizeMasterSetup.setUpdatedBy(updatedBy);
            return hoardingTypeSizeMasterSetupRepository.saveAndFlush(hoardingTypeSizeMasterSetup);
        }
        return null;
    }
}
