package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyCalculationDetailsEduCess;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface PropertyCalculationDetailsEduCessRepository extends JpaRepository<PropertyCalculationDetailsEduCess, Long> {

    List<PropertyCalculationDetailsEduCess> findByMunicipalId(int municipalId);

    List<PropertyCalculationDetailsEduCess> findBySuspendedStatus(Integer status);

}
