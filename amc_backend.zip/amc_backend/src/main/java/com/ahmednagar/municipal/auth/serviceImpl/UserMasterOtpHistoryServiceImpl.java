package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.UserMasterOtpHistory;
import com.ahmednagar.municipal.auth.repository.UserMasterOtpHistoryRepository;
import com.ahmednagar.municipal.auth.service.UserMasterOtpHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserMasterOtpHistoryServiceImpl implements UserMasterOtpHistoryService {

    @Autowired
    UserMasterOtpHistoryRepository userMasterOtpHistoryRepository;

    @Override
    public List<UserMasterOtpHistory> getAllUserMasterOtpHistory() {
        return userMasterOtpHistoryRepository.findAll();
    }

}
