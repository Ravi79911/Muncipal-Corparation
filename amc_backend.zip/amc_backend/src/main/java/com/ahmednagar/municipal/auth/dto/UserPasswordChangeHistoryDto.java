package com.ahmednagar.municipal.auth.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserPasswordChangeHistoryDto {

    private Long id;
    private UserDetailsDTO userId;
    private String lastPwdChange;
    private LocalDateTime pwdChangedDateTime;
    private String ipAddress;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private Long municipalId;

}
