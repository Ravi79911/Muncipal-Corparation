package com.ahmednagar.municipal.forms.formsWaterManagement.service;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.UserBasicDetails;

import java.util.List;
import java.util.Optional;

public interface UserBasicDetailsService {

    UserBasicDetails createUserBasicDetails(UserBasicDetails userBasicDetails, int createdBy);

//    UserBasicDetails updateUserBasicDetails(int id, UserBasicDetails userBasicDetails, int updatedBy);

    UserBasicDetails deleteUserBasicDetailsById(int id, int suspendedStatus, int updatedBy);

//    UserBasicDetails getUserBasicDetailsById(int id);

    List<UserBasicDetails> getUserBasicDetailsByMunicipalId(int municipalId);
}
