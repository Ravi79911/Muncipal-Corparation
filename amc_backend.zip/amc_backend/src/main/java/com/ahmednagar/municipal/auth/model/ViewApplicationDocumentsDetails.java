package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_view_application_documents_details")
public class ViewApplicationDocumentsDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "document_file_name")
    @NotNull
    @Size(max = 150, message = "Document file name cannot exceed 150 characters")
    private String documentFileName;

    @Column(name = "document_path")
    @NotNull(message = "Document path is required")
    @Size(max = 150, message = "Document path cannot exceed 150 characters")
    private String documentPath;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @Column(name = "approved_status")
    private Float approvedStatus;

    @ManyToOne
    @JoinColumn(name = "document_master_id",referencedColumnName = "id", nullable = false)
    private ViewMlDocumentsMaster viewMlDocumentsMaster;

    @ManyToOne
    @JoinColumn(name = "application_master_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewApplicationFromMaster viewApplicationFromMaster;

}

