package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandTransactionDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandTransactionMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyDemandTransactionDetailsRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyDemandTransactionMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyDemandTransactionDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyDemandTransactionDetailsServiceImpl implements PropertyDemandTransactionDetailsService {

    @Autowired
    MunicipalPropertyMasterRepository municipalPropertyMasterRepository;

    @Autowired
    PropertyDemandTransactionMasterRepository propertyDemandTransactionMasterRepository;

    @Autowired
    PropertyDemandTransactionDetailsRepository propertyDemandTransactionDetailsRepository;

    @Override
    public PropertyDemandTransactionDetails createPropertyDemandTransactionDetails(PropertyDemandTransactionDetails propertyDemandTransactionDetails) {
        Optional<MunicipalPropertyMaster> municipalPropertyMaster =
                municipalPropertyMasterRepository.findById(propertyDemandTransactionDetails.getMunicipalPropertyMaster().getId());

        if (!municipalPropertyMaster.isPresent()) {
            throw new IllegalArgumentException("municipal property master id doesn't exist");
        }
        Optional<PropertyDemandTransactionMaster> propertyDemandTransactionMaster =
                propertyDemandTransactionMasterRepository.findById(propertyDemandTransactionDetails.getPropertyDemandTransactionMaster().getId());

        if (!propertyDemandTransactionMaster.isPresent()) {
            throw new IllegalArgumentException("property demand transaction master id doesn't exist");
        }
        propertyDemandTransactionDetails.setCreatedDate(LocalDateTime.now());
        return propertyDemandTransactionDetailsRepository.saveAndFlush(propertyDemandTransactionDetails);
    }

    @Override
    public List<PropertyDemandTransactionDetails> getAllPropertyDemandTransactionDetails() {
        return propertyDemandTransactionDetailsRepository.findAll();
    }

    @Override
    public Optional<PropertyDemandTransactionDetails> getPropertyDemandTransactionDetailsById(Long id) {
        return propertyDemandTransactionDetailsRepository.findById(id);
    }

    @Override
    public List<PropertyDemandTransactionDetails> getPropertyDemandTransactionDetailsByMunicipalId(int municipalId) {
        return propertyDemandTransactionDetailsRepository.findByMunicipalId(municipalId);
    }

    @Override
    public PropertyDemandTransactionDetails patchPropertyDemandTransactionDetailsSuspendedStatus(Long id, int suspendedStatus) {
        Optional<PropertyDemandTransactionDetails> patchPropertyDemandTransactionDetails = propertyDemandTransactionDetailsRepository.findById(id);
        if (patchPropertyDemandTransactionDetails.isPresent()) {
            PropertyDemandTransactionDetails existingPropertyDemandTransactionDetails = patchPropertyDemandTransactionDetails.get();
            existingPropertyDemandTransactionDetails.setSuspendedStatus(suspendedStatus);
            return propertyDemandTransactionDetailsRepository.saveAndFlush(existingPropertyDemandTransactionDetails);
        } else {
            throw new RuntimeException("property demand transaction details not found with id: " + id);
        }
    }

}
