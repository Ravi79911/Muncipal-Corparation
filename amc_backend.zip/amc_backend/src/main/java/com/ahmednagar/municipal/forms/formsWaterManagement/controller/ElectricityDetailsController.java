package com.ahmednagar.municipal.forms.formsWaterManagement.controller;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ElectricityDetails;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.ElectricityDetailsServices;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/water/forms/electricity")
public class ElectricityDetailsController {

    @Autowired
    private ElectricityDetailsServices electricityDetailsService;

//    1. Post API to create a new electricity details
    @PostMapping("/create")
    public ResponseEntity<?> create(@Valid @RequestBody ElectricityDetails electricityDetails, @RequestParam int createdBy){
        ElectricityDetails createdElectricityDetails = electricityDetailsService.createElectricityDetails(electricityDetails, 1);
        if(createdElectricityDetails == null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Electricity Details not created");
        }else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("Electricity Details created successfully"+createdElectricityDetails);
        }
    }
////    2. Put API to update an existing electricity details
//    @PutMapping("/update/{id}")
//    public ResponseEntity<?> update(@PathVariable int id, @Valid @RequestBody ElectricityDetails electricityDetails, @RequestParam int createdBy){
//        ElectricityDetails updatedElectricityDetails = electricityDetailsService.updateElectricityDetails(id, electricityDetails, 1);
//        if(updatedElectricityDetails == null){
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                    .body("Electricity Details not updated");
//        }else {
//            return ResponseEntity.status(HttpStatus.OK)
//                    .body("Electricity Details updated successfully"+updatedElectricityDetails);
//        }
//    }

//    3. Delete API to delete electricity details by ID
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> delete(@PathVariable int id, @RequestParam(required = false, defaultValue = "1") int status, @RequestParam int createdBy){
        ElectricityDetails deletedElectricityDetails = electricityDetailsService.deleteElectricityDetails(id, status, 1);
        if(deletedElectricityDetails == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Electricity Details not found with the given ID");
        }
        return ResponseEntity.ok(deletedElectricityDetails);
    }

//    4. Get API to get all electricity details by municipalId
    @GetMapping("/getAll/{municipalId}")
    public ResponseEntity<?> getAllbyMunicipalId(@PathVariable int municipalId){
        List<ElectricityDetails> electricityDetailsList = electricityDetailsService.getAllElectricityByMunicipalId(municipalId);
        if(electricityDetailsList == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Electricity Details not found with the given municipalId");
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(electricityDetailsList);
    }

////    5. Get API to get an electricity details by ID
//    @GetMapping("/get/{id}")
//    public ResponseEntity<?> getById(@PathVariable int id){
//        ElectricityDetails electricityDetails = electricityDetailsService.getElectricityDetailsbyId(id);
//        if(electricityDetails == null){
//            return ResponseEntity.status(HttpStatus.NOT_FOUND)
//                    .body("Electricity Details not found with the given ID");
//        }
//        return ResponseEntity.status(HttpStatus.OK)
//                .body(electricityDetails);
//    }

}
