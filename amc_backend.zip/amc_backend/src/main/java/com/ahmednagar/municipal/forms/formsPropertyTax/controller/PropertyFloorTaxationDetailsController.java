package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.forms.formsPropertyTax.dto.PropertyFloorTaxationDetailsDto;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyFloorTaxationDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyFloorTaxationDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/forms")
public class PropertyFloorTaxationDetailsController {

    @Autowired
    PropertyFloorTaxationDetailsService propertyFloorTaxationDetailsService;

    @PostMapping("/createPropertyFloorTaxationDetails")
    public ResponseEntity<PropertyFloorTaxationDetails> createPropertyFloorTaxationDetails(@Valid @RequestBody PropertyFloorTaxationDetails propertyFloorTaxationDetails) {
        PropertyFloorTaxationDetails createdPropertyFloorTaxationDetails = propertyFloorTaxationDetailsService.createPropertyFloorTaxationDetails(propertyFloorTaxationDetails);
        if (createdPropertyFloorTaxationDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdPropertyFloorTaxationDetails);
    }

    @GetMapping("/getPropertyFloorTaxationDetails/{id}")
    public ResponseEntity<PropertyFloorTaxationDetails> getPropertyFloorTaxationDetailsById(@PathVariable Long id) {
        PropertyFloorTaxationDetails propertyFloorTaxationDetails = propertyFloorTaxationDetailsService.findPropertyFloorTaxationDetailsById(id);
        return ResponseEntity.ok(propertyFloorTaxationDetails);
    }

    @GetMapping("/getAllPropertyFloorTaxationDetailsByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllPropertyFloorTaxationDetailsByMunicipalId(@PathVariable int municipalId) {
        List<PropertyFloorTaxationDetailsDto> propertyFloorTaxationDetails = propertyFloorTaxationDetailsService.findAllPropertyFloorTaxationDetailsByMunicipalId(municipalId);
        if (propertyFloorTaxationDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("no property floor taxation details found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(propertyFloorTaxationDetails);
    }

    @PutMapping("/updatePropertyFloorTaxationDetails/{id}")
    public ResponseEntity<PropertyFloorTaxationDetails> updatePropertyFloorTaxationDetails(@PathVariable("id") Long id, @RequestBody PropertyFloorTaxationDetails updatedPropertyFloorTaxationDetails) {
        try {
            PropertyFloorTaxationDetails updated = propertyFloorTaxationDetailsService.updatePropertyFloorTaxationDetails(id, updatedPropertyFloorTaxationDetails, 1);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/propertyFloorTaxationDetails/suspendedStatus/{id}")
    public ResponseEntity<PropertyFloorTaxationDetails> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        PropertyFloorTaxationDetails updatedPropertyFloorTaxationDetails = propertyFloorTaxationDetailsService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedPropertyFloorTaxationDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedPropertyFloorTaxationDetails);
    }

}

