package com.ahmednagar.municipal.forms.formsWaterManagement.dto;

public class ElectricityDetailsDto {
}
