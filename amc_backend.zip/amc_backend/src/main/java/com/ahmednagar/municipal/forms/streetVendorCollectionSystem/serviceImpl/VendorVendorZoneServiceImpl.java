package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorZone;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorZoneRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorZoneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class VendorVendorZoneServiceImpl implements VendorZoneService {

    @Autowired
    private VendorZoneRepository vendorZoneRepository;

    @Override
    public List<VendorZone> findAllZones() {
        return vendorZoneRepository.findAll();
    }
}
