package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.AdvertisementTemporaryRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.AdvertisementTemporaryRolesDataFlowSetup;
import com.ahmednagar.municipal.auth.service.AdvertisementTemporaryRolesDataFlowSetupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/advertisement/temporary/roles/data/flow/setup/")
public class AdvertisementTemporaryRolesDataFlowSetupController {

    @Autowired
    private AdvertisementTemporaryRolesDataFlowSetupService advertisementTemporaryRolesDataFlowSetupService;

    @GetMapping("/getAllRole")
    public ResponseEntity<List<AdvertisementTemporaryRolesDataFlowSetupDto>> getAllRolesDataFlowSetup() {
        List<AdvertisementTemporaryRolesDataFlowSetupDto> role = advertisementTemporaryRolesDataFlowSetupService.findAllRolesDataFlowSetup();
        return ResponseEntity.ok(role);
    }

    @GetMapping("/document/verification/accept/next-role")
    public ResponseEntity<?> getNextRoleIdForDocumentVerificationAccept(@RequestParam Long currentRoleId, @RequestParam Long statusCode, @RequestParam Integer isActive) {
        AdvertisementTemporaryRolesDataFlowSetup advertisementTemporaryRolesDataFlowSetup = advertisementTemporaryRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRoleId, statusCode, isActive);
        return ResponseEntity.ok(advertisementTemporaryRolesDataFlowSetup);

    }

    @GetMapping("/document/verification/reject/next-role")
    public ResponseEntity<List<AdvertisementTemporaryRolesDataFlowSetup>> getNextRoleIdForDocumentVerificationReject(@RequestParam Long currentRoleId, @RequestParam Long statusCode, @RequestParam Integer isActive) {
        List<AdvertisementTemporaryRolesDataFlowSetup> nextRoles = advertisementTemporaryRolesDataFlowSetupService.getNextRoleListForListSelection(currentRoleId, statusCode, isActive);
        return ResponseEntity.ok(nextRoles);
    }

}

