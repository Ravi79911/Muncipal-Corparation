package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import com.ahmednagar.municipal.master.municipalLicence.dto.MlDocumentsMasterDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ApplicationDocumentsDetailsDto {
    private int id;
    private String documentFileName;
    private ApplicationFromMasterDto applicationMasterId;
    private MlDocumentsMasterDto documentMasterId;
    private String documentPath;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;
}
