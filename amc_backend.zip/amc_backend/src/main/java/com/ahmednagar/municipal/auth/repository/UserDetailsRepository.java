package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.UserDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserDetailsRepository extends JpaRepository<UserDetails, Long> {

    List<UserDetails> findByMunicipalId(Long municipalId);
}
