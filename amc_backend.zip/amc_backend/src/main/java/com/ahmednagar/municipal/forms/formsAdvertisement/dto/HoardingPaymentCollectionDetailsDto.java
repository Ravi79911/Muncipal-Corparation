package com.ahmednagar.municipal.forms.formsAdvertisement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingPaymentCollectionDetailsDto {
    private Long id;
    private Long paymentCollectionMasterId;
    private Long hoardingApplicationDetailId;
    private String paymentAmountDemand;
    private String paymentAmountPaid;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
