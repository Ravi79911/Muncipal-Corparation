package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.UserLoginLogoffHistory;
import com.ahmednagar.municipal.master.municipalLicence.model.MlBusinessNature;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface UserLoginLogoffHistoryRepository extends JpaRepository<UserLoginLogoffHistory,Long> {
    List<UserLoginLogoffHistory> findByMunicipalId(Long municipalId);

}
