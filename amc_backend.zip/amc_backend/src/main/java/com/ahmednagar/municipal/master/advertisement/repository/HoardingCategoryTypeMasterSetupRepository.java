package com.ahmednagar.municipal.master.advertisement.repository;

import com.ahmednagar.municipal.master.advertisement.model.HoardingCategoryTypeMasterSetup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface HoardingCategoryTypeMasterSetupRepository extends JpaRepository<HoardingCategoryTypeMasterSetup,Long> {
    List<HoardingCategoryTypeMasterSetup> findAllByMunicipalId(int municipalId);
}
