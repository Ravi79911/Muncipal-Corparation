package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.CitizenPasswordChangeHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CitizenPasswordChangeHistoryRepository extends JpaRepository<CitizenPasswordChangeHistory, Long> {

    List<CitizenPasswordChangeHistory> findByCitizenId(Long citizenId);

}
