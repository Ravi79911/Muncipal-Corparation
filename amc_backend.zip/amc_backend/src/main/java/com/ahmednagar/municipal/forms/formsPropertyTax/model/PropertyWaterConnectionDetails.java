package com.ahmednagar.municipal.forms.formsPropertyTax.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_muni_property_water_connection_details")
public class PropertyWaterConnectionDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "water connection type is required")
    @Size(max = 50, message = "water connection type can't exceed 50 characters")
    @Column(name = "water_connection_type")
    private String waterConnectionType;

    @Column(name = "name_of_connection_holder")
    private String nameOfConnectionHolder;

    @NotNull(message = "water consumer number is required")
    @Size(max = 50, message = "water consumer number can't exceed 50 characters")
    @Column(name = "water_consumer_number")
    private String waterConsumerNumber;

    @Column(name = "water_connect_date")
    private LocalDate waterConnectionDate;

    @NotNull(message = "created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private MunicipalPropertyMaster municipalPropertyMaster;

}
