package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.MunicipalLicenseTransactionDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.MunicipalLicenseTransactionDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MunicipalLicenseTransactionDetailsService {
    MunicipalLicenseTransactionDetails saveMunicipalLicenseTransactionDetails(MunicipalLicenseTransactionDetails municipalLicenseTransactionDetails);

    MunicipalLicenseTransactionDetails findMunicipalLicenseTransactionDetailsById(Long id);

    List<MunicipalLicenseTransactionDetailsDto> findAllMunicipalLicenseTransactionDetailsByMunicipalId(int municipalId);

    MunicipalLicenseTransactionDetails updateMunicipalLicenseTransactionDetails(Long id, MunicipalLicenseTransactionDetails updatedMunicipalLicenseTransactionDetails, int updatedBy);

    MunicipalLicenseTransactionDetails changeSuspendedStatus(Long id, int status, int updatedBy);
}
