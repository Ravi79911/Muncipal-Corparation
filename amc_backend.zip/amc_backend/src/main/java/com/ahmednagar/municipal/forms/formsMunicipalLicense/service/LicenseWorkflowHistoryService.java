package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseWorkflowHistory;
import org.springframework.stereotype.Service;

@Service
public interface LicenseWorkflowHistoryService {
    LicenseWorkflowHistory saveLicenseWorkflowHistory(LicenseWorkflowHistory licenseWorkflowHistory);
}
