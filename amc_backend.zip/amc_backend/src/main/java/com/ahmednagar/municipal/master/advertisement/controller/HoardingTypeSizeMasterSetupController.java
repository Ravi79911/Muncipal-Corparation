package com.ahmednagar.municipal.master.advertisement.controller;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingTypeSizeMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeSizeMasterSetup;
import com.ahmednagar.municipal.master.advertisement.service.HoardingTypeSizeMasterSetupService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/advertisement")
@Validated
@CrossOrigin
public class HoardingTypeSizeMasterSetupController {
    @Autowired
    private HoardingTypeSizeMasterSetupService hoardingTypeSizeMasterSetupService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingTypeSizeMasterSetup> createHoardingTypeSizeMasterSetup(@Valid @RequestBody HoardingTypeSizeMasterSetup hoardingTypeSizeMasterSetup){
        HoardingTypeSizeMasterSetup savedHoardingTypeSizeMasterSetup=hoardingTypeSizeMasterSetupService.saveHoardingTypeSizeMasterSetup(hoardingTypeSizeMasterSetup);
        return ResponseEntity.status(201).body(savedHoardingTypeSizeMasterSetup);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingTypeSizeMasterSetupDto>> getAllHoardingTypeSizeMasterSetup(){
        List<HoardingTypeSizeMasterSetupDto> hoardingTypeSizeMasterSetup=hoardingTypeSizeMasterSetupService.findAllHoardingTypeSizeMasterSetup();
        return ResponseEntity.ok(hoardingTypeSizeMasterSetup);

    }
    //for single user by Id
    @GetMapping("/getMlBusinessNatureById/{id}")
    public ResponseEntity<HoardingTypeSizeMasterSetup> getHoardingTypeSizeMasterSetupById(@PathVariable Long id){
        HoardingTypeSizeMasterSetup hoardingTypeSizeMasterSetup=hoardingTypeSizeMasterSetupService.findById(id);
        return ResponseEntity.ok(hoardingTypeSizeMasterSetup);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingTypeSizeMasterSetupByMunicipalId(@PathVariable int municipalId){
        List<HoardingTypeSizeMasterSetup> hoardingTypeSizeMasterSetups = hoardingTypeSizeMasterSetupService.findAllByMunicipalId(municipalId);
        if (hoardingTypeSizeMasterSetups.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingTypeSizeMasterSetup nature found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingTypeSizeMasterSetups);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingTypeSizeMasterSetup> updateHoardingTypeSizeMasterSetup(@PathVariable("id") Long id, @RequestBody HoardingTypeSizeMasterSetup updatedHoardingTypeSizeMasterSetup){
        try{
            HoardingTypeSizeMasterSetup updated=hoardingTypeSizeMasterSetupService.updateHoardingTypeSizeMasterSetup(id,updatedHoardingTypeSizeMasterSetup,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingTypeSizeMasterSetupService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }

}

