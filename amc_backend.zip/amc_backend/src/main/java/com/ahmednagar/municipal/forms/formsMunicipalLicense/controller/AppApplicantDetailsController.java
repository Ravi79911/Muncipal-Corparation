package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.AppApplicantDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.AppApplicantDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.AppApplicantDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/license/forms/appApplicantDetails")
public class AppApplicantDetailsController {

    @Autowired
    private AppApplicantDetailsService appApplicantDetailsService;

    //create AppApplicantDetails
    @PostMapping("/create")
    public ResponseEntity<AppApplicantDetails> createAppApplicationDetails(@Valid @RequestBody AppApplicantDetails appApplicantDetails,@RequestParam int createdBy){
        AppApplicantDetails createdAppApplicationDetails=appApplicantDetailsService.saveAppApplicationDetails(appApplicantDetails,1);
        if(createdAppApplicationDetails==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdAppApplicationDetails);
    }

    // list of entity creation method
    @PostMapping("/createList")
    public ResponseEntity<List<AppApplicantDetails>> createAppApplicantDetails(@Valid @RequestBody List<AppApplicantDetails> appApplicantDetailsList) {
        try {
            List<AppApplicantDetails> newAppApplicantDetailsList = appApplicantDetailsService.createAppApplicantDetailsList(appApplicantDetailsList);
            return ResponseEntity.ok(newAppApplicantDetailsList);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(List.of());
        }
    }

        //  to get the Application Details by id for user
    @GetMapping("/get/{id}")
    public ResponseEntity<AppApplicantDetails> getApplicationDetailsById(@PathVariable Long id){
        AppApplicantDetails appApplicantDetails=appApplicantDetailsService.findAppApplicantDetailsById(id);
        return ResponseEntity.ok(appApplicantDetails);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllAppApplicantDetailsByMunicipalId(@PathVariable int municipalId){
        List<AppApplicantDetailsDto> appApplicantDetails=appApplicantDetailsService.findAllAppApplicantDetailsByMunicipalId(municipalId);
        if (appApplicantDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No appApplicantDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(appApplicantDetails);
    }
    //     Update AppApplication Details From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<AppApplicantDetails> updateAppApplicantDetails(@PathVariable("id") Long id, @RequestBody AppApplicantDetails updatedAppApplicantDetails){
        try{
            AppApplicantDetails updated=appApplicantDetailsService.updateAppApplicantDetails(id,updatedAppApplicantDetails,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete AppApplication Details for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<AppApplicantDetails> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        AppApplicantDetails updatedAppApplicantDetails = appApplicantDetailsService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedAppApplicantDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedAppApplicantDetails);
    }


}
