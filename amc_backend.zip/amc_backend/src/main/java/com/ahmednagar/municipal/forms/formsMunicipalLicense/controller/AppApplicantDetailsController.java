package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.AppApplicantDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.AppApplicantDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.AppApplicantDetailsService;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyOwnerMaster;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/forms/license/appApplicantDetails")
public class AppApplicantDetailsController {

    @Autowired
    private AppApplicantDetailsService appApplicantDetailsService;

    //create AppApplicantDetails
    @PostMapping("/create")
    public ResponseEntity<AppApplicantDetails> createAppApplicationDetails(@Valid @RequestBody AppApplicantDetails appApplicantDetails,@RequestParam int createdBy){
        AppApplicantDetails createdAppApplicationDetails=appApplicantDetailsService.saveAppApplicationDetails(appApplicantDetails,1);
        if(createdAppApplicationDetails==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdAppApplicationDetails);
    }

    // list of entity creation method
    @PostMapping("/createList")
    public ResponseEntity<List<AppApplicantDetails>> createAppApplicantDetails(@Valid @RequestBody List<AppApplicantDetails> appApplicantDetailsList) {
        try {
            List<AppApplicantDetails> newAppApplicantDetailsList = appApplicantDetailsService.createAppApplicantDetailsList(appApplicantDetailsList);
            return ResponseEntity.ok(newAppApplicantDetailsList);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(List.of());
        }
    }

    @PostMapping(value = "/createLicenseList", consumes = "multipart/form-data")
    public ResponseEntity<List<AppApplicantDetails>> createAppApplicantDetails(
            @RequestPart("applicantDetails") List<AppApplicantDetails> appApplicantDetails,
            @RequestPart(value = "applicantPhoto", required = false) List<MultipartFile> applicantPhoto) {
        List<AppApplicantDetails> savedMasters = appApplicantDetailsService.createAppApplicantDetailsLicenseList(appApplicantDetails, applicantPhoto);
        return ResponseEntity.ok(savedMasters);
    }

        //  to get the Application Details by id for user
    @GetMapping("/get/{id}")
    public ResponseEntity<AppApplicantDetails> getApplicationDetailsById(@PathVariable Long id){
        AppApplicantDetails appApplicantDetails=appApplicantDetailsService.findAppApplicantDetailsById(id);
        return ResponseEntity.ok(appApplicantDetails);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllAppApplicantDetailsByMunicipalId(@PathVariable int municipalId){
        List<AppApplicantDetailsDto> appApplicantDetails=appApplicantDetailsService.findAllAppApplicantDetailsByMunicipalId(municipalId);
        if (appApplicantDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No appApplicantDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(appApplicantDetails);
    }
    //     Update AppApplication Details From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<AppApplicantDetails> updateAppApplicantDetails(@PathVariable("id") Long id, @RequestBody AppApplicantDetails updatedAppApplicantDetails){
        try{
            AppApplicantDetails updated=appApplicantDetailsService.updateAppApplicantDetails(id,updatedAppApplicantDetails);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    @PutMapping(value = "/updateAppApplicant/{id}", consumes = "multipart/form-data")
    public ResponseEntity<ApiResponse> updateAppApplicantDetailsInList(@PathVariable Long id,
                                                                          @RequestPart("applicantDetails") AppApplicantDetails updatedAppApplicantDetails,
                                                                          @RequestPart(value = "applicantPhoto", required = false) MultipartFile applicantPhoto) {
        try {
            AppApplicantDetails updatedOwner = appApplicantDetailsService.updateAppApplicantDetailsInList(id, updatedAppApplicantDetails, applicantPhoto);

            return ResponseEntity.ok(new ApiResponse("AppApplicant updated successfully!", true, updatedOwner));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An internal error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //delete AppApplication Details for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<AppApplicantDetails> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        AppApplicantDetails updatedAppApplicantDetails = appApplicantDetailsService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedAppApplicantDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedAppApplicantDetails);
    }

    @DeleteMapping("/deleteAppApplicantDetails/{applicationMasterId}")
    public ResponseEntity<String> deleteAppApplicantDetails(@PathVariable Long applicationMasterId) {
        try {
            appApplicantDetailsService.deleteAppApplicantDetailsByApplicationMasterId(applicationMasterId);
            return ResponseEntity.ok("applicationMasterId details records deleted successfully for ApplicationMasterId id: " + applicationMasterId);
        } catch (Exception ex) {
            return ResponseEntity.status(500).body("An unexpected error occurred: " + ex.getMessage());
        }
    }


}
