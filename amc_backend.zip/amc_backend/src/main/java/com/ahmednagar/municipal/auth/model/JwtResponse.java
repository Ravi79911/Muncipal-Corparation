package com.ahmednagar.municipal.auth.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class JwtResponse {

    private String accessToken;
    private String refreshToken;
    private String mobileNumber;
    private Long userId;
    private String username;
    private String role;
    private String groupName;

}
