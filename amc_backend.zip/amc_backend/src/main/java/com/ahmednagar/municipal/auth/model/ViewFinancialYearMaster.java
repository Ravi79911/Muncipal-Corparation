package com.ahmednagar.municipal.auth.model;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import com.ahmednagar.municipal.master.propertyTax.model.*;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_view_financial_year_master")
public class ViewFinancialYearMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "fin_id")
    private int finId;

    @NotNull(message = "please enter the financial year")
    @Column(name = "Fin_year")
    private String fyYear;

    @Column(name = "CreatedDate")
    private LocalDate createdDate;

//    @OneToMany(mappedBy = "financialYearMaster", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//    private Set<PropertyAreaRangeMaster> propertyAreaRangeMasters;

//    @OneToMany(mappedBy = "financialYearMaster", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//    private Set<PropertyTaxCessRateMaster> propertyTaxCessRateMasters;
//
//    @OneToMany(mappedBy = "financialYearMaster", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//    private Set<PropertyTaxComponent> propertyTaxComponents;
//
//    @OneToMany(mappedBy = "financialYearMaster", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//    private Set<PropertyTaxRate> propertyTaxRates;
//
//    @OneToMany(mappedBy = "financialYearMaster", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//    private Set<MunicipalPropertyMaster> municipalPropertyMasters;
//
//    @OneToMany(mappedBy = "financialYearMaster", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//    private Set<AnnualRatingValueMaster> annualRatingValueMasters;
//
//    @OneToMany(mappedBy = "financialYearMaster", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//    private Set<BuildingAgingMaintenanceDeductionMaster> buildingAgingMaintenanceDeductionMasters;

}
