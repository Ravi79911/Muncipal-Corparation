package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.SubMenuMaster;
import com.ahmednagar.municipal.auth.service.SubMenuMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class SubMenuMasterController {

    @Autowired
    SubMenuMasterService subMenuMasterService;

    @PostMapping("/createSubMenu")
    public ResponseEntity<SubMenuMaster> createRole(@Valid @RequestBody SubMenuMaster subMenuMaster) {
        SubMenuMaster createdSubMenuMaster = subMenuMasterService.saveSubMenu(subMenuMaster);
        if (createdSubMenuMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdSubMenuMaster);
    }

    @GetMapping("/getAllSubMenu")
    public ResponseEntity<List<SubMenuMaster>> getAllSubMenu() {
        List<SubMenuMaster> subMenuMasters = subMenuMasterService.findAllSubMenu();
        return ResponseEntity.ok(subMenuMasters);
    }

    @GetMapping("/getSubMenuByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllSubMenuByMunicipalId(@PathVariable Long municipalId) {
        List<SubMenuMaster> subMenuMasters = subMenuMasterService.findAllSubMenuByMunicipalId(municipalId);
        if (subMenuMasters.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No subMenu found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(subMenuMasters);
    }

    @PutMapping("/subMenu/update/{id}")
    public ResponseEntity<SubMenuMaster> updateSubMenu(@PathVariable("id") Long id, @RequestBody SubMenuMaster updatedSubMenuMaster) {
        try {
            SubMenuMaster updated = subMenuMasterService.updateSubMenu(id, updatedSubMenuMaster);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/subMenu/suspendedStatus/{id}")
    public ResponseEntity<SubMenuMaster> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        SubMenuMaster updatedSubMenuMaster = subMenuMasterService.changeSuspendedStatus(id, status);
        if (updatedSubMenuMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedSubMenuMaster);
    }

}

