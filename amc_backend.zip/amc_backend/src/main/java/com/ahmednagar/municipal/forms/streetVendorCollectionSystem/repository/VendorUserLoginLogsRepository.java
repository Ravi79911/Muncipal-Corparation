package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserLoginLogs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface VendorUserLoginLogsRepository extends JpaRepository<VendorUserLoginLogs, Long> {
}
