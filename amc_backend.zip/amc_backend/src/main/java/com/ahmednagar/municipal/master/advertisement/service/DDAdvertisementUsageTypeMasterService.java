package com.ahmednagar.municipal.master.advertisement.service;

import com.ahmednagar.municipal.master.advertisement.model.DDAdvertisementUsageTypeMaster;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface DDAdvertisementUsageTypeMasterService {

    List<DDAdvertisementUsageTypeMaster> findAllDDAuthUsageTypeMaster();

}
