package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.ModuleMasterDto;
import com.ahmednagar.municipal.auth.model.ModuleMaster;
import com.ahmednagar.municipal.auth.service.ModuleMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class ModuleMasterController {
    @Autowired
    private ModuleMasterService moduleMasterService;

    //create Module Master
    @PostMapping("/createModuleMaster")
    public ResponseEntity<ModuleMaster> createModuleMaster(@Valid @RequestBody ModuleMaster moduleMaster){
        ModuleMaster createdModuleMaster=moduleMasterService.saveModuleMaster(moduleMaster);
        if(createdModuleMaster==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdModuleMaster);
    }
    //for all admin users
    @GetMapping("/allModuleMaster")
    public ResponseEntity<List<ModuleMasterDto>> getAllModuleMaster(){
        List<ModuleMasterDto> moduleMaster=moduleMasterService.findAllModuleMaster();
        return ResponseEntity.ok(moduleMaster);
    }

    //get Module Master By MunicipalId
    @GetMapping("/MunicipalModuleMaster/{municipalId}")
    public ResponseEntity<?> getAllModuleMasterByMunicipalId(@PathVariable Long municipalId){
        List<ModuleMasterDto> moduleMaster=moduleMasterService.findAllModuleMasterByMunicipalId(municipalId);
        if (moduleMaster.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No moduleMaster with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(moduleMaster);
    }

    //     Update Module Master for admin
    @PutMapping("/updatedModuleMaster/{id}")
    public ResponseEntity<ModuleMaster> updateModuleMaster(@PathVariable("id") Long id, @RequestBody ModuleMaster updatedModuleMaster){
        try{
            ModuleMaster updated=moduleMasterService.updateModuleMaster(id,updatedModuleMaster);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete Module Master for admin
    @PatchMapping("/deleteModuleMaster/{id}")
    public ResponseEntity<ModuleMaster> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        ModuleMaster updatedModuleMaster = moduleMasterService.changeSuspendedStatus(id, status);         // updatedBy is always 1 for now as it is the admin
        if (updatedModuleMaster== null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedModuleMaster);
    }

}

