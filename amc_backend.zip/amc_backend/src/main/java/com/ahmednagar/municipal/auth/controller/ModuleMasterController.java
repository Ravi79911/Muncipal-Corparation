package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.ModuleMaster;
import com.ahmednagar.municipal.auth.service.ModuleMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class ModuleMasterController {

    @Autowired
    ModuleMasterService moduleMasterService;

    @PostMapping("/createModuleMaster")
    public ResponseEntity<ModuleMaster> createModuleMaster(@Valid @RequestBody ModuleMaster moduleMaster) {
        ModuleMaster createdModuleMaster = moduleMasterService.saveModuleMaster(moduleMaster);
        if (createdModuleMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdModuleMaster);
    }

    @GetMapping("/getAllModuleMaster")
    public ResponseEntity<List<ModuleMaster>> getAllModuleMaster() {
        List<ModuleMaster> moduleMaster = moduleMasterService.findAllModuleMaster();
        return ResponseEntity.ok(moduleMaster);
    }

    @GetMapping("/getModuleMasterByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllModuleMasterByMunicipalId(@PathVariable Long municipalId) {
        List<ModuleMaster> moduleMaster = moduleMasterService.findAllModuleMasterByMunicipalId(municipalId);
        if (moduleMaster.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No moduleMaster with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(moduleMaster);
    }

    @PutMapping("/moduleMaster/update/{id}")
    public ResponseEntity<ModuleMaster> updateModuleMaster(@PathVariable("id") Long id, @RequestBody ModuleMaster updatedModuleMaster) {
        try {
            ModuleMaster updated = moduleMasterService.updateModuleMaster(id, updatedModuleMaster);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/moduleMaster/suspendedStatus/{id}")
    public ResponseEntity<ModuleMaster> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        ModuleMaster updatedModuleMaster = moduleMasterService.changeSuspendedStatus(id, status);
        if (updatedModuleMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedModuleMaster);
    }

}

