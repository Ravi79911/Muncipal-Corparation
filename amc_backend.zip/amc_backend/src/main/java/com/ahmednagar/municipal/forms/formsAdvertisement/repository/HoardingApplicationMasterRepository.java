package com.ahmednagar.municipal.forms.formsAdvertisement.repository;

import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface HoardingApplicationMasterRepository extends JpaRepository<HoardingApplicationMaster, Long> {

    List<HoardingApplicationMaster> findAllByMunicipalId(int municipalId);

    Optional<HoardingApplicationMaster> findByApplicationNo(String applicationNo);

}
