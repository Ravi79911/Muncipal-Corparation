package com.ahmednagar.municipal.forms.formsAdvertisement.service;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingApplicationMasterDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingApplicationMasterService {

    HoardingApplicationMaster saveHoardingApplicationMaster(HoardingApplicationMaster hoardingApplicationMaster);

    List<HoardingApplicationMasterDto> findAllHoardingApplicationMaster();

    HoardingApplicationMaster findById(Long id);

    List<HoardingApplicationMaster> findAllByMunicipalId(int municipalId);

    HoardingApplicationMaster updateHoardingApplicationMaster(Long id, HoardingApplicationMaster updatedHoardingApplicationMaster);

    HoardingApplicationMaster changeStatus(Long id, Integer status, int updatedBy);

    HoardingApplicationMaster findByApplicationNo(String applicationNo);

    boolean isHordingApplicationNoExists(String applicationNo);

    void deleteHoardingApplicationMasterById(Long id);
}
