package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionDetail;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorCollectionDetailRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorCollectionDetailsService;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.util.VendorReceiptNumberGenerator;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.util.VendorTransactionNumberGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VendorCollectionDetailServiceImpl implements VendorCollectionDetailsService {

    @Autowired
    private VendorCollectionDetailRepository vendorCollectionDetailRepository;

    @Override
    public VendorCollectionDetail saveCollectionDetail(VendorCollectionDetail vendorCollectionDetail) {
        vendorCollectionDetail.setCreatedDate(LocalDateTime.now());
        vendorCollectionDetail.setSuspendedStatus(0);
        vendorCollectionDetail.setTransactionDate(LocalDateTime.now());
        vendorCollectionDetail.setTransactionNo(VendorTransactionNumberGenerator.generateTransactionNo());
        vendorCollectionDetail.setReciptNo(VendorReceiptNumberGenerator.generateReceiptNumber());
        return vendorCollectionDetailRepository.save(vendorCollectionDetail);
    }

    @Override
    public Optional<VendorCollectionDetail> findById(Long id) {
        return vendorCollectionDetailRepository.findById(id);
    }

    @Override
    public List<VendorCollectionDetail> getDetailsByVendorUserIdAndCreatedDate(Long vendorUserId, LocalDate createdDate) {
        LocalDateTime startOfDay = createdDate.atStartOfDay();
        LocalDateTime endOfDay = createdDate.atTime(23, 59, 59);
        return vendorCollectionDetailRepository.findByVendorUserId_IdAndCreatedDateBetween(vendorUserId, startOfDay, endOfDay);

    }

    @Override
    public List<VendorCollectionDetail> getAllVendorCollectionDetails() {
        return vendorCollectionDetailRepository.findAll();
    }


}
