package com.ahmednagar.municipal.auth.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserMasterDTO {

    private Long id;
    private String nameOfUser;
    private String fatherName;
    private String address;
    private String email;
    private String mobileNo;
    private LocalDate dateOfBirth;
    private String userName;
    private boolean isEmailVerified;
    private boolean isMobileVerified;
    private boolean isVerified;
    private List<UserMasterZoneWardAllocationDTO> userMasterZoneWardAllocationDTO;
    private String roleName;

}
