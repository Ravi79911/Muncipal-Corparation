package com.ahmednagar.municipal.forms.formsAdvertisement.service;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingAllottedDemandDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingAllottedDemand;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingAllottedDemandService {
    HoardingAllottedDemand saveHoardingAllottedDemand(HoardingAllottedDemand hoardingAllottedDemand);

    List<HoardingAllottedDemandDto> findAllHoardingAllottedDemand();

    HoardingAllottedDemand findById(Long id);

    List<HoardingAllottedDemand> findAllByMunicipalId(int municipalId);

    HoardingAllottedDemand updateHoardingAllottedDemand(Long id, HoardingAllottedDemand updatedHoardingAllottedDemand, int updatedBy);

    HoardingAllottedDemand changeStatus(Long id, Integer status, int updatedBy);
}
