package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationDocumentsDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationDocumentsDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
@Service
public interface ApplicationDocumentsDetailsService {
    ApplicationDocumentsDetails saveApplicationDocumentsDetails(ApplicationDocumentsDetails applicationDocumentsDetails);

//    List<ApplicationDocumentsDetailsDto> findAllApplicationDocumentsDetails();
//
//    List<ApplicationDocumentsDetails> findAllActiveApplicationDocumentsDetails(Integer status);

    ApplicationDocumentsDetails findApplicationDocumentsDetailsById(int id);

    List<ApplicationDocumentsDetails> findAllApplicationDocumentsDetailByMunicipalId(int municipalId);

    ApplicationDocumentsDetails updateApplicationDocumentsDetails(int id, ApplicationDocumentsDetails updatedApplicationDocumentsDetails, int updatedBy);

    ApplicationDocumentsDetails changeSuspendedStatus(int id, int status,int updatedBy);

    ApplicationDocumentsDetails uploadDocument(MultipartFile file, int createdBy, int suspendedStatus, int municipalId, Long applicationMasterId, int documentsMasterId) throws Exception;
}
