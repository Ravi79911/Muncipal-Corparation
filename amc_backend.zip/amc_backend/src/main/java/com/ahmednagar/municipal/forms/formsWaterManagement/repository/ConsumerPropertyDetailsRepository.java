package com.ahmednagar.municipal.forms.formsWaterManagement.repository;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerPropertyDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ConsumerPropertyDetailsRepository extends JpaRepository<ConsumerPropertyDetails, Integer> {

    List<ConsumerPropertyDetails> findByMunicipalId(int municipalId);
}
