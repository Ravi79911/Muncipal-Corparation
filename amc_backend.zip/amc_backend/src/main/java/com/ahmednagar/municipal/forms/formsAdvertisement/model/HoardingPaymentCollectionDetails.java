package com.ahmednagar.municipal.forms.formsAdvertisement.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb2_hoarding_payment_collection_details")
public class HoardingPaymentCollectionDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name = "payment_collection_master_id", nullable = false)
    @NotNull(message = "Payment collection master ID cannot be null")
    private Long paymentCollectionMasterId;

    @Column(name = "hoarding_application_detail_id", nullable = false)
    @NotNull(message = "Hoarding application detail ID cannot be null")
    private Long hoardingApplicationDetailId;

    @Column(name = "payment_amount_demand", nullable = false)
    @NotBlank(message = "Payment amount demand cannot be blank")
    @Size(max = 150, message = "Payment amount demand cannot exceed 150 characters")
    private String paymentAmountDemand;

    @Column(name = "payment_amount_paid", nullable = false)
    @NotBlank(message = "Payment amount paid cannot be blank")
    @Size(max = 150, message = "Payment amount paid cannot exceed 150 characters")
    private String paymentAmountPaid;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;
}
