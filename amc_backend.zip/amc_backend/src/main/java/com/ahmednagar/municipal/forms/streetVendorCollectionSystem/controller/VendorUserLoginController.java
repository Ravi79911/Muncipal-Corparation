package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;


import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserLoginMaster;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUser;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorUserLoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorUserLoginController {

    @Autowired
    private VendorUserLoginService vendorUserLoginService;

    @PostMapping("/userLogin")
    public ResponseEntity<?> login(@RequestParam String userName, @RequestParam String password) {
        try {
            VendorUserLoginMaster userLogin = vendorUserLoginService.login(userName, password);
            int loginflag = userLogin.getLoginFlag();
            Long vendorUserloginId = userLogin.getId();
            VendorUser vendorUserId = userLogin.getVendorUser();

            // Create a response map to include both loginFlag and vendorUserId
            Map<String, Object> response = new HashMap<>();
            response.put("loginFlag", loginflag);
            response.put("vendorUserId", vendorUserId);
            response.put("vendorUserLoginId", vendorUserloginId);

            return ResponseEntity.ok(response); // Return the map as JSON
        } catch (RuntimeException e) {
            return ResponseEntity.status(401).body(Map.of("error", e.getMessage())); // Return error as JSON
        }
    }


    @PostMapping("/createUser")
    public ResponseEntity<?> createUser(@RequestBody VendorUserLoginMaster user) {
        try {
            VendorUserLoginMaster userLogin = vendorUserLoginService.createUser(user);
            return ResponseEntity.ok(userLogin); // Return as JSON
        } catch (RuntimeException e) {
            return ResponseEntity.status(401).body(Map.of("error", e.getMessage())); // Return error as JSON
        }
    }

    @PostMapping("/updatePassword")
    public ResponseEntity<?> updatePassword(
            @RequestParam Long userId,
            @RequestBody Map<String, String> passwords) {
        try {
            String oldPassword = passwords.get("oldPassword");
            String newPassword = passwords.get("newPassword");

            // Call the service method to update the password
            vendorUserLoginService.updateUserPassword(userId, oldPassword, newPassword);

            return ResponseEntity.ok(Map.of("message", "Password updated successfully"));
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body(Map.of("error", e.getMessage()));
        }
    }

}
