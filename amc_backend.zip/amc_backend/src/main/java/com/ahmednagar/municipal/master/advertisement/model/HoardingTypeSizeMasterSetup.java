package com.ahmednagar.municipal.master.advertisement.model;

import com.ahmednagar.municipal.master.municipalLicence.model.TradeApplicationType;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_hoarding_type_size_master_setup")
public class HoardingTypeSizeMasterSetup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name = "hoarding_length_sqft", nullable = false)
    @NotNull(message = "Hoarding length in sqft cannot be null")
    @DecimalMin(value = "0.000", inclusive = false, message = "Hoarding length in sqft must be greater than 0")
    private BigDecimal hoardingLengthSqft;

    @Column(name = "hoarding_width_sqft", nullable = false)
    @NotNull(message = "Hoarding width in sqft cannot be null")
    @DecimalMin(value = "0.000", inclusive = false, message = "Hoarding width in sqft must be greater than 0")
    private BigDecimal hoardingWidthSqft;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "hoarding_type_master_id", nullable = false, referencedColumnName = "id")
    private HoardingTypeMasterSetup hoardingTypeMasterId;
}
