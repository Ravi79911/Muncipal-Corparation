package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.ViewConsumerPropertyDetails;
import com.ahmednagar.municipal.auth.model.ViewNewWaterConnectionFormMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface ViewConsumerPropertyDetailsRepository extends JpaRepository<ViewConsumerPropertyDetails,Long> {

    Optional<ViewConsumerPropertyDetails> findByViewNewWaterConnectionFormMaster(ViewNewWaterConnectionFormMaster viewNewWaterConnectionFormMaster);

}
