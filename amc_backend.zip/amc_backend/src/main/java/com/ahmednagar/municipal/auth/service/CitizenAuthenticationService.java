//package com.ahmednagar.municipal.auth.service;
//
//import org.springframework.stereotype.Service;
//
//@Service
//public interface CitizenAuthenticationService {
//
//    boolean citizenAuthenticate(String usernameOrMobile, String password);
//
//}
