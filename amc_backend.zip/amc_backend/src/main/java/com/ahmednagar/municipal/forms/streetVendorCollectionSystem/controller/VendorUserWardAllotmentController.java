package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserWardAllotment;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorUserWardAllotmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorUserWardAllotmentController {

    @Autowired
    private VendorUserWardAllotmentService vendorUserWardAllotmentService;

    @PostMapping("/saveUserWardAllotment")
    public ResponseEntity<VendorUserWardAllotment> createUserWardAllotment(@RequestBody VendorUserWardAllotment vendorUserWardAllotment) {
        return ResponseEntity.ok(vendorUserWardAllotmentService.saveUserWardAllotment(vendorUserWardAllotment));
    }

    @GetMapping("/getByIDUserWardAllotment")
    public ResponseEntity<Optional<VendorUserWardAllotment>> getUserWardAllotmentById(@RequestParam Long id) {
    try {
        Optional<VendorUserWardAllotment> userWardAllotment = vendorUserWardAllotmentService.getUserWardAllotment(id);
        return ResponseEntity.ok(userWardAllotment);
    } catch (Exception e) {
    }
        return ResponseEntity.notFound().build();
    }
}
