package com.ahmednagar.municipal.auth.dto;

import com.ahmednagar.municipal.auth.model.CitizenSignUpMaster;
import com.ahmednagar.municipal.auth.model.ViewMunicipalPropertyMaster;
import com.ahmednagar.municipal.auth.model.WorkFlowMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class WorkFlowLevelDto {

    private Long id;
    private String status;
    private Integer mailStatus;
    private String remarks;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;
    private ViewMunicipalPropertyMaster applicationId;
    private UserMasterDTO currentUserId;
    private UserMasterDTO nextUserId;
    private WorkFlowMaster workFlowMasterId;
    private CitizenSignUpMaster citizenId;

}
