package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MunicipalPropertyOwnerMasterDto {

    private int id;
    private int propertyMasId;
    private int ownershipTypeName;
    private String ownerName;
    private String ownerFatherHusbName;
    private String ownerRelation;
    private String ownerCurrentAddress;
    private String ownerMobileNo;
    private String ownerEmailId;
    private String ownerGender;
    private String ownerMartialStatus;
    private String ownerOccupation;
    private String ownerDob;
    private int aadharNo;
    private String panNumber;
    private Boolean isFromArmedForce;
    private String ownerPhotographUpload;
    private Boolean isSpeciallyAbled;
    private int municipalId;
    private int createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;

}
