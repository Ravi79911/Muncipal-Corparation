package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.AdvertisementWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.LicenseWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.ViewHoardingApplicationMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface AdvertisementWorkFlowLevelRepository extends JpaRepository<AdvertisementWorkFlowLevel,Long> {

    @Query(value = "SELECT TOP 1 * FROM tbl_advertisement_work_flow_level WHERE hoarding_application_master_id = :hoardingApplicationMasterId AND status_code = :statusCode ORDER BY created_date DESC", nativeQuery = true)
    Optional<AdvertisementWorkFlowLevel> findLatestWorkFlowByHoardingApplicationMasterIdAndStatusCode(@Param("hoardingApplicationMasterId") Long hoardingApplicationMasterId, @Param("statusCode") Long statusCode);


    Optional<AdvertisementWorkFlowLevel> findTopByHoardingApplicationMasterIdOrderByCreatedDateDesc(ViewHoardingApplicationMaster hoardingApplicationMasterId);

    List<AdvertisementWorkFlowLevel> findByHoardingApplicationMasterId_Id(Long applicationId);

}
