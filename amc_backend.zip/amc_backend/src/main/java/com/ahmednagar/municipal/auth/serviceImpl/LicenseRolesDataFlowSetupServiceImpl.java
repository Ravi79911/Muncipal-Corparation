package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.LicenseRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.LicenseRolesDataFlowSetup;
import com.ahmednagar.municipal.auth.repository.LicenseRolesDataFlowSetupRepository;
import com.ahmednagar.municipal.auth.service.LicenseRolesDataFlowSetupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LicenseRolesDataFlowSetupServiceImpl implements LicenseRolesDataFlowSetupService {

    @Autowired
    private LicenseRolesDataFlowSetupRepository licenseRolesDataFlowSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<LicenseRolesDataFlowSetupDto> findAllRolesDataFlowSetup() {
        List<LicenseRolesDataFlowSetup> roles = licenseRolesDataFlowSetupRepository.findAll();
        return roles.stream()
                .map(role -> modelMapper.map(role, LicenseRolesDataFlowSetupDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<LicenseRolesDataFlowSetup> getNextRoleListForListSelection(Long currentRoleId, Long statusCode, Integer isActive) {
        List<LicenseRolesDataFlowSetup> list = licenseRolesDataFlowSetupRepository
                .findAllByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId,statusCode, isActive);
        if (list.isEmpty()) {
            throw new RuntimeException("No next roles found for currentRoleId: " + currentRoleId + " and status code: " + 1007L+"(DocumentVerificationReject)");
        }
        return list;
    }

    @Override
    public LicenseRolesDataFlowSetup getNextRoleForSingleSelection(Long currentRoleId, Long statusCode, Integer isActive) {
        return licenseRolesDataFlowSetupRepository
                .findByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId, statusCode, isActive)
                .orElseThrow(() -> new RuntimeException(
                        "No next role found for currentRoleId: " + currentRoleId +
                                ", statusCode: " + statusCode + ", isActive: " + isActive));
    }

}
