package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "Tbl_Vendor_Master")
public class VendorMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "vendor_name_eng")
    private String vendorNameEng;

    @Column(name = "vendor_name_mrathi")
    private String vendorNameMrathi;

    @Column(name = "vendor_addrs")
    private String vendorAddrs;

    @Column(name = "mobile_no")
    private String mobileNo;

    @Column(name = "email_id")
    private String emailId;

    @Column(name = "shop_name")
    private String shopName;

    @Column(name = "street_name")
    private String streetName;

    @ManyToOne
    @JoinColumn(name = "market_name_id", referencedColumnName = "id")
    private VendorMarketMaster marketNameId;

    @ManyToOne
    @JoinColumn(name = "vendor_type_id", referencedColumnName = "id")
    private VendorType vendorTypeId;

    @ManyToOne
    @JoinColumn(name = "nature_bussines_id", referencedColumnName = "id")
    private VendorNatureOfBussines natureBussinesId;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;
}
