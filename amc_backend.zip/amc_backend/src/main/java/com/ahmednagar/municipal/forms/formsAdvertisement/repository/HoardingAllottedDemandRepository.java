package com.ahmednagar.municipal.forms.formsAdvertisement.repository;

import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingAllottedDemand;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@EnableJpaRepositories
public interface HoardingAllottedDemandRepository extends JpaRepository<HoardingAllottedDemand,Long> {

    List<HoardingAllottedDemand> findAllByMunicipalId(int municipalId);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM tb2_hoarding_alloated_demand WHERE hoarding_application_master_id = :hoardingApplicationMasterId", nativeQuery = true)
    void deleteHoardingAllottedDemandByHoardingApplicationMasterId(@Param("hoardingApplicationMasterId") Long hoardingApplicationMasterId);

}
