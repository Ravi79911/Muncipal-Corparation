package com.ahmednagar.municipal.forms.formsAdvertisement.repository;

import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingAllottedDemand;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface HoardingAllottedDemandRepository extends JpaRepository<HoardingAllottedDemand,Long> {
    List<HoardingAllottedDemand> findAllByMunicipalId(int municipalId);
}
