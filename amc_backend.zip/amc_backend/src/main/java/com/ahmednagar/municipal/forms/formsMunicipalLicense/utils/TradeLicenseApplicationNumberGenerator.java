package com.ahmednagar.municipal.forms.formsMunicipalLicense.utils;

import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicInteger;

public class TradeLicenseApplicationNumberGenerator {
    private static final String PREFIX = "APN";
    private static final AtomicInteger counter = new AtomicInteger();

    public static String generateApplicationNo(Long applicationTypeId) {
        // Application type ID as two digits
        String applicationTypePart = String.format("%02d", applicationTypeId);

        // Current year and month
        LocalDateTime now = LocalDateTime.now();
        String yearPart = String.format("%02d", now.getYear() % 100); // Last two digits of the year
        String monthPart = String.format("%02d", now.getMonthValue()); // Two-digit month

        // Serial number padded to six digits
        int serialNumber = counter.incrementAndGet();
        String serialNumberPart = String.format("%06d", serialNumber);

        // Concatenate parts to form the application number
        return PREFIX + applicationTypePart + yearPart + monthPart + serialNumberPart;
    }
}

