package com.ahmednagar.municipal.forms.formsMunicipalLicense.utils;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.LicenseApplicationCounterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class TradeLicenseApplicationNumberGenerator {

    @Autowired
    private LicenseApplicationCounterService licenseApplicationCounterService;

    private static final String PREFIX = "APN";
    //private static final AtomicInteger counter = new AtomicInteger();

    public String generateApplicationNo(Long applicationTypeId) {
        // Application type ID as two digits
        String applicationTypePart = String.format("%02d", applicationTypeId);

        // Current year and month
        LocalDateTime now = LocalDateTime.now();
        String yearPart = String.format("%02d", now.getYear() % 100); // Last two digits of the year
        String monthPart = String.format("%02d", now.getMonthValue()); // Two-digit month

        // Get unique application number and increment
        int uniqueNumber = licenseApplicationCounterService.getNextCounterValue("license_application_no") % 1000;
        String serialNumberPart = String.format("%06d", uniqueNumber);

        // Concatenate parts to form the application number
        return PREFIX + applicationTypePart + yearPart + monthPart + serialNumberPart;
    }
}

