package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.SubMenuMaster;
import com.ahmednagar.municipal.auth.repository.SubMenuMasterRepository;
import com.ahmednagar.municipal.auth.service.SubMenuMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class SubMenuMasterServiceImpl implements SubMenuMasterService {

    @Autowired
    SubMenuMasterRepository subMenuMasterRepository;

    @Override
    public SubMenuMaster saveSubMenu(SubMenuMaster subMenuMaster) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        subMenuMaster.setCreatedDate(currentDateTime);
        subMenuMaster.setUpdatedDate(LocalDateTime.now());
        subMenuMaster.setUpdatedBy(subMenuMaster.getUpdatedBy() != null ? subMenuMaster.getUpdatedBy() : 0);
        subMenuMaster.setSuspendedStatus(subMenuMaster.getSuspendedStatus() != null ? subMenuMaster.getSuspendedStatus() : 0);
        return subMenuMasterRepository.saveAndFlush(subMenuMaster);
    }

    @Override
    public List<SubMenuMaster> findAllSubMenu() {
        List<SubMenuMaster> subMenuMasters = subMenuMasterRepository.findAll();
        return subMenuMasterRepository.findAll();
    }

    @Override
    public List<SubMenuMaster> findAllSubMenuByMunicipalId(Long municipalId) {
        List<SubMenuMaster> subMenuMasters = subMenuMasterRepository.findByMunicipalId(municipalId);
        return subMenuMasterRepository.findByMunicipalId(municipalId);
    }

    @Override
    public SubMenuMaster updateSubMenu(Long id, SubMenuMaster updatedSubMenuMaster) {
        Optional<SubMenuMaster> subMenuOptional = subMenuMasterRepository.findById(id);
        if (subMenuOptional.isPresent()) {
            SubMenuMaster existingSubMenuMaster = subMenuOptional.get();
            existingSubMenuMaster.setSuspendedStatus(updatedSubMenuMaster.getSuspendedStatus());
            existingSubMenuMaster.setMunicipalId(updatedSubMenuMaster.getMunicipalId());

            return subMenuMasterRepository.saveAndFlush(existingSubMenuMaster);
        } else {
            throw new RuntimeException("subMenu not found with id: " + id);
        }
    }

    @Override
    public SubMenuMaster changeSuspendedStatus(Long id, int status) {
        Optional<SubMenuMaster> subMenuOptional = subMenuMasterRepository.findById(id);
        if (subMenuOptional.isPresent()) {
            SubMenuMaster subMenuMaster = subMenuOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            subMenuMaster.setUpdatedDate(currentDateTime);
            subMenuMaster.setSuspendedStatus(status);
            subMenuMaster.setUpdatedBy(subMenuMaster.getUpdatedBy());
            return subMenuMasterRepository.saveAndFlush(subMenuMaster);
        }
        return null;
    }

}

