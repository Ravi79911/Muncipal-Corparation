package com.ahmednagar.municipal.forms.formsWaterManagement.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

public class ApplicationNoGenerator {
    private static final String PREFIX = "WCON";
    private static final AtomicInteger counter = new AtomicInteger();

    public static String generateApplicationNo() {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MMyy");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HHmmss");
        LocalDateTime now = LocalDateTime.now();

        String datePart = now.format(dateFormatter);
        String timePart = now.format(timeFormatter);
        int uniqueNumber = counter.incrementAndGet();
        String uniqueNumberPart = String.format("%06d", uniqueNumber);

        return PREFIX + datePart + timePart + uniqueNumberPart;
    }
}
