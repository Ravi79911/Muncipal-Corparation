package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.RenewalSurrenderAmendmentAppliedDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationLicenseDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.RenewalSurrenderAmendmentAppliedDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationLicenseDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.RenewalSurrenderAmendmentAppliedDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.RenewalSurrenderAmendmentAppliedDetailsService;
import com.ahmednagar.municipal.master.municipalLicence.model.LicenseFinancialYearMaster;
import com.ahmednagar.municipal.master.municipalLicence.model.MlRateMaster;
import com.ahmednagar.municipal.master.municipalLicence.repository.LicenseFinancialYearMasterRepository;
import com.ahmednagar.municipal.master.municipalLicence.repository.MlRateMasterRepository;
import com.ahmednagar.municipal.master.propertyTax.model.FinancialYearMaster;
import com.ahmednagar.municipal.master.propertyTax.repository.FinancialYearMasterRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RenewalSurrenderAmendmentAppliedDetailsServiceImpl implements RenewalSurrenderAmendmentAppliedDetailsService {

    @Autowired
    private RenewalSurrenderAmendmentAppliedDetailsRepository renewalSurrenderAmendmentAppliedDetailsRepository;

    @Autowired
    private MlRateMasterRepository mlRateMasterRepository;

    @Autowired
    private LicenseFinancialYearMasterRepository licenseFinancialYearMasterRepository;

    @Autowired
    private ApplicationLicenseDetailsRepository applicationLicenseDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    private static final Logger logger = LogManager.getLogger(RenewalSurrenderAmendmentAppliedDetailsServiceImpl.class);

    @Override
    public RenewalSurrenderAmendmentAppliedDetails saveAmendmentAppliedDetails(RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails, int createdBy) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        renewalSurrenderAmendmentAppliedDetails.setCreatedDate(currentDateTime);
        renewalSurrenderAmendmentAppliedDetails.setSuspendedStatus(renewalSurrenderAmendmentAppliedDetails.getSuspendedStatus() != null ? renewalSurrenderAmendmentAppliedDetails.getSuspendedStatus() : 0);      // 0 means active
        renewalSurrenderAmendmentAppliedDetails.setCreatedBy(createdBy);
        // 1 means admin
        MlRateMaster mlRateMaster = mlRateMasterRepository.findById(renewalSurrenderAmendmentAppliedDetails.getMlRateMasterId().getId())
                .orElseThrow(() -> new RuntimeException("MlRateMaster not found"));
        // Compare applicationTypeId
        if (!mlRateMaster.getApplicationTypeId().getId().equals(renewalSurrenderAmendmentAppliedDetails.getApplicationTypeId().getId())) {
            throw new IllegalArgumentException("Mismatch between applicationTypeId in MlRateMaster and the passed parameter");
        }

        renewalSurrenderAmendmentAppliedDetails.setApplicationFee(mlRateMaster.getApplicationFee()); // Assuming `MlRateMaster` has `applicationFee`.
        renewalSurrenderAmendmentAppliedDetails.setCreatedDate(LocalDateTime.now());

        return renewalSurrenderAmendmentAppliedDetailsRepository.save(renewalSurrenderAmendmentAppliedDetails);
    }

    @Override
    public RenewalSurrenderAmendmentAppliedDetails saveSurrenderAppliedDetails(RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails, int i) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        renewalSurrenderAmendmentAppliedDetails.setCreatedDate(currentDateTime);
        renewalSurrenderAmendmentAppliedDetails.setSuspendedStatus(renewalSurrenderAmendmentAppliedDetails.getSuspendedStatus() != null ? renewalSurrenderAmendmentAppliedDetails.getSuspendedStatus() : 0);      // 0 means active
        //renewalSurrenderAmendmentAppliedDetails.setCreatedBy(createdBy);
        // 1 means admin
        MlRateMaster mlRateMaster = mlRateMasterRepository.findById(renewalSurrenderAmendmentAppliedDetails.getMlRateMasterId().getId())
                .orElseThrow(() -> new RuntimeException("MlRateMaster not found"));
        // Compare applicationTypeId
        if (!mlRateMaster.getApplicationTypeId().getId().equals(renewalSurrenderAmendmentAppliedDetails.getApplicationTypeId().getId())) {
            throw new IllegalArgumentException("Mismatch between applicationTypeId in MlRateMaster and the passed parameter");
        }

        // Set application fee from MlRateMaster
        BigDecimal applicationFee = mlRateMaster.getApplicationFee();
        renewalSurrenderAmendmentAppliedDetails.setApplicationFee(applicationFee);

        // Set penalty and denial amount to zero
        BigDecimal penalty = BigDecimal.ZERO;
        BigDecimal denialAmount = BigDecimal.ZERO;

        renewalSurrenderAmendmentAppliedDetails.setPenalty(penalty);
        renewalSurrenderAmendmentAppliedDetails.setDenialArrearAmount(denialAmount);

        // Calculate total amount
        BigDecimal totalAmount = applicationFee.add(penalty).add(denialAmount);
        renewalSurrenderAmendmentAppliedDetails.setTotalAmount(totalAmount);

        // Set created date
        renewalSurrenderAmendmentAppliedDetails.setCreatedDate(LocalDateTime.now());

        // Save and return

        return renewalSurrenderAmendmentAppliedDetailsRepository.save(renewalSurrenderAmendmentAppliedDetails);
    }

    @Override
    public RenewalSurrenderAmendmentAppliedDetails calculateRenewalApplicationFee(RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails) {
        // Fetch the MlRateMaster based on ml_rate_master_id
        MlRateMaster mlRateMaster = mlRateMasterRepository.findById(renewalSurrenderAmendmentAppliedDetails.getMlRateMasterId().getId())
                .orElseThrow(() -> new IllegalArgumentException("MlRateMaster not found"));

        // Compare applicationTypeId
        if (!mlRateMaster.getApplicationTypeId().getId().equals(renewalSurrenderAmendmentAppliedDetails.getApplicationTypeId().getId())) {
            throw new IllegalArgumentException("Mismatch between applicationTypeId in MlRateMaster and the passed parameter");
        }

        // Call getLatestDetailsByLicenseNo method with prevLicenseNo
        RenewalSurrenderAmendmentAppliedDetails previousLicenceDetails = getLatestDetailsByLicenseNo(renewalSurrenderAmendmentAppliedDetails.getPrevLicenseNo());

        if (previousLicenceDetails != null) {
            // Calculate number of missing years by subtracting the financial years
            LicenseFinancialYearMaster current_finYear = licenseFinancialYearMasterRepository.findById(renewalSurrenderAmendmentAppliedDetails.getFyYearId().getId());

            String currentFinYear = current_finYear.getFyYear();
            String previousFinYear = previousLicenceDetails.getFyYearId().getFyYear();

            int missing_year = getMissingYears(currentFinYear, previousFinYear);

            logger.info(currentFinYear+previousFinYear+missing_year);

            // Check if missing year is 0
            if (missing_year == 0) {
                throw new IllegalArgumentException("You already have an active license with license number: " + renewalSurrenderAmendmentAppliedDetails.getPrevLicenseNo());
            }

            // Set application fee from MlRateMaster
            BigDecimal applicationFee = mlRateMaster.getApplicationFee(); // Assuming applicationFee is a field in MlRateMaster
            renewalSurrenderAmendmentAppliedDetails.setApplicationFee(applicationFee);

            // Handle missing year = 1
            if (missing_year == 1) {
                renewalSurrenderAmendmentAppliedDetails.setDenialArrearAmount(BigDecimal.ZERO);
                renewalSurrenderAmendmentAppliedDetails.setPenalty(BigDecimal.ZERO);
                renewalSurrenderAmendmentAppliedDetails.setTotalAmount(applicationFee);
            } else if (missing_year > 1) {
                // Calculate penalty and denial arrear amount for missing years > 1
                BigDecimal denialAmount = applicationFee.multiply(BigDecimal.valueOf(missing_year)); // Denial arrear amount

                BigDecimal lateFeePercentage = mlRateMaster.getLateFee().divide(BigDecimal.valueOf(100));
                BigDecimal penalty = denialAmount.multiply(lateFeePercentage); // 20% of the penalty

                renewalSurrenderAmendmentAppliedDetails.setDenialArrearAmount(denialAmount);
                renewalSurrenderAmendmentAppliedDetails.setPenalty(penalty);

                // Calculate total amount (application fee + penalty + denial arrear amount)
                BigDecimal totalAmount = applicationFee.add(penalty).add(denialAmount);
                renewalSurrenderAmendmentAppliedDetails.setTotalAmount(totalAmount);
            }

        } else if (applicationLicenseDetailsRepository.findByLicenseNo(renewalSurrenderAmendmentAppliedDetails.getPrevLicenseNo()).isPresent()) {
            // Try searching in ApplicationLicenseDetails table/repository
            ApplicationLicenseDetails currentLicenseDetails = applicationLicenseDetailsRepository
                    .findByLicenseNo(renewalSurrenderAmendmentAppliedDetails.getPrevLicenseNo())
                    .orElseThrow(() -> new IllegalArgumentException("Previous license details not found in ApplicationLicenseDetails repository either."));

            // Calculate number of missing years by subtracting the financial years
            LicenseFinancialYearMaster current_finYear = licenseFinancialYearMasterRepository.findById(renewalSurrenderAmendmentAppliedDetails.getFyYearId().getId());

            String currentFinYear = current_finYear.getFyYear();
            String previousFinYear = String.valueOf(currentLicenseDetails.getExpiryDate());

            int missing_year = getMissingYears(currentFinYear, previousFinYear);
            logger.info(currentFinYear+previousFinYear+missing_year);

            // Check if missing year is 0
            if (missing_year == 0) {
                throw new IllegalArgumentException("You already have an active license with license number: " + renewalSurrenderAmendmentAppliedDetails.getPrevLicenseNo());
            }

            // Set application fee from MlRateMaster
            BigDecimal applicationFee = mlRateMaster.getApplicationFee(); // Assuming applicationFee is a field in MlRateMaster
            renewalSurrenderAmendmentAppliedDetails.setApplicationFee(applicationFee);

            // Handle missing year = 1
            if (missing_year == 1) {
                renewalSurrenderAmendmentAppliedDetails.setDenialArrearAmount(BigDecimal.ZERO);
                renewalSurrenderAmendmentAppliedDetails.setPenalty(BigDecimal.ZERO);
                renewalSurrenderAmendmentAppliedDetails.setTotalAmount(applicationFee);
            } else if (missing_year > 1) {
                // Calculate penalty and denial arrear amount for missing years > 1
                BigDecimal denialAmount = applicationFee.multiply(BigDecimal.valueOf(missing_year)); // Denial arrear amount

                BigDecimal lateFeePercentage = mlRateMaster.getLateFee().divide(BigDecimal.valueOf(100));
                BigDecimal penalty = denialAmount.multiply(lateFeePercentage); // 20% of the penalty

                renewalSurrenderAmendmentAppliedDetails.setDenialArrearAmount(denialAmount);
                renewalSurrenderAmendmentAppliedDetails.setPenalty(penalty);

                // Calculate total amount (application fee + penalty + denial arrear amount)
                BigDecimal totalAmount = applicationFee.add(penalty).add(denialAmount);
                renewalSurrenderAmendmentAppliedDetails.setTotalAmount(totalAmount);
            }
        }else {
            throw new IllegalArgumentException("Previous license details not found for license number: " + renewalSurrenderAmendmentAppliedDetails.getPrevLicenseNo());
        }
        // Save the updated application
        return renewalSurrenderAmendmentAppliedDetails;

    }

    @Override
    public RenewalSurrenderAmendmentAppliedDetails savedRenewalApplication(RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails) {
        return renewalSurrenderAmendmentAppliedDetailsRepository.save(renewalSurrenderAmendmentAppliedDetails);
    }


    @Override
    public RenewalSurrenderAmendmentAppliedDetails findRenewalSurrenderAmendmentAppliedDetailsById(int id) {
        Optional<RenewalSurrenderAmendmentAppliedDetails> renewalSurrenderAmendmentAppliedDetails = renewalSurrenderAmendmentAppliedDetailsRepository.findById(id);
        return renewalSurrenderAmendmentAppliedDetails.orElse(null);

    }

    @Override
    public List<RenewalSurrenderAmendmentAppliedDetailsDto> findAllRenewalSurrenderAmendmentAppliedDetailsByMunicipalId(int municipalId) {
        List<RenewalSurrenderAmendmentAppliedDetails> renewalSurrenderAmendmentAppliedDetails = renewalSurrenderAmendmentAppliedDetailsRepository.findByMunicipalId(municipalId);
        return renewalSurrenderAmendmentAppliedDetails.stream()
                .map(renewalSurrenderAmendmentAppliedDetail -> modelMapper.map(renewalSurrenderAmendmentAppliedDetail, RenewalSurrenderAmendmentAppliedDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public RenewalSurrenderAmendmentAppliedDetails updateRenewalSurrenderAmendmentAppliedDetails(int id, RenewalSurrenderAmendmentAppliedDetails updatedRenewalSurrenderAmendmentAppliedDetails, int updatedBy) {
        Optional<RenewalSurrenderAmendmentAppliedDetails> renewalSurrenderAmendmentAppliedDetailsOptional = renewalSurrenderAmendmentAppliedDetailsRepository.findById(id);
        if (renewalSurrenderAmendmentAppliedDetailsOptional.isPresent()) {
            RenewalSurrenderAmendmentAppliedDetails existingRenewalSurrenderAmendmentAppliedDetails = renewalSurrenderAmendmentAppliedDetailsOptional.get();
            existingRenewalSurrenderAmendmentAppliedDetails.setSuspendedStatus(updatedRenewalSurrenderAmendmentAppliedDetails.getSuspendedStatus());
            existingRenewalSurrenderAmendmentAppliedDetails.setMunicipalId(updatedRenewalSurrenderAmendmentAppliedDetails.getMunicipalId());

            return renewalSurrenderAmendmentAppliedDetailsRepository.saveAndFlush(existingRenewalSurrenderAmendmentAppliedDetails);
        } else {
            throw new RuntimeException("app RenewalSurrenderAmendmentAppliedDetails not found with id: " + id);
        }
    }

    @Override
    public RenewalSurrenderAmendmentAppliedDetails changeSuspendedStatus(int id, int status, int updatedBy) {
        Optional<RenewalSurrenderAmendmentAppliedDetails> renewalSurrenderAmendmentAppliedDetailsOptional = renewalSurrenderAmendmentAppliedDetailsRepository.findById(id);
        if (renewalSurrenderAmendmentAppliedDetailsOptional.isPresent()) {
            RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails = renewalSurrenderAmendmentAppliedDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            renewalSurrenderAmendmentAppliedDetails.setSuspendedStatus(status);      // 1 means suspended
            return renewalSurrenderAmendmentAppliedDetailsRepository.saveAndFlush(renewalSurrenderAmendmentAppliedDetails);
        }
        return null;
    }

    public RenewalSurrenderAmendmentAppliedDetails getLatestDetailsByLicenseNo(String preLicenseNo) {
        // Fetch the single latest record
        return renewalSurrenderAmendmentAppliedDetailsRepository.findTopByLicenseNoOrderByCreatedDateDesc(preLicenseNo);
    }

    // Function to calculate missing years between two given year ranges
    public int getMissingYears(String year1, String year2) {

        // Extract the starting year from both strings
        int startYear1 = Integer.parseInt(year1.split("-")[0]);
        int startYear2 = Integer.parseInt(year2.split("-")[0]);

        // Return the absolute difference between the starting years
        return Math.abs(startYear1 - startYear2);
    }
}

