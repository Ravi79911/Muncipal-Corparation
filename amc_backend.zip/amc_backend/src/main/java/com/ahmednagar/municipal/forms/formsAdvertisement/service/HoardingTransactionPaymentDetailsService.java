package com.ahmednagar.municipal.forms.formsAdvertisement.service;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingTransactionPaymentDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingTransactionPaymentDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingTransactionPaymentDetailsService {
    HoardingTransactionPaymentDetails saveHoardingTransactionPaymentDetails(HoardingTransactionPaymentDetails hoardingTransactionPaymentDetails);

    List<HoardingTransactionPaymentDetailsDto> findAllHoardingTransactionPaymentDetails();

    HoardingTransactionPaymentDetails findById(Long id);

    List<HoardingTransactionPaymentDetails> findAllByMunicipalId(int municipalId);

    HoardingTransactionPaymentDetails updateHoardingTransactionPaymentDetails(Long id, HoardingTransactionPaymentDetails updatedHoardingTransactionPaymentDetails, int updatedBy);

    HoardingTransactionPaymentDetails changeStatus(Long id, Integer status, int updatedBy);
}
