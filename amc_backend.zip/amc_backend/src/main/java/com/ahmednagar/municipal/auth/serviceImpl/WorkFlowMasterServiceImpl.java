package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.WorkFlowMaster;
import com.ahmednagar.municipal.auth.repository.WorkFlowMasterRepository;
import com.ahmednagar.municipal.auth.service.WorkFlowMasterService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class WorkFlowMasterServiceImpl implements WorkFlowMasterService {

    @Autowired
    private WorkFlowMasterRepository workFlowMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public WorkFlowMaster saveWorkFlowMaster(WorkFlowMaster workFlowMaster) {
        workFlowMaster.setCreatedDate(LocalDateTime.now());
        workFlowMaster.setUpdatedDate(LocalDateTime.now());
        workFlowMaster.setUpdatedBy(workFlowMaster.getUpdatedBy() != null ? workFlowMaster.getUpdatedBy() : 0);
        workFlowMaster.setSuspendedStatus(workFlowMaster.getSuspendedStatus() != null ? workFlowMaster.getSuspendedStatus() : 0);

        return workFlowMasterRepository.save(workFlowMaster);
    }

    @Override
    public WorkFlowMaster findById(Long id) {
        Optional<WorkFlowMaster> workFlowMaster = workFlowMasterRepository.findById(id);
        return workFlowMaster.orElse(null);
    }
}