package com.ahmednagar.municipal.master.municipalLicence.controller;

import com.ahmednagar.municipal.master.municipalLicence.model.DDTradeLicenseCalculationMethodMaster;
import com.ahmednagar.municipal.master.municipalLicence.service.DDTradeLicenseCalculationMethodMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/dd")
public class DDTradeLicenseCalculationMethodMasterController {
    @Autowired
    private DDTradeLicenseCalculationMethodMasterService ddTradeLicenseCalculationMethodMasterService;

    @GetMapping("/getAllDDTradeLicenseCalculationMethodMaster")
    public ResponseEntity<List<DDTradeLicenseCalculationMethodMaster>> getAllDDTradeLicenseCalculationMethodMaster() {
        return ResponseEntity.ok(ddTradeLicenseCalculationMethodMasterService.getAllDDTradeLicenseCalculationMethodMaster());
    }

}
