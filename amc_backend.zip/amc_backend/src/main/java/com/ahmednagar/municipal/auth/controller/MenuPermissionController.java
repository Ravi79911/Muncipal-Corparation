package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.MenuPermissionDto;
import com.ahmednagar.municipal.auth.model.MenuPermission;
import com.ahmednagar.municipal.auth.service.MenuPermissionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class MenuPermissionController {
    @Autowired
    private MenuPermissionService menuPermissionService;

    //create menu
    @PostMapping("/createMenuPermission")
    public ResponseEntity<MenuPermission> createMenuPermission(@Valid @RequestBody MenuPermission menuPermission){
        MenuPermission createdMenuPermission=menuPermissionService.saveMenuPermission(menuPermission);
        if(createdMenuPermission==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdMenuPermission);
    }
    // find all menu permission
    public ResponseEntity<List<MenuPermissionDto>> getAllMenuPermission(){
        List<MenuPermissionDto> menuPermission=menuPermissionService.findAllMenuPermission();
        return ResponseEntity.ok(menuPermission);
    }
    //get menu By MunicipalId
    @GetMapping("/MunicipalMenuPermission/{municipalId}")
    public ResponseEntity<?> getAllMenuPermissionByMunicipalId(@PathVariable Long municipalId){
        List<MenuPermissionDto> menuPermission=menuPermissionService.findAllMenuPermissionByMunicipalId(municipalId);
        if (menuPermission.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No MenuPermission found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(menuPermission);
    }
    //     Update menu for admin
    @PutMapping("/updatedMenuPermission/{id}")
    public ResponseEntity<MenuPermission> updateMenuPermission(@PathVariable("id") Long id, @RequestBody MenuPermission updatedMenuPermission){
        try{
            MenuPermission updated=menuPermissionService.updateMenuPermission(id,updatedMenuPermission);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete fileUrl for admin
    @PatchMapping("/deleteMenuPermission/{id}")
    public ResponseEntity<MenuPermission> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        MenuPermission updatedMenuPermission = menuPermissionService.changeSuspendedStatus(id, status);         // updatedBy is always 1 for now as it is the admin
        if (updatedMenuPermission== null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedMenuPermission);
    }

}

