package com.ahmednagar.municipal.master.advertisement.service;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingTypeRateMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeRateMasterSetup;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingTypeRateMasterSetupService {
    HoardingTypeRateMasterSetup saveHoardingTypeRateMasterSetup(HoardingTypeRateMasterSetup hoardingTypeRateMasterSetup);

    List<HoardingTypeRateMasterSetupDto> findAllHoardingTypeRateMasterSetup();

    HoardingTypeRateMasterSetup findById(Long id);

    List<HoardingTypeRateMasterSetup> findAllByMunicipalId(int municipalId);

    HoardingTypeRateMasterSetup updateHoardingTypeRateMasterSetup(Long id, HoardingTypeRateMasterSetup updatedHoardingTypeRateMasterSetup,int updatedBy);

    HoardingTypeRateMasterSetup changeStatus(Long id, Integer status,int updatedBy);

}
