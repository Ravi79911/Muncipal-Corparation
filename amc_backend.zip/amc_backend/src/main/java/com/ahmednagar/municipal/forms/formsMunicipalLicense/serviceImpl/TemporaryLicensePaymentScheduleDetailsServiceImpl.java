package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.TemporaryLicensePaymentScheduleDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.TemporaryLicensePaymentScheduleDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.TemporaryLicensePaymentScheduleDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.TemporaryLicensePaymentScheduleDetailsService;
import com.ahmednagar.municipal.master.municipalLicence.model.MlRateMaster;
import com.ahmednagar.municipal.master.municipalLicence.repository.MlRateMasterRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TemporaryLicensePaymentScheduleDetailsServiceImpl implements TemporaryLicensePaymentScheduleDetailsService {
    @Autowired
    private TemporaryLicensePaymentScheduleDetailsRepository temporaryLicensePaymentScheduleDetailsRepository;

    @Autowired
    private MlRateMasterRepository mlRateMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public TemporaryLicensePaymentScheduleDetails createTemporaryLicensePaymentScheduleDetails(TemporaryLicensePaymentScheduleDetails temporaryLicensePaymentScheduleDetails) {
        MlRateMaster mlRateMaster = mlRateMasterRepository.findById(temporaryLicensePaymentScheduleDetails.getMlRateMasterId().getId())
                .orElseThrow(() -> new RuntimeException("MlRateMaster not found"));

        BigDecimal amountPerDay = mlRateMaster.getApplicationFee(); // Assuming `MlRateMaster` has this field.
        temporaryLicensePaymentScheduleDetails.setAmountPerDay(amountPerDay);

        long noOfDays = ChronoUnit.DAYS.between(temporaryLicensePaymentScheduleDetails.getStartDate(), temporaryLicensePaymentScheduleDetails.getEndDate());
        temporaryLicensePaymentScheduleDetails.setNoOfDays((int) noOfDays);

        BigDecimal totalAmountDue = amountPerDay.multiply(BigDecimal.valueOf(noOfDays));
        temporaryLicensePaymentScheduleDetails.setTotalAmountDue(totalAmountDue);

        return temporaryLicensePaymentScheduleDetailsRepository.save(temporaryLicensePaymentScheduleDetails);
    }

    @Override
    public BigDecimal calculateTotalAmount(TemporaryLicensePaymentScheduleDetails temporaryLicensePaymentScheduleDetails) {
        // Calculate the total amount due based on the number of days and amount per day

        return temporaryLicensePaymentScheduleDetails.getAmountPerDay().multiply(new BigDecimal(temporaryLicensePaymentScheduleDetails.getNoOfDays()));
    }

    @Override
    public TemporaryLicensePaymentScheduleDetails findById(Long id) {
        return temporaryLicensePaymentScheduleDetailsRepository.findById(id).orElseThrow(() -> new RuntimeException("Schedule not found"));
    }

    @Override
    public TemporaryLicensePaymentScheduleDetails findTemporaryLicensePaymentScheduleDetailsById(Long id) {
        Optional<TemporaryLicensePaymentScheduleDetails> temporaryLicensePaymentScheduleDetails=temporaryLicensePaymentScheduleDetailsRepository.findById(id);
        return temporaryLicensePaymentScheduleDetails.orElse(null);

    }

    @Override
    public BigDecimal calculateTax(TemporaryLicensePaymentScheduleDetails temporaryLicensePaymentScheduleDetails, BigDecimal taxRate) {
        // Calculate the tax based on the total amount due and tax rate
        BigDecimal totalAmountDue = temporaryLicensePaymentScheduleDetails.getTotalAmountDue();
        return totalAmountDue.multiply(taxRate).divide(new BigDecimal(100));
    }

    @Override
    public List<TemporaryLicensePaymentScheduleDetailsDto> findAllTemporaryLicensePaymentScheduleDetails() {
        List<TemporaryLicensePaymentScheduleDetails> temporaryLicensePaymentScheduleDetails = temporaryLicensePaymentScheduleDetailsRepository.findAll();
        return temporaryLicensePaymentScheduleDetails.stream()
                .map(temporaryLicensePaymentScheduleDetails1 -> modelMapper.map(temporaryLicensePaymentScheduleDetails1, TemporaryLicensePaymentScheduleDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<TemporaryLicensePaymentScheduleDetails> findAllByMunicipalId(int municipalId) {
        return temporaryLicensePaymentScheduleDetailsRepository.findAllByMunicipalId(municipalId);
    }
}
