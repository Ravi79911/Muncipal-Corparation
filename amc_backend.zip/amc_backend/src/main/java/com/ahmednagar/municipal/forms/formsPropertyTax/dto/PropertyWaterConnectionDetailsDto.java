package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PropertyWaterConnectionDetailsDto {

    private Long id;
    private int propertyMasId;
    private String waterConnectionType;
    private String nameOfConnectionHolder;
    private String waterConsumerNumber;
    private LocalDate waterConnectionDate;
    private int municipalId;
    private int createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;

}
