package com.ahmednagar.municipal.forms.formsPropertyTax.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

public class ApplicationNumberGenerator {

    /*
     01 - New Assessment
     02 - Re-Assessment
     03 - Mutation
     04 - Bifurcation
     05 - Amalgamation
    */

    private static final String PREFIX = "SAF"; // prefix for application number
    private static final String VACANT_LAND_PREFIX = "ZO"; // prefix for holding number for vacant land

    // separate atomic integer counters for each method
    private static final AtomicInteger applicationNumberCounter = new AtomicInteger();
    private static final AtomicInteger holdingNumberCounter = new AtomicInteger();
    private static final AtomicInteger vacantLandHoldingNumberCounter = new AtomicInteger();

    // this method ensures the unique number increments for application number's, increments for each call, independent of other methods
    private static int getNextApplicationNumber() {
        return applicationNumberCounter.incrementAndGet();
    }

    // this method ensures the unique number increments for holding number's, increments for each call, independent of other methods
    private static int getNextHoldingNumber() {
        return holdingNumberCounter.incrementAndGet();
    }

    // this method ensures the unique number increments for holding number's for vacant land, increments for each call, independent of other methods
    private static int getNextVacantLandHoldingNumber() {
        return vacantLandHoldingNumberCounter.incrementAndGet();
    }

    // application number generation for new/re-assessment/mutation/bifurcation/amalgamation
    public static String generateApplicationNo(String assessmentType, String zoneWard) {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("ddMMyy");
        String datePart = LocalDateTime.now().format(dateFormatter);

        // get unique application number and increment (independent counter)
        int uniqueNumber = getNextApplicationNumber() % 1000;
        String uniqueNumberPart = String.format("%04d", uniqueNumber);

        return PREFIX + assessmentType + zoneWard + datePart + uniqueNumberPart;
    }

    // holding number generation for new assessment
    public static String generateHoldingNo(String zoneWard) {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("ddMMyy");
        String datePart = LocalDateTime.now().format(dateFormatter);

        // get unique holding number and increment (independent counter)
        int uniqueNumber = getNextHoldingNumber() % 1000;
        String uniqueNumberPart = String.format("%04d", uniqueNumber);

        return zoneWard + datePart + uniqueNumberPart;
    }

    // holding number generation for vacant land
    public static String generateHoldingNoForVacantLand(String zoneWard) {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("ddMMyy");
        String datePart = LocalDateTime.now().format(dateFormatter);

        // get unique holding number for vacant land and increment (independent counter)
        int uniqueNumber = getNextVacantLandHoldingNumber() % 1000;
        String uniqueNumberPart = String.format("%04d", uniqueNumber);

        return zoneWard + datePart + uniqueNumberPart + VACANT_LAND_PREFIX;
    }
}
