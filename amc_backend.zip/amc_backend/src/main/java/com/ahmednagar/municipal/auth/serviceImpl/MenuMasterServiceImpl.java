package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.MenuMaster;
import com.ahmednagar.municipal.auth.repository.MenuMasterRepository;
import com.ahmednagar.municipal.auth.service.MenuMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class MenuMasterServiceImpl implements MenuMasterService {

    @Autowired
    MenuMasterRepository menuMasterRepository;

    @Override
    public MenuMaster saveMenu(MenuMaster menuMaster) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        menuMaster.setCreatedDate(currentDateTime);
        menuMaster.setUpdatedDate(LocalDateTime.now());
        menuMaster.setUpdatedBy(menuMaster.getUpdatedBy() != null ? menuMaster.getUpdatedBy() : 0);
        menuMaster.setSuspendedStatus(menuMaster.getSuspendedStatus() != null ? menuMaster.getSuspendedStatus() : 0);
        return menuMasterRepository.saveAndFlush(menuMaster);
    }

    @Override
    public List<MenuMaster> findAllMenu() {
        List<MenuMaster> menuMasters = menuMasterRepository.findAll();
        return menuMasterRepository.findAll();
    }

    @Override
    public List<MenuMaster> findAllMenuByMunicipalId(Long municipalId) {
        List<MenuMaster> menuMasters = menuMasterRepository.findByMunicipalId(municipalId);
        return menuMasterRepository.findByMunicipalId(municipalId);
    }

    @Override
    public MenuMaster updateMenu(Long id, MenuMaster updatedMenuMaster) {
        Optional<MenuMaster> menuOptional = menuMasterRepository.findById(id);
        if (menuOptional.isPresent()) {
            MenuMaster existingMenuMaster = menuOptional.get();
            existingMenuMaster.setSuspendedStatus(updatedMenuMaster.getSuspendedStatus());
            existingMenuMaster.setMunicipalId(updatedMenuMaster.getMunicipalId());

            return menuMasterRepository.saveAndFlush(existingMenuMaster);
        } else {
            throw new RuntimeException("menu not found with id: " + id);
        }
    }

    @Override
    public MenuMaster changeSuspendedStatus(Long id, int status) {
        Optional<MenuMaster> menuOptional = menuMasterRepository.findById(id);
        if (menuOptional.isPresent()) {
            MenuMaster menuMaster = menuOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            menuMaster.setUpdatedDate(currentDateTime);
            menuMaster.setSuspendedStatus(status);
            menuMaster.setUpdatedBy(menuMaster.getUpdatedBy());
            return menuMasterRepository.saveAndFlush(menuMaster);
        }
        return null;
    }

}
