package com.ahmednagar.municipal.master.advertisement.controller;

import com.ahmednagar.municipal.master.advertisement.model.DDAdvertisementUsageTypeMaster;
import com.ahmednagar.municipal.master.advertisement.service.DDAdvertisementUsageTypeMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/dd/auth/usage/type/master")
public class DDAdvertisementUsageTypeMasterController {

    @Autowired
    private DDAdvertisementUsageTypeMasterService ddAuthUsageTypeMasterService;

    @GetMapping("/getAll")
    public ResponseEntity<List<DDAdvertisementUsageTypeMaster>> getAllDDAuthUsageTypeMaster() {
        return ResponseEntity.ok(ddAuthUsageTypeMasterService.findAllDDAuthUsageTypeMaster());
    }

}
