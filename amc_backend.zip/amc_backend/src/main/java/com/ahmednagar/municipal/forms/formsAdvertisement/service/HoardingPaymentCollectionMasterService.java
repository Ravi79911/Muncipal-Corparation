package com.ahmednagar.municipal.forms.formsAdvertisement.service;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingPaymentCollectionMasterDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingPaymentCollectionMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingPaymentCollectionMasterService {
    HoardingPaymentCollectionMaster saveHoardingPaymentCollectionMaster(HoardingPaymentCollectionMaster hoardingPaymentCollectionMaster);

    List<HoardingPaymentCollectionMasterDto> findAllHoardingPaymentCollectionMaster();

    HoardingPaymentCollectionMaster findById(Long id);

    List<HoardingPaymentCollectionMaster> findAllByMunicipalId(int municipalId);

    HoardingPaymentCollectionMaster updateHoardingPaymentCollectionMaster(Long id, HoardingPaymentCollectionMaster updatedHoardingPaymentCollectionMaster, int updatedBy);

    HoardingPaymentCollectionMaster changeStatus(Long id, Integer status, int updatedBy);
}
