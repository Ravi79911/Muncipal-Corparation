package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_citizen_password_change_history")
public class CitizenPasswordChangeHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "citizen id is required")
    @Column(name = "citizen_id", nullable = false)
    private Long citizenId;

    @NotBlank(message = "last password is required")
    @Column(name = "last_password", nullable = false, columnDefinition = "NVARCHAR(MAX)")
    private String lastPassword;

    @NotNull(message = "last password timestamp is required")
    @Column(name = "last_password_timestamp", nullable = false)
    private LocalDateTime lastPasswordTimestamp;

    @Size(max = 150, message = "ip address must not exceed 150 characters")
    @Column(name = "ip_address", length = 150)
    private String ipAddress;

    @NotNull(message = "created by is required")
    @Column(name = "created_by", nullable = false)
    private Integer createdBy;

    @NotNull(message = "created date is required")
    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id", nullable = false)
    private Integer municipalId;

}
