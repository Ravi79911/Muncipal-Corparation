package com.ahmednagar.municipal.master.advertisement.controller;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingTypeMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeMasterSetup;
import com.ahmednagar.municipal.master.advertisement.service.HoardingTypeMasterSetupService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/advertisement/hoardingtype/master/setup")
@Validated
@CrossOrigin
public class HoardingTypeMasterSetupController {
    @Autowired
    private HoardingTypeMasterSetupService hoardingTypeMasterSetupService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingTypeMasterSetup> createHoardingTypeMasterSetup(@Valid @RequestBody HoardingTypeMasterSetup hoardingTypeMasterSetup){
        HoardingTypeMasterSetup savedHoardingTypeMasterSetup=hoardingTypeMasterSetupService.saveHoardingTypeMasterSetup(hoardingTypeMasterSetup);
        return ResponseEntity.status(201).body(savedHoardingTypeMasterSetup);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingTypeMasterSetupDto>> getAllHoardingTypeMasterSetup(){
        List<HoardingTypeMasterSetupDto> hoardingTypeMasterSetup=hoardingTypeMasterSetupService.findAllHoardingTypeMasterSetup();
        return ResponseEntity.ok(hoardingTypeMasterSetup);

    }
    //for single user by Id
    @GetMapping("/getMlBusinessNatureById/{id}")
    public ResponseEntity<HoardingTypeMasterSetup> getHoardingTypeMasterSetupById(@PathVariable Long id){
        HoardingTypeMasterSetup hoardingTypeMasterSetup=hoardingTypeMasterSetupService.findById(id);
        return ResponseEntity.ok(hoardingTypeMasterSetup);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingTypeMasterSetupByMunicipalId(@PathVariable int municipalId){
        List<HoardingTypeMasterSetup> hoardingTypeMasterSetups = hoardingTypeMasterSetupService.findAllByMunicipalId(municipalId);
        if (hoardingTypeMasterSetups.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingTypeMasterSetup found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingTypeMasterSetups);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingTypeMasterSetup> updateHoardingTypeMasterSetup(@PathVariable("id") Long id, @RequestBody HoardingTypeMasterSetup updatedHoardingTypeMasterSetup){
        try{
            HoardingTypeMasterSetup updated=hoardingTypeMasterSetupService.updateHoardingTypeMasterSetup(id,updatedHoardingTypeMasterSetup,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingTypeMasterSetupService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }

}

