package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.CitizenOTPHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CitizenOTPHistoryRepository extends JpaRepository<CitizenOTPHistory, Long> {

}
