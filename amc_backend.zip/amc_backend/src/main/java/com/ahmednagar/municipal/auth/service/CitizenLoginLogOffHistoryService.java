package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.model.CitizenLoginLogOffHistory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CitizenLoginLogOffHistoryService {

    CitizenLoginLogOffHistory saveCitizenLoginLogoff(CitizenLoginLogOffHistory citizenLoginLogOffHistory);

    List<CitizenLoginLogOffHistory> getAllCitizenLoginLogoffHistories();

    CitizenLoginLogOffHistory updateCitizenLoginLogoff(Long id, CitizenLoginLogOffHistory citizenLoginLogOffHistory);

    CitizenLoginLogOffHistory changeSuspendedStatus(Long id, Integer suspendedStatus);

}
