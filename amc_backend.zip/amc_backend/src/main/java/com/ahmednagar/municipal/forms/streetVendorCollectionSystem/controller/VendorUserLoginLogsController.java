package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserLoginLogs;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorUserLoginLogsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorUserLoginLogsController {

    @Autowired
    private VendorUserLoginLogsService vendorUserLoginLogsService;

    @PostMapping("/saveUserLoginLogs")
    public ResponseEntity<VendorUserLoginLogs> createUserLoginLogs(@RequestBody VendorUserLoginLogs vendorUserLoginLogs) {
        return ResponseEntity.ok(vendorUserLoginLogsService.saveUserLoginLogs(vendorUserLoginLogs));
    }
}
