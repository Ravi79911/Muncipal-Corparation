package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFromMaster;
import com.ahmednagar.municipal.master.municipalLicence.dto.TradeApplicationTypeDto;
import com.ahmednagar.municipal.master.municipalLicence.model.TradeApplicationType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ApplicationLicenseDetailsDto {

    private Long id;
    private String licenseNo;
    private String licenseHolderName;
    private String licenseType;
    private Date generationDate;
    private Date expiryDate;
    private Date rentAgreementDate;
    private String agreementNo;
    private Date agreementValidFrom;
    private Date agreementValidUpto;
    private Boolean isLicenseActive;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private Long municipalId;
    private ApplicationFromMasterDto applicationMasterId;
    private TradeApplicationTypeDto applicationTypeId;

}
