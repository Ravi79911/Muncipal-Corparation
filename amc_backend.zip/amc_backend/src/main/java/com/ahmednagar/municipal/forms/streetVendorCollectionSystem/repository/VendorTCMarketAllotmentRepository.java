package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorTCMarketAllotment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface VendorTCMarketAllotmentRepository extends JpaRepository<VendorTCMarketAllotment, Long> {

    List<VendorTCMarketAllotment> findBySuspendedStatus(Integer suspendedStatus);
}
