package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import com.ahmednagar.municipal.master.propertyTax.dto.PropertyTaxComponentNameMasterDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PropertyFloorTaxationDetailsDto {

    private Long id;
    private int propertyMasId;
    private int propertyFloorMasId;
    private PropertyTaxComponentNameMasterDto taxHeadId;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;

}
