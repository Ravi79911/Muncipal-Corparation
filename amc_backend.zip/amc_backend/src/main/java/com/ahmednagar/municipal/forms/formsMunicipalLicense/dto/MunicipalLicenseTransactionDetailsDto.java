package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MunicipalLicenseTransactionDetailsDto {
    private Long id;
    private MunicipalLicensePaymentDetailsDto municipalLicensePaymentId;
    private String transactionNumber;
    private BigDecimal transactionAmount;
    private LocalDate transactionDate;
    private String transactionStatus;
    private LocalDate paymentDate;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
