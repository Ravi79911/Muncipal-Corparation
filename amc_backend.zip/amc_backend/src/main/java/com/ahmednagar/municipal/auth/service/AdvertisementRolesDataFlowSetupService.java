package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.AdvertisementRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.AdvertisementRolesDataFlowSetup;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface AdvertisementRolesDataFlowSetupService {

    List<AdvertisementRolesDataFlowSetupDto> findAllRolesDataFlowSetup();

    List<AdvertisementRolesDataFlowSetup> getNextRoleListForListSelection(Long currentRoleId, Long statusCode, Integer isActive);

    AdvertisementRolesDataFlowSetup getNextRoleForSingleSelection(Long currentRoleId, Long statusCode, Integer isActive);

}
