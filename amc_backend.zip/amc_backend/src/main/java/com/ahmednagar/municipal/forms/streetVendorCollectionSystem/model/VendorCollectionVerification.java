package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "tbl_collection_verification_master")
public class VendorCollectionVerification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "collection_amount")
    private Double collectionAmount;

    @Column(name = "verification_date_time")
    private LocalDateTime verificationDateTime;

    @Column(name = "verified_status")
    private String verifiedStatus;

    @Column(name = "verified_amount")
    private Double verifiedAmount;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private int suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "verified_by_userid", referencedColumnName = "id")
    private VendorUser verifiedByUserid;

    @ManyToOne
    @JoinColumn(name = "collection_detail_id", referencedColumnName = "id")
    private VendorCollectionDetail collectionDetailId;
}
