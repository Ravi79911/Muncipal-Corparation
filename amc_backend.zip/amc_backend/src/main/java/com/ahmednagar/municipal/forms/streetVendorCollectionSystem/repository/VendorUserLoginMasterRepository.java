package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserLoginMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

@EnableJpaRepositories
public interface VendorUserLoginMasterRepository extends JpaRepository<VendorUserLoginMaster, Long> {

    Optional<VendorUserLoginMaster> findByUserNameAndPassword(String userName, String password);



    Optional<VendorUserLoginMaster> findByUserName(String userName);

    @Query("SELECT v FROM VendorUserLoginMaster v JOIN FETCH v.vendorUser WHERE v.id = :id")
    VendorUserLoginMaster findByIdWithVendorUser(@Param("id") Long id);

}
