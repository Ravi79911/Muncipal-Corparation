package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface VendorMasterService {

    VendorMaster saveVendorMaster(VendorMaster vendorMaster);
    Optional<VendorMaster> findByIdVendorMaster(Long id);
    Optional<VendorMaster> updateVendorMaster(Long id, VendorMaster vendorMaster);
    List<VendorMaster> getAllVendorMasters();
    Optional<VendorMaster> deleteVendorMaster(Long id);
    List<VendorMaster> getVendors(Long marketNameId, String vendorNameEng);
}
