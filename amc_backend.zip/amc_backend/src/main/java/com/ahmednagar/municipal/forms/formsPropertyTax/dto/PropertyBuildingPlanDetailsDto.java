package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PropertyBuildingPlanDetailsDto {

    private int id;
    private int propertyMasId;
    private String buildingPlanApprovalNo;
    private LocalDate buildingPlanApprovalDate;
    private boolean furtherBuildingPlanApprovedFlag;
    private int municipalId;
    private int createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;

}
