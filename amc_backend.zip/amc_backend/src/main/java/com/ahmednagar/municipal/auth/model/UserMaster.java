package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_user_master")
public class UserMaster implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "name of user can't be empty")
    @Column(name = "name_of_user", nullable = false)
    private String nameOfUser;

    @NotBlank(message = "father's name can't be empty")
    @Column(name = "father_name", nullable = false)
    private String fatherName;

    @NotBlank(message = "address can't be empty")
    @Column(name = "address", nullable = false)
    private String address;

    @Email(message = "email should be valid")
    @Column(name = "email", nullable = false)
    private String email;

    //@Pattern(regexp = "^[0-9]{10}$", message = "mobile number must be 10 digits")
    @Column(name = "mobile_no", nullable = false)
    private String mobileNo;

    @Past(message = "date of birth must be in the past")
    @Column(name = "dob", nullable = false)
    private LocalDate dateOfBirth;

    @Column(name = "user_picture")
    private String userPicture;

    @NotBlank(message = "username can't be empty")
    @Column(name = "user_name", nullable = false)
    private String userName;

    @NotBlank(message = "password is required")
    @Size(min = 8, message = "password must be at least 8 characters long")
//    @Pattern(regexp = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$%&_?])[A-Za-z\\d@#$%&_?]{8,}$",
//            message = "Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character (@#$%&_?)")
    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "is_email_verified")
    private boolean isEmailVerified;

    @Column(name = "is_mobile_verified")
    private boolean isMobileVerified;

    @Column(name = "is_verify")
    private boolean isVerified;

    @Column(name = "email_otp")
    private String emailOtp;

    @Column(name = "email_otp_time_stamp")
    private LocalDateTime emailOtpGeneratedDateTime;

    @Column(name = "mobile_otp")
    private String mobileOtp;

    @Column(name = "mobile_otp_time_stamp")
    private LocalDateTime mobileOtpGeneratedDateTime;

    @Column(name = "token")
    private String token;

    @Column(name = "token_time_stamp")
    private LocalDateTime tokenGeneratedDateTime;

    @Column(name = "ip_address")
    private String ipAddress;

    @NotNull(message = "created by is required")
    @Column(name = "created_by", nullable = false)
    private int createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date", nullable = false)
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "role_mas_id", referencedColumnName = "id", nullable = false)
    private RoleMaster roleMaster;

    @ToString.Exclude
    @OneToMany(mappedBy = "userMaster", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private List<UserMasterZoneWardAllocation> userMasterZoneWardAllocations;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        if (roleMaster != null && roleMaster.getRoleName() != null) {
            return List.of(new SimpleGrantedAuthority(roleMaster.getRoleName()));
        } else {
            // Optionally, handle the null case (return empty list or throw an exception)
            // Here we return an empty list as a fallback
            return List.of();
        }
    }

    @Override
    public String getUsername() {
        return this.email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

}
