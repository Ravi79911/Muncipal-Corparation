package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.UserMasterPasswordChangeHistory;
import com.ahmednagar.municipal.auth.service.UserMasterPasswordChangeHistoryService;
import com.ahmednagar.municipal.auth.utils.IpAddressService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/auth")
public class UserMasterPasswordChangeHistoryController {

    @Autowired
    UserMasterPasswordChangeHistoryService userMasterPasswordChangeHistoryService;

    @Autowired
    IpAddressService ipAddressService;

    @GetMapping("/getUserMasterPasswordChangeHistoryByUserMasterId/{userMasterId}")
    public List<UserMasterPasswordChangeHistory> getPasswordChangeHistory(@PathVariable Long userMasterId) {
        return userMasterPasswordChangeHistoryService.getHistoryByUserMasterId(userMasterId);
    }

    @GetMapping("/getAllUserMasterPasswordChangeHistory")
    public ResponseEntity<List<UserMasterPasswordChangeHistory>> getAllUserPasswordChangeHistory() {
        List<UserMasterPasswordChangeHistory> userPasswordChangeHistory = userMasterPasswordChangeHistoryService.getAllUserMasterPasswordChangeHistory();
        return ResponseEntity.ok(userPasswordChangeHistory);
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @PostMapping("/createPasswordChangeHistory")
    public ResponseEntity<UserMasterPasswordChangeHistory> createPasswordChangeHistory(
            @RequestBody UserMasterPasswordChangeHistory history,
            HttpServletRequest request) {

        String clientIp = ipAddressService.getClientIp(request);
        System.out.println("Real client IP: " + clientIp);

        UserMasterPasswordChangeHistory savedHistory = userMasterPasswordChangeHistoryService.createPasswordChangeHistory(history, request);
        return ResponseEntity.ok(savedHistory);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
