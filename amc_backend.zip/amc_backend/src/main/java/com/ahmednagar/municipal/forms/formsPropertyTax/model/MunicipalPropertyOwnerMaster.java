package com.ahmednagar.municipal.forms.formsPropertyTax.model;

import com.ahmednagar.municipal.master.propertyTax.model.OwnerShip;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_muni_property_owner_master")
public class MunicipalPropertyOwnerMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @NotBlank(message = "owner name can't be empty")
    @Size(max = 50, message = "owner name can't exceed 50 characters")
    @Column(name = "owner_name")
    private String ownerName;

    @NotBlank(message = "owner father/husband name can't be empty")
    @Size(max = 50, message = "owner father/husband name can't exceed 50 characters")
    @Column(name = "owner_father_husb_name")
    private String ownerFatherHusbName;

    @NotBlank(message = "owner relation can't be empty")
    @Size(max = 50, message = "owner relation can't exceed 50 characters")
    @Column(name = "owner_relation")
    private String ownerRelation;

    @NotBlank(message = "owner current address can't be empty")
    @Size(max = 500, message = "owner current address can't exceed 500 characters")
    @Column(name = "owner_current_address")
    private String ownerCurrentAddress;

    @NotBlank(message = "owner mobile number can't be empty")
    @Pattern(regexp = "^\\+?[0-9. ()-]{7,25}$", message = "invalid mobile number")
    @Column(name = "owner_mobile_no")
    private String ownerMobileNo;

    @Email(message = "owner email id must be a valid email address")
    @Size(max = 50, message = "owner email id can't exceed 50 characters")
    @Column(name = "owner_email_id")
    private String ownerEmailId;

    @NotBlank(message = "owner gender can't be empty")
    @Size(max = 50, message = "owner gender can't exceed 50 characters")
    @Column(name = "owner_gender")
    private String ownerGender;

    @NotBlank(message = "owner martial status can't be empty")
    @Size(max = 50, message = "owner martial status can't exceed 50 characters")
    @Column(name = "owner_martial_status")
    private String ownerMartialStatus;

    //    @NotBlank(message = "owner occupation can't be empty")
    @Size(max = 50, message = "owner occupation can't exceed 50 characters")
    @Column(name = "owner_occupation")
    private String ownerOccupation;

    @NotNull(message = "owner date of birth can't be null")
    @Past(message = "owner date of birth must be in the past")
    @Column(name = "owner_dob")
    private LocalDate ownerDob;

    @NotNull(message = "aadhar number is required")
    @Column(name = "aadhar_no")
    private Long aadharNo;

    @Size(max = 50, message = "pan number can't exceed 50 characters")
    @Column(name = "pan_number")
    private String panNumber;

    @NotNull(message = "armed force status is required")
    @Column(name = "is_from_armed_force")
    private Boolean isFromArmedForce;

    //    @NotBlank(message = "owner photograph upload can't be empty")
    @Column(name = "owner_photograph_upload")
    private String ownerPhotographUpload;

    @NotNull(message = "is specially abled status is required")
    @Column(name = "is_specially_abled")
    private Boolean isSpeciallyAbled;

    @NotNull(message = "created By is required")
    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @NotNull(message = "suspended status is required")
    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
    private MunicipalPropertyMaster municipalPropertyMaster;

    @ManyToOne
    @JoinColumn(name = "ownership_type_name", referencedColumnName = "id", nullable = false)
    private OwnerShip ownerShips;

}
