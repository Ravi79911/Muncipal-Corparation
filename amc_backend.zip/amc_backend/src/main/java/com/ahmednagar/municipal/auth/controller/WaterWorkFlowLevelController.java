package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.dto.WaterWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.WaterWorkFlowLevel;
import com.ahmednagar.municipal.auth.service.WaterWorkFlowLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/water/work/flow/level")
public class WaterWorkFlowLevelController {

    @Autowired
    private WaterWorkFlowLevelService waterWorkFlowLevelService;

    // Endpoint to handle workflow transitions
    @PostMapping("/transition")
    public ResponseEntity<WaterWorkFlowLevel> handleWaterWorkFlowTransition(@RequestBody WaterWorkFlowLevel waterWorkFlowLevel) {
        WaterWorkFlowLevel updatedWaterWorkFlowLevel = waterWorkFlowLevelService.handleWaterWorkFlowTransition(waterWorkFlowLevel);
        return ResponseEntity.ok(updatedWaterWorkFlowLevel);
    }
    //for admin all users
    @GetMapping("/all")
    public ResponseEntity<List<WaterWorkFlowLevelDto>> getAllWorkFlow(){
        List<WaterWorkFlowLevelDto> workFlow= waterWorkFlowLevelService.findAllWorkFlow();
        return ResponseEntity.ok(workFlow);
    }

    @PostMapping("/new-application")
    public ResponseEntity<WaterWorkFlowLevel> createNewWaterWorkflow(@RequestBody WaterWorkFlowLevel workFlowRequest) {
        WaterWorkFlowLevel savedWorkflow = waterWorkFlowLevelService.createNewApplicationTransation(workFlowRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedWorkflow);
    }
    @GetMapping("/getAllRemarks/{applicationId}")
    public ResponseEntity<List<RemarksDto>> getRemarksByApplicationId(@RequestParam Long applicationId) {
        List<RemarksDto> remarks = waterWorkFlowLevelService.getRemarksByApplicationId(applicationId);
        return ResponseEntity.ok(remarks);
    }
}
