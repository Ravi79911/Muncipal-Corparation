package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_view_ml_trade_type_masters")
public class ViewMlTradeTypeMasters {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @NotNull
    @Column(name = "tradeTypeName")
    private String tradeTypeName;

    @NotBlank(message = "Trade Type Registered Name is required.")
    @Column(name = "tradeTypeRegName", nullable = false)
    private String tradeTypeRegName;

    @NotNull
    @Column(name = "isDangerousType")
    private Boolean isDangerousType;

    @PositiveOrZero(message = "Trade Code must be a positive number or zero.")
    @Column(name = "tradeCode")
    private Long tradeCode;

    //@NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

//    @OneToMany(mappedBy = "tradeTypeId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<MlRateMaster> mlRateMasters;
//
//    @OneToMany(mappedBy = "businessCatId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<ApplicationFromMaster> applicationFromMasters;

}
