package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.LicenseWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.ViewNewWaterConnectionFormMaster;
import com.ahmednagar.municipal.auth.model.WaterWorkFlowLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface WaterWorkFlowLevelRepository extends JpaRepository<WaterWorkFlowLevel,Long> {

    @Query(value = "SELECT TOP 1 * FROM tbl_water_work_flow_level WHERE water_application_id = :waterApplicationId AND status_code = :statusCode ORDER BY created_date DESC", nativeQuery = true)
    Optional<WaterWorkFlowLevel> findLatestWorkFlowByWaterApplicationIdAndStatusCode(@Param("waterApplicationId") Long waterApplicationId, @Param("statusCode") Long statusCode);

    Optional<WaterWorkFlowLevel> findTopByWaterApplicationIdOrderByCreatedDateDesc(ViewNewWaterConnectionFormMaster waterApplicationId);

    List<WaterWorkFlowLevel> findByWaterApplicationId_Id(Long applicationId);
}
