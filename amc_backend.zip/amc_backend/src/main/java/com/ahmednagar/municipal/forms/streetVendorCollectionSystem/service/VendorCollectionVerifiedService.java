package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionVerification;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public interface VendorCollectionVerifiedService {

    VendorCollectionVerification saveVendorCollectionVerification(VendorCollectionVerification vendorCollectionVerification);

    List<VendorCollectionVerification> getAllVendorCollectionVerifications();
    Optional<VendorCollectionVerification> getVendorCollectionVerificationById(Long id);
    //List<VendorCollectionVerification> getFilteredRecords(Long zoneId, Long zoneWardId, LocalDate dateFrom,
    //                                                      LocalDate dateTo, Long vendorUserId, String verifiedStatus);

    List<VendorCollectionVerification> getByCreatedDateAndVendorUserId(LocalDate createdDate, Long vendorUserId);

    List<VendorCollectionVerification> updateVendorCollectionVerifications(
            List<Long> ids, List<VendorCollectionVerification> updatedDataList);
}
