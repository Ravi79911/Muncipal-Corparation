package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyAdditionalDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyAdditionalDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/forms")
public class PropertyAdditionalDetailsController {

    @Autowired
    PropertyAdditionalDetailsService propertyAdditionalDetailsService;

    @RequestMapping("/createPropertyAdditionalDetails")
    public ResponseEntity<List<PropertyAdditionalDetails>> createPropertyAdditionalDetails(@Valid @RequestBody List<PropertyAdditionalDetails> propertyAdditionalDetails) {
        List<PropertyAdditionalDetails> newPropertyAdditionalDetails = propertyAdditionalDetailsService.createPropertyAdditionalDetails(propertyAdditionalDetails);
        return ResponseEntity.ok(newPropertyAdditionalDetails);
    }

//    @PostMapping("/createPropertyAdditionalDetails")
//    public ResponseEntity<List<PropertyAdditionalDetails>> createPropertyAdditionalDetails(@Valid@RequestBody List<PropertyAdditionalDetails> propertyAdditionalDetails) {
//        List<PropertyAdditionalDetails> createdDetails = propertyAdditionalDetailsService.createPropertyAdditionalDetails(propertyAdditionalDetails);
//        return ResponseEntity.status(HttpStatus.CREATED).body(createdDetails);
//    }

    @GetMapping("/getAllPropertyAdditionalDetails")
    public ResponseEntity<List<PropertyAdditionalDetails>> getAllPropertyAdditionalDetails() {
        return ResponseEntity.ok(propertyAdditionalDetailsService.getAllPropertyAdditionalDetails());
    }

    @GetMapping("/propertyAdditionalDetails/{id}")
    public ResponseEntity<Object> getPropertyAdditionalDetailsById(@PathVariable Long id) {
        Optional<PropertyAdditionalDetails> propertyAdditionalDetails = propertyAdditionalDetailsService.getPropertyAdditionalDetailsById(id);
        if (propertyAdditionalDetails.isPresent()) {
            return ResponseEntity.ok(propertyAdditionalDetails.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getPropertyAdditionalDetailsByMunicipalId/{municipalId}")
    public List<PropertyAdditionalDetails> getPropertyAdditionalDetailsByMunicipalId(@PathVariable int municipalId) {
        return propertyAdditionalDetailsService.getPropertyAdditionalDetailsByMunicipalId(municipalId);
    }

    @PatchMapping("/propertyAdditionalDetails/suspendedStatus/{id}")
    public ResponseEntity<PropertyAdditionalDetails> patchPropertyAdditionalDetailsSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        PropertyAdditionalDetails patchedPropertyAdditionalDetails = propertyAdditionalDetailsService.patchPropertyAdditionalDetailsSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedPropertyAdditionalDetails);
    }

}
