package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.model.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public interface CitizenSignUpService {

    CitizenSignUpMaster registerCitizen(CitizenSignUpMaster citizenSignUpMaster, MultipartFile imageFile, HttpServletRequest request);

    CitizenSignUpMaster updateCitizenProfile(CitizenSignUpMaster citizenSignUpMaster, MultipartFile imageFile);

//    Resource getCitizenProfilePicByCitizenId(Long citizenId) throws IOException;

    String getProfilePicUrlFromToken(String token);

    CitizenSignUpMaster findCitizenProfileByJwt(String jwt);

    CitizenSignUpMaster findByCitizenId(Long id);

    boolean isEmailExists(String email);

    boolean isMobileNoExists(String mobileNo);

    boolean isUserNameExists(String userName);

    void generateAndSendOtp(CitizenSignUpMaster citizenSignUpMaster);

    String sendOtpForMobileLogin(String mobileNo);

    boolean validateEmailOtp(CitizenSignUpMaster citizenSignUpMaster, String otp);

    boolean validateMobileOtp(CitizenSignUpMaster citizenSignUpMaster, String otp);

    String validateForgotUsernameOtp(CitizenSignUpMaster citizenSignUpMaster, String emailOtp, String mobileOtp);

    void resendEmailOtp(CitizenSignUpMaster citizenSignUpMaster);

    void resendMobileOtp(CitizenSignUpMaster citizenSignUpMaster);

    String forgotUsername(ForgotUserNameRequest forgotUserNameRequest);

    String requestChangeEmailOrMobile(Long citizenId, ChangeEmailMobileRequest changeEmailMobileRequest);

    boolean validateChangeEmailOrMobileOtp(Long citizenId, String otp, ChangeEmailMobileRequest changeEmailMobileRequest);

    String changePassword(Long citizenId, ChangePasswordRequest changePasswordRequest);

    String forgotPassword(String email);

    String resetPassword(String token, ForgotPassword forgotPassword);

}
