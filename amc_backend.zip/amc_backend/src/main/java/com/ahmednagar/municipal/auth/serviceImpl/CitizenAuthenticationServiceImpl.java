//package com.ahmednagar.municipal.auth.serviceImpl;
//
//import com.ahmednagar.municipal.auth.model.CitizenSignUpMaster;
//import com.ahmednagar.municipal.auth.repository.CitizenSignUpRepository;
//import com.ahmednagar.municipal.auth.service.CitizenAuthenticationService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import java.util.Optional;
//
//@Service
//public class CitizenAuthenticationServiceImpl implements CitizenAuthenticationService {
//
//    @Autowired
//    CitizenSignUpRepository citizenSignUpRepository;
//
//    @Autowired
//    PasswordEncoder passwordEncoder;
//
//    @Override
//    public boolean citizenAuthenticate(String usernameOrMobile, String password) {
//
//        // check if the login is by email or mobile
//        CitizenSignUpMaster citizen = null;
//
//        // try fetching by email first
//        Optional<CitizenSignUpMaster> citizenByEmail = citizenSignUpRepository.findByEmail(usernameOrMobile);
//        if (citizenByEmail.isPresent()) {
//            citizen = citizenByEmail.get();
//        } else {
//            // try fetching by mobile number if not found by email
//            Optional<CitizenSignUpMaster> citizenByMobile = citizenSignUpRepository.findByMobileNo(usernameOrMobile);
//            if (citizenByMobile.isPresent()) {
//                citizen = citizenByMobile.get();
//            }
//        }
//
//        if (citizen == null) {
//            throw new BadCredentialsException("citizen not found with username (email or mobile): " + usernameOrMobile);
//        }
//
//        // validate the password (check if entered password matches the stored one)
//        if (!passwordEncoder.matches(password, citizen.getPassword())) {
//            throw new BadCredentialsException("invalid username or password");
//        }
//
//        return true; // authentication successful
//    }
//
//}
