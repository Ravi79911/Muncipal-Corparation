package com.ahmednagar.municipal.forms.formsAdvertisement.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb2_hoarding_alloated_demand")
public class HoardingAllottedDemand {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name = "hoarding_application_detail_id", nullable = false)
    @NotNull(message = "Hoarding application detail ID cannot be null")
    private Long hoardingApplicationDetailId;

    @Column(name = "calculated_amount", nullable = false)
    @NotBlank(message = "Calculated amount cannot be blank")
    @Size(max = 150, message = "Calculated amount cannot exceed 150 characters")
    private String calculatedAmount;

    @Column(name = "calculated_period_days", nullable = false)
    @NotNull(message = "Calculated period in days cannot be null")
    @Min(value = 0, message = "Calculated period in days must be greater than or equal to 0")
    private Long calculatedPeriodDays;

    @Column(name = "calculated_period_months", nullable = false)
    @NotNull(message = "Calculated period in months cannot be null")
    @Min(value = 0, message = "Calculated period in months must be greater than or equal to 0")
    private Long calculatedPeriodMonths;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;
}
