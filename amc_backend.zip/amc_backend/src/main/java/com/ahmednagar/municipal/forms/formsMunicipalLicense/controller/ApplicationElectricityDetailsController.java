package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationElectricityDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationElectricityDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationElectricityDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/license/form/applicationElectricityDetails")
public class ApplicationElectricityDetailsController {

    @Autowired
    private ApplicationElectricityDetailsService applicationElectricityDetailsService;

    //create ApplicationElectricityDetails
    @PostMapping("/create")
    public ResponseEntity<ApplicationElectricityDetails> createApplicationElectricityDetails(@Valid @RequestBody ApplicationElectricityDetails applicationElectricityDetails, @RequestParam int createdBy){
        ApplicationElectricityDetails createdApplicationElectricityDetails=applicationElectricityDetailsService.saveApplicationElectricityDetails(applicationElectricityDetails,1);
        if(createdApplicationElectricityDetails==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdApplicationElectricityDetails);

        }

//    //for admin users
//    @GetMapping("/all")
//    public ResponseEntity<List<ApplicationElectricityDetailsDto>> getAllApplicationElectricityDetails(){
//        List<ApplicationElectricityDetailsDto> applicationElectricityDetails=applicationElectricityDetailsService.findAllApplicationElectricityDetails();
//        return ResponseEntity.ok(applicationElectricityDetails);
//    }
//
//    //for active users
//    @GetMapping("/active")
//    public ResponseEntity<List<ApplicationElectricityDetails>> getAllActiveApplicationElectricityDetails(@RequestParam(required = false, defaultValue = "0") Integer status){
//        List<ApplicationElectricityDetails> activeApplicationElectricityDetails=applicationElectricityDetailsService.findAllActiveApplicationElectricityDetails(status);
//        return ResponseEntity.ok(activeApplicationElectricityDetails);
//
//    }

    //get Application Electricity Details By Id
    @GetMapping("/get/{id}")
    public ResponseEntity<ApplicationElectricityDetails> getApplicationElectricityDetailsById(@PathVariable int id){
        ApplicationElectricityDetails applicationElectricityDetails=applicationElectricityDetailsService.findApplicationElectricityDetailsById(id);
        return ResponseEntity.ok(applicationElectricityDetails);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllApplicationElectricDetailsByMunicipalId(@PathVariable int municipalId){
        List<ApplicationElectricityDetailsDto> applicationElectricityDetails=applicationElectricityDetailsService.findAllApplicationElectricDetailsByMunicipalId(municipalId);
        if (applicationElectricityDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No application Electric Detail found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(applicationElectricityDetails);
    }

    //     Update AppApplication Details From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<ApplicationElectricityDetails> updateApplicationElectricityDetails(@PathVariable("id") int id, @RequestBody ApplicationElectricityDetails updatedApplicationElectricityDetails){
        try{
            ApplicationElectricityDetails updated=applicationElectricityDetailsService.updateapplicationElectricityDetailsService(id,updatedApplicationElectricityDetails,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete AppApplication Details for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<ApplicationElectricityDetails> changeSuspendedStatus(@PathVariable int id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        ApplicationElectricityDetails updatedApplicationElectricityDetails= applicationElectricityDetailsService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedApplicationElectricityDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedApplicationElectricityDetails);
    }


}
