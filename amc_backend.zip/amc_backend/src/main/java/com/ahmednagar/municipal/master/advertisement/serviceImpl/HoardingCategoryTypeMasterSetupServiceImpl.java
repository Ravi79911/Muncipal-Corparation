package com.ahmednagar.municipal.master.advertisement.serviceImpl;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingCategoryTypeMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingCategoryTypeMasterSetup;
import com.ahmednagar.municipal.master.advertisement.repository.HoardingCategoryTypeMasterSetupRepository;
import com.ahmednagar.municipal.master.advertisement.service.HoardingCategoryTypeMasterSetupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingCategoryTypeMasterSetupServiceImpl implements HoardingCategoryTypeMasterSetupService {
    @Autowired
    private HoardingCategoryTypeMasterSetupRepository hoardingCategoryTypeMasterSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingCategoryTypeMasterSetup saveHoardingCategoryTypeMasterSetup(HoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterSetup) {
        hoardingCategoryTypeMasterSetup.setCreatedDate(LocalDateTime.now());
        hoardingCategoryTypeMasterSetup.setUpdatedDate(LocalDateTime.now());
        hoardingCategoryTypeMasterSetup.setUpdatedBy(hoardingCategoryTypeMasterSetup.getUpdatedBy() != null ? hoardingCategoryTypeMasterSetup.getUpdatedBy() : 0);
        hoardingCategoryTypeMasterSetup.setSuspendedStatus(hoardingCategoryTypeMasterSetup.getSuspendedStatus() != null ? hoardingCategoryTypeMasterSetup.getSuspendedStatus() : 0);

        return hoardingCategoryTypeMasterSetupRepository.save(hoardingCategoryTypeMasterSetup);

    }

    @Override
    public List<HoardingCategoryTypeMasterSetupDto> findAllHoardingCategoryTypeMasterSetup() {
        List<HoardingCategoryTypeMasterSetup> hoardingCategoryTypeMasterSetups = hoardingCategoryTypeMasterSetupRepository.findAll();
        return hoardingCategoryTypeMasterSetups.stream()
                .map(hoardingCategoryTypeMasterSetup -> modelMapper.map(hoardingCategoryTypeMasterSetup, HoardingCategoryTypeMasterSetupDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingCategoryTypeMasterSetup findById(Long id) {
        Optional<HoardingCategoryTypeMasterSetup> hoardingCategoryTypeMasterSetup=hoardingCategoryTypeMasterSetupRepository.findById(id);
        return hoardingCategoryTypeMasterSetup.orElse(null);

    }

    @Override
    public List<HoardingCategoryTypeMasterSetup> findAllByMunicipalId(int municipalId) {
        return hoardingCategoryTypeMasterSetupRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingCategoryTypeMasterSetup updateHoardingCategoryTypeMasterSetup(Long id, HoardingCategoryTypeMasterSetup updatedHoardingCategoryTypeMasterSetup, int updatedBy) {
        Optional<HoardingCategoryTypeMasterSetup> hoardingCategoryTypeMasterSetupOptional = hoardingCategoryTypeMasterSetupRepository.findById(id);
        if (hoardingCategoryTypeMasterSetupOptional.isPresent()) {
            HoardingCategoryTypeMasterSetup existingHoardingCategoryTypeMasterSetup = hoardingCategoryTypeMasterSetupOptional.get();
            existingHoardingCategoryTypeMasterSetup.setHoardingCategoryTypeName(updatedHoardingCategoryTypeMasterSetup.getHoardingCategoryTypeName());
            existingHoardingCategoryTypeMasterSetup.setUpdatedBy(updatedBy);
            existingHoardingCategoryTypeMasterSetup.setUpdatedDate(LocalDateTime.now());
            return hoardingCategoryTypeMasterSetupRepository.saveAndFlush(existingHoardingCategoryTypeMasterSetup);
        } else {
            throw new RuntimeException("HoardingCategoryTypeMasterSetup not found with id: " + id);
        }
    }

    @Override
    public HoardingCategoryTypeMasterSetup changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingCategoryTypeMasterSetup> hoardingCategoryTypeMasterSetupOpt = hoardingCategoryTypeMasterSetupRepository.findById(id);
        if (hoardingCategoryTypeMasterSetupOpt.isPresent()) {
            HoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterSetup = hoardingCategoryTypeMasterSetupOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingCategoryTypeMasterSetup.setUpdatedDate(currentDateTime);
            hoardingCategoryTypeMasterSetup.setSuspendedStatus(status);      // 1 means suspended
            hoardingCategoryTypeMasterSetup.setUpdatedBy(updatedBy);
            return hoardingCategoryTypeMasterSetupRepository.saveAndFlush(hoardingCategoryTypeMasterSetup);
        }
        return null;
    }
}