package com.ahmednagar.municipal.auth.utils;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Service;

@Service
public class IpAddressService {

//    // method to retrieve the real client's IP address
//    public String getClientIp(HttpServletRequest request) {
//        String ipAddress = request.getHeader("X-Forwarded-For");
//
//        // if the X-Forwarded-For header is present, it contains a comma-separated list of IPs.
//        // the first IP in the list is the real client IP.
//        if (ipAddress != null && !ipAddress.isEmpty()) {
//            // multiple proxies can add multiple IPs to this list, we take the first IP
//            String[] ipArray = ipAddress.split(",");
//            ipAddress = ipArray[0].trim();
//        } else {
//            // if no X-Forwarded-For header, fallback to remote address
//            ipAddress = request.getRemoteAddr();
//        }
//
//        // check for loopback addresses, which could indicate that the request is local
//        // and we want the actual client IP from a network request
//        if (ipAddress.equals("0:0:0:0:0:0:0:1") || ipAddress.equals("127.0.0.1")) {
//            // if loopback address, treat it as localhost (or handle differently based on your needs)
//            ipAddress = "localhost";  // you can handle this differently if needed.
//        }
//
//        return ipAddress;
//    }

    // Get the real client's IP address, checking for proxy headers
    public String getClientIp(HttpServletRequest request) {
        // Check the X-Forwarded-For header for proxies (this contains the original client IP)
        String ipAddress = request.getHeader("X-Forwarded-For");

        // If the header is empty or null, fall back to the remote address (the IP of the proxy or server)
        if (ipAddress == null || ipAddress.isEmpty()) {
            ipAddress = request.getRemoteAddr();
        } else {
            // In case of multiple proxies, X-Forwarded-For contains a comma-separated list of IPs
            // The first IP in the list is the real client's IP
            ipAddress = ipAddress.split(",")[0];
        }

        // If the address is from a local IP (localhost or internal network), handle it separately
        if ("127.0.0.1".equals(ipAddress) || "::1".equals(ipAddress)) {
            System.out.println("client is accessing from localhost: " + ipAddress);
        }

        // Return the real client IP address
        return ipAddress;
    }

}
