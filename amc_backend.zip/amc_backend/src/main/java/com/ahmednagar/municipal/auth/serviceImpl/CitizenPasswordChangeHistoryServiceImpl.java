package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.CitizenPasswordChangeHistory;
import com.ahmednagar.municipal.auth.repository.CitizenPasswordChangeHistoryRepository;
import com.ahmednagar.municipal.auth.service.CitizenPasswordChangeHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CitizenPasswordChangeHistoryServiceImpl implements CitizenPasswordChangeHistoryService {

    @Autowired
    CitizenPasswordChangeHistoryRepository citizenPasswordChangeHistoryRepository;

    @Override
    public List<CitizenPasswordChangeHistory> getAllCitizenPasswordChanges() {
        return citizenPasswordChangeHistoryRepository.findAll();
    }

    @Override
    public List<CitizenPasswordChangeHistory> findPasswordChangeHistoryWithCitizenId(Long citizenId) {
        return citizenPasswordChangeHistoryRepository.findByCitizenId(citizenId);
    }

}
