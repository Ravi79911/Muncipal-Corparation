package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorTCMarketAllotment;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorTCMarketAllotmentRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorTCMarketAllotmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VendorTCMarketAllotmentServiceImpl implements VendorTCMarketAllotmentService {

    @Autowired
    private VendorTCMarketAllotmentRepository vendorTCMarketAllotmentRepository;

    @Override
    public VendorTCMarketAllotment saveVendorTCMarketAllotment(VendorTCMarketAllotment vendorTCMarketAllotment) {
        vendorTCMarketAllotment.setCreatedDate(LocalDateTime.now());
        vendorTCMarketAllotment.setSuspendedStatus(0);
        return vendorTCMarketAllotmentRepository.saveAndFlush(vendorTCMarketAllotment);
    }

    @Override
    public List<VendorTCMarketAllotment> getAllVendorTCMarketAllotment() {
        return vendorTCMarketAllotmentRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<VendorTCMarketAllotment> getVendorTCMarketAllotmentById(Long id) {
        return vendorTCMarketAllotmentRepository.findById(id);
    }

    @Override
    public Optional<VendorTCMarketAllotment> updateVendorTCMarketAllotment(Long id, VendorTCMarketAllotment vendorTCMarketAllotment) {
      Optional<VendorTCMarketAllotment> existingVendorTCMarketAllotment = vendorTCMarketAllotmentRepository.findById(id);
        if (existingVendorTCMarketAllotment.isPresent()) {
            VendorTCMarketAllotment updatedVendorTCMarketAllotment = existingVendorTCMarketAllotment.get();
            updatedVendorTCMarketAllotment.setMarketMasId(vendorTCMarketAllotment.getMarketMasId());
            updatedVendorTCMarketAllotment.setTcUserId(vendorTCMarketAllotment.getTcUserId());
            updatedVendorTCMarketAllotment.setUpdatedBy(vendorTCMarketAllotment.getUpdatedBy());
            updatedVendorTCMarketAllotment.setIsActive(vendorTCMarketAllotment.getIsActive());
            updatedVendorTCMarketAllotment.setUpdatedDate(LocalDateTime.now());
            updatedVendorTCMarketAllotment.setEffectedFrom(vendorTCMarketAllotment.getEffectedFrom());
            return Optional.of(vendorTCMarketAllotmentRepository.save(updatedVendorTCMarketAllotment));
        }
        return Optional.empty();
    }

    @Override
    public Optional<VendorTCMarketAllotment> deleteVendorTCMarketAllotment(Long id) {
        Optional<VendorTCMarketAllotment> existingVendorTCMarketAllotment = vendorTCMarketAllotmentRepository.findById(id);
        if (existingVendorTCMarketAllotment.isPresent()) {
            VendorTCMarketAllotment deletedVendorTCMarketAllotment = existingVendorTCMarketAllotment.get();
            deletedVendorTCMarketAllotment.setSuspendedStatus(1);
            return Optional.of(vendorTCMarketAllotmentRepository.save(deletedVendorTCMarketAllotment));
        }
        return Optional.empty();
    }
}
