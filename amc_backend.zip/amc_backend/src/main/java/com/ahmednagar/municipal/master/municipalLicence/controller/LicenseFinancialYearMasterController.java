package com.ahmednagar.municipal.master.municipalLicence.controller;

import com.ahmednagar.municipal.master.municipalLicence.dto.LicenseFinancialYearMasterDto;
import com.ahmednagar.municipal.master.municipalLicence.model.LicenseFinancialYearMaster;
import com.ahmednagar.municipal.master.municipalLicence.service.LicenseFinancialYearMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/ml/licenseFinancialYearMaster")
public class LicenseFinancialYearMasterController {

    @Autowired
    LicenseFinancialYearMasterService licenseFinancialYearMasterService;

    @PostMapping("/create")
    public ResponseEntity<LicenseFinancialYearMaster> createLicenseFinancialMasters(@Valid @RequestBody LicenseFinancialYearMasterDto licenseFinancialYearMasterDto) {
        LicenseFinancialYearMaster newLicenseFinancialYearMaster = licenseFinancialYearMasterService.createLicenseFinancialMaster(licenseFinancialYearMasterDto);
        return ResponseEntity.ok(newLicenseFinancialYearMaster);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<LicenseFinancialYearMasterDto>> findAllLicenseFinancialYears() {
        List<LicenseFinancialYearMasterDto> licenseFinancialYears = licenseFinancialYearMasterService.findAllFyYears();
        return ResponseEntity.ok(licenseFinancialYears);
    }
}
