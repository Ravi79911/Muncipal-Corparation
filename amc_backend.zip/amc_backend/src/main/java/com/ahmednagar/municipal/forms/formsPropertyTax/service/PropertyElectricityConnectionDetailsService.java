package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyElectricityConnectionDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface PropertyElectricityConnectionDetailsService {

    PropertyElectricityConnectionDetails createPropertyElectricityConnectionDetails(PropertyElectricityConnectionDetails propertyElectricityConnectionDetails);

    List<PropertyElectricityConnectionDetails> getAllPropertyElectricityConnectionDetails();

    Optional<PropertyElectricityConnectionDetails> getPropertyElectricityConnectionDetailsById(int id);

    List<PropertyElectricityConnectionDetails> getPropertyElectricityConnectionDetailsByMunicipalId(int municipalId);

    PropertyElectricityConnectionDetails patchPropertyElectricityDetailsSuspendedStatus(int id, int suspendedStatus);

}
