package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PropertyDemandMasterDto {

    private Long id;
    private int propertyMasId;
    private BigDecimal totalBuildupAreaSqft;
    private BigDecimal totalCarpetAreaSqft;
    private BigDecimal totalArv;
    private BigDecimal totalAnnualTax;
    private LocalDate effectFrom;
    private String memoNo;
    private String memoType;
    private String ptNumber;
    private String holdingNumber;
    private int municipalId;
    private int createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;

}
