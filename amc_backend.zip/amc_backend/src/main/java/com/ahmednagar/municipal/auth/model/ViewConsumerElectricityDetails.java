package com.ahmednagar.municipal.auth.model;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.NewConnectionFormShubham;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbls_view_consumer_electricity_details")
public class ViewConsumerElectricityDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @NotBlank(message = "KNO cannot be blank")
    @Size(max = 200, message = "KNO must be 200 characters or less")
    @Column(name = "kno", length = 200)
    private String kno;

    @NotBlank(message = "Bind Book No cannot be blank")
    @Size(max = 200, message = "Bind Book No must be 200 characters or less")
    @Column(name = "bindBookNo", length = 200)
    private String bindBookNo;

    @NotBlank(message = "Account No cannot be blank")
    @Size(max = 200, message = "Account No must be 200 characters or less")
    @Column(name = "account_no", length = 200)
    private String accountNo;

    @NotBlank(message = "Category Type cannot be blank")
    @Size(max = 200, message = "Category Type must be 200 characters or less")
    @Column(name = "category_type", length = 200)
    private String categoryType;

    @NotNull(message = "Created By cannot be null")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @NotNull(message = "Suspended Status cannot be null")
    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID cannot be null")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "appmas_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewNewWaterConnectionFormMaster viewNewWaterConnectionFormMaster;

}
