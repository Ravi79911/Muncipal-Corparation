package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorType;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface VendorTypeService {

    VendorType saveVendorType(VendorType vendorType);
    Optional<VendorType> findVendorTypeById(Long id);
    Optional<VendorType> deleteVendorType(Long id);
    List<VendorType> getAllVendorTypes();
    Optional<VendorType> updateVendorType(Long id, VendorType vendorType);
}
