package com.ahmednagar.municipal.master.advertisement.service;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingDocumentSubCategoryMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingDocumentSubCategoryMasterSetup;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingDocumentSubCategoryMasterSetupService {
    HoardingDocumentSubCategoryMasterSetup saveHoardingDocumentSubCategoryMasterSetup(HoardingDocumentSubCategoryMasterSetup hoardingDocumentSubCategoryMasterSetup);

    List<HoardingDocumentSubCategoryMasterSetupDto> findAllHoardingDocumentSubCategoryMasterSetup();

    HoardingDocumentSubCategoryMasterSetup findById(Long id);

    List<HoardingDocumentSubCategoryMasterSetup> findAllByMunicipalId(int municipalId);

    HoardingDocumentSubCategoryMasterSetup updateHoardingDocumentSubCategoryMasterSetup(Long id, HoardingDocumentSubCategoryMasterSetup updatedHoardingDocumentSubCategoryMasterSetup,int updatedBy);

    HoardingDocumentSubCategoryMasterSetup changeStatus(Long id, Integer status,int updatedBy);

}
