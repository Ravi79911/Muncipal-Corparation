package com.ahmednagar.municipal.auth.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class LoginResponse {

    private String message;
    private Long userId;
    private String email;
    private String mobileNo;
    private String role;
    private String groupName;

}
