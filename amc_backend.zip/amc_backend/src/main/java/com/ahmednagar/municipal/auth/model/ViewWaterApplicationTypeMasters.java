package com.ahmednagar.municipal.auth.model;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.NewConnectionFormShubham;
import com.ahmednagar.municipal.master.waterManagement.modal.DocumentTypeMaster;
import com.ahmednagar.municipal.master.waterManagement.modal.FeeMaster;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_view_water_application_type_masters")
public class ViewWaterApplicationTypeMasters {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "application_type_id")
    private Long id;

    @NotNull
    @Column(name = "application_type_name")
    private String applicationTypeName;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

//    @OneToMany(mappedBy = "applicationTypeList", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<FeeMaster> feeMasters;
//
//    @OneToMany(mappedBy = "applicationTypeId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<DocumentTypeMaster> documentTypeMasters;
//
//    @OneToMany(mappedBy = "applicationTypeId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<NewConnectionFormShubham> newConnectionFormShubham;
}
