package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.AuthWardMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface AuthWardRepository extends JpaRepository<AuthWardMaster, Long> {

    boolean existsByIdAndZoneMasId(Long wardId, Long zoneId);

}
