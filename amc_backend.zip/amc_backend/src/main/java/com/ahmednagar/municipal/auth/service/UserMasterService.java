package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.model.ForgotPassword;
import com.ahmednagar.municipal.auth.model.UserMaster;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface UserMasterService {

    UserMaster createUserMaster(UserMaster userMaster, MultipartFile userPicture);

    UserMaster findByUserId(Long id);

    void generateAndSendOtp(UserMaster userMaster);

    boolean validateEmailOtp(UserMaster userMaster, String otp);

    boolean validateMobileOtp(UserMaster userMaster, String otp);

    void resendEmailOtp(UserMaster userMaster);

    void resendMobileOtp(UserMaster userMaster);

    boolean isEmailExists(String email);

    boolean isUserNameExists(String userName);

    String forgotPassword(String email);

    String resetPassword(String token, ForgotPassword forgotPassword);

}
