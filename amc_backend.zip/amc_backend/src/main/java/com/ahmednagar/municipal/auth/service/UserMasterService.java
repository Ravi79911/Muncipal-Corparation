package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.model.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public interface UserMasterService {

    UserMaster createUserMaster(UserMaster userMaster, MultipartFile userPicture, Long zoneId, List<Long> wardIds);

    List<UserMasterDTO> getAllUserMaster();

    String getProfilePicUrlFromToken(String token);

    UserMaster findByUserId(Long id);

    UserMaster findByEmailOrMobile(String email, String mobile); // for forgot username

    void generateAndSendOtp(UserMaster userMaster);

    boolean validateEmailOtp(UserMaster userMaster, String otp);

    boolean validateMobileOtp(UserMaster userMaster, String otp);

    void resendEmailOtp(UserMaster userMaster);

    void resendMobileOtp(UserMaster userMaster);

    boolean isEmailExists(String email);

    boolean isMobileNumberExists(String mobileNo);

    boolean isUserNameExists(String userName);

    boolean validateEmailOrMobileOtp(Long userId, String otp, ChangeEmailMobileRequest changeEmailMobileRequest);

    String requestEmailOrMobileChange(Long userId, ChangeEmailMobileRequest changeEmailMobileRequest);

    String validateForgotUsernameOtp(UserMaster userMaster, String emailOtp, String mobileOtp);

    String forgotUsername(ForgotUserNameRequest forgotUserNameRequest);

    String forgotPassword(String email);

    String resetPassword(String token, ForgotPassword forgotPassword);

    String changePassword(Long userId, ChangePasswordRequest changePasswordRequest);

//    List<UserMaster> getUsersByZoneWardAndRole(Long zoneId, Long wardId, Long roleId);
}
