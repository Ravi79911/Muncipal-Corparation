package com.ahmednagar.municipal.master.advertisement.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name = "tbl_dd_advertisement_usage_type_master")
public class DDAdvertisementUsageTypeMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "usage type name can't be empty")
    @Size(max = 50, message = "usage type name can't exceed 50 characters")
    @Column(name = "usage_type_name")
    private String usageTypeName;

    @OneToMany(mappedBy = "usageTypeId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<HoardingTypeRateMasterSetup> hoardingTypeRateMasterSetups;

}
