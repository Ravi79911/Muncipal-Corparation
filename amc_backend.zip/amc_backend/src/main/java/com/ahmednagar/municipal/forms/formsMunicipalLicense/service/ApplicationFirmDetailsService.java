package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationFirmDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFirmDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ApplicationFirmDetailsService {

    ApplicationFirmDetails saveApplicationFirmDetails(ApplicationFirmDetails applicationFirmDetails);

//    List<ApplicationFirmDetailsDto> findAllApplicationFirmDetails();
//
//    List<ApplicationFirmDetails> findAllActiveAppApplicantDetails(Integer status);

    ApplicationFirmDetails findApplicationFirmDetailsById(Long id);

    List<ApplicationFirmDetailsDto> findAllApplicationFirmDetailsByMunicipalId(int municipalId);

    ApplicationFirmDetails updateApplicationFirmDetails(Long id, ApplicationFirmDetails updatedApplicationFirmDetails);

    ApplicationFirmDetails changeSuspendedStatus(Long id, int status, int updatedBy);

    void deleteApplicationFirmDetailsByApplicationMasterId(Long applicationMasterId);
}
