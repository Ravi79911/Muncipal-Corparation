package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUser;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface VendorUserService {

    VendorUser saveUserMaster(VendorUser vendorUser);
    List<VendorUser> findAllUsers();
}
