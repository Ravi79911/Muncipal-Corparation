package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;


import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionDetail;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorCollectionDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorCollectionDetailController {

    @Autowired
    private VendorCollectionDetailsService vendorCollectionDetailsService;

    @PostMapping("/saveCollectionDetails")
    public ResponseEntity<VendorCollectionDetail> createCollectionDetails(@RequestBody VendorCollectionDetail vendorCollectionDetail) {
        return ResponseEntity.ok(vendorCollectionDetailsService.saveCollectionDetail(vendorCollectionDetail));
    }

    @GetMapping("/findById")
    public ResponseEntity<Optional<VendorCollectionDetail>> findById(@RequestParam Long id) {
        return ResponseEntity.ok(vendorCollectionDetailsService.findById(id));
    }

    @GetMapping("/searchByVendorUserIdAndCreatedDate")
    public ResponseEntity<List<VendorCollectionDetail>> getByVendorUserIdAndCreatedDate(
            @RequestParam Long vendorUserId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate createdDate) {
        List<VendorCollectionDetail> details = vendorCollectionDetailsService.getDetailsByVendorUserIdAndCreatedDate(vendorUserId, createdDate);
        return ResponseEntity.ok(details);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<VendorCollectionDetail>> getAll() {
        return ResponseEntity.ok(vendorCollectionDetailsService.getAllVendorCollectionDetails());
    }
}
