package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.AdvertisementWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.model.AdvertisementWorkFlowLevel;
import com.ahmednagar.municipal.auth.service.AdvertisementWorkFlowLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/advertisement/work/flow/level")
public class AdvertisementWorkFlowLevelController {

    @Autowired
    private AdvertisementWorkFlowLevelService advertisementWorkFlowLevelService;

    // Endpoint to handle workflow transitions
    @PostMapping("/transition")
    public ResponseEntity<AdvertisementWorkFlowLevel> handleWorkFlowTransition(@RequestBody AdvertisementWorkFlowLevel advertisementWorkFlowLevel) {
        AdvertisementWorkFlowLevel updatedAdvertisementWorkFlowLevel = advertisementWorkFlowLevelService.handleWorkFlowTransition(advertisementWorkFlowLevel);
        return ResponseEntity.ok(updatedAdvertisementWorkFlowLevel);
    }

    //for admin all users
    @GetMapping("/all")
    public ResponseEntity<List<AdvertisementWorkFlowLevelDto>> getAllWorkFlow() {
        List<AdvertisementWorkFlowLevelDto> workFlow = advertisementWorkFlowLevelService.findAllWorkFlow();
        return ResponseEntity.ok(workFlow);
    }

    @PostMapping("/new-application")
    public ResponseEntity<AdvertisementWorkFlowLevel> createNewAdvertisementWorkflow(@RequestBody AdvertisementWorkFlowLevel workFlowRequest) {
        AdvertisementWorkFlowLevel savedWorkflow = advertisementWorkFlowLevelService.createNewApplicationTransation(workFlowRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedWorkflow);
    }

    @GetMapping("/getAllRemarks/{applicationId}")
    public ResponseEntity<List<RemarksDto>> getRemarksByApplicationId(@RequestParam Long applicationId) {
        List<RemarksDto> remarks = advertisementWorkFlowLevelService.getRemarksByApplicationId(applicationId);
        return ResponseEntity.ok(remarks);
    }


}