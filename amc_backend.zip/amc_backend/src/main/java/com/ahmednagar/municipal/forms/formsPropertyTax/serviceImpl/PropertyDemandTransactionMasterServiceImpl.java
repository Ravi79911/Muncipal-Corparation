package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandTransactionMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyDemandTransactionMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyDemandTransactionMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyDemandTransactionMasterServiceImpl implements PropertyDemandTransactionMasterService {

    @Autowired
    PropertyDemandTransactionMasterRepository propertyDemandTransactionMasterRepository;

    @Autowired
    MunicipalPropertyMasterRepository municipalPropertyMasterRepository;

    @Override
    public PropertyDemandTransactionMaster createPropertyDemandTransactionMaster(PropertyDemandTransactionMaster propertyDemandTransactionMaster) {
        Optional<MunicipalPropertyMaster> municipalPropertyMaster =
                municipalPropertyMasterRepository.findById(propertyDemandTransactionMaster.getMunicipalPropertyMaster().getId());

        if (!municipalPropertyMaster.isPresent()) {
            throw new IllegalArgumentException("municipal property master id doesn't exist");
        }
        propertyDemandTransactionMaster.setCreatedDate(LocalDateTime.now());
        return propertyDemandTransactionMasterRepository.saveAndFlush(propertyDemandTransactionMaster);
    }

    @Override
    public List<PropertyDemandTransactionMaster> getAllPropertyDemandTransactionMaster() {
        return propertyDemandTransactionMasterRepository.findAll();
    }

    @Override
    public Optional<PropertyDemandTransactionMaster> getPropertyDemandTransactionMasterById(Long id) {
        return propertyDemandTransactionMasterRepository.findById(id);
    }

    @Override
    public List<PropertyDemandTransactionMaster> getPropertyDemandTransactionMasterByMunicipalId(int municipalId) {
        return propertyDemandTransactionMasterRepository.findByMunicipalId(municipalId);
    }

    @Override
    public PropertyDemandTransactionMaster patchPropertyDemandTransactionMasterSuspendedStatus(Long id, int suspendedStatus) {
        Optional<PropertyDemandTransactionMaster> patchPropertyDemandTransaction = propertyDemandTransactionMasterRepository.findById(id);
        if (patchPropertyDemandTransaction.isPresent()) {
            PropertyDemandTransactionMaster existingPropertyDemandTransaction = patchPropertyDemandTransaction.get();
            existingPropertyDemandTransaction.setSuspendedStatus(suspendedStatus);
            return propertyDemandTransactionMasterRepository.saveAndFlush(existingPropertyDemandTransaction);
        } else {
            throw new RuntimeException("property demand transaction not found with id: " + id);
        }
    }

}
