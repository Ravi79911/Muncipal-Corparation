package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.UserMasterLoginLogOffHistoryDto;
import com.ahmednagar.municipal.auth.model.UserMasterLoginLogOffHistory;
import com.ahmednagar.municipal.auth.repository.UserMasterLoginLogOffHistoryRepository;
import com.ahmednagar.municipal.auth.service.UserMasterLoginLogOffHistoryService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserMasterLoginLogOffHistoryServiceImpl implements UserMasterLoginLogOffHistoryService {

    @Autowired
    UserMasterLoginLogOffHistoryRepository userMasterLoginLogOffHistoryRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public UserMasterLoginLogOffHistory savedUserLoginLogoffHistory(UserMasterLoginLogOffHistory userMasterLoginLogOffHistory) {
        userMasterLoginLogOffHistory.setCreatedDate(LocalDateTime.now());
        userMasterLoginLogOffHistory.setUpdatedDate(LocalDateTime.now());
        userMasterLoginLogOffHistory.setLoginLogoffDatetime(LocalDateTime.now());
        userMasterLoginLogOffHistory.setUpdatedBy(userMasterLoginLogOffHistory.getUpdatedBy() != null ? userMasterLoginLogOffHistory.getUpdatedBy() : 0);
        userMasterLoginLogOffHistory.setSuspendedStatus(userMasterLoginLogOffHistory.getSuspendedStatus() != null ? userMasterLoginLogOffHistory.getSuspendedStatus() : 0);

        return userMasterLoginLogOffHistoryRepository.save(userMasterLoginLogOffHistory);

    }

    @Override
    public List<UserMasterLoginLogOffHistoryDto> findAllUserLoginLogoffHistory() {
        List<UserMasterLoginLogOffHistory> userLoginLogoffHistories = userMasterLoginLogOffHistoryRepository.findAll();
        return userLoginLogoffHistories.stream()
                .map(userLoginLogoffHistory -> modelMapper.map(userLoginLogoffHistory, UserMasterLoginLogOffHistoryDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<UserMasterLoginLogOffHistoryDto> findAllUserLoginLogoffHistoryByMunicipalId(Long municipalId) {
        List<UserMasterLoginLogOffHistory> userLoginLogoffHistories = userMasterLoginLogOffHistoryRepository.findByMunicipalId(municipalId);
        return userLoginLogoffHistories.stream()
                .map(userLoginLogoffHistory -> modelMapper.map(userLoginLogoffHistory, UserMasterLoginLogOffHistoryDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public UserMasterLoginLogOffHistory updateUserLoginLogoffHistory(Long id, UserMasterLoginLogOffHistory updatedUserMasterLoginLogOffHistory) {
        Optional<UserMasterLoginLogOffHistory> userLoginLogoffHistoryOptional = userMasterLoginLogOffHistoryRepository.findById(id);
        if (userLoginLogoffHistoryOptional.isPresent()) {
            UserMasterLoginLogOffHistory existingUserMasterLoginLogOffHistory = userLoginLogoffHistoryOptional.get();
            existingUserMasterLoginLogOffHistory.setUpdatedBy(existingUserMasterLoginLogOffHistory.getUpdatedBy());
            existingUserMasterLoginLogOffHistory.setUpdatedDate(LocalDateTime.now());
            existingUserMasterLoginLogOffHistory.setSuspendedStatus(updatedUserMasterLoginLogOffHistory.getSuspendedStatus());
            existingUserMasterLoginLogOffHistory.setMunicipalId(updatedUserMasterLoginLogOffHistory.getMunicipalId());

            return userMasterLoginLogOffHistoryRepository.saveAndFlush(existingUserMasterLoginLogOffHistory);
        } else {
            throw new RuntimeException("UserLoginLogoffHistory not found with id: " + id);
        }
    }

    @Override
    public UserMasterLoginLogOffHistory changeStatus(Long id, Integer status, int updatedBy) {
        Optional<UserMasterLoginLogOffHistory> userLoginLogoffHistoryOpt = userMasterLoginLogOffHistoryRepository.findById(id);
        if (userLoginLogoffHistoryOpt.isPresent()) {
            UserMasterLoginLogOffHistory userMasterLoginLogOffHistory = userLoginLogoffHistoryOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            userMasterLoginLogOffHistory.setUpdatedDate(currentDateTime);
            userMasterLoginLogOffHistory.setSuspendedStatus(status);
            userMasterLoginLogOffHistory.setUpdatedBy(updatedBy);
            return userMasterLoginLogOffHistoryRepository.saveAndFlush(userMasterLoginLogOffHistory);
        }
        return null;
    }

}
