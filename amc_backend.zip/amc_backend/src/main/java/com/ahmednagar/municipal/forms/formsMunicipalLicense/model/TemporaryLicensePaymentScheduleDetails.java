package com.ahmednagar.municipal.forms.formsMunicipalLicense.model;

import com.ahmednagar.municipal.master.municipalLicence.model.MlRateMaster;
import com.ahmednagar.municipal.master.municipalLicence.model.TradeApplicationType;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb3_temporary_license_payment_schedule_details")
public class TemporaryLicensePaymentScheduleDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @NotNull(message = "Start date is required")
    @Column(name = "start_date", nullable = false)
    private LocalDate startDate;

    @NotNull(message = "End date is required")
    @Column(name = "end_date", nullable = false)
    private LocalDate endDate;

    @NotNull(message = "Number of days is required")
    @Min(value = 1, message = "Number of days must be at least 1")
    @Column(name = "no_of_days", nullable = false)
    private int noOfDays;

    @Column(name = "amount_per_day")
    private BigDecimal amountPerDay;

    @NotNull(message = "Total amount due is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Total amount due must be greater than zero")
    @Column(name = "total_amount_due", nullable = false, precision = 18, scale = 3)
    private BigDecimal totalAmountDue;

//    @NotEmpty(message = "Status is required")
//    @Column(name = "status", nullable = false, length = 50)
//    private String status;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private int updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "ml_rate_master_id", nullable = false,referencedColumnName = "id")
    private MlRateMaster mlRateMasterId;

    @ManyToOne
    @JoinColumn(name = "application_type_id", nullable = false,referencedColumnName = "id")
    private TradeApplicationType applicationTypeId;

//    @ManyToOne
//    @JoinColumn(name = "municipal_license_id", nullable = false, referencedColumnName = "id")
//    private ApplicationLicenseDetails municipalLicenseId;

}
