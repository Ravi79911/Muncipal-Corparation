package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationFirmDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFirmDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationFirmDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/license/forms/ApplicationFirmDetails")
public class ApplicationFirmDetailsController {

    @Autowired
    private ApplicationFirmDetailsService applicationFirmDetailsService;

    //create AppApplicantDetails
    @PostMapping("/create")
    public ResponseEntity<ApplicationFirmDetails> createApplicationFirmDetails(@Valid @RequestBody ApplicationFirmDetails applicationFirmDetails){
        ApplicationFirmDetails createdAppApplicationFirmDetails=applicationFirmDetailsService.saveApplicationFirmDetails(applicationFirmDetails);
        if(createdAppApplicationFirmDetails==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdAppApplicationFirmDetails);
    }
//    //for all admin users
//    @GetMapping("/all")
//    public ResponseEntity<List<ApplicationFirmDetailsDto>> getAllApplicationFirmDetails(){
//        List<ApplicationFirmDetailsDto> applicationFirmDetails=applicationFirmDetailsService.findAllApplicationFirmDetails();
//        return ResponseEntity.ok(applicationFirmDetails);
//    }
//
//    //for active users
//    @GetMapping("/active")
//    public ResponseEntity<List<ApplicationFirmDetails>> getAllActiveApplicationFirmDetails(@RequestParam(required = false, defaultValue = "0") Integer status){
//        List<ApplicationFirmDetails> activeApplicationFirmDetails=applicationFirmDetailsService.findAllActiveAppApplicantDetails(status);
//        return ResponseEntity.ok(activeApplicationFirmDetails);
//
//    }
    //  to get the Application Details by id for user
    @GetMapping("/get/{id}")
    public ResponseEntity<ApplicationFirmDetails> getApplicationFirmDetailsById(@PathVariable Long id){
        ApplicationFirmDetails applicationFirmDetails=applicationFirmDetailsService.findApplicationFirmDetailsById(id);
        return ResponseEntity.ok(applicationFirmDetails);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllApplicationFirmDetailsByMunicipalId(@PathVariable int municipalId){
        List<ApplicationFirmDetailsDto> applicationFirmDetails=applicationFirmDetailsService.findAllApplicationFirmDetailsByMunicipalId(municipalId);
        if (applicationFirmDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No ApplicationFirmDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(applicationFirmDetails);
    }
    //     Update AppApplication Details From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<ApplicationFirmDetails> updateApplicationFirmDetails(@PathVariable("id") Long id, @RequestBody ApplicationFirmDetails updatedApplicationFirmDetails){
        try{
            ApplicationFirmDetails updated=applicationFirmDetailsService.updateApplicationFirmDetails(id,updatedApplicationFirmDetails,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete AppApplication Details for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<ApplicationFirmDetails> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        ApplicationFirmDetails updatedApplicationFirmDetails = applicationFirmDetailsService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedApplicationFirmDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedApplicationFirmDetails);
    }

}
