package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.exception.ApiException;
import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationFromMasterDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFromMaster;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationFromMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/forms/license/applicationFormMaster")
public class ApplicationFromMasterController {

    @Autowired
    private ApplicationFromMasterService applicationFromMasterService;

    //create Application Form
    @PostMapping("/create")
    public ResponseEntity<ApplicationFromMaster> createApplicationFromMaster(@Valid @RequestBody ApplicationFromMaster applicationFromMaster) {
        ApplicationFromMaster createdApplicationFromMaster = applicationFromMasterService.saveapplicationFromMasterService(applicationFromMaster);
        return ResponseEntity.status(201).body(createdApplicationFromMaster);
    }

    //for all admin users
    @GetMapping("/all")
    public ResponseEntity<List<ApplicationFromMasterDto>> getAllApplicationFromMaster(){
        List<ApplicationFromMasterDto> applicationFromMaster=applicationFromMasterService.findAllApplicationFromMaster();
        return ResponseEntity.ok(applicationFromMaster);
    }
//
//    //for active users
//    @GetMapping("/active")
//    public ResponseEntity<List<ApplicationFromMaster>> getAllActiveApplicationFromMaster(@RequestParam(required = false, defaultValue = "0") Integer status){
//        List<ApplicationFromMaster> activeApplicationFromMaster=applicationFromMasterService.findAllActiveApplicationFromMaster(status);
//        return ResponseEntity.ok(activeApplicationFromMaster);
//
//    }

    //  to get the Application Form by id for user
    @GetMapping("/get/{id}")
    public ResponseEntity<ApplicationFromMaster> getApplicationFromMasterById(@PathVariable Long id) {
        ApplicationFromMaster applicationFromMaster = applicationFromMasterService.findApplicationFromMasterById(id);
        return ResponseEntity.ok(applicationFromMaster);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllApplicationFromMasterByMunicipalId(@PathVariable int municipalId) {
        List<ApplicationFromMasterDto> applicationFromMasters = applicationFromMasterService.findAllApplicationFromMasterByMunicipalId(municipalId);
        if (applicationFromMasters.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No applicationFromMasters found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(applicationFromMasters);
    }

    //     Update Application From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<ApplicationFromMaster> updateApplicationFromMaster(@PathVariable("id") Long id, @RequestBody ApplicationFromMaster updatedApplicationFromMaster) {
        try {
            ApplicationFromMaster updated = applicationFromMasterService.updateApplicationFromMaster(id, updatedApplicationFromMaster, 1);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete Application From for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<ApplicationFromMaster> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        ApplicationFromMaster updatedApplicationFromMaster = applicationFromMasterService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedApplicationFromMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedApplicationFromMaster);
    }

    @DeleteMapping("/deleteApplicationFromMasterById/{id}")
    public ResponseEntity<ApiResponse> deleteApplicationFromMaster(@PathVariable Long id) {
        try {
            applicationFromMasterService.deleteApplicationFromMasterById(id);
            ApiResponse apiResponse = new ApiResponse("ApplicationFrom master deleted successfully", true, LocalDateTime.now(), "SUCCESS", null, null);
            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (ResourceNotFoundException ex) {
            ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false, LocalDateTime.now(), "RESOURCE_NOT_FOUND", null, null);
            return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            throw new ApiException("Error occurred while deleting property master");
        }
    }

}
