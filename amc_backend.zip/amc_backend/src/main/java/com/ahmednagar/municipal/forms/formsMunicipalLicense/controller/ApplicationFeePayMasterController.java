package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationFeePayMasterDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFeePayMaster;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationFeePayMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/license/form/applicationFeePayMaster")
public class ApplicationFeePayMasterController {

    @Autowired
    private ApplicationFeePayMasterService applicationFeePayMasterService;

    //create Application Fee Pay Master
    @PostMapping("/create")
    public ResponseEntity<ApplicationFeePayMaster> createApplicationElectricityDetails(@Valid @RequestBody ApplicationFeePayMaster applicationFeePayMaster, @RequestParam int createdBy){
        ApplicationFeePayMaster createdApplicationFeePayMaster=applicationFeePayMasterService.saveApplicationFeePayMaster(applicationFeePayMaster,1);
        return ResponseEntity.status(201).body(createdApplicationFeePayMaster);
    }

//    //for all admin users
//    @GetMapping("/all")
//    public ResponseEntity<List<ApplicationFeePayMasterDto>> getAllApplicationFeePayMasters(){
//        List<ApplicationFeePayMasterDto> applicationFeePayMasters=applicationFeePayMasterService.findAllApplicationFeePayMaster();
//        return ResponseEntity.ok(applicationFeePayMasters);
//    }
//
//    //for active users
//    @GetMapping("/active")
//    public ResponseEntity<List<ApplicationFeePayMaster>> getAllActiveApplicationFeePayMaster(@RequestParam(required = false, defaultValue = "0") Integer status){
//        List<ApplicationFeePayMaster> activeApplicationFeePayMaster=applicationFeePayMasterService.findAllActiveApplicationFeePayMaster(status);
//        return ResponseEntity.ok(activeApplicationFeePayMaster);
//
//    }

    //get Application Fee Pay By Id
    @GetMapping("/get/{id}")
    public ResponseEntity<ApplicationFeePayMaster> getApplicationFeePayMasterById(@PathVariable int id){
        ApplicationFeePayMaster applicationFeePayMaster=applicationFeePayMasterService.findApplicationFeePayMasterById(id);
        return ResponseEntity.ok(applicationFeePayMaster);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllApplicationFeePayMasterByMunicipalId(@PathVariable int municipalId){
        List<ApplicationFeePayMasterDto> applicationFeePayMaster=applicationFeePayMasterService.findAllApplicationFeePayMasterByMunicipalId(municipalId);
        if (applicationFeePayMaster.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No application FeePayMaster found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(applicationFeePayMaster);
    }

    //     Update AppApplication Details From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<ApplicationFeePayMaster> updateApplicationFeePayMaster(@PathVariable("id") int id, @RequestBody ApplicationFeePayMaster updatedApplicationFeePayMaster){
        try{
            ApplicationFeePayMaster updated=applicationFeePayMasterService.updateApplicationFeePayMaster(id,updatedApplicationFeePayMaster,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete AppApplication Details for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<ApplicationFeePayMaster> changeSuspendedStatus(@PathVariable int id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        ApplicationFeePayMaster updatedApplicationFeePayMaster = applicationFeePayMasterService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedApplicationFeePayMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedApplicationFeePayMaster);
    }


}
