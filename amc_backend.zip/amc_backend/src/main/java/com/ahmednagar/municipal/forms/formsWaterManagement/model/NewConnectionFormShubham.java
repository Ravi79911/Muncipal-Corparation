package com.ahmednagar.municipal.forms.formsWaterManagement.model;

import com.ahmednagar.municipal.master.waterManagement.modal.ApplicationType;
import com.ahmednagar.municipal.master.waterManagement.modal.PipelineType;
import com.ahmednagar.municipal.master.waterManagement.modal.WaterFinancialYearMaster;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_new_connection_shubham_form_Master")
public class NewConnectionFormShubham {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Size(max = 150, message = "Consumer number cannot exceed 150 characters")
    @Column(name = "consumer_n_number", nullable = false)
    private String consumerNNumber;

//    @Column(name = "Application_type_id", nullable = false)
//    private int applicationTypeId;

//    @Column(name = "ferual_type_id", nullable = false)
//    private int ferualTypeId;

    @Column(name = "entry_date", nullable = false)
    private LocalDate entryDate;

    @Size(max = 50, message = "Status cannot exceed 50 characters")
    @Column(name = "status", nullable = false)
    private String status;

    @Size(max = 200, message = "Auto-generated form number cannot exceed 200 characters")
    @Column(name = "autogen_f_number", nullable = false)
    private String autogenFNumber;

    @Column(name = "is_working_meter", nullable = false)
    private int isWorkingMeter;

    @Digits(integer = 20, fraction = 2, message = "Fixed unit (KL) must be a valid decimal number")
    @Column(name = "fixed_unit_kl", nullable = false)
    private BigDecimal fixedUnitKl;

    @Digits(integer = 20, fraction = 2, message = "Fixed unit (GAL) must be a valid decimal number")
    @Column(name = "fixed_unit_gal", nullable = false)
    private BigDecimal fixedUnitGal;

    @Column(name = "category_type", nullable = false)  // should map to category type masters at the time of calculation
    private int categoryType;

    @Column(name = "is_regularization", nullable = false)
    private int isRegularization;

    @Size(max = 50, message = "Apply from cannot exceed 50 characters")
    @Column(name = "apply_from")
    private String applyFrom;

    @Size(max = 200, message = "Connection through cannot exceed 200 characters")
    @Column(name = "connection_through", nullable = false)
    private String connectionThrough;

//    @Column(name = "fy_id", nullable = false)
//    private int fyId;

    @Column(name = "rate_id", nullable = false)
    private int rateId;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "fy_id",referencedColumnName = "id", nullable = false)
    private WaterFinancialYearMaster waterFinancialYearMasterId;

    @ManyToOne
    @JoinColumn(name = "ferual_type_id",referencedColumnName = "id", nullable = false)
    private PipelineType pipelineTypeId;

    @ManyToOne
    @JoinColumn(name = "application_type_id",referencedColumnName = "application_type_id", nullable = false)
    private ApplicationType applicationTypeId;

    // mapped with UserBasicDetails
    @OneToMany(mappedBy = "newConnectionFormId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<UserBasicDetails> userBasicDetails;

    // mapped with ElectricityDetails
    @OneToMany(mappedBy = "newConnectionFormId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<ElectricityDetails> electricityDetails;

    // mapped with ConsumerPropertyDetails
    @OneToMany(mappedBy = "newConnectionFormId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<ConsumerPropertyDetails> consumerPropertyDetails;

    // mapped with DocumentDetails
    @OneToMany(mappedBy = "newConnectionFormId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<DocumentDetails> documentDetails;

}
