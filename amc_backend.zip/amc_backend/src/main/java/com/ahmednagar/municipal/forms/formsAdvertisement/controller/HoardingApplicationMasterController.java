package com.ahmednagar.municipal.forms.formsAdvertisement.controller;

import com.ahmednagar.municipal.exception.ApiException;
import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingApplicationMasterDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationMaster;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingApplicationMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/advertisement/hoarding/application/master/form")
@Validated
@CrossOrigin
public class HoardingApplicationMasterController {

    @Autowired
    private HoardingApplicationMasterService hoardingApplicationMasterService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingApplicationMaster> createHoardingApplicationMaster(@Valid @RequestBody HoardingApplicationMaster hoardingApplicationMaster) {
        HoardingApplicationMaster savedHoardingApplicationMaster = hoardingApplicationMasterService.saveHoardingApplicationMaster(hoardingApplicationMaster);
        return ResponseEntity.status(201).body(savedHoardingApplicationMaster);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingApplicationMasterDto>> getAllHoardingApplicationMaster() {
        List<HoardingApplicationMasterDto> hoardingApplicationMaster = hoardingApplicationMasterService.findAllHoardingApplicationMaster();
        return ResponseEntity.ok(hoardingApplicationMaster);

    }

    //for single user by Id
    @GetMapping("/getHoardingApplicationMasterById/{id}")
    public ResponseEntity<HoardingApplicationMaster> getHoardingApplicationMasterById(@PathVariable Long id) {
        HoardingApplicationMaster hoardingApplicationMaster = hoardingApplicationMasterService.findById(id);
        return ResponseEntity.ok(hoardingApplicationMaster);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingApplicationMasterByMunicipalId(@PathVariable int municipalId) {
        List<HoardingApplicationMaster> hoardingApplicationMasters = hoardingApplicationMasterService.findAllByMunicipalId(municipalId);
        if (hoardingApplicationMasters.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingApplicationMaster found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingApplicationMasters);
    }

    @GetMapping("/searchApplicationNo")
    public HoardingApplicationMaster getByApplicationNo(@RequestParam String applicationNo) {
        return hoardingApplicationMasterService.findByApplicationNo(applicationNo);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingApplicationMaster> updateHoardingApplicationMaster(@PathVariable("id") Long id, @RequestBody HoardingApplicationMaster updatedHoardingApplicationMaster) {
        try {
            HoardingApplicationMaster updated = hoardingApplicationMasterService.updateHoardingApplicationMaster(id, updatedHoardingApplicationMaster);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status) {
        hoardingApplicationMasterService.changeStatus(id, status, 1);
        return ResponseEntity.ok().build();

    }

    // licenseNo exists
    @GetMapping("/checkHoardingApplicationNoExists")
    public ResponseEntity<Boolean> checkHoardingApplicationNoExists(@RequestParam String applicationNo) {
        boolean hoardingApplicationNoExist = hoardingApplicationMasterService.isHordingApplicationNoExists(applicationNo);
        return ResponseEntity.ok(hoardingApplicationNoExist);
    }

    @DeleteMapping("/deleteHoardingApplicationMasterById/{id}")
    public ResponseEntity<ApiResponse> deleteHoardingApplicationMaster(@PathVariable Long id) {
        try {
            hoardingApplicationMasterService.deleteHoardingApplicationMasterById(id);
            ApiResponse apiResponse = new ApiResponse("HoardingApplicationMaster deleted successfully", true, LocalDateTime.now(), "SUCCESS", null, null);
            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (ResourceNotFoundException ex) {
            ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false, LocalDateTime.now(), "RESOURCE_NOT_FOUND", null, null);
            return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            throw new ApiException("Error occurred while deleting property master");
        }
    }

}

