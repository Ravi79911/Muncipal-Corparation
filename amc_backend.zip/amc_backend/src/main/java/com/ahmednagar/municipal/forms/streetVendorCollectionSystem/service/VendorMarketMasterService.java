package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorMarketMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface VendorMarketMasterService {

    VendorMarketMaster saveVendorMarketMaster(VendorMarketMaster vendorMarketMaster);
    Optional<VendorMarketMaster> getVendorMarketMasterById(Long id);
    List<VendorMarketMaster> getAllVendorMarketMasters();
    Optional<VendorMarketMaster> updateVendorMarketMaster(Long id, VendorMarketMaster vendorMarketMaster);
    Optional<VendorMarketMaster> deleteVendorMarketMaster(Long id);
}
