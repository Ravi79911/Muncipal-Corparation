package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingAllottedDemandDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingAllottedDemand;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingAllottedDemandRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingAllottedDemandService;
import com.ahmednagar.municipal.master.advertisement.repository.HoardingTypeRateMasterSetupRepository;
import com.ahmednagar.municipal.master.advertisement.repository.HoardingTypeSizeMasterSetupRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingAllottedDemandServiceImpl implements HoardingAllottedDemandService {

    @Autowired
    private HoardingAllottedDemandRepository hoardingAllottedDemandRepository;

    @Autowired
    private HoardingTypeRateMasterSetupRepository hoardingTypeRateMasterSetupRepository;

    @Autowired
    private HoardingTypeSizeMasterSetupRepository hoardingTypeSizeMasterSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingAllottedDemand saveHoardingAllottedDemand(HoardingAllottedDemand hoardingAllottedDemand) {
        hoardingAllottedDemand.setCreatedDate(LocalDateTime.now());
        hoardingAllottedDemand.setUpdatedDate(LocalDateTime.now());
        hoardingAllottedDemand.setUpdatedBy(hoardingAllottedDemand.getUpdatedBy() != null ? hoardingAllottedDemand.getUpdatedBy() : 0);
        hoardingAllottedDemand.setSuspendedStatus(hoardingAllottedDemand.getSuspendedStatus() != null ? hoardingAllottedDemand.getSuspendedStatus() : 0);

        return hoardingAllottedDemandRepository.save(hoardingAllottedDemand);

    }
    @Override
    public List<HoardingAllottedDemand> createHoardingAllottedDemandList(List<HoardingAllottedDemand> hoardingAllottedDemandList) {
        if (hoardingAllottedDemandList.isEmpty()) {
            throw new IllegalArgumentException("the list of hoardingAllottedDemandList can't be empty");
        }
        Long firstHoardingAllottedDemandId = hoardingAllottedDemandList.get(0).getHoardingApplicationDetailsId().getId();
        boolean allSameHoardingAllottedDemandId = hoardingAllottedDemandList.stream()
                .allMatch(appApplicantDetails -> Objects.equals(appApplicantDetails
                        .getHoardingApplicationDetailsId().getId(), firstHoardingAllottedDemandId));
        if (!allSameHoardingAllottedDemandId) {
            throw new IllegalArgumentException("all application details must have same application form master id");
        }
        LocalDateTime currentDate = LocalDateTime.now();
        List<HoardingAllottedDemand> hoardingAllottedDemandListToSave = hoardingAllottedDemandList.stream()
                .peek(hoardingAllottedDemand -> hoardingAllottedDemand.setCreatedDate(currentDate))
                .collect(Collectors.toList());
        return hoardingAllottedDemandRepository.saveAllAndFlush(hoardingAllottedDemandListToSave);
    }

    @Transactional
    @Override
    public void deleteHoardingAllottedDemandByHoardingApplicationMasterId(Long hoardingApplicationMasterId) {
        try {
            hoardingAllottedDemandRepository.deleteHoardingAllottedDemandByHoardingApplicationMasterId(hoardingApplicationMasterId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<HoardingAllottedDemandDto> findAllHoardingAllottedDemand() {
        List<HoardingAllottedDemand> hoardingAllottedDemands = hoardingAllottedDemandRepository.findAll();
        return hoardingAllottedDemands.stream()
                .map(hoardingAllottedDemand -> modelMapper.map(hoardingAllottedDemand, HoardingAllottedDemandDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingAllottedDemand findById(Long id) {
        Optional<HoardingAllottedDemand> hoardingAllottedDemand = hoardingAllottedDemandRepository.findById(id);
        return hoardingAllottedDemand.orElse(null);

    }

    @Override
    public List<HoardingAllottedDemand> findAllByMunicipalId(int municipalId) {
        return hoardingAllottedDemandRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingAllottedDemand updateHoardingAllottedDemand(Long id, HoardingAllottedDemand updatedHoardingAllottedDemand, int updatedBy) {
        Optional<HoardingAllottedDemand> hoardingAllottedDemandOptional = hoardingAllottedDemandRepository.findById(id);
        if (hoardingAllottedDemandOptional.isPresent()) {
            HoardingAllottedDemand existingHoardingAllottedDemand = hoardingAllottedDemandOptional.get();
            //existingHoardingAllottedDemand.setHoardingCategoryTypeName(updatedHoardingCategoryTypeMasterSetup.getHoardingCategoryTypeName());
            existingHoardingAllottedDemand.setUpdatedBy(updatedBy);
            existingHoardingAllottedDemand.setUpdatedDate(LocalDateTime.now());
            return hoardingAllottedDemandRepository.saveAndFlush(existingHoardingAllottedDemand);
        } else {
            throw new RuntimeException("HoardingAllottedDemand not found with id: " + id);
        }
    }

    @Override
    public HoardingAllottedDemand changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingAllottedDemand> hoardingAllottedDemandOpt = hoardingAllottedDemandRepository.findById(id);
        if (hoardingAllottedDemandOpt.isPresent()) {
            HoardingAllottedDemand hoardingAllottedDemand = hoardingAllottedDemandOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingAllottedDemand.setUpdatedDate(currentDateTime);
            hoardingAllottedDemand.setSuspendedStatus(status);      // 1 means suspended
            hoardingAllottedDemand.setUpdatedBy(updatedBy);
            return hoardingAllottedDemandRepository.saveAndFlush(hoardingAllottedDemand);
        }
        return null;
    }
}