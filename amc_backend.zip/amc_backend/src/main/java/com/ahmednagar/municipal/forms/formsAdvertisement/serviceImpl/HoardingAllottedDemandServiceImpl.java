package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingAllottedDemandDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingAllottedDemand;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingAllottedDemandRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingAllottedDemandService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingAllottedDemandServiceImpl implements HoardingAllottedDemandService {
    @Autowired
    private HoardingAllottedDemandRepository hoardingAllottedDemandRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingAllottedDemand saveHoardingAllottedDemand(HoardingAllottedDemand hoardingAllottedDemand) {
        hoardingAllottedDemand.setCreatedDate(LocalDateTime.now());
        hoardingAllottedDemand.setUpdatedDate(LocalDateTime.now());
        hoardingAllottedDemand.setUpdatedBy(hoardingAllottedDemand.getUpdatedBy() != null ? hoardingAllottedDemand.getUpdatedBy() : 0);
        hoardingAllottedDemand.setSuspendedStatus(hoardingAllottedDemand.getSuspendedStatus() != null ? hoardingAllottedDemand.getSuspendedStatus() : 0);

        return hoardingAllottedDemandRepository.save(hoardingAllottedDemand);

    }

    @Override
    public List<HoardingAllottedDemandDto> findAllHoardingAllottedDemand() {
        List<HoardingAllottedDemand> hoardingAllottedDemands = hoardingAllottedDemandRepository.findAll();
        return hoardingAllottedDemands.stream()
                .map(hoardingAllottedDemand -> modelMapper.map(hoardingAllottedDemand, HoardingAllottedDemandDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingAllottedDemand findById(Long id) {
        Optional<HoardingAllottedDemand> hoardingAllottedDemand=hoardingAllottedDemandRepository.findById(id);
        return hoardingAllottedDemand.orElse(null);

    }

    @Override
    public List<HoardingAllottedDemand> findAllByMunicipalId(int municipalId) {
        return hoardingAllottedDemandRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingAllottedDemand updateHoardingAllottedDemand(Long id, HoardingAllottedDemand updatedHoardingAllottedDemand, int updatedBy) {
        Optional<HoardingAllottedDemand> hoardingAllottedDemandOptional = hoardingAllottedDemandRepository.findById(id);
        if (hoardingAllottedDemandOptional.isPresent()) {
            HoardingAllottedDemand existingHoardingAllottedDemand= hoardingAllottedDemandOptional.get();
            //existingHoardingAllottedDemand.setHoardingCategoryTypeName(updatedHoardingCategoryTypeMasterSetup.getHoardingCategoryTypeName());
            existingHoardingAllottedDemand.setUpdatedBy(updatedBy);
            existingHoardingAllottedDemand.setUpdatedDate(LocalDateTime.now());
            return hoardingAllottedDemandRepository.saveAndFlush(existingHoardingAllottedDemand);
        } else {
            throw new RuntimeException("HoardingAllottedDemand not found with id: " + id);
        }
    }

    @Override
    public HoardingAllottedDemand changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingAllottedDemand> hoardingAllottedDemandOpt = hoardingAllottedDemandRepository.findById(id);
        if (hoardingAllottedDemandOpt.isPresent()) {
            HoardingAllottedDemand hoardingAllottedDemand = hoardingAllottedDemandOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingAllottedDemand.setUpdatedDate(currentDateTime);
            hoardingAllottedDemand.setSuspendedStatus(status);      // 1 means suspended
            hoardingAllottedDemand.setUpdatedBy(updatedBy);
            return hoardingAllottedDemandRepository.saveAndFlush(hoardingAllottedDemand);
        }
        return null;
    }
}