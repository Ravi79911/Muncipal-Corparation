package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationFeePayMasterDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFeePayMaster;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFirmDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationFeePayMasterRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationFeePayMasterService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ApplicationFeePayMasterServiceImpl implements ApplicationFeePayMasterService {
    @Autowired
    private ApplicationFeePayMasterRepository applicationFeePayMasterRepository;

    @Autowired
    private ModelMapper modelMapper;


    @Override
    public ApplicationFeePayMaster saveApplicationFeePayMaster(ApplicationFeePayMaster applicationFeePayMaster, int createdBy) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        applicationFeePayMaster.setCreatedDate(currentDateTime);
        applicationFeePayMaster.setSuspendedStatus(applicationFeePayMaster.getSuspendedStatus() != null ? applicationFeePayMaster.getSuspendedStatus() : 0);      // 0 means active// 1 means admin
        applicationFeePayMaster.setCreatedBy(createdBy);            // 1 means admin
        return applicationFeePayMasterRepository.saveAndFlush(applicationFeePayMaster);
    }

//    @Override
//    public List<ApplicationFeePayMasterDto> findAllApplicationFeePayMaster() {
//        List<ApplicationFeePayMaster> applicationFeePayMasters = applicationFeePayMasterRepository.findAll();
//        return applicationFeePayMasters.stream()
//                .map(applicationFeePayMaster -> modelMapper.map(applicationFeePayMaster, ApplicationFeePayMasterDto.class))
//                .collect(Collectors.toList());
//    }
//
//    @Override
//    public List<ApplicationFeePayMaster> findAllActiveApplicationFeePayMaster(Integer status) {
//        return applicationFeePayMasterRepository.findBySuspendedStatus(status);
//    }

    @Override
    public ApplicationFeePayMaster findApplicationFeePayMasterById(Long id) {
        Optional<ApplicationFeePayMaster> applicationFeePayMaster=applicationFeePayMasterRepository.findById(id);
        return applicationFeePayMaster.orElse(null);

    }

    @Override
    public List<ApplicationFeePayMasterDto> findAllApplicationFeePayMasterByMunicipalId(int municipalId) {
        List<ApplicationFeePayMaster> applicationFeePayMasters = applicationFeePayMasterRepository.findByMunicipalId(municipalId);
        return applicationFeePayMasters.stream()
                .map(applicationFeePayMaster -> modelMapper.map(applicationFeePayMaster, ApplicationFeePayMasterDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public ApplicationFeePayMaster updateApplicationFeePayMaster(Long id, ApplicationFeePayMaster updatedApplicationFeePayMaster, int updatedBy) {
        Optional<ApplicationFeePayMaster> applicationFeePayMasterOptional = applicationFeePayMasterRepository.findById(id);
        if (applicationFeePayMasterOptional.isPresent()) {
            ApplicationFeePayMaster existingApplicationFeePayMaster = applicationFeePayMasterOptional.get();
//            existingApplicationFeePayMaster.setUpdatedBy(updatedBy);
            existingApplicationFeePayMaster.setBankName(updatedApplicationFeePayMaster.getBankName());
            existingApplicationFeePayMaster.setBankBranch(updatedApplicationFeePayMaster.getBankBranch());
            existingApplicationFeePayMaster.setFeePaymentMode(updatedApplicationFeePayMaster.getFeePaymentMode());
            existingApplicationFeePayMaster.setSuspendedStatus(updatedApplicationFeePayMaster.getSuspendedStatus());
            existingApplicationFeePayMaster.setStartDate(updatedApplicationFeePayMaster.getStartDate());
            existingApplicationFeePayMaster.setEndDate(updatedApplicationFeePayMaster.getEndDate());
            existingApplicationFeePayMaster.setNoOfDays(updatedApplicationFeePayMaster.getNoOfDays());
            existingApplicationFeePayMaster.setApplicationFee(updatedApplicationFeePayMaster.getApplicationFee());
            existingApplicationFeePayMaster.setPenalty(updatedApplicationFeePayMaster.getPenalty());
            existingApplicationFeePayMaster.setDenialArrearAmount(updatedApplicationFeePayMaster.getDenialArrearAmount());
            existingApplicationFeePayMaster.setTotalFeePaid(updatedApplicationFeePayMaster.getTotalFeePaid());
            existingApplicationFeePayMaster.setFeePaymentMode(updatedApplicationFeePayMaster.getFeePaymentMode());

            return applicationFeePayMasterRepository.saveAndFlush(existingApplicationFeePayMaster);
        } else {
            throw new RuntimeException("app application Details not found with id: " + id);
        }
    }

    @Override
    public ApplicationFeePayMaster changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<ApplicationFeePayMaster> applicationFeePayMasterOptional = applicationFeePayMasterRepository.findById(id);
        if (applicationFeePayMasterOptional.isPresent()) {
            ApplicationFeePayMaster applicationFeePayMaster = applicationFeePayMasterOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            //applicationFeePayMaster.setUpdatedDate(currentDateTime);
            applicationFeePayMaster.setSuspendedStatus(status);      // 1 means suspended
            //applicationFeePayMaster.setUpdatedBy(updatedBy);
            return applicationFeePayMasterRepository.saveAndFlush(applicationFeePayMaster);
        }
        return null;
    }

    @Transactional
    @Override
    public void deleteApplicationFeePayMasterByApplicationMasterId(Long applicationMasterId) {
        try{
            applicationFeePayMasterRepository.deleteApplicationFeePayMasterByApplicationMasterId(applicationMasterId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

}
