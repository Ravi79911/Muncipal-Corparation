package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "tbl_citizen_otp_history")
public class CitizenOTPHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "email")
    private String email;

    @Column(name = "mobile_no")
    private String mobileNo;

    @Column(name = "email_otp")
    private String emailOtp;

    @Column(name = "mobile_otp")
    private String mobileOtp;

    @Column(name = "email_otp_timestamp")
    private LocalDateTime emailOtpTimestamp;

    @Column(name = "mobile_otp_timestamp")
    private LocalDateTime mobileOtpTimestamp;

    public CitizenOTPHistory(String email, String mobileNo, String emailOtp, String mobileOtp,
                             LocalDateTime emailOtpTimestamp, LocalDateTime mobileOtpTimestamp) {
        this.email = email;
        this.mobileNo = mobileNo;
        this.emailOtp = emailOtp;
        this.mobileOtp = mobileOtp;
        this.emailOtpTimestamp = emailOtpTimestamp;
        this.mobileOtpTimestamp = mobileOtpTimestamp;
    }

}
