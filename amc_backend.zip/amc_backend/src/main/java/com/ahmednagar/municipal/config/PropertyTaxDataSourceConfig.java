package com.ahmednagar.municipal.config;

import jakarta.persistence.EntityManagerFactory;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = {
                "com.ahmednagar.municipal.master.propertyTax.repository",
                "com.ahmednagar.municipal.forms.formsPropertyTax.repository"
        },
        entityManagerFactoryRef = "propertyEntityManagerFactory",
        transactionManagerRef = "propertyTransactionManager"
)
public class PropertyTaxDataSourceConfig {

    @Bean(name = "propertyDataSource")
    @Primary
    @ConfigurationProperties(prefix = "spring.property.datasource")
    public DataSource propertyDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Primary
    @Bean(name = "propertyEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean propertyEntityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                               @Qualifier("propertyDataSource") DataSource propertyDataSource) {
        return builder
                .dataSource(propertyDataSource)
                .packages(
                        "com.ahmednagar.municipal.master.propertyTax.model",
                        "com.ahmednagar.municipal.master.waterManagement.modal",
                        "com.ahmednagar.municipal.forms.formsPropertyTax.model",
                        "com.ahmednagar.municipal.forms.formsWaterManagement.model"
                )
                .persistenceUnit("propertyPU")
                .build();
    }

    @Primary
    @Bean(name = "propertyTransactionManager")
    public PlatformTransactionManager propertyTransactionManager(
            @Qualifier("propertyEntityManagerFactory") EntityManagerFactory propertyEntityManagerFactory) {
        return new JpaTransactionManager(propertyEntityManagerFactory);
    }
}
