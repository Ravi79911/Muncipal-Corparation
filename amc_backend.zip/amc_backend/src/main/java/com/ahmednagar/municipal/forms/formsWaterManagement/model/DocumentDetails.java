package com.ahmednagar.municipal.forms.formsWaterManagement.model;

import com.ahmednagar.municipal.master.waterManagement.modal.DocumentTypeMaster;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbls_consumer_document_details")
public class DocumentDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    @NotNull(message = "Appmas ID is mandatory")
//    @Column(name = "appmas_id")
//    private int appmasId;

//    @NotNull(message = "Document Mas ID is mandatory")
//    @Column(name = "document_mas_id")
//    private int documentMasId;

//    @NotNull(message = "File name path is mandatory")
    @Size(max = 500, message = "File name path should not exceed 150 characters")
    @Column(name = "file_name_path", length = 500)
    private String fileNamePath;

    @Size(max = 300, message = "File number should not exceed 200 characters")
    @Column(name = "file_name", length = 300, nullable = false)
    private String fileName;

    @NotNull(message = "Status is mandatory")
    @Column(name = "document_no")
    private String documentNum;

    @NotNull(message = "Status is mandatory")
    @Column(name = "status")
    private int status;

//    @Size(max = 2000, message = "Remarks should not exceed 2000 characters")
//    @Column(name = "remarks", length = 2000, nullable = false)
//    private String remarks;

    @NotNull(message = "Created By is mandatory")
    @Column(name = "created_by")
    private int createdBy;

//    @NotNull(message = "Created Date is mandatory")
    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private int suspendedStatus;

    @NotNull(message = "Municipal ID is mandatory")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "appmas_id", referencedColumnName = "id", nullable = false)
    private NewConnectionFormShubham newConnectionFormId;

    @ManyToOne
    @JoinColumn(name = "document_type_mas_id", referencedColumnName = "id", nullable = false)
    private DocumentTypeMaster documentTypeMasterId;
}
