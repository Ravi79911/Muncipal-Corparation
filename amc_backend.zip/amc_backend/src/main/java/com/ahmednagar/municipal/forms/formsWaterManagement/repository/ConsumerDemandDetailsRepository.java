package com.ahmednagar.municipal.forms.formsWaterManagement.repository;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerDemandDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ConsumerDemandDetailsRepository extends JpaRepository<ConsumerDemandDetails, Long> {

    @Query(value = "SELECT TOP 1 * FROM tbl_water_demand_details WHERE consumer_id = :consumerId ORDER BY generated_date DESC", nativeQuery = true)
    ConsumerDemandDetails findLatestBillByConsumerId(@Param("consumerId") Long consumerId);

//    ConsumerDemandDetails findTopByConsumerDetailsLegacyDataId_IdOrderByGeneratedDateDesc(Long consumerId);


}
