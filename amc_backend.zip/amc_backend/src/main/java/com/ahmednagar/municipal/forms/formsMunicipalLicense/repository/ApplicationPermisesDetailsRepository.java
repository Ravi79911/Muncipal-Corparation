package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationPermisesDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ApplicationPermisesDetailsRepository extends JpaRepository<ApplicationPermisesDetails,Integer> {
    List<ApplicationPermisesDetails> findByMunicipalId(int municipalId);

    List<ApplicationPermisesDetails> findBySuspendedStatus(Integer status);
}
