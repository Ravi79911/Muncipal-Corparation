package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationPermisesDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@EnableJpaRepositories
public interface ApplicationPermisesDetailsRepository extends JpaRepository<ApplicationPermisesDetails,Long> {
    List<ApplicationPermisesDetails> findByMunicipalId(int municipalId);

    List<ApplicationPermisesDetails> findBySuspendedStatus(Integer status);

    List<ApplicationPermisesDetails> findByapplicationMasterId_Id(Long applicationMasterId);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM tbl2_application_permises_details WHERE application_master_id = :applicationMasterId", nativeQuery = true)
    void deleteApplicationPermisesDetailsByApplicationMasterId(@Param("applicationMasterId") Long ApplicationFromMaster);

}
