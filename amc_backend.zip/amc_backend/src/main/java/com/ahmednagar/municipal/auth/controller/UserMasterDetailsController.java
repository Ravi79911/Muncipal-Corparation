package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.UserMasterDetails;
import com.ahmednagar.municipal.auth.service.UserMasterDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/auth")
public class UserMasterDetailsController {

    @Autowired
    UserMasterDetailsService userMasterDetailsService;

    @PostMapping("/createUserDetails")
    public ResponseEntity<?> createUserDetails(@Valid @RequestBody UserMasterDetails userMasterDetails, @RequestParam int createdBy) {
        UserMasterDetails createdUserMasterDetails = userMasterDetailsService.createUserDetails(userMasterDetails, createdBy);
        if (createdUserMasterDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdUserMasterDetails);
    }

    @PutMapping("/userDetails/update/{id}")
    public ResponseEntity<?> updateUserDetails(@PathVariable Long id, @RequestBody UserMasterDetails userMasterDetails) {
        UserMasterDetails updatedUserMasterDetails = userMasterDetailsService.updateUserDetails(id, userMasterDetails);
        if (updatedUserMasterDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedUserMasterDetails);
    }

    @PatchMapping("/userDetails/suspendedStatus/{id}")
    public ResponseEntity<?> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        UserMasterDetails updatedUserMasterDetails = userMasterDetailsService.changeSuspendedStatus(id, status);
        if (updatedUserMasterDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedUserMasterDetails);
    }

    @GetMapping("/getUserDetailsByMunicipalId/{municipalId}")
    public ResponseEntity<?> getByMunicipalId(@PathVariable Long municipalId) {
        List<UserMasterDetails> userMasterDetails = userMasterDetailsService.getUserDetailsByMunicipalId(municipalId);
        if (userMasterDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(userMasterDetails);
    }

}
