package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.MenuMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface MenuMasterRepository extends JpaRepository<MenuMaster, Long> {

    List<MenuMaster> findByMunicipalId(Long municipalId);

}
