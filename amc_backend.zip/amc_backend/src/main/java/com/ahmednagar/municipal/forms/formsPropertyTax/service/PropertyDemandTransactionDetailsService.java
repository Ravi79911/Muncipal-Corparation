package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandTransactionDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface PropertyDemandTransactionDetailsService {

    PropertyDemandTransactionDetails createPropertyDemandTransactionDetails(PropertyDemandTransactionDetails propertyDemandTransactionDetails);

    List<PropertyDemandTransactionDetails> getAllPropertyDemandTransactionDetails();

    Optional<PropertyDemandTransactionDetails> getPropertyDemandTransactionDetailsById(Long id);

    List<PropertyDemandTransactionDetails> getPropertyDemandTransactionDetailsByMunicipalId(int municipalId);

    PropertyDemandTransactionDetails patchPropertyDemandTransactionDetailsSuspendedStatus(Long id, int suspendedStatus);

}
