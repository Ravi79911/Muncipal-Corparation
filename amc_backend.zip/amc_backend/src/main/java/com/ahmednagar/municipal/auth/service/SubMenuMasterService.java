package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.model.SubMenuMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface SubMenuMasterService {

    SubMenuMaster saveSubMenu(SubMenuMaster subMenuMaster);

    List<SubMenuMaster> findAllSubMenu();

    List<SubMenuMaster> findAllSubMenuByMunicipalId(Long municipalId);

    SubMenuMaster updateSubMenu(Long id, SubMenuMaster updatedSubMenuMaster);

    SubMenuMaster changeSuspendedStatus(Long id, int status);

}
