package com.ahmednagar.municipal.master.advertisement.repository;

import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeSizeMasterSetup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface HoardingTypeSizeMasterSetupRepository extends JpaRepository<HoardingTypeSizeMasterSetup,Long> {
    List<HoardingTypeSizeMasterSetup> findAllByMunicipalId(int municipalId);
}
