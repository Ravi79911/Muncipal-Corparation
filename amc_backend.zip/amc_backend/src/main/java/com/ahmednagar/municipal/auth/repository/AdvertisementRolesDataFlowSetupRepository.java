package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.AdvertisementRolesDataFlowSetup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;


@EnableJpaRepositories
public interface AdvertisementRolesDataFlowSetupRepository extends JpaRepository<AdvertisementRolesDataFlowSetup,Long> {

    Optional<AdvertisementRolesDataFlowSetup> findByCurrentRoleIdAndStatusCodeAndIsActive(
            Long currentRoleId,
            Long statusCode,
            Integer isActive
    );

    List<AdvertisementRolesDataFlowSetup> findAllByCurrentRoleIdAndStatusCodeAndIsActive(Long currentRoleId, Long statusCode, Integer isActive);
}
