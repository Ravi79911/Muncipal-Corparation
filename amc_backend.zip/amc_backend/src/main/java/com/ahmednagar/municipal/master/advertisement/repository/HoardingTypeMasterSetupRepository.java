package com.ahmednagar.municipal.master.advertisement.repository;

import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeMasterSetup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface HoardingTypeMasterSetupRepository extends JpaRepository<HoardingTypeMasterSetup,Long> {
    List<HoardingTypeMasterSetup> findAllByMunicipalId(int municipalId);
}
