package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.AppApplicantDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.AppApplicantDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.AppApplicantDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationFromMasterRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.AppApplicantDetailsService;
import com.ahmednagar.municipal.notification.EmailService;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class AppApplicantDetailsServiceImpl implements AppApplicantDetailsService {

    @Value("${upload.license.doc.dir}")
    private String UPLOAD_DIR;
    private static final List<String> ALLOWED_EXTENSIONS = Arrays.asList(".jpg", ".jpeg", ".png");
    private static final long MAX_FILE_SIZE = 200 * 1024;

    @Autowired
    EmailService emailService;

    @Autowired
    private AppApplicantDetailsRepository appApplicantDetailsRepository;

    @Autowired
    private ApplicationFromMasterRepository applicationFromMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public AppApplicantDetails saveAppApplicationDetails(AppApplicantDetails appApplicantDetails, int createdBy) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        appApplicantDetails.setCreatedDate(currentDateTime);
        appApplicantDetails.setSuspendedStatus(appApplicantDetails.getSuspendedStatus() != null ? appApplicantDetails.getSuspendedStatus() : 0);      // 0 means active// 1 means admin
        appApplicantDetails.setCreatedBy(createdBy);            // 1 means admin
        return appApplicantDetailsRepository.saveAndFlush(appApplicantDetails);
    }

    @Override
    public List<AppApplicantDetails> createAppApplicantDetailsList(List<AppApplicantDetails> appApplicantDetailsList) {
        if (appApplicantDetailsList.isEmpty()) {
            throw new IllegalArgumentException("the list of appApplicantDetailsList can't be empty");
        }
        Long firstApplicationMasterId = appApplicantDetailsList.get(0).getApplicationMasterId().getId();
        boolean allSameApplicationMasterId = appApplicantDetailsList.stream()
                .allMatch(appApplicantDetails -> Objects.equals(appApplicantDetails
                        .getApplicationMasterId().getId(), firstApplicationMasterId));
        if (!allSameApplicationMasterId) {
            throw new IllegalArgumentException("all application details must have same application form master id");
        }
        LocalDateTime currentDate = LocalDateTime.now();
        List<AppApplicantDetails> appApplicantDetailsListToSave = appApplicantDetailsList.stream()
                .peek(appApplicantDetails -> appApplicantDetails.setCreatedDate(currentDate))
                .collect(Collectors.toList());
        return appApplicantDetailsRepository.saveAllAndFlush(appApplicantDetailsListToSave);
    }

    @Override
    public List<AppApplicantDetails> createAppApplicantDetailsLicenseList(List<AppApplicantDetails> appApplicantDetails, List<MultipartFile> applicantPhoto) {
        if (applicantPhoto != null && appApplicantDetails.size() != applicantPhoto.size()) {
            throw new IllegalArgumentException("number of owners and photographs must match");
        }

        Long expectedApplicantMasterId = null;
        List<AppApplicantDetails> savedMasters = new ArrayList<>();

        for (int i = 0; i < appApplicantDetails.size(); i++) {
            AppApplicantDetails master = appApplicantDetails.get(i);
            MultipartFile photograph = applicantPhoto != null ? applicantPhoto.get(i) : null;

            if (i == 0) {
                expectedApplicantMasterId = master.getApplicationMasterId().getId();
                if (!applicationFromMasterRepository.existsById(expectedApplicantMasterId)) {
                    throw new IllegalArgumentException("application master id " + expectedApplicantMasterId + " doesn't exist");
                }
            } else {
                if (!expectedApplicantMasterId.equals(master.getApplicationMasterId().getId())) {
                    throw new IllegalArgumentException("Application master id mismatch. All owners must belong to the same application master.");
                }
            }

            if (photograph != null && !photograph.isEmpty()) {
                if (photograph.getSize() > MAX_FILE_SIZE) {
                    throw new IllegalArgumentException("file size exceeds 200KB for owner: " + master.getFirmOwnerName());
                }

                String originalFilename = photograph.getOriginalFilename();
                String fileExtension = "";
                if (originalFilename != null && originalFilename.contains(".")) {
                    fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
                }
                if (!ALLOWED_EXTENSIONS.contains(fileExtension.toLowerCase())) {
                    throw new IllegalArgumentException("invalid file extension for owner: " + master.getFirmOwnerName() +
                            ". allowed extensions are: " + ALLOWED_EXTENSIONS);
                }

                // Save file
                String userFolderName = "Owner_Photograph";
                Path userFolderPath = Paths.get(UPLOAD_DIR, userFolderName);
                try {
                    Files.createDirectories(userFolderPath);
                    String newFileName = "Owner_Photograph_" + UUID.randomUUID() + fileExtension;
                    Path filePath = userFolderPath.resolve(newFileName);
                    Files.write(filePath, photograph.getBytes());

                    // Generate the dynamic URL
                    String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                            .path("/licenseDocumentUpload/Owner_Photograph/")
                            .path(newFileName)
                            .toUriString();

                    master.setApplicantPhoto(fileUrl);
                    log.info("File uploaded for owner: {} at URL: {}", master.getFirmOwnerName(), fileUrl);
                } catch (IOException e) {
                    throw new RuntimeException("error while saving the file for owner: " + master.getFirmOwnerName(), e);
                }
            } else {
                master.setApplicantPhoto(null);
            }

            master.setCreatedDate(LocalDateTime.now());
            savedMasters.add(appApplicantDetailsRepository.saveAndFlush(master));

            String applicationNumber = appApplicantDetailsRepository.findApplicationNoByApplicationMasterId(expectedApplicantMasterId);
            log.info("Application Number: {}", applicationNumber);
            sendOwnerRegistrationNotification(master, applicationNumber);
        }
        return savedMasters;
    }

    private void sendOwnerRegistrationNotification(AppApplicantDetails master, String applicationNumber) {
        String ownerName = master.getFirmOwnerName();
        String htmlMessageContent = buildOwnerRegistrationEmailContent(ownerName, applicationNumber);
        log.info("sending email to {}", master.getFirmOwnerEmailId());
        try {
            emailService.sendEmail(
                    master.getFirmOwnerEmailId(),
                    "Property Registration Successful",
                    htmlMessageContent
            );
            // Optional: Send SMS or WhatsApp notifications (if needed)
            // sendSMSNotification(ownerMaster);
            // sendWhatsAppNotification(ownerMaster);
        } catch (Exception e) {
            throw new RuntimeException("failed to send email to " + master.getFirmOwnerEmailId() + ": " + e.getMessage(), e);
        }
    }

    private String buildOwnerRegistrationEmailContent(String ownerName, String applicationNumber) {
        return "<div style='font-family:Arial, sans-serif; background-color:#f4f4f9; padding:30px; border-radius:10px; max-width:600px; margin:auto;'>"
                + "<div style='text-align:center; margin-bottom:20px;'>"
                + "<img src='https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png' alt='Swati Industries' style='max-width:150px; height:auto;' />"
                + "</div>"
                + "<div style='background-color:#ffffff; padding:20px; border-radius:10px; box-shadow:0 4px 8px rgba(0, 0, 0, 0.1);'>"
                + "<h2 style='color:#333333;'>Dear " + ownerName + ",</h2>"
                + "<p style='font-size:16px; color:#555555;'>Congratulations! Your property ownership registration has been successfully completed.</p>"
                + "<p style='font-size:16px; color:#555555;'><b>Application Number:</b> <span style='color:#007bff;'>" + applicationNumber + "</span></p>"
                + "<p style='font-size:16px; color:#555555;'>Please retain this application number for future reference. You can use it for tracking application status or related inquiries.</p>"
                + "<p style='font-size:16px; color:#555555;'>We appreciate your association with us and are happy to assist you further.</p>"
                + "<p style='font-size:16px; color:#555555;'>If you have any questions, feel free to reach out to us.</p>"
                + "</div>"
                + "<div style='text-align:center; margin-top:30px;'>"
                + "<p style='font-size:14px; color:#888888;'>Best regards,</p>"
                + "<p style='font-size:16px; color:#333333;'>Swati Industries</p>"
                + "<a href='https://swatiind.com/' target='_blank' style='color:#007bff; text-decoration:none; font-size:16px;'>Visit our website</a>"
                + "</div>"
                + "</div>";
    }


    @Override
    public AppApplicantDetails findAppApplicantDetailsById(Long id) {
        Optional<AppApplicantDetails> appApplicantDetails = appApplicantDetailsRepository.findById(id);
        return appApplicantDetails.orElse(null);

    }

    @Override
    public List<AppApplicantDetailsDto> findAllAppApplicantDetailsByMunicipalId(int municipalId) {
        List<AppApplicantDetails> appApplicantDetails = appApplicantDetailsRepository.findByMunicipalId(municipalId);
        return appApplicantDetails.stream()
                .map(appApplicantDetail -> modelMapper.map(appApplicantDetail, AppApplicantDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public AppApplicantDetails updateAppApplicantDetails(Long id, AppApplicantDetails updatedAppApplicantDetails) {
        Optional<AppApplicantDetails> appApplicantDetailsOptional = appApplicantDetailsRepository.findById(id);
        if (appApplicantDetailsOptional.isPresent()) {
            AppApplicantDetails existingAppApplicantDetails = appApplicantDetailsOptional.get();
            existingAppApplicantDetails.setFirmOwnerName(updatedAppApplicantDetails.getFirmOwnerName());
            existingAppApplicantDetails.setRelationName(updatedAppApplicantDetails.getRelationName());
            existingAppApplicantDetails.setFirmOwnerFatherHusbandName(updatedAppApplicantDetails.getFirmOwnerFatherHusbandName());
            existingAppApplicantDetails.setFirmOwnerMobNo(updatedAppApplicantDetails.getFirmOwnerMobNo());
            existingAppApplicantDetails.setFirmOwnerDesignation(updatedAppApplicantDetails.getFirmOwnerDesignation());
            existingAppApplicantDetails.setOwnerAddress(updatedAppApplicantDetails.getOwnerAddress());
            existingAppApplicantDetails.setFirmOwnerEmailId(updatedAppApplicantDetails.getFirmOwnerEmailId());
            //existingAppApplicantDetails.setPanNumber(updatedAppApplicantDetails.getPanNumber());
            existingAppApplicantDetails.setGender(updatedAppApplicantDetails.getGender());

            return appApplicantDetailsRepository.saveAndFlush(existingAppApplicantDetails);
        } else {
            throw new RuntimeException("app application Details not found with id: " + id);
        }
    }

    @Override
    public AppApplicantDetails changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<AppApplicantDetails> appApplicantDetailsOptional = appApplicantDetailsRepository.findById(id);
        if (appApplicantDetailsOptional.isPresent()) {
            AppApplicantDetails appApplicantDetails = appApplicantDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            //appApplicantDetails.setUpdatedDate(currentDateTime);
            appApplicantDetails.setSuspendedStatus(status);      // 1 means suspended
            //appApplicantDetails.setUpdatedBy(updatedBy);
            return appApplicantDetailsRepository.saveAndFlush(appApplicantDetails);
        }
        return null;
    }

    @Override
    @Transactional
    public void deleteAppApplicantDetailsByApplicationMasterId(Long applicationMasterId) {
        try {
            appApplicantDetailsRepository.deleteAppApplicantDetailsByApplicationMasterId(applicationMasterId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public AppApplicantDetails updateAppApplicantDetailsInList(Long id, AppApplicantDetails updatedAppApplicantDetails, MultipartFile applicantPhoto) {
        // find the specific entity by id
        Optional<AppApplicantDetails> appApplicantDetailsOptional = appApplicantDetailsRepository.findById(id);

        if (!appApplicantDetailsOptional.isPresent()) {
            throw new IllegalArgumentException("AppApplicant Details with ID " + id + " not found.");
        }

        AppApplicantDetails existingAppApplicantDetails = appApplicantDetailsOptional.get();

        // validate ownership id
        if (updatedAppApplicantDetails.getApplicationMasterId() != null && updatedAppApplicantDetails.getApplicationMasterId().getId() != null) {
            Long ownershipId = updatedAppApplicantDetails.getApplicationMasterId().getId();
            boolean ownershipExists = applicationFromMasterRepository.existsById(ownershipId);
            if (!ownershipExists) {
                throw new IllegalArgumentException("Ownership ID " + ownershipId + " does not exist in the database.");
            }
            existingAppApplicantDetails.setApplicationMasterId(updatedAppApplicantDetails.getApplicationMasterId()); // update ownership if valid
        }

        // update other fields if they are not null or blank
        existingAppApplicantDetails.setFirmOwnerName(updatedAppApplicantDetails.getFirmOwnerName());
        existingAppApplicantDetails.setRelationName(updatedAppApplicantDetails.getRelationName());
        existingAppApplicantDetails.setFirmOwnerFatherHusbandName(updatedAppApplicantDetails.getFirmOwnerFatherHusbandName());
        existingAppApplicantDetails.setFirmOwnerMobNo(updatedAppApplicantDetails.getFirmOwnerMobNo());
        existingAppApplicantDetails.setFirmOwnerDesignation(updatedAppApplicantDetails.getFirmOwnerDesignation());
        existingAppApplicantDetails.setOwnerAddress(updatedAppApplicantDetails.getOwnerAddress());
        existingAppApplicantDetails.setFirmOwnerEmailId(updatedAppApplicantDetails.getFirmOwnerEmailId());
        //existingAppApplicantDetails.setPanNumber(updatedAppApplicantDetails.getPanNumber());
        existingAppApplicantDetails.setGender(updatedAppApplicantDetails.getGender());
        deleteDocument(existingAppApplicantDetails.getApplicantPhoto());
        //existingAppApplicantDetails = handleDocumentUpload(existingAppApplicantDetails, applicantPhoto);

        // process and associate the single photo if provided
        if (applicantPhoto != null && !applicantPhoto.isEmpty()) {
            String originalFilename = applicantPhoto.getOriginalFilename();
            String fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));

            // validate file size and extension
            if (!ALLOWED_EXTENSIONS.contains(fileExtension.toLowerCase())) {
                throw new IllegalArgumentException("Invalid file extension. Allowed extensions are: " + ALLOWED_EXTENSIONS);
            }
            if (applicantPhoto.getSize() > MAX_FILE_SIZE) {
                throw new IllegalArgumentException("File size exceeds the 200KB limit");
            }
            // Save file
            String userFolderName = "Owner_Photograph";
            Path userFolderPath = Paths.get(UPLOAD_DIR, userFolderName);

//            // save the file
//            String newFileName = "Owner_Photograph_" + existingAppApplicantDetails.getId() + "_" + UUID.randomUUID() + fileExtension;
//            Path filePath = Paths.get(UPLOAD_DIR, newFileName);
            try {
                Files.createDirectories(userFolderPath);
                String newFileName = "Owner_Photograph_" + UUID.randomUUID() + fileExtension;
                Path filePath = userFolderPath.resolve(newFileName);
                Files.write(filePath, applicantPhoto.getBytes());

                // Generate URL for the uploaded photo
                String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                        .path("/licenseDocumentUpload/Owner_Photograph/")
                        //.path("Owner_Photograph/")
                        .path(newFileName)
                        .toUriString();

                existingAppApplicantDetails.setApplicantPhoto(fileUrl);
            } catch (IOException e) {
                throw new RuntimeException("Error while saving the file for owner: " + existingAppApplicantDetails.getFirmOwnerName(), e);
            }
        }

        return appApplicantDetailsRepository.saveAndFlush(existingAppApplicantDetails);
    }
    // delete old uploaded document correctly
    public void deleteDocument(String documentPath) {
        if (documentPath != null) {
            try {
                URI uri = new URI(documentPath);
                String path = uri.getPath();
                String relativeFilePath = path.replace("/advertisementDocumentUploads/", "");

                Path filePath = Paths.get(UPLOAD_DIR, relativeFilePath);
                Files.deleteIfExists(filePath);
            } catch (IOException | URISyntaxException e) {
                throw new RuntimeException("Error deleting document: " + e.getMessage(), e);
            }
        }
    }

}
