package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.AppApplicantDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.AppApplicantDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.AppApplicantDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.AppApplicantDetailsService;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyFloorMaster;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AppApplicantDetailsServiceImpl implements AppApplicantDetailsService {

    @Autowired
    private AppApplicantDetailsRepository appApplicantDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public AppApplicantDetails saveAppApplicationDetails(AppApplicantDetails appApplicantDetails, int createdBy) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        appApplicantDetails.setCreatedDate(currentDateTime);
        appApplicantDetails.setSuspendedStatus(appApplicantDetails.getSuspendedStatus() != null ? appApplicantDetails.getSuspendedStatus() : 0);      // 0 means active// 1 means admin
        appApplicantDetails.setCreatedBy(createdBy);            // 1 means admin
        return appApplicantDetailsRepository.saveAndFlush(appApplicantDetails);
    }

    @Override
    public List<AppApplicantDetails> createAppApplicantDetailsList(List<AppApplicantDetails> appApplicantDetailsList) {
        if (appApplicantDetailsList.isEmpty()) {
            throw new IllegalArgumentException("the list of appApplicantDetailsList can't be empty");
        }
        Long firstApplicationMasterId = appApplicantDetailsList.get(0).getApplicationMasterId().getId();
        boolean allSameApplicationMasterId = appApplicantDetailsList.stream()
                .allMatch(appApplicantDetails -> Objects.equals(appApplicantDetails
                        .getApplicationMasterId().getId(), firstApplicationMasterId));
        if (!allSameApplicationMasterId) {
            throw new IllegalArgumentException("all application details must have same application form master id");
        }
        LocalDateTime currentDate = LocalDateTime.now();
        List<AppApplicantDetails> appApplicantDetailsListToSave = appApplicantDetailsList.stream()
                .peek(appApplicantDetails -> appApplicantDetails.setCreatedDate(currentDate))
                .collect(Collectors.toList());
        return appApplicantDetailsRepository.saveAllAndFlush(appApplicantDetailsListToSave);
    }

    @Override
    public AppApplicantDetails findAppApplicantDetailsById(Long id) {
        Optional<AppApplicantDetails> appApplicantDetails = appApplicantDetailsRepository.findById(id);
        return appApplicantDetails.orElse(null);

    }

    @Override
    public List<AppApplicantDetailsDto> findAllAppApplicantDetailsByMunicipalId(int municipalId) {
        List<AppApplicantDetails> appApplicantDetails = appApplicantDetailsRepository.findByMunicipalId(municipalId);
        return appApplicantDetails.stream()
                .map(appApplicantDetail -> modelMapper.map(appApplicantDetail, AppApplicantDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public AppApplicantDetails updateAppApplicantDetails(Long id, AppApplicantDetails updatedAppApplicantDetails, int updatedBy) {
        Optional<AppApplicantDetails> appApplicantDetailsOptional = appApplicantDetailsRepository.findById(id);
        if (appApplicantDetailsOptional.isPresent()) {
            AppApplicantDetails existingAppApplicantDetails = appApplicantDetailsOptional.get();
            //existingAppApplicantDetails.setUpdatedBy(updatedBy);
            //existingAppApplicantDetails.setUpdatedDate(LocalDateTime.now());
            existingAppApplicantDetails.setSuspendedStatus(updatedAppApplicantDetails.getSuspendedStatus());
            existingAppApplicantDetails.setMunicipalId(updatedAppApplicantDetails.getMunicipalId());

            return appApplicantDetailsRepository.saveAndFlush(existingAppApplicantDetails);
        } else {
            throw new RuntimeException("app application Details not found with id: " + id);
        }
    }

    @Override
    public AppApplicantDetails changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<AppApplicantDetails> appApplicantDetailsOptional = appApplicantDetailsRepository.findById(id);
        if (appApplicantDetailsOptional.isPresent()) {
            AppApplicantDetails appApplicantDetails = appApplicantDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            //appApplicantDetails.setUpdatedDate(currentDateTime);
            appApplicantDetails.setSuspendedStatus(status);      // 1 means suspended
            //appApplicantDetails.setUpdatedBy(updatedBy);
            return appApplicantDetailsRepository.saveAndFlush(appApplicantDetails);
        }
        return null;
    }

}
