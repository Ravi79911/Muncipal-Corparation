package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "Tbl_TC_Market_Allotment")
public class VendorTCMarketAllotment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "effected_from")
    private LocalDate effectedFrom;

    @Column(name = "is_active")
    private Boolean isActive; // Use Float to represent real type in SQL

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "tc_user_id", referencedColumnName = "id")
    private VendorUser tcUserId;

    @ManyToOne
    @JoinColumn(name = "market_mas_id", referencedColumnName = "id")
    private VendorMarketMaster marketMasId;
}
