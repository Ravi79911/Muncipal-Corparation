package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyElectricityConnectionDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyElectricityConnectionDetailsRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyElectricityConnectionDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyElectricityConnectionDetailsServiceImpl implements PropertyElectricityConnectionDetailsService {

    @Autowired
    PropertyElectricityConnectionDetailsRepository propertyElectricityConnectionDetailsRepository;

    @Override
    public PropertyElectricityConnectionDetails createPropertyElectricityConnectionDetails(
            PropertyElectricityConnectionDetails propertyElectricityConnectionDetails) {
        if (propertyElectricityConnectionDetails.getSuspendedStatus() == null) {
            propertyElectricityConnectionDetails.setSuspendedStatus(0);
        }
        propertyElectricityConnectionDetails.setCreatedDate(LocalDateTime.now());
        return propertyElectricityConnectionDetailsRepository.saveAndFlush(propertyElectricityConnectionDetails);
    }

    @Override
    public List<PropertyElectricityConnectionDetails> getAllPropertyElectricityConnectionDetails() {
        return propertyElectricityConnectionDetailsRepository.findAll();
    }

    @Override
    public Optional<PropertyElectricityConnectionDetails> getPropertyElectricityConnectionDetailsById(int id) {
        return propertyElectricityConnectionDetailsRepository.findById(id);
    }

    @Override
    public List<PropertyElectricityConnectionDetails> getPropertyElectricityConnectionDetailsByMunicipalId(int municipalId) {
        return propertyElectricityConnectionDetailsRepository.findByMunicipalId(municipalId);
    }

    @Override
    public PropertyElectricityConnectionDetails patchPropertyElectricityDetailsSuspendedStatus(int id, int suspendedStatus) {
        Optional<PropertyElectricityConnectionDetails> patchPropertyElectricityConnection = propertyElectricityConnectionDetailsRepository.findById(id);
        if (patchPropertyElectricityConnection.isPresent()) {
            PropertyElectricityConnectionDetails existingPropertyElectricityConnection = patchPropertyElectricityConnection.get();
            existingPropertyElectricityConnection.setSuspendedStatus(suspendedStatus);
            return propertyElectricityConnectionDetailsRepository.saveAndFlush(existingPropertyElectricityConnection);
        } else {
            throw new RuntimeException("property electricity connection not found with id: " + id);
        }
    }


}
