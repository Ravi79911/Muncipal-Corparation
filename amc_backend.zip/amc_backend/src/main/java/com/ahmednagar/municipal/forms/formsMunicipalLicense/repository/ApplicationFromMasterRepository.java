package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFromMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ApplicationFromMasterRepository extends JpaRepository<ApplicationFromMaster, Long> {

    List<ApplicationFromMaster> findByMunicipalId(int municipalId);

    List<ApplicationFromMaster> findBySuspendedStatus(Integer status);

}
