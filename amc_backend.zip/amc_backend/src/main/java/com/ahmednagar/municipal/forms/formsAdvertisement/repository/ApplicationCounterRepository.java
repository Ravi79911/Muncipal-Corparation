package com.ahmednagar.municipal.forms.formsAdvertisement.repository;

import com.ahmednagar.municipal.forms.formsAdvertisement.model.ApplicationCounter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface ApplicationCounterRepository extends JpaRepository<ApplicationCounter,Long> {
    Optional<Object> findByCounterName(String counterName);
}
