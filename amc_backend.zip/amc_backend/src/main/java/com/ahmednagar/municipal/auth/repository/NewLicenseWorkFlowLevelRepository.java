package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.NewLicenseWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.ViewApplicationFromMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface NewLicenseWorkFlowLevelRepository extends JpaRepository<NewLicenseWorkFlowLevel,Long> {

    List<NewLicenseWorkFlowLevel> findByApplicationMasterId(ViewApplicationFromMaster applicationMasterId);

    @Query(value = "SELECT TOP 1 * FROM tbl_new_license_work_flow_level WHERE application_master_id = :applicationMasterId AND status_code = :statusCode ORDER BY created_date DESC", nativeQuery = true)
    Optional<NewLicenseWorkFlowLevel> findLatestWorkFlowByApplicationIdAndStatusCode(@Param("applicationMasterId") Long applicationMasterId, @Param("statusCode") Long statusCode);

}
