package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.CitizenLoginLogOffHistory;
import com.ahmednagar.municipal.auth.service.CitizenLoginLogOffHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("citizen/login/logOff/history")
public class CitizenLoginLogOffHistoryController {

    @Autowired
    CitizenLoginLogOffHistoryService citizenLoginLogOffHistoryService;

    @PostMapping("/create")
    public ResponseEntity<CitizenLoginLogOffHistory> saveCitizenLoginLogoff(@RequestBody CitizenLoginLogOffHistory citizenLoginLogoffHistory) {
        CitizenLoginLogOffHistory saved = citizenLoginLogOffHistoryService.saveCitizenLoginLogoff(citizenLoginLogoffHistory);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/all")
    public ResponseEntity<List<CitizenLoginLogOffHistory>> getAllCitizenLoginLogoffHistories() {
        List<CitizenLoginLogOffHistory> histories = citizenLoginLogOffHistoryService.getAllCitizenLoginLogoffHistories();
        return ResponseEntity.ok(histories);
    }

    @PutMapping("/updatedCitizenLoginLogoffHistory/{id}")
    public ResponseEntity<CitizenLoginLogOffHistory> updateCitizenLoginLogoff(
            @PathVariable Long id,
            @RequestBody CitizenLoginLogOffHistory citizenLoginLogoffHistory) {
        CitizenLoginLogOffHistory updated = citizenLoginLogOffHistoryService.updateCitizenLoginLogoff(id, citizenLoginLogoffHistory);
        return ResponseEntity.ok(updated);
    }

    @PatchMapping("/deleteCitizenLoginLogoffHistory/{id}")
    public ResponseEntity<Void> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false) Integer suspendedStatus) {
        citizenLoginLogOffHistoryService.changeSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok().build();
    }

}
