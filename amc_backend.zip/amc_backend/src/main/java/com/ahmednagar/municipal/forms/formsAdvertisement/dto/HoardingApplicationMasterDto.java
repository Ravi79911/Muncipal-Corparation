package com.ahmednagar.municipal.forms.formsAdvertisement.dto;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingCategoryTypeMasterSetupDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingApplicationMasterDto {
    private Long id;
    private HoardingCategoryTypeMasterSetupDto hoardingCategoryTypeMasterId;
    private Long noOfHoardings;
    private Long applicationNo;
    private Long usesTypeId;
    private LocalDateTime applicationDate;
    private LocalDateTime allocatedFromDate;
    private LocalDateTime allocatedUptoDate;
    private String nameOfAdvertiser;
    private Long advertiserMobileNo;
    private String emailId;
    private Long whatsappNo;
    private String advertiserAddress;
    private String purposeOfHoarding;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
