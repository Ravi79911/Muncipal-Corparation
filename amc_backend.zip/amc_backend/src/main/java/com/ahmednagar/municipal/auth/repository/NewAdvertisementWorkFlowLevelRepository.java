package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.NewAdvertisementWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.NewLicenseWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.ViewHoardingApplicationMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface NewAdvertisementWorkFlowLevelRepository extends JpaRepository<NewAdvertisementWorkFlowLevel,Long> {

    List<NewAdvertisementWorkFlowLevel> findByHoardingApplicationMasterId(ViewHoardingApplicationMaster hoardingApplicationMasterId);

    @Query(value = "SELECT TOP 1 * FROM tbl_new_advertisement_work_flow_level WHERE hoarding_application_master_id = :hoardingApplicationMasterId AND status_code = :statusCode ORDER BY created_date DESC", nativeQuery = true)
    Optional<NewAdvertisementWorkFlowLevel> findLatestWorkFlowByApplicationIdAndStatusCode(@Param("hoardingApplicationMasterId") Long hoardingApplicationMasterId, @Param("statusCode") Long statusCode);


    //Optional<Object> findLatestWorkFlowByApplicationIdAndStatusCode(Long applicationId, Long statusCode);
}
