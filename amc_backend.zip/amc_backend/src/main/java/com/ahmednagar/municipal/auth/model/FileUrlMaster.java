package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_file_url_master")
public class FileUrlMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "File name URL is mandatory")
    @Size(max = 50, message = "File name URL cannot exceed 50 characters")
    @Column(name = "file_name_url", nullable = false)
    private String fileNameUrl;

    @Column(name = "created_by")
    private int createdBy;

    @NotNull(message = "Created date is mandatory")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is mandatory")
    @Column(name = "municipal_id", nullable = false)
    private Long municipalId;

    @OneToMany(mappedBy = "fileUrlId",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<SubMenu> subMenus;

    @OneToMany(mappedBy = "fileUrlId",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<FilePermission> filePermissions;

    @ManyToOne
    @JoinColumn(name = "Modules_mas_id",nullable = false,referencedColumnName = "id")
    private ModuleMaster modulesMasId;

}
