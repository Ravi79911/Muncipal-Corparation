package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyDemandMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyDemandMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PropertyDemandMasterServiceImpl implements PropertyDemandMasterService {

    @Autowired
    PropertyDemandMasterRepository propertyDemandMasterRepository;

    @Autowired
    MunicipalPropertyMasterRepository municipalPropertyMasterRepository;

    // single entity creation
    @Override
    public PropertyDemandMaster createPropertyDemandMaster(PropertyDemandMaster propertyDemandMaster) {
        if (propertyDemandMaster.getSuspendedStatus() == null) {
            propertyDemandMaster.setCreatedBy(0);
        }
        propertyDemandMaster.setCreatedDate(LocalDateTime.now());
        return propertyDemandMasterRepository.save(propertyDemandMaster);
    }

    // list of entity creation
    @Override
    public List<PropertyDemandMaster> createPropertyDemandMasterList(List<PropertyDemandMaster> propertyDemandMasterList) {
        if (propertyDemandMasterList.isEmpty()) {
            throw new IllegalArgumentException("the list of PropertyDemandMaster can't be empty");
        }
        Long firstPropertyMunicipalPropertyMasterId = propertyDemandMasterList.get(0).getMunicipalPropertyMaster().getId();
        boolean allSameMunicipalPropertyMasterId = propertyDemandMasterList.stream()
                .allMatch(propertyDemandMaster -> Objects.equals(propertyDemandMaster
                        .getMunicipalPropertyMaster().getId(), firstPropertyMunicipalPropertyMasterId));
        if (!allSameMunicipalPropertyMasterId) {
            throw new IllegalArgumentException("all PropertyDemandMaster must have same municipal property master id");
        }

        // validate if the municipal property master id exists in the database
        for (PropertyDemandMaster propertyDemandMaster : propertyDemandMasterList) {
            Long municipalPropertyMasterId = propertyDemandMaster.getMunicipalPropertyMaster().getId();
            Optional<MunicipalPropertyMaster> municipalPropertyMaster = municipalPropertyMasterRepository.findById(municipalPropertyMasterId);
            if (!municipalPropertyMaster.isPresent()) {
                throw new IllegalArgumentException("MunicipalPropertyMaster with ID " + municipalPropertyMasterId + " does not exist");
            }
        }

        LocalDateTime currentDate = LocalDateTime.now();
        List<PropertyDemandMaster> propertyDemandMasterListToSave = propertyDemandMasterList.stream()
                .peek(propertyDemandMaster -> propertyDemandMaster.setCreatedDate(currentDate))
                .collect(Collectors.toList());
        return propertyDemandMasterRepository.saveAllAndFlush(propertyDemandMasterListToSave);
    }

    @Override
    public List<PropertyDemandMaster> getAllPropertyDemandMaster() {
        return propertyDemandMasterRepository.findAll();
    }

    @Override
    public Optional<PropertyDemandMaster> getPropertyDemandMasterById(Long id) {
        return propertyDemandMasterRepository.findById(id);
    }

    @Override
    public List<PropertyDemandMaster> getPropertyDemandMasterByMunicipalId(int municipalId) {
        return propertyDemandMasterRepository.findByMunicipalId(municipalId);
    }

    @Override
    public PropertyDemandMaster patchPropertyDemandMasterSuspendedStatus(Long id, int suspendedStatus) {
        Optional<PropertyDemandMaster> patchPropertyDemand = propertyDemandMasterRepository.findById(id);
        if (patchPropertyDemand.isPresent()) {
            PropertyDemandMaster existingPropertyDemand = patchPropertyDemand.get();
            existingPropertyDemand.setSuspendedStatus(suspendedStatus);
            return propertyDemandMasterRepository.saveAndFlush(existingPropertyDemand);
        } else {
            throw new RuntimeException("property demand master not found with id: " + id);
        }
    }

}
