package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyBuildingPlanDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface PropertyBuildingPlanDetailsService {

    PropertyBuildingPlanDetails createPropertyBuildingPlanDetails(PropertyBuildingPlanDetails propertyBuildingPlanDetails);

    List<PropertyBuildingPlanDetails> getAllPropertyBuildingPlanDetails();

    Optional<PropertyBuildingPlanDetails> getPropertyBuildingPlanDetailsById(int id);

    List<PropertyBuildingPlanDetails> getPropertyBuildingPlanDetailsByMunicipalId(int municipalId);

    PropertyBuildingPlanDetails patchPropertyBuildingPlanDetailsSuspendedStatus(int id, int suspendedStatus);

}
