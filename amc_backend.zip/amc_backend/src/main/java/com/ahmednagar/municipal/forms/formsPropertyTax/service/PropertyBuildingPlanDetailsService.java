package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyBuildingPlanDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface PropertyBuildingPlanDetailsService {

    PropertyBuildingPlanDetails createPropertyBuildingPlanDetails(PropertyBuildingPlanDetails propertyBuildingPlanDetails);

    List<PropertyBuildingPlanDetails> getAllPropertyBuildingPlanDetails();

    Optional<PropertyBuildingPlanDetails> getPropertyBuildingPlanDetailsById(Long id);

    List<PropertyBuildingPlanDetails> getPropertyBuildingPlanDetailsByMunicipalId(int municipalId);

    PropertyBuildingPlanDetails patchPropertyBuildingPlanDetailsSuspendedStatus(Long id, int suspendedStatus);

    PropertyBuildingPlanDetails updatePropertyBuildingPlanDetailsById(Long id, PropertyBuildingPlanDetails propertyBuildingPlanDetails);

    void deletePropertyBuildingPlanDetailsByMunicipalPropertyMasterId(Long municipalPropertyMasterId);

}
