package com.ahmednagar.municipal.config;

import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = {"com.ahmednagar.municipal.master.municipalLicence.repository","com.ahmednagar.municipal.forms.formsMunicipalLicense.repository"},
        entityManagerFactoryRef = "licenceEntityManagerFactory",
        transactionManagerRef = "licenceTransactionManager"
)
public class MunicipalLicenceDataSourceConfig {

    @Bean(name = "licenceDataSource")
    @ConfigurationProperties(prefix = "spring.licence.datasource")
    public DataSource licenceDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "licenceEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean licenceEntityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                              @Qualifier("licenceDataSource") DataSource licenceDataSource) {
        return builder.dataSource(licenceDataSource)
                .packages("com.ahmednagar.municipal.master.municipalLicence.model","com.ahmednagar.municipal.forms.formsMunicipalLicense.model")
                .persistenceUnit("licencePU")
                .build();
    }

    @Bean(name = "licenceTransactionManager")
    public PlatformTransactionManager licenceTransactionManager(
            @Qualifier("licenceEntityManagerFactory") EntityManagerFactory licenceEntityManagerFactory) {
        return new JpaTransactionManager(licenceEntityManagerFactory);
    }
}
