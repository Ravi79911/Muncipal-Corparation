package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ApplicationPermisesDetailsDto {
    private int id;
    private ApplicationFromMasterDto applicationMasterId;
    private int permisesOwsershipId;
    private LocalDateTime rentAgreementDate;
    private String agreementNo;
    private Date agreementValidFrom;
    private Date agreementValidUpto;
    private String agreementBetweenFirstPartyName;
    private String agreementBetweenSecondPartyName;
    private String holdingPropertyNo;
    private String leaseRentedPeriod;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;
}
