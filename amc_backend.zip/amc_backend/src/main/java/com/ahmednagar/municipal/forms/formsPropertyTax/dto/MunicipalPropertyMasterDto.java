package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MunicipalPropertyMasterDto {

    private Long id;
    private String applicationNo;
    private LocalDateTime applicationDate;
    private String holdingNo;
    private String modeOfTransfer;
    private LocalDate dateOfTransfer;
    private String landKhataNo;
    private String plotNo;
    private BigDecimal areaOfLandSqft;
    private BigDecimal areaOfLandDecimal;
    private String propertyAge;
    private String villageMaujaName;
    private String propertyAddress;
    private String propertyCity;
    private String propertyDistrict;
    private String propertyState;
    private Long propertyPinCode;
    private String propertyCorrespondenceAddress;
    private String propertyCorrespondenceCity;
    private String propertyCorrespondenceDistrict;
    private String propertyCorrespondenceState;
    private Long propertyCorrespondencePinCode;
    private int municipalId;
    private Integer createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private Long financialYearMasterId;
    private Long propertyAssismentTypeId;
    private Long zoneId;
    private Long zoneWardId;
    private Long ownerShipId;
    private Long propertyTypeId;
    private Long propertyCategoryUsesTypeId;
    private Long roadTypeId;

}
