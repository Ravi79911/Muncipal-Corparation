package com.ahmednagar.municipal.exception;

import lombok.Data;

@Data
public class ProfileUpdateException extends RuntimeException {

    public ProfileUpdateException(String message) {
        super(message);
    }

    public ProfileUpdateException(String message, Throwable cause) {
        super(message, cause);
    }

}
