package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_view_application_from_master")
public class ViewApplicationFromMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "application_no")
    private String applicationNo;

    @Column(name = "application_applied_from")
    @NotNull(message = "Application Applied From is required")
    @Size(max = 50, message = "Application Applied From cannot exceed 50 characters")
    private String applicationAppliedFrom;

    @Column(name = "application_date")
    @NotNull(message = "Application Date is required")
    private LocalDateTime applicationDate;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "application_type_id", nullable = false, referencedColumnName = "id")
    private ViewTradeApplicationTypeMasters viewTradeApplicationTypeMasters;

    @ManyToOne
    @JoinColumn(name = "firm_type_id", nullable = false, referencedColumnName = "id")
    private ViewMlFirmTypeMasters viewMlFirmTypeMasters;

    @ManyToOne
    @JoinColumn(name = "permisses_ownership_id", nullable = false, referencedColumnName = "id")
    private ViewMlBusinessPremisesMasters viewMlBusinessPremisesMasters;

    @ToString.Exclude
    @ManyToOne
    @JoinColumn(name = "business_cat_id", nullable = false, referencedColumnName = "id")
    private ViewMlTradeTypeMasters viewMlTradeTypeMasters;

    @Column(name = "nature_of_business_id")
    private Long mlBusinessNature;

    @ManyToOne
    @JoinColumn(name = "applied_fy_year_id", referencedColumnName = "id")
    private ViewLicenseFinancialYearMaster viewLicenseFinancialYearMaster;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewApplicationFromMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewAppApplicantDetails> viewAppApplicantDetails = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewApplicationFromMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewApplicationDocumentsDetails> viewApplicationDocumentsDetails = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewApplicationFromMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewApplicationElectricityDetails> viewApplicationElectricityDetails = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewApplicationFromMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewApplicationFeePayMaster> viewApplicationFeePayMasters = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewApplicationFromMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewApplicationFirmDetails> viewApplicationFirmDetails = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewApplicationFromMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewApplicationLicenseDetails> viewApplicationLicenseDetails = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewApplicationFromMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewApplicationPermisesDetails> viewApplicationPermisesDetails = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewApplicationFromMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewRenewalSurrenderAmendmentAppliedDetails> viewRenewalSurrenderAmendmentAppliedDetails = null;

}
