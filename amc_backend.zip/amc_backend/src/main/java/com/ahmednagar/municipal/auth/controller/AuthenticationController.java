package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.jwt.JwtHelper;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.UserMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/auth")
public class AuthenticationController {

    @Autowired
    UserMasterRepository userMasterRepository;

    @Autowired
    UserDetailsService userDetailsService;

    @Autowired
    AuthenticationManager manager;

    @Autowired
    JwtHelper helper;

    @PostMapping("/authenticate")
    public ResponseEntity<?> login(@RequestBody JwtRequest request) {

        String usernameOrMobile = request.getEmail(); // this can be email or mobile number
        String password = request.getPassword();

        // authenticate the user
        this.doAuthenticate(usernameOrMobile, password);

        // load user details
        UserDetails userDetails = userDetailsService.loadUserByUsername(usernameOrMobile);

        if (!(userDetails instanceof org.springframework.security.core.userdetails.User)) {
            return new ResponseEntity<>("User details type mismatch", HttpStatus.BAD_REQUEST);
        }

        // now, retrieve the actual UserMaster from the database
        UserMaster userMaster = userMasterRepository.findByEmail(usernameOrMobile).orElse(null);
        if (userMaster == null) {
            return new ResponseEntity<>("User not found", HttpStatus.BAD_REQUEST);
        }

        // check OTP and verification status
        if (!userMaster.isMobileVerified()) {
            LoginResponse loginResponse = new LoginResponse("Please verify with mobile OTP", userMaster.getId(), userMaster.getEmail(),
                    userMaster.getMobileNo(), userMaster.getRoleMaster().getRoleName(), userMaster.getRoleMaster().getGroupName());
            return new ResponseEntity<>(loginResponse, HttpStatus.BAD_REQUEST);
        }

        if (!userMaster.isEmailVerified()) {
            LoginResponse loginResponse = new LoginResponse("Please verify with email OTP", userMaster.getId(), userMaster.getEmail(),
                    userMaster.getMobileNo(), userMaster.getRoleMaster().getRoleName(), userMaster.getRoleMaster().getGroupName());
            return new ResponseEntity<>(loginResponse, HttpStatus.BAD_REQUEST);
        }

        if (!userMaster.isVerified()) {
            LoginResponse loginResponse = new LoginResponse("Account not fully verified yet", userMaster.getId(), userMaster.getEmail(),
                    userMaster.getMobileNo(), userMaster.getRoleMaster().getRoleName(), userMaster.getRoleMaster().getGroupName());
            return new ResponseEntity<>(loginResponse, HttpStatus.BAD_REQUEST);
        }

        // generate JWT tokens
        String accessToken = helper.generateAccessToken(userMaster);
        String refreshToken = helper.generateRefreshToken(userMaster);

        // return response with tokens
        JwtResponse response = JwtResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .username(userMaster.getEmail())
                .mobileNumber(userMaster.getMobileNo())
                .userId(userMaster.getId())
                .role(userMaster.getRoleMaster().getRoleName())
                .groupName(userMaster.getRoleMaster().getGroupName())
                .build();

        return new ResponseEntity<>(response, HttpStatus.OK);

//=========================================================================================================================================

//        this.doAuthenticate(request.getEmail(), request.getPassword());
//
//        UserDetails userDetails = userDetailsService.loadUserByUsername(request.getEmail());
//        if (userDetails.isEnabled()) {
//            String token = this.helper.generateToken(userDetails);
//
//            JwtResponse response = JwtResponse.builder()
//                    .jwtToken(token)
//                    .username(userDetails.getUsername()).build();
//            return new ResponseEntity<>(response, HttpStatus.OK);
//        }
//        return null;

    }

    @PostMapping("/refreshToken")
    public ResponseEntity<?> refreshToken(@RequestBody RefreshTokenRequest request) {

        String refreshToken = request.getRefreshToken();
        String username = null;

        // extract the username from the refresh token
        try {
            username = helper.getUsernameFromToken(refreshToken);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("invalid or expired refresh token");
        }

        // load user details using the username
        UserDetails userDetails = userDetailsService.loadUserByUsername(username);

        // now, get the actual UserMaster from the database
        UserMaster userMaster = userMasterRepository.findByEmail(username).orElse(null);
        if (userMaster == null) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("user not found");
        }

        // validate the refresh token
        if (helper.validateToken(refreshToken, userDetails)) {
            // generate new access token and refresh token
            String newAccessToken = helper.generateAccessToken(userDetails);
            String newRefreshToken = helper.generateRefreshToken(userDetails);

            // return the new tokens along with user details
            JwtResponse response = JwtResponse.builder()
                    .accessToken(newAccessToken)
                    .refreshToken(newRefreshToken)
                    .username(userMaster.getEmail())
                    .mobileNumber(userMaster.getMobileNo())
                    .userId(userMaster.getId())
                    .role(userMaster.getRoleMaster().getRoleName())
                    .groupName(userMaster.getRoleMaster().getGroupName())
                    .build();

            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("invalid or expired refresh token");
        }
    }

    private void doAuthenticate(String usernameOrMobile, String password) {
        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(usernameOrMobile, password);
        try {
            manager.authenticate(authentication);
        } catch (BadCredentialsException e) {
            throw new BadCredentialsException("Invalid credentials, please check your username or password");
        }
    }

}
