package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorTCMarketAllotment;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface VendorTCMarketAllotmentService {

    VendorTCMarketAllotment saveVendorTCMarketAllotment(VendorTCMarketAllotment vendorTCMarketAllotment);
    List<VendorTCMarketAllotment> getAllVendorTCMarketAllotment();
    Optional<VendorTCMarketAllotment> getVendorTCMarketAllotmentById(Long id);
    Optional<VendorTCMarketAllotment> updateVendorTCMarketAllotment(Long id, VendorTCMarketAllotment vendorTCMarketAllotment);
    Optional<VendorTCMarketAllotment> deleteVendorTCMarketAllotment(Long id);
}
