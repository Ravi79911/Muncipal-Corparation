package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbls_view_consumer_property_details")
public class ViewConsumerPropertyDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

//    @Size(max = 25, message = "Zone name cannot exceed 50 characters")
//    @Column(name = "zone_name", nullable = false)
//    private String zoneName;
//
//    @Size(max = 25, message = "Ward name cannot exceed 50 characters")
//    @Column(name = "ward_name", nullable = false)
//    private String wardName;

    @Size(max = 50, message = "Holding number cannot exceed 50 characters")
    @Column(name = "holding_no", nullable = false)
    private String holdingNo;

    @Size(max = 50, message = "Khata number cannot exceed 50 characters")
    @Column(name = "khata_no", nullable = false)
    private String khataNo;

    @Size(max = 50, message = "Plot number cannot exceed 50 characters")
    @Column(name = "plot_no", nullable = false)
    private String plotNo;

    @Digits(integer = 18, fraction = 2, message = "Length area must be a valid decimal number")
    @Column(name = "length_area", nullable = false)
    private BigDecimal lengthArea;

    @Digits(integer = 18, fraction = 2, message = "Breath area must be a valid decimal number")
    @Column(name = "breath_area", nullable = false)
    private BigDecimal breathArea;

    @Digits(integer = 18, fraction = 2, message = "Buildup area in square feet must be a valid decimal number")
    @Column(name = "buildup_area_sqft", nullable = false)
    private BigDecimal buildupAreaSqft;

    @Digits(integer = 18, fraction = 2, message = "Buildup area in square meters must be a valid decimal number")
    @Column(name = "buildup_area_sqmtr", nullable = false)
    private BigDecimal buildupAreaSqmtr;

    @NotNull(message = "Number of flats cannot be null")
    @Column(name = "nosOfFlats", nullable = false)
    private int nosOfFlats;

    @NotNull(message = "Property master ID cannot be null")
    @Column(name = "property_mas_id", nullable = false)
    private int propertyMasId;

    @NotNull(message = "Created by cannot be null")
    @Column(name = "created_by", nullable = false)
    private int createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @NotNull(message = "Suspended status cannot be null")
    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID cannot be null")
    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

    // Newly added fields
    @Size(max = 500, message = "Property address cannot exceed 500 characters")
    @Column(name = "property_address", nullable = false)
    private String propertyAddress;

    @Size(max = 50, message = "City cannot exceed 50 characters")
    @Column(name = "city", nullable = false)
    private String city;

    @Size(max = 50, message = "District cannot exceed 50 characters")
    @Column(name = "district", nullable = false)
    private String district;

    @Size(max = 50, message = "State cannot exceed 50 characters")
    @Column(name = "state", nullable = false)
    private String state;

    @Digits(integer = 6, fraction = 0, message = "Pincode must be a 6-digit number")
    @Column(name = "pincode", nullable = false)
    private long pincode;

    @Size(max = 100, message = "Landmark cannot exceed 100 characters")
    @Column(name = "landmark", nullable = false)
    private String landmark;

    @Column(name = "ownership_type_id")
    private Long OwnershipType;

    @Column(name="sub_uses_type_id")
    private Long DDWaterPropertySubCategoryUsesType;

    @Column(name="uses_type_id")
    private Long DDWaterPropertyUsesType;

    @Column(name="roadtype_id")
    private Long DDWaterRoadType;

    @ManyToOne
    @JoinColumn(name = "ward_name", referencedColumnName = "id")
    private AuthWardMaster authWardMaster;

    @ManyToOne
    @JoinColumn(name = "zone_name", referencedColumnName = "id", nullable = false)
    private AuthZoneMaster authZoneMaster;

    @ManyToOne
    @JoinColumn(name = "appmas_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewNewWaterConnectionFormMaster viewNewWaterConnectionFormMaster;

}
