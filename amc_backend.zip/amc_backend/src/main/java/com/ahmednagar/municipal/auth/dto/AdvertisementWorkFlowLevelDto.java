package com.ahmednagar.municipal.auth.dto;

import com.ahmednagar.municipal.auth.model.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AdvertisementWorkFlowLevelDto {

    private Long id;
    private String status;
    private Long statusCode;
    private Integer mailStatus;
    private String remarks;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;
    private ViewHoardingApplicationMaster hoardingApplicationMasterId;
    private ViewHoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterId;
    private UserMasterDTO currentUserId;
    private UserMasterDTO nextUserId;
    private WorkFlowMaster workFlowMasterId;
    private CitizenSignUpMaster citizenId;

}
