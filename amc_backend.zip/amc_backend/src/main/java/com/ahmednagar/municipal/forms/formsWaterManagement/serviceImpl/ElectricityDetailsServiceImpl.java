package com.ahmednagar.municipal.forms.formsWaterManagement.serviceImpl;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ElectricityDetails;
import com.ahmednagar.municipal.forms.formsWaterManagement.repository.ElectricityDetailsRepository;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.ElectricityDetailsServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ElectricityDetailsServiceImpl implements ElectricityDetailsServices {

    @Autowired
    private ElectricityDetailsRepository electricityDetailsRepository;

    @Override
    public ElectricityDetails createElectricityDetails(ElectricityDetails electricityDetails, int createdBy) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        electricityDetails.setCreatedDate(currentDateTime);
        electricityDetails.setCreatedBy(createdBy);         // createdBy is the user ID == 1 as of now
        electricityDetails.setSuspendedStatus(electricityDetails.getSuspendedStatus() != null ? electricityDetails.getSuspendedStatus() : 0);   // 0 means active
//        electricityDetails.setUpdatedDate(currentDateTime);
//        electricityDetails.setUpdatedBy(createdBy);         // updatedBy is the user ID == 1 as of now
        return electricityDetailsRepository.saveAndFlush(electricityDetails);
    }

//    @Override
//    public ElectricityDetails updateElectricityDetails(int id, ElectricityDetails electricityDetails, int updatedBy) {
//        Optional<ElectricityDetails> electricityDetailsById = electricityDetailsRepository.findById(id);
//        if(electricityDetailsById.isPresent()){
//            ElectricityDetails  electricityDetailsEntity = electricityDetailsById.get();
////            electricityDetailsEntity.setAppmasId(electricityDetails.getAppmasId());
//            electricityDetailsEntity.setNewConnectionFormId(electricityDetails.getNewConnectionFormId());
//            electricityDetailsEntity.setKno(electricityDetails.getKno());
//            electricityDetailsEntity.setBindBookNo(electricityDetails.getBindBookNo());
//            electricityDetailsEntity.setAccountNo(electricityDetails.getAccountNo());
//            electricityDetailsEntity.setCategoryType(electricityDetails.getCategoryType());
////            electricityDetailsEntity.setUpdatedDate(electricityDetails.getUpdatedDate());
////            electricityDetailsEntity.setUpdatedBy(updatedBy);
//            return electricityDetailsRepository.saveAndFlush(electricityDetailsEntity);
//        }
//        return null;
//    }

    @Override
    public ElectricityDetails deleteElectricityDetails(int id, int status, int updatedBy) {
        Optional<ElectricityDetails> electricityDetailsById = electricityDetailsRepository.findById(id);
        if(electricityDetailsById.isPresent()){
            ElectricityDetails  electricityDetailsEntity = electricityDetailsById.get();
            electricityDetailsEntity.setSuspendedStatus(status);
//            electricityDetailsEntity.setUpdatedDate(LocalDateTime.now());
//            electricityDetailsEntity.setUpdatedBy(updatedBy);
            return electricityDetailsRepository.saveAndFlush(electricityDetailsEntity);
        }
        return null;
    }

    @Override
    public List<ElectricityDetails> getAllElectricityByMunicipalId(int municipalId) {
        return electricityDetailsRepository.findByMunicipalId(municipalId);
    }

//    @Override
//    public ElectricityDetails getElectricityDetailsbyId(int id) {
//        return electricityDetailsRepository.findById(id).orElse(null);
//    }

}
