package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Builder
@Table(name = "tbl_work_flow_level")
public class WorkFlowLevel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "status")
    private String status;

    @Column(name = "status_code")
    private Long statusCode;

    @Column(name = "mail_status")
    private Integer mailStatus;

    @Column(name = "remarks")
    private String remarks;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @Transient
    private List<Long> rejectedDocumentIds;

    @ManyToOne
    @JoinColumn(name = "application_id", referencedColumnName = "id", nullable = false)
    private ViewMunicipalPropertyMaster applicationId;

    @ManyToOne
    @JoinColumn(name = "current_user_id", referencedColumnName = "id")
    private UserMaster currentUserId;

    @ManyToOne
    @JoinColumn(name = "next_user_id", referencedColumnName = "id")
    private UserMaster nextUserId;

    @ManyToOne
    @JoinColumn(name = "work_flow_master_id", nullable = false, referencedColumnName = "id")
    private WorkFlowMaster workFlowMasterId;

    @ManyToOne
    @JoinColumn(name = "citizen_id", referencedColumnName = "id")
    private CitizenSignUpMaster citizenId;

}
