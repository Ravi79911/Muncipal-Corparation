package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_view_property_assisment_type_master")
public class ViewPropertyAssismentTypeMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "property assisment type name is required")
    @Column(name = "property_assisment_type_name")
    private String propertyAssismentTypeName;

    @NotNull(message = "created by is required")
    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

//    @OneToMany(mappedBy = "propertyAssismentType", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    private Set<PropertyUploadDocumentMaster> propertyUploadDocumentMasters;

}
