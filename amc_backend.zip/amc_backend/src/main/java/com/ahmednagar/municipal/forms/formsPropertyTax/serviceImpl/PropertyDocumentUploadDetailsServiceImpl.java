package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDocumentUploadDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyDocumentUploadDetailsRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyDocumentUploadDetailsService;
import com.ahmednagar.municipal.master.propertyTax.model.PropertyUploadDocumentMaster;
import com.ahmednagar.municipal.master.propertyTax.repository.PropertyUploadDocumentMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class PropertyDocumentUploadDetailsServiceImpl implements PropertyDocumentUploadDetailsService {

    //private static final String BASE_UPLOAD_DIR = "D:\\muncipal_demo\\ahmednagar_muncipal\\src\\main\\resources\\propertyDocumentUploads";
    private static final long MAX_FILE_SIZE = 2 * 1024 * 1024; // 2MB

    @Value("${upload.base.dir}")
    private String BASE_UPLOAD_DIR;

    @Autowired
    PropertyDocumentUploadDetailsRepository propertyDocumentUploadDetailsRepository;

    @Autowired
    PropertyUploadDocumentMasterRepository propertyUploadDocumentMasterRepository;

    @Override
    public PropertyDocumentUploadDetails createPropertyDocumentUploadDetails(PropertyDocumentUploadDetails propertyDocumentUploadDetails, MultipartFile documentPath) {
        Long masterId = propertyDocumentUploadDetails.getPropertyUploadDocumentMaster().getId();
        PropertyUploadDocumentMaster master = propertyUploadDocumentMasterRepository.findById(masterId)
                .orElseThrow(() -> new IllegalArgumentException("invalid document master id"));

        String documentName = master.getDocumentName();
        if (documentName == null || documentName.isEmpty()) {
            throw new IllegalArgumentException("document name is missing");
        }

        documentName = documentName.replace(" ", "_");

        if (documentPath != null && !documentPath.isEmpty()) {
            if (!isPdf(documentPath)) {
                throw new IllegalArgumentException("only pdf files are allowed");
            }
            if (documentPath.getSize() > MAX_FILE_SIZE) {
                throw new IllegalArgumentException("file size exceeds the maximum limit of " + MAX_FILE_SIZE / (1024 * 1024) + " MB.");
            }
            try {
                byte[] fileBytes = documentPath.getBytes();
                Path typeDirectory = Paths.get(BASE_UPLOAD_DIR, documentName);
                if (!Files.exists(typeDirectory)) {
                    Files.createDirectories(typeDirectory);
                }
                String newFileName = documentName + "_" + UUID.randomUUID() + ".pdf";
                newFileName = newFileName.replace(" ", "_");
                Path filePath = typeDirectory.resolve(newFileName);
                Files.write(filePath, fileBytes);
                propertyDocumentUploadDetails.setDocumentPath(filePath.toString());

                System.out.println("UPLOAD_DIR: " + BASE_UPLOAD_DIR);
                System.out.println("Document Path: " + propertyDocumentUploadDetails.getDocumentPath());

                propertyDocumentUploadDetails.setCreatedDate(LocalDateTime.now());
                return propertyDocumentUploadDetailsRepository.saveAndFlush(propertyDocumentUploadDetails);

            } catch (IOException e) {
                throw new RuntimeException("error while saving the document: " + e.getMessage(), e);
            }
        } else {
            throw new IllegalArgumentException("uploaded file is null or empty");
        }
    }

    // check allowed extension at the time of save
    private boolean isPdf(MultipartFile file) {
        String contentType = file.getContentType();
        String fileName = file.getOriginalFilename();
        return (contentType != null && contentType.equalsIgnoreCase("application/pdf")) ||
                (fileName != null && fileName.toLowerCase().endsWith(".pdf"));
    }

    @Override
    public Resource loadPropertyDocumentUploadDetails(Long id) throws IOException {
        PropertyDocumentUploadDetails propertyDocumentUploadDetails = propertyDocumentUploadDetailsRepository.findById(id)
                .orElseThrow(() -> new IOException("property document upload details not found with id: " + id));
        String fileName = propertyDocumentUploadDetails.getDocumentPath();
        if (fileName == null || fileName.isEmpty()) {
            throw new IOException("property document upload details not found for id: " + id);
        }
        Path path = Paths.get(BASE_UPLOAD_DIR, fileName);
        return new FileSystemResource(path.toFile());
    }

    @Override
    public List<PropertyDocumentUploadDetails> getAllPropertyDocumentUploadDetails() {
        return propertyDocumentUploadDetailsRepository.findAll();
    }

    @Override
    public Optional<PropertyDocumentUploadDetails> getPropertyDocumentUploadDetailsById(Long id) {
        return propertyDocumentUploadDetailsRepository.findById(id);
    }

    @Override
    public List<PropertyDocumentUploadDetails> getPropertyDocumentUploadDetailsByMunicipalId(int municipalId) {
        return propertyDocumentUploadDetailsRepository.findByMunicipalId(municipalId);
    }

    @Override
    public PropertyDocumentUploadDetails patchPropertyDocumentUploadDetailsSuspendedStatus(Long id, int suspendedStatus) {
        Optional<PropertyDocumentUploadDetails> patchPropertyDocumentUpload = propertyDocumentUploadDetailsRepository.findById(id);
        if (patchPropertyDocumentUpload.isPresent()) {
            PropertyDocumentUploadDetails existingPropertyDocumentUpload = patchPropertyDocumentUpload.get();
            existingPropertyDocumentUpload.setSuspendedStatus(suspendedStatus);
            return propertyDocumentUploadDetailsRepository.saveAndFlush(existingPropertyDocumentUpload);
        } else {
            throw new RuntimeException("property document upload details not found with id: " + id);
        }
    }

}
