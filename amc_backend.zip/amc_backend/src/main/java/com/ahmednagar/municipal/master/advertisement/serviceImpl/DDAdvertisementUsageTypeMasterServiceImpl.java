package com.ahmednagar.municipal.master.advertisement.serviceImpl;

import com.ahmednagar.municipal.master.advertisement.model.DDAdvertisementUsageTypeMaster;
import com.ahmednagar.municipal.master.advertisement.repository.DDAdvertisementUsageTypeMasterRepository;
import com.ahmednagar.municipal.master.advertisement.service.DDAdvertisementUsageTypeMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DDAdvertisementUsageTypeMasterServiceImpl implements DDAdvertisementUsageTypeMasterService {

    @Autowired
    private DDAdvertisementUsageTypeMasterRepository ddAuthUsageTypeMasterRepository;


    @Override
    public List<DDAdvertisementUsageTypeMaster> findAllDDAuthUsageTypeMaster() {
        return ddAuthUsageTypeMasterRepository.findAll();
    }
}
