package com.ahmednagar.municipal.forms.formsPropertyTax.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_muni_property_demand_transaction_master")
public class PropertyDemandTransactionMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "transaction number is required")
    @Size(max = 50, message = "transaction number can't exceed 50 characters")
    @Column(name = "transaction_no")
    private String transactionNo;

    @NotNull(message = "transaction date is required")
    @Column(name = "transaction_date")
    private LocalDate transactionDate;

    @NotNull(message = "amount is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "amount must be greater than 0")
    @Column(name = "amount")
    private float amount;

    @NotBlank(message = "rebates any is required")
    @Size(max = 50, message = "rebates can't exceed 50 characters")
    @Column(name = "rebates_any")
    private String rebatesAny;

    @NotBlank(message = "penalty calculation any is required")
    @Size(max = 50, message = "penalty calculation can't exceed 50 characters")
    @Column(name = "penalty_calcu_any")
    private String penaltyCalcuAny;

    @Column(name = "penality_duration_from")
    private LocalDate penaltyDurationFrom;

    @Column(name = "penality_duration_upto")
    private LocalDate penaltyDurationUpto;

    @Column(name = "collect_demand_id_from")
    private LocalDate collectDemandIdFrom;

    @Column(name = "collect_demand_id_upto")
    private LocalDate collectDemandIdUpto;

    @NotBlank(message = "transaction type is required")
    @Size(max = 50, message = "transaction type can't exceed 50 characters")
    @Column(name = "transaction_type_cash_cheque_online_etc")
    private String transactionType;

    @NotBlank(message = "bank reconciliation status is required")
    @Size(max = 50, message = "bank reconciliation status can't exceed 50 characters")
    @Column(name = "bank_reconcilation_status")
    private String bankReconciliationStatus;

    @NotBlank(message = "payment status is required")
    @Size(max = 50, message = "payment status can't exceed 50 characters")
    @Column(name = "payment_status_paid_bal")
    private String paymentStatusPaidBal;

    @NotBlank(message = "remarks any is required")
    @Size(max = 50, message = "remarks can't exceed 50 characters")
    @Column(name = "remarks_any")
    private String remarksAny;

    @NotBlank(message = "bank reconcile id is required")
    @Size(max = 50, message = "bank reconcile id can't exceed 50 characters")
    @Column(name = "bank_reconcile_id")
    private String bankReconcileId;

    @NotBlank(message = "reconciliation status is required")
    @Size(max = 50, message = "reconciliation status can't exceed 50 characters")
    @Column(name = "reconcilation_status")
    private String reconciliationStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @NotNull(message = "created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Min(value = 0, message = "suspended status must be 0 (inactive) or 1 (active)")
    @Max(value = 1, message = "suspended status must be 0 (inactive) or 1 (active)")
    @Column(name = "suspended_status")
    private int suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
    private MunicipalPropertyMaster municipalPropertyMaster;

    @OneToMany(mappedBy = "propertyDemandTransactionMaster", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<PropertyDemandTransactionDetails> propertyDemandTransactionDetails;

}
