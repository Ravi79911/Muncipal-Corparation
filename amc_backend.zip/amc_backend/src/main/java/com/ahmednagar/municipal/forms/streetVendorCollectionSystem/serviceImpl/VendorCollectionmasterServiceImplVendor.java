package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionMaster;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorCollectionMasterRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorCollectionMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VendorCollectionmasterServiceImplVendor implements VendorCollectionMasterService {

    @Autowired
    private VendorCollectionMasterRepository collectionmasterRepositoryVendor;

    @Override
    public VendorCollectionMaster saveCollectionMaster(VendorCollectionMaster vendorCollectionMaster) {
        vendorCollectionMaster.setCreatedDate(LocalDateTime.now());
        vendorCollectionMaster.setSuspendedStatus(0);
        return collectionmasterRepositoryVendor.save(vendorCollectionMaster);
    }

    @Override
    public List<VendorCollectionMaster> getAllCollectionMaster() {
        return collectionmasterRepositoryVendor.findBySuspendedStatus(0);
    }

    @Override
    public Optional<VendorCollectionMaster> deleteCollectionMaster(Long id) {
        Optional<VendorCollectionMaster> vendorCollectionMaster = collectionmasterRepositoryVendor.findById(id);
        vendorCollectionMaster.get().setSuspendedStatus(1);
        return Optional.of(collectionmasterRepositoryVendor.saveAndFlush(vendorCollectionMaster.get()));
    }
}
