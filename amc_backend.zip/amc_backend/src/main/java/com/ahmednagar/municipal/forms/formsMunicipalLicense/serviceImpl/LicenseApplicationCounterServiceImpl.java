package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseApplicationCounter;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.LicenseApplicationCounterRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.LicenseApplicationCounterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LicenseApplicationCounterServiceImpl implements LicenseApplicationCounterService {

    @Autowired
    private LicenseApplicationCounterRepository licenseApplicationCounterRepository;

    @Override
    public int getNextCounterValue(String counterName) {
        LicenseApplicationCounter licenseApplicationCounter = (LicenseApplicationCounter) licenseApplicationCounterRepository.findByCounterName(counterName)
                .orElseThrow(() -> new IllegalStateException("licenseApplicationCounter not found: " + counterName));

//        System.out.println("Current counter value: " + counter.getCounterValue());

        int nextValue = licenseApplicationCounter.getCounterValue() + 1;
        licenseApplicationCounter.setCounterValue(nextValue);

//        System.out.println("New counter value: " + nextValue);

        licenseApplicationCounterRepository.saveAndFlush(licenseApplicationCounter);
        return nextValue;
    }
}
