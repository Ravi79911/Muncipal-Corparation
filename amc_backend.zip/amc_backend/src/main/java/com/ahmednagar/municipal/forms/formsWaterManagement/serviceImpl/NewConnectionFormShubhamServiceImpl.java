package com.ahmednagar.municipal.forms.formsWaterManagement.serviceImpl;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.NewConnectionFormShubham;
import com.ahmednagar.municipal.forms.formsWaterManagement.repository.NewConnectionFormShubhamRepository;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.NewConnectionFormShubhamService;
import com.ahmednagar.municipal.forms.formsWaterManagement.utils.ApplicationNoGenerator;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class NewConnectionFormShubhamServiceImpl implements NewConnectionFormShubhamService {
    @Autowired
    private NewConnectionFormShubhamRepository newConnectionFormShubhamRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public NewConnectionFormShubham saveNewConnectionFormShubham(NewConnectionFormShubham newConnectionFormShubham, int createdBy) {
        String generatedApplicationNumber = ApplicationNoGenerator.generateApplicationNo();
        newConnectionFormShubham.setAutogenFNumber(generatedApplicationNumber);
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        newConnectionFormShubham.setCreatedDate(currentDateTime);
        newConnectionFormShubham.setSuspendedStatus(newConnectionFormShubham.getSuspendedStatus() != null ? newConnectionFormShubham.getSuspendedStatus() : 0);      // 0 means active
        newConnectionFormShubham.setCreatedBy(createdBy);            // 1 means admin
        return newConnectionFormShubhamRepository.saveAndFlush(newConnectionFormShubham);
    }

    @Override
    public NewConnectionFormShubham deleteNewConnectionForm(int id, int suspendedStatus) {
        Optional<NewConnectionFormShubham> newConnectionFormShubham = newConnectionFormShubhamRepository.findById(id);
        if(newConnectionFormShubham.isPresent()) {
            NewConnectionFormShubham newConnectionFormShubhamToBeDeleted = newConnectionFormShubham.get();
            newConnectionFormShubhamToBeDeleted.setSuspendedStatus(suspendedStatus);
            return newConnectionFormShubhamRepository.saveAndFlush(newConnectionFormShubhamToBeDeleted);
        }
        return null;
    }

    @Override
    public List<NewConnectionFormShubham> findByMunicipalId(int municipalId) {
        return newConnectionFormShubhamRepository.findByMunicipalId(municipalId);
    }

}
