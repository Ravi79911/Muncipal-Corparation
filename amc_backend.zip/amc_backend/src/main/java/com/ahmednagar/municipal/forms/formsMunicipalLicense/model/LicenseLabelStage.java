package com.ahmednagar.municipal.forms.formsMunicipalLicense.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb3_license_label_stage")
public class LicenseLabelStage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @NotNull(message = "Name cannot be null")
    @Size(max = 150, message = "Name cannot exceed 150 characters")
    @Column(name = "name")
    private String name;

    @NotNull(message = "Role cannot be null")
    @Size(max = 150, message = "Role cannot exceed 150 characters")
    @Column(name = "role")
    private String role;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private int updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private Long municipalId;

    @OneToMany(mappedBy = "stageId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<LicenseApplicationWorkflow> licenseApplicationWorkflows;
}
