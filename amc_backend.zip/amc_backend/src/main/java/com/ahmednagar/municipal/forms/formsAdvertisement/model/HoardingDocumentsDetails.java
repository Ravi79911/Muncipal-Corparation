package com.ahmednagar.municipal.forms.formsAdvertisement.model;

import com.ahmednagar.municipal.master.advertisement.model.HoardingDocumentSubCategoryMasterSetup;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb2_hoarding_documents_details")
public class HoardingDocumentsDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name = "document_file_name")
    @NotNull
    @Size(max = 150, message = "document file name cannot exceed 150 characters")
    private String documentFileName;

    @Column(name = "document_url", nullable = false)
    @NotBlank(message = "Document URL cannot be blank")
    @Size(max = 150, message = "Document URL cannot exceed 150 characters")
    private String documentUrl;

//    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @Column(name = "approved_status")
    private Float approvedStatus;

    @JsonBackReference
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "hoarding_application_master_id", nullable = false, referencedColumnName = "id")
    private HoardingApplicationMaster hoardingApplicationMasterId;

    @JsonBackReference
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "hoarding_documents_sub_category_master_id", nullable = false, referencedColumnName = "id")
    private HoardingDocumentSubCategoryMasterSetup hoardingDocumentsSubCategoryMasterId;

}
