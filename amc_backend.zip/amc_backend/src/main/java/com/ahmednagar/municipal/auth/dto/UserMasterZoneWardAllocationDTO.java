package com.ahmednagar.municipal.auth.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserMasterZoneWardAllocationDTO {

    private Long zoneId;
    private String zoneName;
    private Long wardId;
    private String wardNo;

}
