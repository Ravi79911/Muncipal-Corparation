package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.CitizenLoginLogOffHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CitizenLoginLogOffHistoryRepository extends JpaRepository<CitizenLoginLogOffHistory, Long> {

}
