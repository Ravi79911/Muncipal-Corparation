package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorZoneWard;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface VendorZoneWardService {

    List<VendorZoneWard> getByZoneWardByZoneId(Long zoneId);
}
