package com.ahmednagar.municipal.forms.formsWaterManagement.service;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerPropertyDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ConsumerPropertyDetailsService {

    ConsumerPropertyDetails deleteConsumerPropertyDetails(int id, int suspendedStatus);

    ConsumerPropertyDetails saveConsumerPropertyDetails(ConsumerPropertyDetails consumerPropertyDetails, int createdBy);

    List<ConsumerPropertyDetails> getConsumerPropertyByMunicipalId(int municipalId);

}