package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseApplicationAutoTransfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface LicenseApplicationAutoTransferRepository extends JpaRepository<LicenseApplicationAutoTransfer,Long> {
}
