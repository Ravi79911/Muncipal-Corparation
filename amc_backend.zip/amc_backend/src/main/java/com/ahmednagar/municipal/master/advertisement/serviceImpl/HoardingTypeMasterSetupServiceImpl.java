package com.ahmednagar.municipal.master.advertisement.serviceImpl;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingTypeMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeMasterSetup;
import com.ahmednagar.municipal.master.advertisement.repository.HoardingTypeMasterSetupRepository;
import com.ahmednagar.municipal.master.advertisement.service.HoardingTypeMasterSetupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingTypeMasterSetupServiceImpl implements HoardingTypeMasterSetupService {
    @Autowired
    private HoardingTypeMasterSetupRepository hoardingTypeMasterSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingTypeMasterSetup saveHoardingTypeMasterSetup(HoardingTypeMasterSetup hoardingTypeMasterSetup) {
        hoardingTypeMasterSetup.setCreatedDate(LocalDateTime.now());
        hoardingTypeMasterSetup.setUpdatedDate(LocalDateTime.now());
        hoardingTypeMasterSetup.setUpdatedBy(hoardingTypeMasterSetup.getUpdatedBy() != null ? hoardingTypeMasterSetup.getUpdatedBy() : 0);
        hoardingTypeMasterSetup.setSuspendedStatus(hoardingTypeMasterSetup.getSuspendedStatus() != null ? hoardingTypeMasterSetup.getSuspendedStatus() : 0);

        return hoardingTypeMasterSetupRepository.save(hoardingTypeMasterSetup);

    }

    @Override
    public List<HoardingTypeMasterSetupDto> findAllHoardingTypeMasterSetup() {
        List<HoardingTypeMasterSetup> hoardingTypeMasterSetups = hoardingTypeMasterSetupRepository.findAll();
        return hoardingTypeMasterSetups.stream()
                .map(hoardingTypeMasterSetup -> modelMapper.map(hoardingTypeMasterSetup, HoardingTypeMasterSetupDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingTypeMasterSetup findById(Long id) {
        Optional<HoardingTypeMasterSetup> hoardingTypeMasterSetup=hoardingTypeMasterSetupRepository.findById(id);
        return hoardingTypeMasterSetup.orElse(null);

    }

    @Override
    public List<HoardingTypeMasterSetup> findAllByMunicipalId(int municipalId) {
        return hoardingTypeMasterSetupRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingTypeMasterSetup updateHoardingTypeMasterSetup(Long id, HoardingTypeMasterSetup updatedHoardingTypeMasterSetup, int updatedBy) {
        Optional<HoardingTypeMasterSetup> hoardingTypeMasterSetupOptional = hoardingTypeMasterSetupRepository.findById(id);
        if (hoardingTypeMasterSetupOptional.isPresent()) {
            HoardingTypeMasterSetup existingHoardingTypeMasterSetup= hoardingTypeMasterSetupOptional.get();
            existingHoardingTypeMasterSetup.setHoardingTypeName(updatedHoardingTypeMasterSetup.getHoardingTypeName());
            existingHoardingTypeMasterSetup.setUpdatedBy(updatedBy);
            existingHoardingTypeMasterSetup.setUpdatedDate(LocalDateTime.now());
            return hoardingTypeMasterSetupRepository.saveAndFlush(existingHoardingTypeMasterSetup);
        } else {
            throw new RuntimeException("HoardingTypeMasterSetup not found with id: " + id);
        }
    }

    @Override
    public HoardingTypeMasterSetup changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingTypeMasterSetup> hoardingTypeMasterSetupOpt = hoardingTypeMasterSetupRepository.findById(id);
        if (hoardingTypeMasterSetupOpt.isPresent()) {
            HoardingTypeMasterSetup hoardingTypeMasterSetup = hoardingTypeMasterSetupOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingTypeMasterSetup.setUpdatedDate(currentDateTime);
            hoardingTypeMasterSetup.setSuspendedStatus(status);      // 1 means suspended
            hoardingTypeMasterSetup.setUpdatedBy(updatedBy);
            return hoardingTypeMasterSetupRepository.saveAndFlush(hoardingTypeMasterSetup);
        }
        return null;
    }
}
