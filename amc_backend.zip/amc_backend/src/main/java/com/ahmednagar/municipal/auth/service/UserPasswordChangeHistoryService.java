package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.UserPasswordChangeHistoryDto;
import com.ahmednagar.municipal.auth.model.UserPasswordChangeHistory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserPasswordChangeHistoryService {
    UserPasswordChangeHistory savedUserPasswordChangeHistory(UserPasswordChangeHistory userPasswordChangeHistory);

    List<UserPasswordChangeHistoryDto> findAllUserPasswordChangeHistory();

    List<UserPasswordChangeHistoryDto> findAllUserPasswordChangeHistoryByMunicipalId(Long municipalId);

    UserPasswordChangeHistory updateUserPasswordChangeHistory(Long id, UserPasswordChangeHistory updatedUserPasswordChangeHistory);

    UserPasswordChangeHistory changeStatus(Long id, Integer status);
}
