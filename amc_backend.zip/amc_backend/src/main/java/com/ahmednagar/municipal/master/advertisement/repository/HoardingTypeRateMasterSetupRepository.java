package com.ahmednagar.municipal.master.advertisement.repository;

import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeRateMasterSetup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface HoardingTypeRateMasterSetupRepository extends JpaRepository<HoardingTypeRateMasterSetup,Long> {
    List<HoardingTypeRateMasterSetup> findAllByMunicipalId(int municipalId);
}
