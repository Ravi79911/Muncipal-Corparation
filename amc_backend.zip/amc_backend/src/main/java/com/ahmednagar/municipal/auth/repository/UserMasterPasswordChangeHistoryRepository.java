package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.UserMasterPasswordChangeHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;

@EnableJpaRepositories
public interface UserMasterPasswordChangeHistoryRepository extends JpaRepository<UserMasterPasswordChangeHistory, Long> {

//    List<UserMasterPasswordChangeHistory> findByUserIdOrderByPwdChangedDateTimeDesc(Long userId);

//    @Query("SELECT u FROM UserMasterPasswordChangeHistory u WHERE u.userMasterId = :userMasterId")
//    List<UserMasterPasswordChangeHistory> findByUserMasterId(@Param("userMasterId") Long userMasterId);

    @Query("SELECT u, um FROM UserMasterPasswordChangeHistory u " +
            "JOIN UserMaster um ON u.userMasterId = um.id " +
            "WHERE u.userMasterId = :userMasterId")
    List<UserMasterPasswordChangeHistory> findPasswordChangeHistoryWithUserMaster(@Param("userMasterId") Long userMasterId);

//    List<UserMasterPasswordChangeHistory> findByMunicipalId(Long municipalId);

}
