package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDocumentUploadDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface PropertyDocumentUploadDetailsRepository extends JpaRepository<PropertyDocumentUploadDetails, Long> {

    List<PropertyDocumentUploadDetails> findByMunicipalId(int municipalId);

    List<PropertyDocumentUploadDetails> findByMunicipalPropertyMaster_Id(Long propertyMasId);

}
