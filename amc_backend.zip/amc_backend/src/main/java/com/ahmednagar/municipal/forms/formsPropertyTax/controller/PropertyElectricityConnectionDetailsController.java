package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyElectricityConnectionDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyElectricityConnectionDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/forms")
public class PropertyElectricityConnectionDetailsController {

    @Autowired
    PropertyElectricityConnectionDetailsService propertyElectricityConnectionDetailsService;

    @PostMapping("/createElectricityConnectionDetails")
    public ResponseEntity<PropertyElectricityConnectionDetails> createElectricityConnection(@Valid @RequestBody PropertyElectricityConnectionDetails propertyElectricityConnectionDetails) {
        PropertyElectricityConnectionDetails newPropertyElectricity = propertyElectricityConnectionDetailsService.createPropertyElectricityConnectionDetails(propertyElectricityConnectionDetails);
        return ResponseEntity.ok(newPropertyElectricity);
    }

    @GetMapping("/getAllElectricityConnectionDetails")
    public ResponseEntity<List<PropertyElectricityConnectionDetails>> getAllElectricityConnection() {
        return ResponseEntity.ok(propertyElectricityConnectionDetailsService.getAllPropertyElectricityConnectionDetails());
    }

    @GetMapping("/electricityConnectionDetails/{id}")
    public ResponseEntity<Object> getElectricityConnectionById(@PathVariable int id) {
        Optional<PropertyElectricityConnectionDetails> propertyElectricityConnection = propertyElectricityConnectionDetailsService.getPropertyElectricityConnectionDetailsById(id);
        if (propertyElectricityConnection.isPresent()) {
            return ResponseEntity.ok(propertyElectricityConnection.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getElectricityConnectionDetailsByMunicipalId/{municipalId}")
    public List<PropertyElectricityConnectionDetails> getElectricityConnectionByMunicipalId(@PathVariable int municipalId) {
        return propertyElectricityConnectionDetailsService.getPropertyElectricityConnectionDetailsByMunicipalId(municipalId);
    }

    @PatchMapping("/electricityConnectionDetails/suspendedStatus/{id}")
    public ResponseEntity<PropertyElectricityConnectionDetails> patchElectricityConnectionSuspendedStatus(@PathVariable int id, @RequestParam int suspendedStatus) {
        PropertyElectricityConnectionDetails patchedPropertyElectricityConnection = propertyElectricityConnectionDetailsService.patchPropertyElectricityDetailsSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedPropertyElectricityConnection);
    }

}
