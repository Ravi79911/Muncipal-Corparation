package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.exception.ApiException;
import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyElectricityConnectionDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyElectricityConnectionDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/forms")
public class PropertyElectricityConnectionDetailsController {

    @Autowired
    PropertyElectricityConnectionDetailsService propertyElectricityConnectionDetailsService;

    @PostMapping("/createElectricityConnectionDetails")
    public ResponseEntity<PropertyElectricityConnectionDetails> createElectricityConnection(@Valid @RequestBody PropertyElectricityConnectionDetails propertyElectricityConnectionDetails) {
        PropertyElectricityConnectionDetails newPropertyElectricity = propertyElectricityConnectionDetailsService.createPropertyElectricityConnectionDetails(propertyElectricityConnectionDetails);
        return ResponseEntity.ok(newPropertyElectricity);
    }

    @GetMapping("/getAllElectricityConnectionDetails")
    public ResponseEntity<List<PropertyElectricityConnectionDetails>> getAllElectricityConnection() {
        return ResponseEntity.ok(propertyElectricityConnectionDetailsService.getAllPropertyElectricityConnectionDetails());
    }

    @GetMapping("/electricityConnectionDetails/{id}")
    public ResponseEntity<Object> getElectricityConnectionById(@PathVariable Long id) {
        Optional<PropertyElectricityConnectionDetails> propertyElectricityConnection = propertyElectricityConnectionDetailsService.getPropertyElectricityConnectionDetailsById(id);
        if (propertyElectricityConnection.isPresent()) {
            return ResponseEntity.ok(propertyElectricityConnection.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getElectricityConnectionDetailsByMunicipalId/{municipalId}")
    public List<PropertyElectricityConnectionDetails> getElectricityConnectionByMunicipalId(@PathVariable int municipalId) {
        return propertyElectricityConnectionDetailsService.getPropertyElectricityConnectionDetailsByMunicipalId(municipalId);
    }

    @PatchMapping("/electricityConnectionDetails/suspendedStatus/{id}")
    public ResponseEntity<PropertyElectricityConnectionDetails> patchElectricityConnectionSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        PropertyElectricityConnectionDetails patchedPropertyElectricityConnection = propertyElectricityConnectionDetailsService.patchPropertyElectricityDetailsSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedPropertyElectricityConnection);
    }

    @PutMapping("/updatePropertyElectricityConnectionDetailsById/{id}")
    public ResponseEntity<ApiResponse> updatePropertyElectricityConnectionDetailsById(@PathVariable Long id,
                                                                                      @RequestBody PropertyElectricityConnectionDetails propertyElectricityConnectionDetails) {
        try {
            PropertyElectricityConnectionDetails updatedDetails = propertyElectricityConnectionDetailsService.updatePropertyElectricityConnectionDetailsById(id, propertyElectricityConnectionDetails);
            return ResponseEntity.ok(new ApiResponse("Property Electricity Connection updated successfully!", true, updatedDetails));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (ApiException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An internal error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/deletePropertyElectricityConnectionDetails/{municipalPropertyMasterId}")
    public ResponseEntity<String> deletePropertyElectricityConnectionDetails(@PathVariable Long
                                                                                     municipalPropertyMasterId) {
        try {
            propertyElectricityConnectionDetailsService.deletePropertyElectricityConnectionDetailsByMunicipalPropertyMasterId(municipalPropertyMasterId);
            return ResponseEntity.ok("PropertyElectricityConnectionDetails details records deleted successfully for MunicipalPropertyMaster id: " + municipalPropertyMasterId);
        } catch (Exception ex) {
            return ResponseEntity.status(500).body("An unexpected error occurred: " + ex.getMessage());
        }
    }

}
