package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_menu_master")
public class MenuMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "menu name is mandatory")
    @Size(max = 50, message = "menu name can't exceed 50 characters")
    @Column(name = "menu_name", nullable = false)
    private String menuName;

    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is mandatory")
    @Column(name = "municipal_id", nullable = false)
    private Long municipalId;

    @ManyToOne
    @JoinColumn(name = "module_id", nullable = false, referencedColumnName = "id")
    private ModuleMaster moduleMaster;

//    @OneToMany(mappedBy = "menuId",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
//    //@JsonIgnore
//    private Set<SubMenu> subMenus;

//    @OneToMany(mappedBy = "menuId",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
//    //@JsonIgnore
//    private Set<MenuPermission> menuPermissions;

}
