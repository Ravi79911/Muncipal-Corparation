package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AppApplicantDetailsDto {
    private int id;
    private ApplicationFromMasterDto applicationMasterId;
    private String firmOwnerName;
    private String relationName;
    private String firmOwnerFatherHusbandName;
    private String firmOwnerMobNo;
    private String firmOwnerEmailId;
    private String panNumber;
    private String firmOwnerDesignation;
    private String gender;
    private String ownerAddress;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;


}
