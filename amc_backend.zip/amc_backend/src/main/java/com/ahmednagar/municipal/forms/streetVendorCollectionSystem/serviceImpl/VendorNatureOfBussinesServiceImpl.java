package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorNatureOfBussines;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorNatureOfBussinesRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorNatureOfBussinesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VendorNatureOfBussinesServiceImpl implements VendorNatureOfBussinesService {

    @Autowired
    private VendorNatureOfBussinesRepository vendorNatureOfBussinesRepository;

    @Override
    public VendorNatureOfBussines saveVendorNatureOfBussines(VendorNatureOfBussines vendorNatureOfBussines) {
        vendorNatureOfBussines.setCreatedDate(LocalDateTime.now());
        vendorNatureOfBussines.setSuspendedStatus(0);
        vendorNatureOfBussinesRepository.saveAndFlush(vendorNatureOfBussines);
        return vendorNatureOfBussines;
    }

    @Override
    public Optional<VendorNatureOfBussines> getVendorNatureOfBussinesById(Long id) {
        return vendorNatureOfBussinesRepository.findById(id);
    }

    @Override
    public Optional<VendorNatureOfBussines> updateVendorNatureOfBussines(Long id, VendorNatureOfBussines vendorNatureOfBussines) {
        Optional<VendorNatureOfBussines> existingVendorNatureOfBussines = vendorNatureOfBussinesRepository.findById(id);
        if (existingVendorNatureOfBussines.isPresent()) {
            VendorNatureOfBussines updatedVendorNatureOfBussines = existingVendorNatureOfBussines.get();
            updatedVendorNatureOfBussines.setBusinessNameEng(vendorNatureOfBussines.getBusinessNameEng());
            updatedVendorNatureOfBussines.setBusinessNameMrathi(vendorNatureOfBussines.getBusinessNameMrathi());
            updatedVendorNatureOfBussines.setUpdatedDate(LocalDateTime.now());
            updatedVendorNatureOfBussines.setUpdatedBy(vendorNatureOfBussines.getUpdatedBy());
            vendorNatureOfBussinesRepository.saveAndFlush(updatedVendorNatureOfBussines);
            return Optional.of(updatedVendorNatureOfBussines);
        }
        return Optional.empty();
    }

    @Override
    public Optional<VendorNatureOfBussines> deleteVendorNatureOfBussines(Long id) {
        Optional<VendorNatureOfBussines> existingVendorNatureOfBussines = vendorNatureOfBussinesRepository.findById(id);
        if (existingVendorNatureOfBussines.isPresent()) {
            VendorNatureOfBussines deletedVendorNatureOfBussines = existingVendorNatureOfBussines.get();
            deletedVendorNatureOfBussines.setSuspendedStatus(1);
            vendorNatureOfBussinesRepository.saveAndFlush(deletedVendorNatureOfBussines);
            return Optional.of(deletedVendorNatureOfBussines);
        }
        return Optional.empty();
    }

    @Override
    public List<VendorNatureOfBussines> getAllVendorNatureOfBussines() {
        return vendorNatureOfBussinesRepository.findBySuspendedStatus(0);
    }
}
