package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "Table_Nature_Of_Bussines")
public class VendorNatureOfBussines {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "bussines_name_eng")
    private String businessNameEng;

    @Column(name = "bussines_name_marathi")
    private String businessNameMrathi;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;
}
