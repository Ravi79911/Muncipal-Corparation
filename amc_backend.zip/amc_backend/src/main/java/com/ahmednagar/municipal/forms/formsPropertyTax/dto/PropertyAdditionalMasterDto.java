//package com.ahmednagar.municipal.forms.formsPropertyTax.dto;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@AllArgsConstructor
//@NoArgsConstructor
//@Data
//public class PropertyAdditionalMasterDto {
//
//    private int id;
//    private int propertyMasterId;
//    private boolean hasMobileTowerFlag;
//    private boolean hasHoardingBoardFlag;
//    private boolean hasPetrolPumpFlag;
//    private boolean hasRainHarvestingProvisionFlag;
//    private int municipalId;
//    private int createdBy;
//    private int suspendedStatus;
//
//}
