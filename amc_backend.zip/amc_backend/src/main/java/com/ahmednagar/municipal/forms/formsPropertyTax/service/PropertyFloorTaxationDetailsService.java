package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.dto.PropertyFloorTaxationDetailsDto;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyFloorTaxationDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface PropertyFloorTaxationDetailsService {

    PropertyFloorTaxationDetails createPropertyFloorTaxationDetails(PropertyFloorTaxationDetails propertyFloorTaxationDetails);

    PropertyFloorTaxationDetails findPropertyFloorTaxationDetailsById(Long id);

    List<PropertyFloorTaxationDetailsDto> findAllPropertyFloorTaxationDetailsByMunicipalId(int municipalId);

    PropertyFloorTaxationDetails updatePropertyFloorTaxationDetails(Long id, PropertyFloorTaxationDetails updatedPropertyFloorTaxationDetails, int updatedBy);

    PropertyFloorTaxationDetails changeSuspendedStatus(Long id, int status, int updatedBy);

}
