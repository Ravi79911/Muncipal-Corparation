package com.ahmednagar.municipal.master.advertisement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingDocumentSubCategoryMasterSetupDto {
    private Long id;
    private HoardingDocumentCategoryMasterSetupDto hoardingDocumentCategoryMasterId;
    private String subCategoryName;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
