package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionVerification;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorCollectionVerifiedRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorCollectionVerifiedService;
import com.ahmednagar.municipal.master.propertyTax.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class VendorCollectionVerificationImpl implements VendorCollectionVerifiedService {

    @Autowired
    private VendorCollectionVerifiedRepository vendorCollectionVerifiedRepository;

    @Override
    public VendorCollectionVerification saveVendorCollectionVerification(VendorCollectionVerification vendorCollectionVerification) {
        vendorCollectionVerification.setCreatedDate(LocalDateTime.now());
        vendorCollectionVerification.setSuspendedStatus(0);
        return vendorCollectionVerifiedRepository.save(vendorCollectionVerification);
    }

    @Override
    public List<VendorCollectionVerification> updateVendorCollectionVerifications(
            List<Long> ids, List<VendorCollectionVerification> updatedDataList) {

        if (ids.size() != updatedDataList.size()) {
            throw new IllegalArgumentException("The size of IDs and updated data must match.");
        }

        List<VendorCollectionVerification> updatedRecords = new ArrayList<>();

        for (int i = 0; i < ids.size(); i++) {
            Long id = ids.get(i);
            VendorCollectionVerification updatedData = updatedDataList.get(i);

            Optional<VendorCollectionVerification> vendorCollectionVerification =
                    vendorCollectionVerifiedRepository.findById(id);

            if (vendorCollectionVerification.isPresent()) {
                VendorCollectionVerification existingRecord = vendorCollectionVerification.get();
                existingRecord.setVerifiedStatus(updatedData.getVerifiedStatus());
                existingRecord.setVerifiedAmount(updatedData.getVerifiedAmount());
                existingRecord.setVerificationDateTime(LocalDateTime.now());
                existingRecord.setVerifiedByUserid(updatedData.getVerifiedByUserid());

                updatedRecords.add(existingRecord);
            } else {
                throw new ResourceNotFoundException("VendorCollectionVerification", "id", id);
            }
        }

        vendorCollectionVerifiedRepository.saveAll(updatedRecords);
        return updatedRecords;
    }



    @Override
    public List<VendorCollectionVerification> getAllVendorCollectionVerifications() {
        return vendorCollectionVerifiedRepository.findAll();
    }

    @Override
    public Optional<VendorCollectionVerification> getVendorCollectionVerificationById(Long id) {
        return vendorCollectionVerifiedRepository.findById(id);
    }


//    @Override
//    public List<VendorCollectionVerification> getFilteredRecords(Long zoneId, Long zoneWardId, LocalDate dateFrom,
//                                                                 LocalDate dateTo, Long vendorUserId, String verifiedStatus) {
//        LocalDateTime startDateTime = (dateFrom != null) ? dateFrom.atStartOfDay() : null;
//        LocalDateTime endDateTime = (dateTo != null) ? dateTo.atTime(LocalTime.MAX) : null;
//        return vendorCollectionVerifiedRepository.findFiltered(zoneId, zoneWardId, startDateTime, endDateTime, vendorUserId, verifiedStatus);
//    }


    @Override
    public List<VendorCollectionVerification> getByCreatedDateAndVendorUserId(LocalDate createdDate, Long vendorUserId) {
        LocalDateTime startDateTime = (createdDate != null) ? createdDate.atStartOfDay() : null;
        LocalDateTime endDateTime = (createdDate != null) ? createdDate.atTime(LocalTime.MAX) : null;

        return vendorCollectionVerifiedRepository.findByCreatedDateAndVendorUserId(startDateTime, endDateTime, vendorUserId);
    }






}
