package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.ViewNewWaterConnectionFormMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories

public interface ViewNewWaterConnectionFormMasterRepository extends JpaRepository<ViewNewWaterConnectionFormMaster,Long> {
}
