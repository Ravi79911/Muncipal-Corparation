package com.ahmednagar.municipal.forms.formsWaterManagement.serviceImpl;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerPropertyDetails;
import com.ahmednagar.municipal.forms.formsWaterManagement.repository.ConsumerPropertyDetailsRepository;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.ConsumerPropertyDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ConsumerPropertyDetailsServiceImpl implements ConsumerPropertyDetailsService {

    @Autowired
    private ConsumerPropertyDetailsRepository consumerPropertyDetailsRepository;

    @Override
    public ConsumerPropertyDetails deleteConsumerPropertyDetails(int id, int suspendedStatus) {
        Optional<ConsumerPropertyDetails> consumerPropertyDetailsById = consumerPropertyDetailsRepository.findById(id);
        if (consumerPropertyDetailsById.isPresent()) {
            ConsumerPropertyDetails consumerPropertyDetailsEntity = consumerPropertyDetailsById.get();
            consumerPropertyDetailsEntity.setSuspendedStatus(suspendedStatus);
            return consumerPropertyDetailsRepository.saveAndFlush(consumerPropertyDetailsEntity);
        }
        return null;
    }

    @Override
    public ConsumerPropertyDetails saveConsumerPropertyDetails(ConsumerPropertyDetails consumerPropertyDetails, int createdBy) {
        consumerPropertyDetails.setCreatedDate(LocalDateTime.now());
        consumerPropertyDetails.setCreatedBy(createdBy);
        return consumerPropertyDetailsRepository.saveAndFlush(consumerPropertyDetails);
    }

    @Override
    public List<ConsumerPropertyDetails> getConsumerPropertyByMunicipalId(int municipalId) {
        return consumerPropertyDetailsRepository.findByMunicipalId(municipalId);
    }
}
