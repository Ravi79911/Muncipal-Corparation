package com.ahmednagar.municipal.forms.formsWaterManagement.model;

import com.ahmednagar.municipal.master.waterManagement.modal.DDConsumerPropertyCategory;
import com.ahmednagar.municipal.master.waterManagement.modal.DDWaterPropertyUsesType;
import com.ahmednagar.municipal.master.waterManagement.modal.PipelineType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbl_consumer_details_legeacy_data")
public class ConsumerDetailsLegacyData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "Zone", nullable = false, length = 50)
    @Size(max = 50, message = "Zone cannot exceed 50 characters")
    private String zone;

    @Column(name = "Ward_No", nullable = false, length = 50)
    @Size(max = 50, message = "Ward No cannot exceed 50 characters")
    private String wardNo;

    @Column(name = "Owner_Name", nullable = false, length = 100)
    @Size(max = 100, message = "Owner Name cannot exceed 100 characters")
    private String ownerName;

    @Column(name = "Consumer_Number", nullable = false, length = 50, unique = true)
    @Size(max = 50, message = "Consumer Number cannot exceed 50 characters")
    private String consumerNumber;

    @Column(name = "Property_No", nullable = false, length = 50)
    @Size(max = 50, message = "Property Number cannot exceed 50 characters")
    private String propertyNo;

    @Column(name = "Mobile_No", nullable = false)
    private Long mobileNo;

    @Column(name = "Address", nullable = false, columnDefinition = "nvarchar(MAX)")
    private String address;

    @Column(name = "Meter_no", length = 50)
    private String meterNo;

//    @Column(name = "Cons_water_props_usestype_dd_id", nullable = false)
//    private Long consWaterPropsUseTypeDdId;

//    @Column(name = "Pipeline_Type_id", nullable = false)
//    private Long pipelineTypeId;

//    @Column(name = "Cons_props_Category_usestype_dd_id", nullable = false)
//    private Long consPropsCategoryUseTypeDdId;

    @Column(name = "Status", nullable = false, length = 50)
    @Size(max = 50, message = "Status cannot exceed 50 characters")
    private String status;

    @Column(name = "updated_by", nullable = false)
    private Integer updatedBy;

    @Column(name = "updated_date", nullable = false)
    private LocalDateTime updatedDate;

    @Column(name = "created_by", nullable = false)
    private Integer createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @Column(name = "municipal_id", nullable = false)
    private Long municipalId;

    @Column(name = "is_metered", nullable = false)
    private boolean isMetered;

    @OneToMany(mappedBy = "consumerDetailsLegacyDataId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<ConsumerDemandDetails> consumerDemandDetails;

    @ManyToOne
    @JoinColumn(name = "Cons_water_props_usestype_dd_id", referencedColumnName = "id", nullable = false)
    private DDWaterPropertyUsesType consWaterPropsUseTypeDdId;

    @ManyToOne
    @JoinColumn(name = "Pipeline_Type_id", referencedColumnName = "id", nullable = false)
    private PipelineType pipelineTypeId;

    @ManyToOne
    @JoinColumn(name = "Cons_props_Category_usestype_dd_id", referencedColumnName = "id", nullable = false)
    private DDConsumerPropertyCategory consPropsCategoryUseTypeDdId;

}
