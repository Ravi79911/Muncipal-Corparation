package com.ahmednagar.municipal.auth.dto;

import com.ahmednagar.municipal.auth.model.CitizenSignUpMaster;
import com.ahmednagar.municipal.auth.model.ViewMunicipalPropertyMaster;
import com.ahmednagar.municipal.auth.model.WorkFlowMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class NewPropertyWorkFlowLevelDto {

    private Long id;
    private Long zoneId;
    private Long wardId;
    private String status;
    private Long statusCode;
    private Float mailStatus;
    private String remarks;
    private Integer createdBy;
    private LocalDateTime createdDate;
    private Long municipalId;
    private ViewMunicipalPropertyMaster applicationId;
    private RoleDto currentRoleId;
    private UserMasterDTO currentUserId;
    private UserMasterDTO nextUserId;
    private RoleDto nextRoleId;
    private WorkFlowMaster workFlowMasterId;
    private CitizenSignUpMaster citizenId;

}
