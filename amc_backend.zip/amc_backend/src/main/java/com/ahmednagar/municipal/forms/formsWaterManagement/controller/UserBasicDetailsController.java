package com.ahmednagar.municipal.forms.formsWaterManagement.controller;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.UserBasicDetails;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.UserBasicDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/water/forms/user-basic-details")
public class UserBasicDetailsController {

    @Autowired
    private UserBasicDetailsService userBasicDetailsService;

    // 1. Post API to create a new user basic details
    @PostMapping
    public ResponseEntity<?> createUserBasicDetails(@Valid @RequestBody UserBasicDetails userBasicDetails, @RequestParam int createdBy) {
       UserBasicDetails createdUserBasicDetails = userBasicDetailsService.createUserBasicDetails(userBasicDetails, createdBy);
       if (createdUserBasicDetails == null) {
           return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                   .body("User Basic Details not created");
       }
       return ResponseEntity.status(HttpStatus.CREATED)
               .body(createdUserBasicDetails);
    }

//    // 2. Put API to update an existing user basic details
//    @PutMapping("/{id}")
//    public ResponseEntity<?> updateUserBasicDetails(@PathVariable int id, @Valid @RequestBody UserBasicDetails userBasicDetails, @RequestParam int updatedBy) {
//        UserBasicDetails updatedUserBasicDetails = userBasicDetailsService.updateUserBasicDetails(id, userBasicDetails, 1);
//        if (updatedUserBasicDetails == null) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                    .body("User Basic Details not updated");
//        }
//        return ResponseEntity.status(HttpStatus.OK)
//                .body(updatedUserBasicDetails);
//    }

    // 3. Delete API to delete user basic details by ID
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> deleteUserBasicDetailsById(@PathVariable int id, @RequestParam int updatedBy, @RequestParam(required = false, defaultValue = "1") int suspendedStatus) {
        UserBasicDetails userBasicDetails = userBasicDetailsService.deleteUserBasicDetailsById(id, suspendedStatus, 1);
        if (userBasicDetails == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(" User Basic Details not found with the given ID: " + id);
        }
        return ResponseEntity.ok(userBasicDetails);
    }


//    // 4. Get API to retrieve user basic details by ID
//    @GetMapping("/{id}")
//    public ResponseEntity<?> getUserBasicDetailsById(@PathVariable int id) {
//        UserBasicDetails userBasicDetails = userBasicDetailsService.getUserBasicDetailsById(id);
//        if (userBasicDetails == null) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND)
//                    .body("User Basic Details not found with the given ID: " + id);
//        }
//        return ResponseEntity.ok(userBasicDetails);
//    }

    // 5. Get API to retrieve user basic details by Municipal ID
    @GetMapping("/municipal/{municipalId}")
    public ResponseEntity<?> getUserBasicDetailsByMunicipalId(@PathVariable int municipalId) {
        List<UserBasicDetails> userBasicDetailsList = userBasicDetailsService.getUserBasicDetailsByMunicipalId(municipalId);
        if (userBasicDetailsList.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("User Basic Details not found with the given municipal ID");
        }
        return ResponseEntity.ok(userBasicDetailsList);
    }

}
