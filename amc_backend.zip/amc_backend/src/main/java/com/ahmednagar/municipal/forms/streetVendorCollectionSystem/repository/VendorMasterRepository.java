package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;

@EnableJpaRepositories
public interface VendorMasterRepository extends JpaRepository<VendorMaster, Long> {

    List<VendorMaster> findBySuspendedStatus(Integer suspendedStatus);

    @Query("SELECT v FROM VendorMaster v WHERE (:marketNameId IS NULL OR v.marketNameId.id = :marketNameId) AND (:vendorNameEng IS NULL OR v.vendorNameEng LIKE %:vendorNameEng%)")
    List<VendorMaster> findByMarketNameIdAndVendorNameEng(@Param("marketNameId") Long marketNameId, @Param("vendorNameEng") String vendorNameEng);
}
