package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.LicenseRolesDataFlowSetup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;


@EnableJpaRepositories
public interface LicenseRolesDataFlowSetupRepository extends JpaRepository<LicenseRolesDataFlowSetup,Long> {

    Optional<LicenseRolesDataFlowSetup> findByCurrentRoleIdAndStatusCodeAndIsActive(
            Long currentRoleId,
            Long statusCode,
            Integer isActive
    );

    List<LicenseRolesDataFlowSetup> findAllByCurrentRoleIdAndStatusCodeAndIsActive(Long currentRoleId, Long statusCode, Integer isActive);
}
