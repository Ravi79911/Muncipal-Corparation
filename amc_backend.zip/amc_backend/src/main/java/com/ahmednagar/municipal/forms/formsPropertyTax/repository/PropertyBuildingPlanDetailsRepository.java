package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyBuildingPlanDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface PropertyBuildingPlanDetailsRepository extends JpaRepository<PropertyBuildingPlanDetails, Long> {

    List<PropertyBuildingPlanDetails> findByMunicipalPropertyMasterId(Long municipalPropertyMasterId);

    void deleteByMunicipalPropertyMasterId(Long municipalPropertyMasterId);

    List<PropertyBuildingPlanDetails> findByMunicipalId(int municipalId);

}
