package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyFloorTaxationDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface PropertyFloorTaxationDetailsRepository extends JpaRepository<PropertyFloorTaxationDetails, Long> {

    List<PropertyFloorTaxationDetails> findByMunicipalId(int municipalId);

    List<PropertyFloorTaxationDetails> findBySuspendedStatus(Integer status);

}
