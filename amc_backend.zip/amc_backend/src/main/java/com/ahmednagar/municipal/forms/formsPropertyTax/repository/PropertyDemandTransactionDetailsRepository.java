package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandTransactionDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface PropertyDemandTransactionDetailsRepository extends JpaRepository<PropertyDemandTransactionDetails, Long> {

    List<PropertyDemandTransactionDetails> findByMunicipalId(int municipalId);

}
