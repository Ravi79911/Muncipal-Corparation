package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.AdvertisementWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.NewAdvertisementWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.model.AdvertisementWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.NewAdvertisementWorkFlowLevel;
import com.ahmednagar.municipal.auth.service.NewAdvertisementWorkFlowLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/new/advertisement/work/flow/level")
public class NewAdvertisementWorkFlowLevelController {

    @Autowired
    private NewAdvertisementWorkFlowLevelService newAdvertisementWorkFlowLevelService;

    // Endpoint to handle workflow transitions
    @PostMapping("/transition")
    public ResponseEntity<NewAdvertisementWorkFlowLevel> handleWorkFlowTransition(@RequestBody NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel) {
        NewAdvertisementWorkFlowLevel updatedNewAdvertisementWorkFlowLevel = newAdvertisementWorkFlowLevelService.handleWorkFlowTransition(newAdvertisementWorkFlowLevel);
        return ResponseEntity.ok(updatedNewAdvertisementWorkFlowLevel);
    }

    //for admin all users
    @GetMapping("/all")
    public ResponseEntity<List<NewAdvertisementWorkFlowLevelDto>> getAllWorkFlow() {
        List<NewAdvertisementWorkFlowLevelDto> workFlow = newAdvertisementWorkFlowLevelService.findAllWorkFlow();
        return ResponseEntity.ok(workFlow);
    }

    @PostMapping("/new-application")
    public ResponseEntity<NewAdvertisementWorkFlowLevel> createNewAdvertisementWorkflow(@RequestBody NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel) {
        NewAdvertisementWorkFlowLevel savedWorkflow = newAdvertisementWorkFlowLevelService.createNewApplicationTransation(newAdvertisementWorkFlowLevel);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedWorkflow);
    }

}
