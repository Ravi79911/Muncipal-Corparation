package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.FileUrlDto;
import com.ahmednagar.municipal.auth.model.FileUrlMaster;
import com.ahmednagar.municipal.auth.repository.FileUrlRepository;
import com.ahmednagar.municipal.auth.service.FileUrlService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FileUrlServiceImpl implements FileUrlService {
    @Autowired
    private FileUrlRepository fileUrlRepository;

    @Autowired
    private ModelMapper modelMapper;


    @Override
    public FileUrlMaster createFileUrl(FileUrlMaster fileUrlMaster) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        fileUrlMaster.setCreatedDate(currentDateTime);
        fileUrlMaster.setUpdatedDate(LocalDateTime.now());
        fileUrlMaster.setUpdatedBy(fileUrlMaster.getUpdatedBy() != null ? fileUrlMaster.getUpdatedBy() : 0);
        fileUrlMaster.setSuspendedStatus(fileUrlMaster.getSuspendedStatus() != null ? fileUrlMaster.getSuspendedStatus() : 0);      // 0 means active// 1 means admin
        return fileUrlRepository.saveAndFlush(fileUrlMaster);
    }

    @Override
    public List<FileUrlDto> findAllFileUrl() {
        List<FileUrlMaster> fileUrlMasters = fileUrlRepository.findAll();
        return fileUrlMasters.stream()
                .map(fileUrlMaster -> modelMapper.map(fileUrlMaster, FileUrlDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<FileUrlDto> findAllFileUrlByMunicipalId(Long municipalId) {
        List<FileUrlMaster> fileUrlMasters = fileUrlRepository.findByMunicipalId(municipalId);
        return fileUrlMasters.stream()
                .map(fileUrlMaster -> modelMapper.map(fileUrlMaster, FileUrlDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public FileUrlMaster updateFileUrl(Long id, FileUrlMaster updatedFileUrlMaster) {
        Optional<FileUrlMaster> fileUrlOptional = fileUrlRepository.findById(id);
        if (fileUrlOptional.isPresent()) {
            FileUrlMaster existingFileUrlMaster = fileUrlOptional.get();
            existingFileUrlMaster.setSuspendedStatus(updatedFileUrlMaster.getSuspendedStatus());
            existingFileUrlMaster.setMunicipalId(updatedFileUrlMaster.getMunicipalId());

            return fileUrlRepository.saveAndFlush(existingFileUrlMaster);
        } else {
            throw new RuntimeException("fileUrl not found with id: " + id);
        }
    }

    @Override
    public FileUrlMaster changeSuspendedStatus(Long id, int status) {
        Optional<FileUrlMaster> fileUrlOptional = fileUrlRepository.findById(id);
        if (fileUrlOptional.isPresent()) {
            FileUrlMaster fileUrlMaster = fileUrlOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            fileUrlMaster.setUpdatedDate(currentDateTime);
            fileUrlMaster.setSuspendedStatus(status);      // 1 means suspended
            fileUrlMaster.setUpdatedBy(fileUrlMaster.getUpdatedBy());
            return fileUrlRepository.saveAndFlush(fileUrlMaster);
        }
        return null;
    }
}
