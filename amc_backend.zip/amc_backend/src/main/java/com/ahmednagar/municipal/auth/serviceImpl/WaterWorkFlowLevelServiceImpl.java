package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.dto.WaterWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.*;
import com.ahmednagar.municipal.auth.service.WaterWorkFlowLevelService;
import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class WaterWorkFlowLevelServiceImpl implements WaterWorkFlowLevelService {

    @Autowired
    private WaterWorkFlowLevelRepository waterWorkFlowLevelRepository;

    @Autowired
    private RoleMasterRepository roleMasterRepository;

    @Autowired
    private WorkFlowMasterRepository workFlowMasterRepository;

    @Autowired
    private UserMasterRepository userMasterRepository;

    @Autowired
    private CitizenSignUpRepository citizenSignUpRepository;

    @Autowired
    private ViewNewWaterConnectionFormMasterRepository viewNewWaterConnectionFormMasterRepository;

    @Autowired
    private ViewConsumerDocumentDetailsRepository viewConsumerDocumentDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    public UserMaster getLipikForWaterCitizen(Long citizenId) {
        Long roleId = 1L; // Role ID for Lipik

        CitizenSignUpMaster citizen = citizenSignUpRepository.findById(citizenId)
                .orElseThrow(() -> new EntityNotFoundException("Citizen not found with ID: " + citizenId));

        // Fetch the first Lipik (UserMaster) matching Zone, Ward, Role
        return userMasterRepository.findFirstByZoneWardAndRole(citizen.getZoneId(), citizen.getWardId(), roleId)
                .orElseThrow(() -> new EntityNotFoundException("No Lipik found for Zone: " + citizen.getZoneId()
                        + " and Ward: " + citizen.getWardId()));
    }

    @Override
    public WaterWorkFlowLevel createNewApplicationTransation(WaterWorkFlowLevel newApplicationWaterWorkFlowRequest) {

        if (newApplicationWaterWorkFlowRequest.getCitizenId() == null) {
            throw new RuntimeException("Citizen ID is required to initiate a new application workflow.");
        }

        UserMaster newApplicationLipik = getLipikForWaterCitizen(newApplicationWaterWorkFlowRequest.getCitizenId().getId());
        // Validate WorkFlow Master
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newApplicationWaterWorkFlowRequest.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Master not found"));

        // Build WorkFlowLevel Object with Defaults
        WaterWorkFlowLevel newWorkFlow = WaterWorkFlowLevel.builder()
                .waterApplicationId(newApplicationWaterWorkFlowRequest.getWaterApplicationId())
                .currentUserId(null)
                .nextUserId(newApplicationLipik)
                .workFlowMasterId(workFlowMaster)
                .status("NEW") // Default status for new applications
                .statusCode(1000L) // Example status code
                .createdBy(newApplicationWaterWorkFlowRequest.getCreatedBy())
                .createdDate(LocalDateTime.now())
                .mailStatus(newApplicationWaterWorkFlowRequest.getMailStatus())
                .remarks(newApplicationWaterWorkFlowRequest.getRemarks())
                .suspendedStatus(0) // Default
                .municipalId(newApplicationWaterWorkFlowRequest.getMunicipalId())
                .citizenId(newApplicationWaterWorkFlowRequest.getCitizenId())
                .build();

        updateApprovedStatus(newApplicationWaterWorkFlowRequest.getWaterApplicationId().getId());

        // Save Workflow to Database
        return waterWorkFlowLevelRepository.save(newWorkFlow);
    }

    @Override
    public List<WaterWorkFlowLevelDto> findAllWorkFlow() {
        List<WaterWorkFlowLevel> waterWorkFlowLevels = waterWorkFlowLevelRepository.findAll();

        return waterWorkFlowLevels.stream().map(waterWorkFlowLevel -> {
            WaterWorkFlowLevelDto dto = modelMapper.map(waterWorkFlowLevel, WaterWorkFlowLevelDto.class);

            // Manually map UserMaster to UserMasterDTO
            if (waterWorkFlowLevel.getCurrentUserId() != null) {
                dto.setCurrentUserId(modelMapper.map(waterWorkFlowLevel.getCurrentUserId(), UserMasterDTO.class));
            }
            if (waterWorkFlowLevel.getNextUserId() != null) {
                dto.setNextUserId(modelMapper.map(waterWorkFlowLevel.getNextUserId(), UserMasterDTO.class));
            }

            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public WaterWorkFlowLevel handleWaterWorkFlowTransition(WaterWorkFlowLevel waterWorkFlowLevel) {
        waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        Long currentRoleMasterId = getCurrentRoleMasterId(waterWorkFlowLevel);  // Get RoleMasterId for Current User
        Long nextRoleMasterId = getNextRoleMasterId(waterWorkFlowLevel);       // Get RoleMasterId for Next User
        //Long nextRoleCitizenMasterId =getNextRoleCitizenMasterId(workFlowLevel);

        RoleMaster currentRole = roleMasterRepository.findById(currentRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));

        RoleMaster nextRole = roleMasterRepository.findById(nextRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Next Role not found"));

        // Optional<RoleMaster> citizenNextRole=roleMasterRepository.findById(nextRoleCitizenMasterId);
        // Dynamically fetch workflow status from WorkFlowMaster table
        WorkFlowMaster currentStatus = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Status not found"));

        List<Long> rejectDocumentIds=waterWorkFlowLevel.getRejectedDocumentIds();

//        CitizenSignUpMaster citizenSignUpMaster=citizenSignUpRepository.findById(licenseWorkFlowLevel.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("citizen not found"));

        // Fetch the current status of the application
        Optional<WaterWorkFlowLevel> existingWorkflow = waterWorkFlowLevelRepository
                .findTopByWaterApplicationIdOrderByCreatedDateDesc(waterWorkFlowLevel.getWaterApplicationId());

        if (existingWorkflow.isPresent()) {
            Long existingStatusCode = existingWorkflow.get().getStatusCode();

            // Check if the application has already been accepted or rejected
            if (existingStatusCode.equals(1002L) || existingStatusCode.equals(1003L)) {
                throw new IllegalStateException("This application has already been " +
                        (existingStatusCode.equals(1002L) ? "Accepted" : "Rejected") +
                        " and cannot be processed further.");
            }
        }

        // Transition based on the current status and role
        switch (currentStatus.getStatus()) {

            case "FORWARDED":
                return handleForwardedStatus(waterWorkFlowLevel, currentRole, nextRole);

            case "BACKWARD":
                return handleBackwardStatus(waterWorkFlowLevel, currentRole, nextRole);

            case "ACCEPT":
                return handleAcceptStatus(waterWorkFlowLevel, currentRole);

            case "REJECT":
                return handleRejectStatus(waterWorkFlowLevel, currentRole, nextRole);

            case "BACK TO CITIZEN":
                return handleBackToCitizenStatus(waterWorkFlowLevel, currentRole);

            case "BACK TO CITIZEN IN BACKWARD":
                return handleBackToCitizenInBackWardCaseStatus(waterWorkFlowLevel, currentRole,nextRole);

            case "BACK TO BACK OFFICE":
                return handleBackToBackOfficeStatus(waterWorkFlowLevel, currentRole, nextRole);

            case "DOCUMENT VERIFICATION ACCEPT":
                return handleDocumentVerificationAccept(waterWorkFlowLevel, currentRole, nextRole);

            case "DOCUMENT VERIFICATION REJECT":
                return handleDocumentVerificationReject(waterWorkFlowLevel, currentRole, nextRole,rejectDocumentIds);

            default:
                throw new RuntimeException("Invalid Status: " + currentStatus.getStatus());
        }
    }

    private WaterWorkFlowLevel handleForwardedStatus(WaterWorkFlowLevel waterWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole) {

        Long nextUserId = waterWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = waterWorkFlowLevel.getCurrentUserId().getId();

        // Check the status_code and call the corresponding forward methods
        if (waterWorkFlowLevel.getStatusCode() == 1005) {
            // Call forwardFromBackOffice when status_code is 1005
            return forwardFromBackOffice(waterWorkFlowLevel);

        } else if (waterWorkFlowLevel.getStatusCode() == 1004) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromCitizen(waterWorkFlowLevel);

        }
        else if (waterWorkFlowLevel.getStatusCode() == 1001) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromBackWard(waterWorkFlowLevel);

        } else {
            // Fetch the next role based on the workFlowMasterId from the database
            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
            waterWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

            // Validate nextRole
            if (nextRole == null && !"executive engineer".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Next role is required but not provided.");
            }

            // Logic based on the current role and next role
            //if (workFlowMaster.getId().equals(1L))
            if (workFlowMaster.getId().equals(waterWorkFlowLevel.getWorkFlowMasterId().getId())) {  // Only handle Forwarded status (workFlowMasterId = 1)
                switch (currentRole.getRoleName().toLowerCase()) {
                    case "back office":
                        if (nextRole.getRoleName().equalsIgnoreCase("lipik")) {
                            waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));
                            waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            waterWorkFlowLevel.setMailStatus(1);
                        } else {
                            throw new IllegalStateException("Back Office can only forward to Lipik.");
                        }
                        break;

                    case "lipik":
                        if (nextRole.getRoleName().equalsIgnoreCase("junior engineer")) {
                            waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));
                            waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            waterWorkFlowLevel.setMailStatus(1);
                        } else {
                            throw new IllegalStateException("Lipik can only forward to junior engineer.");
                        }
                        break;

                    case "junior engineer":
                        if (nextRole.getRoleName().equalsIgnoreCase("deputy engineer")) {
                            waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));
                            waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            waterWorkFlowLevel.setMailStatus(1);
                        } else {
                            throw new IllegalStateException("junior engineer can only forward to deputy engineer.");
                        }
                        break;
                    case "deputy engineer":
                        if (nextRole.getRoleName().equalsIgnoreCase("executive engineer")) {
                            waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));
                            waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            waterWorkFlowLevel.setMailStatus(1);
                        } else {
                            throw new IllegalStateException("deputy engineer can only forward to executive engineer.");
                        }
                        break;

                    case "executive engineer":
                        waterWorkFlowLevel.setNextUserId(null);
                        waterWorkFlowLevel.setStatus("Application Successfully Approved");
                        waterWorkFlowLevel.setStatusCode(1002L); // Status Code for "Accepted"
                        waterWorkFlowLevel.setMailStatus(0);
                }
                if (nextRole == null) {
                    throw new IllegalStateException("Next role is required but not provided.");
                }
                //workFlow.setNextUserId(getUserMasterByRoleMaster(nextRole));
                waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
            }
            //workFlow.setMailStatus(1);
            waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            updateApprovedStatus(waterWorkFlowLevel.getWaterApplicationId().getId());
            return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);
        }
    }

//    private WaterWorkFlowLevel handleBackwardStatus(WaterWorkFlowLevel waterWorkFlowLevel, RoleMaster currentRole, RoleMaster previousRole) {
//        // Fetch the WorkFlowMaster for validation
//        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));
//
//        System.out.println(" current role{}" + currentRole);
//        System.out.println(" previous role{}" + previousRole);
//
//        if (workFlowMaster.getId().equals(2L)) {  // Backward
//            waterWorkFlowLevel.setStatus(workFlowMaster.getStatus()); // Set to Backward status
//            waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
//
//            // Validate previousRole
//            if (previousRole == null) {
//                throw new IllegalStateException("Previous role is required but not provided.");
//            }
//
//            // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
//            if (waterWorkFlowLevel.getCitizenId() != null) {
//                WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
//                        .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));
//
//                waterWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);
//
////                workflowlevel.setStatusCode(Long.valueOf("1004")); // Set the status code to 1004 when going back to Citizen
//
//                return handleBackToCitizenStatus(waterWorkFlowLevel, currentRole,previousRole);  // Handle transition to citizen
//            }
//
//            WorkFlowMaster backOfficeMaster = workFlowMasterRepository.findById(6L)
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 6 not found"));
//
//            waterWorkFlowLevel.setWorkFlowMasterId(backOfficeMaster);
//
//            WaterWorkFlowLevel workFlowLevel = handleBackToBackOfficeStatus(waterWorkFlowLevel, currentRole, previousRole);
//            return workFlowLevel;
//        }
//        return null;
//    }

    private WaterWorkFlowLevel handleBackwardStatus(WaterWorkFlowLevel waterWorkFlowLevel, RoleMaster currentRole, RoleMaster previousRole) {
        // Fetch the next role based on the workFlowMasterId from the database
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = waterWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = waterWorkFlowLevel.getCurrentUserId().getId();

        // Set the status from WorkFlowMaster to WorkFlow
        waterWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        // Validate nextRole
        if (previousRole == null && !"executive engineer".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Next role is required but not provided.");
        }

        // Logic based on the current role and next role for rejection in Water WorkFlow Level
        if (workFlowMaster.getId().equals(waterWorkFlowLevel.getWorkFlowMasterId().getId())) {  // Only handle Backward status (workFlowMasterId = 8)
            switch (currentRole.getRoleName().toLowerCase()) {
                case "lipik":
                    // Lipik can only reject and return to Back Office
                    if ("back office".equalsIgnoreCase(previousRole.getRoleName())) {
                        waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(previousRole, nextUserId)); // Reject and return to Back Office
                        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        waterWorkFlowLevel.setStatus("Rejected by Lipik");
                    } else {
                        throw new IllegalStateException("Lipik can only reject and return to Back Office.");
                    }
                    break;
                case "junior engineer":
                    // Junior Engineer cannot go backward
                    throw new IllegalStateException("Junior Engineer cannot move backward.");
                case "deputy engineer":
                    // Deputy Engineer can reject to Junior Engineer, Lipik, or Back Office
                    if (isValidRoleForDeputyEngineer(previousRole)) {
                        waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(previousRole, nextUserId)); // Reject and return to the selected role
                        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        waterWorkFlowLevel.setStatus("Rejected by Deputy Engineer");
                    } else {
                        throw new IllegalStateException("Deputy Engineer can only reject to Junior Engineer, Lipik, or Back Office.");
                    }
                    break;
                case "executive engineer":
                    // Executive Engineer can reject to Deputy Engineer, Junior Engineer, Lipik, or Back Office
                    if (isValidRoleForExecutiveEngineer(previousRole)) {
                        waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(previousRole, nextUserId)); // Reject and return to the selected role
                        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        waterWorkFlowLevel.setStatus("Rejected by Executive Engineer");
                    } else {
                        throw new IllegalStateException("Executive Engineer can only reject to Deputy Engineer, Junior Engineer, Lipik, or Back Office.");
                    }
                    break;
                default:
                    throw new IllegalStateException("Invalid current role for WaterWorkFlowLevel Reject: " + currentRole.getRoleName());
            }

            // Set mail status and created date for all cases except TS → ID Generation rejection
            if (!"executive engineer".equalsIgnoreCase(currentRole.getRoleName())) {
                waterWorkFlowLevel.setMailStatus(0);  // Assuming 0 means mail sent for rejection
                waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            }

            // Update rejection status for the rejected documents
            //updateRejectStatus(waterWorkFlowLevel.getWaterApplicationId().getId(), rejectDocumentIds);
            waterWorkFlowLevel.setMailStatus(2);
        }

        // Validate previousRole
        if (previousRole == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }

        // Check if citizenId is provided (since workflowMasterId is 8, we need to handle the citizen case)
        if (waterWorkFlowLevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            waterWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

            //updateRejectStatus(waterWorkFlowLevel.getWaterApplicationId().getId(), rejectDocumentIds);

            return handleBackToCitizenInBackWardCaseStatus(waterWorkFlowLevel, currentRole,previousRole);  // Handle transition to citizen
        }

        return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);
    }

    private WaterWorkFlowLevel handleAcceptStatus(WaterWorkFlowLevel waterWorkFlowLevel, RoleMaster currentRole) {

        Long nextUserId = waterWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = waterWorkFlowLevel.getCurrentUserId().getId();
        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        // Check if the application is already accepted or rejected
        Optional<WaterWorkFlowLevel> existingStatus = waterWorkFlowLevelRepository
                .findLatestWorkFlowByWaterApplicationIdAndStatusCode(waterWorkFlowLevel.getWaterApplicationId().getId(), 1002L);

        if (existingStatus.isPresent()) {
            throw new IllegalStateException("This application has already been accepted and cannot be processed again.");
        }

        // Ensure only WorkFlowMasterId = 3 is processed for acceptance
        if (!workFlowMaster.getId().equals(3L)) {
            throw new IllegalStateException("This workflow is not eligible for acceptance.");
        }

        // Ensure only DEPUTY MUNICIPAL COMMISSIONER can accept
        if (!"EXECUTIVE ENGINEER".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only EXECUTIVE ENGINEER can accept the application.");
        }

        // Update status to "Accepted"
        waterWorkFlowLevel.setStatus("ACCEPT");
        waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        waterWorkFlowLevel.setNextUserId(null); // No further forwarding
        waterWorkFlowLevel.setMailStatus(0);
        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
        waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);
    }

    private WaterWorkFlowLevel handleRejectStatus(WaterWorkFlowLevel waterWorkFlowLevel, RoleMaster currentRole, RoleMaster previousRole) {

        Long nextUserId = waterWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = waterWorkFlowLevel.getCurrentUserId().getId();

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        // Check if the application is already accepted or rejected
        Optional<WaterWorkFlowLevel> existingStatus = waterWorkFlowLevelRepository
                .findLatestWorkFlowByWaterApplicationIdAndStatusCode(waterWorkFlowLevel.getWaterApplicationId().getId(), 1003L);

        if (existingStatus.isPresent()) {
            throw new IllegalStateException("This application has already been rejected and cannot be processed again.");
        }

        // Ensure only WorkFlowMasterId = 4 is processed for rejection
        if (!workFlowMaster.getId().equals(4L)) {
            throw new IllegalStateException("This workflow is not eligible for rejection.");
        }

        // Ensure only DEPUTY MUNICIPAL COMMISSIONER can reject
        if (!"EXECUTIVE ENGINEER".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only EXECUTIVE ENGINEER can reject the application.");
        }

        // Update status to "Rejected"
        waterWorkFlowLevel.setStatus("Application Rejected");
        waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        waterWorkFlowLevel.setNextUserId(null); // No further forwarding
        waterWorkFlowLevel.setMailStatus(1); // Set mail notification for rejection
        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
        waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);
    }

    private WaterWorkFlowLevel handleBackToCitizenStatus(WaterWorkFlowLevel waterWorkFlowLevel, RoleMaster currentRole) {

        Long nextUserId = waterWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = waterWorkFlowLevel.getCurrentUserId().getId();

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (workFlowMaster.getId().equals(5L)) {
            waterWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

            waterWorkFlowLevel.setNextUserId(null);
            waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
            waterWorkFlowLevel.setCitizenId(waterWorkFlowLevel.getCitizenId());

        }
        waterWorkFlowLevel.setMailStatus(1);
        waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);
    }

    private WaterWorkFlowLevel handleBackToCitizenInBackWardCaseStatus(WaterWorkFlowLevel workFlow, RoleMaster currentRole, RoleMaster nextRole) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = workFlow.getNextUserId() != null ? workFlow.getNextUserId().getId() : null;
        Long currentUserId = workFlow.getCurrentUserId().getId();

        if (workFlowMaster.getId().equals(5L)) {  // Backward Flow for WorkFlowMasterId = 5 (Water Workflow)

            workFlow.setStatus(workFlowMaster.getStatus());
            workFlow.setStatusCode(workFlowMaster.getStatusCode());

            switch (currentRole.getRoleName().toLowerCase()) {
                case "lipik":
                    // Lipik can only go backward to "Back to Citizen"
                    workFlow.setNextUserId(null);
                    workFlow.setCitizenId(workFlow.getCitizenId());
                    workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                    workFlow.setStatus("Backward to Citizen");
                    break;

                case "junior engineer":
                    // Junior Engineer cannot move backward
                    throw new IllegalStateException("Junior Engineer cannot move backward.");

                case "deputy engineer":
                    // Deputy Engineer can go backward to "Junior Engineer", "Lipik", or "Back to Citizen"
                    if (isValidRolesForDeputyEngineer(nextRole)) {
                        workFlow.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward from " + currentRole.getRoleName());
                    } else {
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                case "executive engineer":
                    // Executive Engineer can go backward to "Deputy Engineer", "Junior Engineer", "Lipik", or "Back to Citizen"
                    if (isValidRolesForExecutiveEngineer(nextRole)) {
                        workFlow.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward from " + currentRole.getRoleName());
                    } else {
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                default:
                    throw new IllegalStateException("Invalid current role for Backward Flow: " + currentRole.getRoleName());
            }
        }

        // Set the mail status and created date after the operation
        workFlow.setMailStatus(1);  // Assuming 1 means mail sent for rejection
        workFlow.setCreatedDate(LocalDateTime.now());

        return waterWorkFlowLevelRepository.save(workFlow);
    }

    private boolean isValidRolesForDeputyEngineer(RoleMaster nextRole) {
        // Deputy Engineer can go back to "Junior Engineer", "Lipik", or "Back to Citizen"
        return "junior engineer".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName());
    }

    private boolean isValidRolesForExecutiveEngineer(RoleMaster nextRole) {
        // Executive Engineer can go back to "Deputy Engineer", "Junior Engineer", "Lipik", or "Back to Citizen"
        return "deputy engineer".equalsIgnoreCase(nextRole.getRoleName()) ||
                "junior engineer".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName());
    }


    private WaterWorkFlowLevel handleBackToBackOfficeStatus(WaterWorkFlowLevel waterWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole) {

        Long nextUserId = waterWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = waterWorkFlowLevel.getCurrentUserId().getId();

        // Fetch WorkFlowMaster for validation
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        // Ensure it's a backward operation (WorkFlowMasterId = 6)
        if (!workFlowMaster.getId().equals(6L)) {
            throw new IllegalStateException("Invalid workflow operation. Expected 'Back to Back Office' status.");
        }

        // Set status and status code based on WorkFlowMaster
        waterWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        // Validate nextRole (must be "Back Office")
        if (nextRole == null || !"back office".equalsIgnoreCase(nextRole.getRoleName())) {
            throw new IllegalStateException(currentRole.getRoleName() + " can only backward to Back Office.");
        }

        // Define allowed roles for backward action
        List<String> allowedRoles = Arrays.asList("lipik", "junior engineer", "deputy engineer", "executive engineer");

        if (!allowedRoles.contains(currentRole.getRoleName().toLowerCase())) {
            throw new IllegalStateException(currentRole.getRoleName() + " is not allowed to perform this Backward action.");
        }

        // Set workflow details
        waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));  // Back to Back Office
        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));

        // Set mail status and created date
        waterWorkFlowLevel.setMailStatus(1); // Notify user
        waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);
    }

    private WaterWorkFlowLevel handleDocumentVerificationAccept(WaterWorkFlowLevel waterWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole) {
        Long nextUserId = waterWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = waterWorkFlowLevel.getCurrentUserId().getId();

        // Fetch the next role based on the workFlowMasterId from the database
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));
        // Set the status from WorkFlowMaster to WorkFlow
        waterWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        // Validate nextRole
        if (nextRole == null && !"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Next role is required but not provided.");
        }

        // Logic based on the current role and next role
        //if (workFlowMaster.getId().equals(workFlow.getWorkFlowMasterId().getId()))
        if (workFlowMaster.getId().equals(7L)) {  // Only handle Forwarded status (workFlowMasterId = 1)
            switch (currentRole.getRoleName().toLowerCase()) {
                case "back office":
                    if (nextRole.getRoleName().equalsIgnoreCase("lipik")) {
                        waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to Lipik
                        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    } else {
                        throw new IllegalStateException("Invalid next role for Back Office.");
                    }
                    break;
                case "lipik":
                    if (nextRole.getRoleName().equalsIgnoreCase("junior engineer")) {
                        waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));  // Forward to Agency/Field
                        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    } else {
                        throw new IllegalStateException("Invalid next role for Lipik.");
                    }
                    break;
                case "junior engineer":
                    if (nextRole.getRoleName().equalsIgnoreCase("deputy engineer")) {
                        waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to Nagar Rachna
                        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    } else {
                        throw new IllegalStateException("Invalid next role for junior engineer");
                    }
                    break;
                case "deputy engineer":
                    if (nextRole.getRoleName().equalsIgnoreCase("executive engineer")) {
                        waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to ATS
                        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    } else {
                        throw new IllegalStateException("Invalid next role for deputy engineer");
                    }
                    break;

                case "executive engineer":
                    waterWorkFlowLevel.setStatus("Application Document Successfully Accepted");
                    waterWorkFlowLevel.setStatusCode(1002L); // Status Code for "Accepted"
                    waterWorkFlowLevel.setNextUserId(null); // No further processing
                    waterWorkFlowLevel.setMailStatus(0);

                    if (nextRole == null) {
                        throw new IllegalStateException("Next role is required but not provided.");
                    }
                    waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                    waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());

            }
            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(waterWorkFlowLevel.getWaterApplicationId().getId());

        }
        return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);
    }
    private void updateApprovedStatus(Long waterApplicationId) {
        List<ViewConsumerDocumentDetails> documentDetails =
                viewConsumerDocumentDetailsRepository.findByViewNewWaterConnectionFormMaster_Id(waterApplicationId);

        for(ViewConsumerDocumentDetails details : documentDetails){

            details.setApprovedStatus(1f); // Set approved_status to 1
            viewConsumerDocumentDetailsRepository.save(details);
        };
    }

    private WaterWorkFlowLevel handleDocumentVerificationReject(WaterWorkFlowLevel waterWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole,List<Long> rejectDocumentIds) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        System.out.println("Current role: " + currentRole);
        System.out.println("Previous role: " + nextRole);

        if (workFlowMaster.getId().equals(8L)) {  // Backward
            waterWorkFlowLevel.setStatus(workFlowMaster.getStatus()); // Set to Backward status
            waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

            // Validate previousRole
            if (nextRole == null) {
                throw new IllegalStateException("Previous role is required but not provided.");
            }

            // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
            if (waterWorkFlowLevel.getCitizenId() != null) {
                WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                        .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

                waterWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);
                // Update reject status after returning to back office
                updateRejectStatus(waterWorkFlowLevel.getWaterApplicationId().getId(), rejectDocumentIds);

                return handleBackToCitizenStatus(waterWorkFlowLevel, currentRole);  // Handle transition to citizen
            }

            WorkFlowMaster backOfficeMaster = workFlowMasterRepository.findById(6L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 6 not found"));

            waterWorkFlowLevel.setWorkFlowMasterId(backOfficeMaster);

            WaterWorkFlowLevel waterWorkFlowLevel1 = handleBackToBackOfficeStatus(waterWorkFlowLevel, currentRole, nextRole);


            // Update reject status after returning to back office
            updateRejectStatus(waterWorkFlowLevel.getWaterApplicationId().getId(), rejectDocumentIds);

            return waterWorkFlowLevel1;
        }

        // Update rejected documents for all other roles
        updateRejectStatus(waterWorkFlowLevel.getWaterApplicationId().getId(), rejectDocumentIds);
        waterWorkFlowLevel.setMailStatus(2);

        return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);
    }

    /**
     * Update approved_status to 0 for rejected documents
     */
    private void updateRejectStatus(Long applicationId, List<Long> rejectDocumentIds) {
        if (rejectDocumentIds == null || rejectDocumentIds.isEmpty()) {
            System.out.println("No documents to update for rejection.");
            return;
        }

        List<ViewConsumerDocumentDetails> documentDetails =
                viewConsumerDocumentDetailsRepository.findAllById(rejectDocumentIds);

        if (documentDetails.isEmpty()) {
            System.out.println("No matching documents found for rejection.");
            return;
        }

        documentDetails.forEach(details -> details.setApprovedStatus(0f)); // Set approved_status to 0

        // Save all updates in batch
        viewConsumerDocumentDetailsRepository.saveAll(documentDetails);

        System.out.println("Updated " + documentDetails.size() + " documents to rejected status.");
    }

//    private WaterWorkFlowLevel handleDocumentVerificationReject(WaterWorkFlowLevel waterWorkFlowLevel, RoleMaster currentRole, RoleMaster nextRole,List<Long> rejectDocumentIds) {
//        // Fetch the next role based on the workFlowMasterId from the database
//        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));
//
//        Long nextUserId = waterWorkFlowLevel.getNextUserId().getId();
//        Long currentUserId = waterWorkFlowLevel.getCurrentUserId().getId();
//
//        // Set the status from WorkFlowMaster to WorkFlow
//        waterWorkFlowLevel.setStatus(workFlowMaster.getStatus());
//        waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
//
//        // Validate nextRole
//        if (nextRole == null && !"executive engineer".equalsIgnoreCase(currentRole.getRoleName())) {
//            throw new IllegalStateException("Next role is required but not provided.");
//        }
//
//        // Logic based on the current role and next role for rejection in Water WorkFlow Level
//        if (workFlowMaster.getId().equals(waterWorkFlowLevel.getWorkFlowMasterId().getId())) {  // Only handle Backward status (workFlowMasterId = 8)
//            switch (currentRole.getRoleName().toLowerCase()) {
//                case "lipik":
//                    // Lipik can only reject and return to Back Office
//                    if ("back office".equalsIgnoreCase(nextRole.getRoleName())) {
//                        waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId)); // Reject and return to Back Office
//                        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
//                        waterWorkFlowLevel.setStatus("Rejected by Lipik");
//                    } else {
//                        throw new IllegalStateException("Lipik can only reject and return to Back Office.");
//                    }
//                    break;
//                case "junior engineer":
//                    // Junior Engineer cannot go backward
//                    throw new IllegalStateException("Junior Engineer cannot move backward.");
//                case "deputy engineer":
//                    // Deputy Engineer can reject to Junior Engineer, Lipik, or Back Office
//                    if (isValidRoleForDeputyEngineer(nextRole)) {
//                        waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId)); // Reject and return to the selected role
//                        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
//                        waterWorkFlowLevel.setStatus("Rejected by Deputy Engineer");
//                    } else {
//                        throw new IllegalStateException("Deputy Engineer can only reject to Junior Engineer, Lipik, or Back Office.");
//                    }
//                    break;
//                case "executive engineer":
//                    // Executive Engineer can reject to Deputy Engineer, Junior Engineer, Lipik, or Back Office
//                    if (isValidRoleForExecutiveEngineer(nextRole)) {
//                        waterWorkFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId)); // Reject and return to the selected role
//                        waterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
//                        waterWorkFlowLevel.setStatus("Rejected by Executive Engineer");
//                    } else {
//                        throw new IllegalStateException("Executive Engineer can only reject to Deputy Engineer, Junior Engineer, Lipik, or Back Office.");
//                    }
//                    break;
//                default:
//                    throw new IllegalStateException("Invalid current role for WaterWorkFlowLevel Reject: " + currentRole.getRoleName());
//            }
//
//            // Set mail status and created date for all cases except TS → ID Generation rejection
//            if (!"executive engineer".equalsIgnoreCase(currentRole.getRoleName())) {
//                waterWorkFlowLevel.setMailStatus(0);  // Assuming 0 means mail sent for rejection
//                waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
//            }
//
//            // Update rejection status for the rejected documents
//            updateRejectStatus(waterWorkFlowLevel.getWaterApplicationId().getId(), rejectDocumentIds);
//            waterWorkFlowLevel.setMailStatus(2);
//        }
//
//        // Validate previousRole
//        if (nextRole == null) {
//            throw new IllegalStateException("Previous role is required but not provided.");
//        }
//
//        // Check if citizenId is provided (since workflowMasterId is 8, we need to handle the citizen case)
//        if (waterWorkFlowLevel.getCitizenId() != null) {
//            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));
//
//            waterWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);
//
//            updateRejectStatus(waterWorkFlowLevel.getWaterApplicationId().getId(), rejectDocumentIds);
//
//            return handleBackToCitizenStatus(waterWorkFlowLevel, currentRole,nextRole);  // Handle transition to citizen
//        }
//
//        return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);
//    }

    private boolean isValidRoleForDeputyEngineer(RoleMaster nextRole) {
        // Deputy Engineer can go back to Junior Engineer, Lipik, or Back Office
        return "junior engineer".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName()) ||
                "back office".equalsIgnoreCase(nextRole.getRoleName());
    }

    private boolean isValidRoleForExecutiveEngineer(RoleMaster nextRole) {
        // Executive Engineer can go back to Deputy Engineer, Junior Engineer, Lipik, or Back Office
        return "deputy engineer".equalsIgnoreCase(nextRole.getRoleName()) ||
                "junior engineer".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName()) ||
                "back office".equalsIgnoreCase(nextRole.getRoleName());
    }

//    private void updateRejectStatus(Long applicationId, List<Long> rejectDocumentIds) {
//        if (rejectDocumentIds == null || rejectDocumentIds.isEmpty()) {
//            System.out.println("No documents to update for rejection.");
//            return;
//        }
//        // Update the reject status for the provided document IDs
//        List<ViewConsumerDocumentDetails> documentDetails =
//                viewConsumerDocumentDetailsRepository.findAllById(rejectDocumentIds);
//
//        for (ViewConsumerDocumentDetails details : documentDetails) {
//            details.setApprovedStatus(0f); // Set approved_status to 0 (rejected)
//            viewConsumerDocumentDetailsRepository.save(details);
//        }
//    }


    public Long getCurrentRoleMasterId(WaterWorkFlowLevel waterWorkFlowLevel) {
        if (waterWorkFlowLevel == null || waterWorkFlowLevel.getCurrentUserId() == null) {
            throw new IllegalArgumentException("WorkFlow or CurrentUserId cannot be null");
        }
        return userMasterRepository.findById(waterWorkFlowLevel.getCurrentUserId().getId())
                .map(UserMaster::getRoleMaster)  // Get RoleMaster directly
                .map(RoleMaster::getId)         // Extract RoleMaster ID
                .orElseThrow(() -> new RuntimeException("RoleMaster not found for User ID: " + waterWorkFlowLevel.getCurrentUserId().getId()));
    }


    public Long getNextRoleMasterId(WaterWorkFlowLevel waterWorkFlowLevel) {
        if (waterWorkFlowLevel == null || waterWorkFlowLevel.getNextUserId() == null) {
            throw new IllegalArgumentException("WorkFlow or NextUserId cannot be null");
        }
        UserMaster nextUserId = userMasterRepository.findById(waterWorkFlowLevel.getNextUserId().getId())
                .orElseThrow(() -> new RuntimeException("next User not found"));
        Long NextRoleId = nextUserId.getRoleMaster().getId();
        RoleMaster roleMaster = roleMasterRepository.findById(NextRoleId)
                .orElseThrow(() -> new RuntimeException("next Role not found"));
        if (roleMaster == null) {
            throw new RuntimeException("RoleMaster not found for NextUser ID: " + waterWorkFlowLevel.getNextUserId().getId());
        }
        return roleMaster.getId();
    }

    public UserMaster getUserMasterByRoleMaster(RoleMaster roleMaster, Long userId) {
        if (roleMaster == null || roleMaster.getId() == null) {
            throw new IllegalArgumentException("RoleMaster or RoleMasterId cannot be null");
        }
        return userMasterRepository.findFirstByRoleMasterAndId(roleMaster,userId)
                .orElseThrow(() -> new RuntimeException("No UserMaster found for RoleMaster: " +userId));
    }

    private WaterWorkFlowLevel forwardFromBackOffice(WaterWorkFlowLevel waterWorkFlowLevel) {
        Long currentRoleMasterId = getCurrentRoleMasterId(waterWorkFlowLevel);  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));
        Long waterApplicationId = waterWorkFlowLevel.getWaterApplicationId().getId();
        if (waterApplicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = waterWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        WaterWorkFlowLevel latestWorkFlow = waterWorkFlowLevelRepository
                .findLatestWorkFlowByWaterApplicationIdAndStatusCode(waterApplicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + waterApplicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1005) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            waterWorkFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            waterWorkFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
            waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            waterWorkFlowLevel.setStatus("Forwarded from "+currentRole.getRoleName());
            waterWorkFlowLevel.setMailStatus(1);
            waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());

            updateApprovedStatus(waterWorkFlowLevel.getWaterApplicationId().getId());
            return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);

        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private WaterWorkFlowLevel forwardFromBackWard(WaterWorkFlowLevel waterWorkFlowLevel) {
        Long currentRoleMasterId = getCurrentRoleMasterId(waterWorkFlowLevel);  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));
        Long waterApplicationId = waterWorkFlowLevel.getWaterApplicationId().getId();
        if (waterApplicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = waterWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        WaterWorkFlowLevel latestWorkFlow = waterWorkFlowLevelRepository
                .findLatestWorkFlowByWaterApplicationIdAndStatusCode(waterApplicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + waterApplicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1001) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            waterWorkFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            waterWorkFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
            waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            waterWorkFlowLevel.setStatus("Forwarded from "+currentRole.getRoleName());
            waterWorkFlowLevel.setMailStatus(1);
            waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());

            updateApprovedStatus(waterWorkFlowLevel.getWaterApplicationId().getId());
            return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);

        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private WaterWorkFlowLevel forwardFromCitizen(WaterWorkFlowLevel waterWorkFlowLevel) {

        Long waterApplicationId = waterWorkFlowLevel.getWaterApplicationId().getId();
        if (waterApplicationId == null) {
            throw new IllegalArgumentException("licenseDetailsId ID cannot be null");
        }
        Long statusCode = waterWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        WaterWorkFlowLevel latestWorkFlow = waterWorkFlowLevelRepository
                .findLatestWorkFlowByWaterApplicationIdAndStatusCode(waterApplicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for licenseDetails ID: " + waterApplicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1004) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            waterWorkFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            waterWorkFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(waterWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
            waterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            waterWorkFlowLevel.setStatus("Forwarded from Citizen");
            waterWorkFlowLevel.setMailStatus(1);
            waterWorkFlowLevel.setCreatedDate(LocalDateTime.now());

            updateApprovedStatus(waterWorkFlowLevel.getWaterApplicationId().getId());

            return waterWorkFlowLevelRepository.save(waterWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    @Override
    public List<RemarksDto> getRemarksByApplicationId(Long applicationId) {
        return waterWorkFlowLevelRepository.findByWaterApplicationId_Id(applicationId).stream()
                .filter(level -> level.getRemarks() != null)
                .sorted(Comparator.comparing(WaterWorkFlowLevel::getCreatedDate))
                .map(level -> new RemarksDto(
                        level.getRemarks(),
                        level.getCreatedDate(),
                        level.getCurrentUserId() != null ? level.getCurrentUserId().getRoleMaster().getRoleName(): "UNKNOWN",
                        level.getCurrentUserId() != null ? level.getCurrentUserId().getNameOfUser(): "UNKNOWN",
                        level.getNextUserId() != null ? level.getNextUserId().getRoleMaster().getRoleName(): "UNKNOWN",
                        level.getNextUserId() != null ? level.getNextUserId().getNameOfUser(): "UNKNOWN"
                ))
                .collect(Collectors.toList());
    }
}