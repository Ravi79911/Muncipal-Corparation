package com.ahmednagar.municipal.forms.formsWaterManagement.controller;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.DocumentDetails;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.DocumentsDetailsServices;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/water/forms/document-details")
public class DocumentDetailsController {

    @Autowired
    private DocumentsDetailsServices documentDetailsService;

    //    to upload pdf fileNo.
    @PostMapping("/upload")
    public ResponseEntity<?> uploadDocument(@Valid @RequestParam("fileName") MultipartFile file,
                                            @RequestParam("documentNum") String documentNum,
                                            @RequestParam("status") int status,
                                            @RequestParam("createdBy") int createdBy,
                                            @RequestParam("suspendedStatus") @DefaultValue("0") int suspendedStatus,
                                            @RequestParam("municipalId") int municipalId,
                                            @RequestParam("newConnectionFormId") int newConnectionFormId,
                                            @RequestParam("documentTypeMasterId") Long documentTypeMasterId)
            {

        try {
            DocumentDetails result = documentDetailsService.uploadDocument(file, documentNum, status, createdBy, suspendedStatus, municipalId, newConnectionFormId, documentTypeMasterId);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }


    // 1. Post API to create a new document details
    @PostMapping
    public ResponseEntity<?> createDocumentDetails(@Valid @RequestBody DocumentDetails documentDetails, @RequestParam int createdBy) {
        DocumentDetails createdDocumentDetails = documentDetailsService.createDocumentDetails(documentDetails, createdBy);
        if (createdDocumentDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Document Details not created");
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdDocumentDetails);
    }

//    // 2. Put API to update an existing document details
//    @PutMapping("/{id}")
//    public ResponseEntity<?> updateDocumentDetails(@PathVariable int id, @Valid @RequestBody DocumentDetails documentDetails, @RequestParam int updatedBy) {
//        DocumentDetails updatedDocumentDetails = documentDetailsService.updateDocumentDetails(id, documentDetails, 1);
//        if (updatedDocumentDetails == null) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                    .body("Document Details not updated");
//        }
//        return ResponseEntity.status(HttpStatus.OK)
//                .body(updatedDocumentDetails);
//    }

    // 3. Delete API to delete document details by ID
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> deleteDocumentDetailsById(@PathVariable Long id, @RequestParam int updatedBy, @RequestParam(required = false, defaultValue = "1") int suspendedStatus) {
        DocumentDetails documentDetails = documentDetailsService.deleteDocumentDetailsById(id, suspendedStatus, 1);
        if (documentDetails == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(" Document Details not found with the given ID: " + id);
        }
        return ResponseEntity.ok(documentDetails);
    }

    // 4. Get API to retrieve document details by ID
//    @GetMapping("/{id}")
//    public ResponseEntity<?> getDocumentDetailsById(@PathVariable int id) {
//        DocumentDetails documentDetails = documentDetailsService.getDocumentDetailsById(id);
//        if (documentDetails == null) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND)
//                    .body("Document Details not found with the given ID: " + id);
//        }
//        return ResponseEntity.ok(documentDetails);
//    }

    // 5. Get API to retrieve document details by Municipal ID
    @GetMapping("/municipal/{municipalId}")
    public ResponseEntity<?> getDocumentDetailsByMunicipalId(@PathVariable int municipalId) {
        List<DocumentDetails> documentDetailsList = documentDetailsService.getDocumentDetailsByMunicipalId(municipalId);
        if (documentDetailsList.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Document Details not found with the given municipal ID");
        }
        return ResponseEntity.ok(documentDetailsList);
    }

//    Get API to retrieve all document which was uploaded by the user
    @GetMapping("documnetDetails/{id}")
    public ResponseEntity<?> getDocumentDetails(@PathVariable Long id) {
        try {
            Resource file = documentDetailsService.loadDocumentDetails(id);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
                    .body(file);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

}
