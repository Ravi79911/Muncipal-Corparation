package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_view_application_electricity_details")
public class ViewApplicationElectricityDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    @NotNull(message = "ID is required")
    private int id;

    @Column(name = "elec_k_number")
    @NotNull(message = "K Number is required")
    @Size(max = 50, message = "K No cannot exceed 50 characters")
    private String electricityKNumber;

    @Column(name = "consumer_no")
    @NotNull(message = "Consumer No is required")
    @Size(max = 70, message = "Consumer No cannot exceed 70 characters")
    private String consumerNo;

    @Column(name = "connection_type")
    @NotNull(message = "Connection Type is required")
    @Size(max = 150, message = "Connection Type cannot exceed 150 characters")
    private String connectionType;

    @Column(name = "consumer_name")
    @NotNull(message = "Consumer Name is required")
    @Size(max = 150, message = "Consumer Name cannot exceed 150 characters")
    private String consumerName;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "application_master_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewApplicationFromMaster viewApplicationFromMaster;

}
