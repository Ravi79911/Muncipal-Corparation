package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_view_muni_property_additional_details")
public class ViewMunicipalPropertyAdditionalDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "provision_name")
    private String provisionName;

    @NotNull(message = "flag status is required")
    @Column(name = "flag_status")
    private boolean flagStatus;

    @Column(name = "area_occupied_sqft")
    private BigDecimal areaOccupiedSqft;

    @Column(name = "installation_at_on")
    private String installationAtOn;

    @Column(name = "installation_date")
    private LocalDate installationDate;

    @NotNull(message = "created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewMunicipalPropertyMaster viewMunicipalPropertyMaster;

}
