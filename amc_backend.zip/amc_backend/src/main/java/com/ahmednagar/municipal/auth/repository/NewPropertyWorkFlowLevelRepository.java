package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.NewPropertyWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.ViewMunicipalPropertyMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface NewPropertyWorkFlowLevelRepository extends JpaRepository<NewPropertyWorkFlowLevel, Long> {

    List<NewPropertyWorkFlowLevel> findByApplicationId(ViewMunicipalPropertyMaster applicationId);

    @Query(value = "SELECT TOP 1 * FROM tbl_new_work_flow_level WHERE application_id = :applicationId AND status_code = :statusCode ORDER BY created_date DESC", nativeQuery = true)
    Optional<NewPropertyWorkFlowLevel> findLatestWorkFlowByApplicationIdAndStatusCode(@Param("applicationId") Long applicationId, @Param("statusCode") Long statusCode);

}
