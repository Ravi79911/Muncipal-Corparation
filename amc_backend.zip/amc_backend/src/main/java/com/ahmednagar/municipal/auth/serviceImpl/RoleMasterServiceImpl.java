package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.RoleDto;
import com.ahmednagar.municipal.auth.model.RoleMaster;
import com.ahmednagar.municipal.auth.repository.RoleMasterRepository;
import com.ahmednagar.municipal.auth.service.RoleMasterService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RoleMasterServiceImpl implements RoleMasterService {

    @Autowired
    RoleMasterRepository roleMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public RoleMaster createRole(RoleMaster roleMaster) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        roleMaster.setCreatedDate(currentDateTime);
        roleMaster.setSuspendedStatus(roleMaster.getSuspendedStatus() != null ? roleMaster.getSuspendedStatus() : 0);
        //role.setCreatedBy(createdBy);
        return roleMasterRepository.saveAndFlush(roleMaster);
    }

    @Override
    public List<RoleDto> findAllRole() {
        List<RoleMaster> roles = roleMasterRepository.findAll();
        return roles.stream()
                .map(role -> modelMapper.map(role, RoleDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<RoleDto> findAllRoleByMunicipalId(int municipalId) {
        List<RoleMaster> roles = roleMasterRepository.findByMunicipalId(municipalId);
        return roles.stream()
                .map(role -> modelMapper.map(role, RoleDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public RoleMaster updateRole(Long id, RoleMaster updatedRole) {
        Optional<RoleMaster> roleMasterOptional = roleMasterRepository.findById(id);
        if (roleMasterOptional.isPresent()) {
            RoleMaster existingRoleMaster = roleMasterOptional.get();
            existingRoleMaster.setRoleName(updatedRole.getRoleName());
            existingRoleMaster.setUpdatedDate(LocalDateTime.now());
            existingRoleMaster.setUpdatedBy(updatedRole.getUpdatedBy());
            existingRoleMaster.setSuspendedStatus(updatedRole.getSuspendedStatus() != null ? updatedRole.getSuspendedStatus() : 0);
            existingRoleMaster.setMunicipalId(updatedRole.getMunicipalId());

            return roleMasterRepository.saveAndFlush(existingRoleMaster);
        } else {
            throw new RuntimeException("RoleMaster not found with id: " + id);
        }
    }

    @Override
    public RoleMaster changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<RoleMaster> roleOptional = roleMasterRepository.findById(id);
        if (roleOptional.isPresent()) {
            RoleMaster role = roleOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            role.setUpdatedDate(currentDateTime);
            role.setSuspendedStatus(status);
            role.setUpdatedBy(updatedBy);
            return roleMasterRepository.saveAndFlush(role);
        }
        return null;
    }

}
