package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.RenewalSurrenderAmendmentAppliedDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;

@EnableJpaRepositories
public interface RenewalSurrenderAmendmentAppliedDetailsRepository extends JpaRepository<RenewalSurrenderAmendmentAppliedDetails,Integer> {
    List<RenewalSurrenderAmendmentAppliedDetails> findByMunicipalId(int municipalId);

    List<RenewalSurrenderAmendmentAppliedDetails> findBySuspendedStatus(Integer status);

//    List<RenewalSurrenderAmendmentAppliedDetails> findByPrevLicenseNo(String prevLicenseNo);

    @Query(value = "SELECT Top 1 * FROM tbl2_renewal_surrender_amendment_applied_details WHERE prev_license_no = :prevLicenseNo ORDER BY created_date DESC", nativeQuery = true)
    RenewalSurrenderAmendmentAppliedDetails findTopByLicenseNoOrderByCreatedDateDesc(@Param("prevLicenseNo") String prevLicenseNo);
}

