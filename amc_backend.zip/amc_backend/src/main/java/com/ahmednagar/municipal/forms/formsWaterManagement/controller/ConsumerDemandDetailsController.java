package com.ahmednagar.municipal.forms.formsWaterManagement.controller;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerDemandDetails;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.ConsumerDemandDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/water/demand/consumer-demand-details")
public class ConsumerDemandDetailsController {

    @Autowired
    private ConsumerDemandDetailsService consumerDemandDetailsService;

    @PostMapping("/create")
    public ResponseEntity<ConsumerDemandDetails> createDemandDetail(
            @RequestBody ConsumerDemandDetails consumerDemandDetails) {
        return ResponseEntity.ok(consumerDemandDetailsService.createDemandDetail(consumerDemandDetails));
    }

//    @GetMapping("/previous-month-reading/{consumerId}")
//    public ResponseEntity<ConsumerDemandDetails> getLatestBillByConsumerId(
//            @PathVariable Long consumerId) {
//        return ResponseEntity.ok(consumerDemandDetailsService.getLatestBillByConsumerId(consumerId));
//    }

    @GetMapping("/latest-reading/{consumerNo}")
    public int getCurrentReadingOfLatestBill(@PathVariable String consumerNo) {
        return consumerDemandDetailsService.getCurrentReadingOfLatestBill(consumerNo);
    }

}
