package com.ahmednagar.municipal.auth.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserMasterLoginLogOffHistoryDto {

    private Long id;
    private UserMasterDetailsDto userId;
    private Float loginLogoffStatus;
    private LocalDateTime loginLogoffDatetime;
    private String ipAddress;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private Long municipalId;

}
