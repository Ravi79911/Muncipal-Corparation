package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.UserMasterLoginLogOffHistoryDto;
import com.ahmednagar.municipal.auth.model.UserMasterLoginLogOffHistory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserMasterLoginLogOffHistoryService {

    UserMasterLoginLogOffHistory savedUserLoginLogoffHistory(UserMasterLoginLogOffHistory userMasterLoginLogOffHistory);

    List<UserMasterLoginLogOffHistoryDto> findAllUserLoginLogoffHistory();

    List<UserMasterLoginLogOffHistoryDto> findAllUserLoginLogoffHistoryByMunicipalId(Long municipalId);

    UserMasterLoginLogOffHistory updateUserLoginLogoffHistory(Long id, UserMasterLoginLogOffHistory updatedUserMasterLoginLogOffHistory);

    UserMasterLoginLogOffHistory changeStatus(Long id, Integer status, int updatedBy);

}
