package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_view_trade_application_type_masters")
public class ViewTradeApplicationTypeMasters {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @NotNull
    @Column(name = "application_type_name")
    private String applicationTypeName;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

//    @OneToMany(mappedBy = "applicationTypeId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<MlRateMaster> mlRateMasters;
//
//    @OneToMany(mappedBy = "applicationTypeId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<MlDocumentsMaster> mlDocumentsMasters;
//
//    @OneToMany(mappedBy = "applicationTypeId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<ApplicationFromMaster> applicationFromMasters;
//
//    @OneToMany(mappedBy = "applicationTypeId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<TemporaryLicensePaymentScheduleDetails> temporaryLicensePaymentScheduleDetails;
//
//    @OneToMany(mappedBy = "applicationTypeId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<ViewRenewalSurrenderAmendmentAppliedDetails> viewRenewalSurrenderAmendmentAppliedDetailsSet;
//
//    @OneToMany(mappedBy = "applicationTypeId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private Set<ViewApplicationLicenseDetails> viewApplicationLicenseDetails;

}
