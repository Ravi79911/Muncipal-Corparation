package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorRate;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorRateRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorRateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.Provider;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VendorRateServiceImpl implements VendorRateService {

    @Autowired
    private VendorRateRepository vendorRateRepository;

    @Override
    public VendorRate saveVendorRate(VendorRate vendorRate) {
        vendorRate.setCreatedDate(LocalDateTime.now());
        vendorRate.setSuspendedStatus(0);
        return vendorRateRepository.saveAndFlush(vendorRate);
    }

    @Override
    public Optional<VendorRate> getByVendorRateId(Long vendorRateId) {
       return vendorRateRepository.findById(vendorRateId);
    }

    @Override
    public Optional<VendorRate> updateVendorRate(Long vendorRateId, VendorRate vendorRate) {
       Optional<VendorRate> existingVendorRate = vendorRateRepository.findById(vendorRateId);
       if (existingVendorRate.isPresent()) {
           existingVendorRate.get().setUpdatedDate(LocalDateTime.now());
           existingVendorRate.get().setUpdatedBy(vendorRate.getUpdatedBy());
           existingVendorRate.get().setFixedRate(vendorRate.getFixedRate());
           existingVendorRate.get().setRateInDays(vendorRate.getRateInDays());
           existingVendorRate.get().setEffectiveDate(vendorRate.getEffectiveDate());
           existingVendorRate.get().setIsActive(vendorRate.getIsActive());
           existingVendorRate.get().setVendorMasId(vendorRate.getVendorMasId());

           return Optional.of(vendorRateRepository.saveAndFlush(existingVendorRate.get()));
       }
       return Optional.empty();
    }

    @Override
    public Optional<VendorRate> deleteVendorRate(Long vendorRateId) {
        Optional<VendorRate> existingVendorRate = vendorRateRepository.findById(vendorRateId);
        if (existingVendorRate.isPresent()) {
            existingVendorRate.get().setSuspendedStatus(1);
            vendorRateRepository.saveAndFlush(existingVendorRate.get());
            return Optional.of(existingVendorRate.get());
        }
        return Optional.empty();
    }

    @Override
    public List<VendorRate> getAllVendorRates() {
        return vendorRateRepository.findBySuspendedStatus(0);
    }

    @Override
    public List<VendorRate> getVendorRatesByMarketNameAndVendorName(String vendorMarketName, String vendorNameEng) {
            return vendorRateRepository.findByVendorMarketNameAndVendorNameEng(vendorMarketName, vendorNameEng);
        }
    }

