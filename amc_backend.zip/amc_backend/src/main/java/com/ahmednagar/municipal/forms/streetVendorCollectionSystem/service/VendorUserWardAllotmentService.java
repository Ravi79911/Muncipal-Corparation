package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserWardAllotment;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public interface VendorUserWardAllotmentService {

    VendorUserWardAllotment saveUserWardAllotment(VendorUserWardAllotment vendorUserWardAllotment);
    Optional<VendorUserWardAllotment> getUserWardAllotment(Long id);
}
