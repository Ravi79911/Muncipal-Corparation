package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorMaster;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorRate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface VendorRateService {

    VendorRate saveVendorRate(VendorRate vendorRate);
    Optional<VendorRate> getByVendorRateId(Long vendorRateId);
    Optional<VendorRate> updateVendorRate(Long vendorRateId, VendorRate vendorRate);
    Optional<VendorRate> deleteVendorRate(Long vendorRateId);
    List<VendorRate> getAllVendorRates();
    List<VendorRate> getVendorRatesByMarketNameAndVendorName(String vendorMarketName, String vendorNameEng);
}
