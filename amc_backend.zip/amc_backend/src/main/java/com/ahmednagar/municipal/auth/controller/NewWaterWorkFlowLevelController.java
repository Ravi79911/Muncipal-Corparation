package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.NewWaterWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.NewWaterWorkFlowLevel;
import com.ahmednagar.municipal.auth.service.NewWaterWorkFlowLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/water/work/new-flow/level")
public class NewWaterWorkFlowLevelController {

    @Autowired
    private NewWaterWorkFlowLevelService newWaterWorkFlowLevelService;

    @PostMapping("/new-transition")
    public ResponseEntity<NewWaterWorkFlowLevel> handleWorkFlowsTransition(@RequestBody NewWaterWorkFlowLevel newWaterWorkFlowLevel) {
        NewWaterWorkFlowLevel updatedNewWaterWorkFlowLevel = newWaterWorkFlowLevelService.handleWorkFlowsTransition(newWaterWorkFlowLevel);
        return ResponseEntity.ok(updatedNewWaterWorkFlowLevel);
    }

    @PostMapping("/new-application")
    public ResponseEntity<NewWaterWorkFlowLevel> createNewWorkflow(@RequestBody NewWaterWorkFlowLevel newWaterWorkFlowLevel) {
        NewWaterWorkFlowLevel savedWorkflow = newWaterWorkFlowLevelService.createNewApplicationTransation(newWaterWorkFlowLevel);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedWorkflow);
    }


    @GetMapping("/getAllNewWorkFlowsList")
    public ResponseEntity<List<NewWaterWorkFlowLevelDto>> getAllNewWaterWorkFlowLevelList() {
        List<NewWaterWorkFlowLevelDto> workFlows = newWaterWorkFlowLevelService.getAllNewWaterWorkFlowLevel();
        return ResponseEntity.ok(workFlows);
    }

}
