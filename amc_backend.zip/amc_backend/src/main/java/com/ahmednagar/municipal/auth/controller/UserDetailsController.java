package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.UserDetails;
import com.ahmednagar.municipal.auth.service.RoleMasterService;
import com.ahmednagar.municipal.auth.service.UserDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/auth")
public class UserDetailsController {

    @Autowired
    private UserDetailsService userDetailsService;

    @PostMapping("/createUserDetails")
    public ResponseEntity<?> createUserDetails(@Valid @RequestBody UserDetails userDetails, @RequestParam int createdBy) {
        UserDetails createdUserDetails = userDetailsService.createUserDetails(userDetails, createdBy);
        if (createdUserDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdUserDetails);

    }

    @PutMapping("/updateUserDetails/{id}")
    public ResponseEntity<?> updateUserDetails(@PathVariable Long id, @RequestBody UserDetails userDetails) {
        UserDetails updatedUserDetails = userDetailsService.updateUserDetails(id, userDetails);
        if (updatedUserDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedUserDetails);
    }

    @PatchMapping("/changeSuspendedStatus/{id}")
    public ResponseEntity<?> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        UserDetails updatedUserDetails = userDetailsService.changeSuspendedStatus(id, status);
        if (updatedUserDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedUserDetails);
    }
    //get userdetails By MunicipalId
    @GetMapping("/MunicipalUserDetails/{municipalId}")
    public ResponseEntity <?> getByMunicipalId (@PathVariable Long municipalId){
        List<UserDetails> userDetails = userDetailsService.getUserDetailsByMunicipalId(municipalId);
        if (userDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(userDetails);
    }
}
