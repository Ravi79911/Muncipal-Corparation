package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.RenewalSurrenderAmendmentAppliedDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.RenewalSurrenderAmendmentAppliedDetails;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface RenewalSurrenderAmendmentAppliedDetailsService {
    RenewalSurrenderAmendmentAppliedDetails saveAmendmentAppliedDetails(RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails, int createdBy);

    RenewalSurrenderAmendmentAppliedDetails saveSurrenderAppliedDetails(RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails, int i);

    RenewalSurrenderAmendmentAppliedDetails calculateRenewalApplicationFee(RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails);

    RenewalSurrenderAmendmentAppliedDetails savedRenewalApplication(RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails);

//    List<RenewalSurrenderAmendmentAppliedDetailsDto> findAllRenewalSurrenderAmendmentAppliedDetails();
//
//    List<RenewalSurrenderAmendmentAppliedDetails> findAllActiveRenewalSurrenderAmendmentAppliedDetails(Integer status);

    RenewalSurrenderAmendmentAppliedDetails findRenewalSurrenderAmendmentAppliedDetailsById(int id);

    List<RenewalSurrenderAmendmentAppliedDetailsDto> findAllRenewalSurrenderAmendmentAppliedDetailsByMunicipalId(int municipalId);

    RenewalSurrenderAmendmentAppliedDetails updateRenewalSurrenderAmendmentAppliedDetails(int id, RenewalSurrenderAmendmentAppliedDetails updatedRenewalSurrenderAmendmentAppliedDetails,int updatedBy);

    RenewalSurrenderAmendmentAppliedDetails changeSuspendedStatus(int id, int status,int updatedBy);


//    RenewalSurrenderAmendmentAppliedDetails getLatestDetailsByLicenseNo(String preLicenseNo);
}
