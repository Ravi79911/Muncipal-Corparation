package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.dto.PropertyCalculationDetailsEduCessDto;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyCalculationDetailsEduCess;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface PropertyCalculationDetailsEduCessService {

    PropertyCalculationDetailsEduCess createPropertyCalculationDetailsEduCess(PropertyCalculationDetailsEduCess propertyCalculationDetailsEducess);

    PropertyCalculationDetailsEduCess findPropertyCalculationDetailsEduCessById(Long id);

    List<PropertyCalculationDetailsEduCessDto> findAllPropertyCalculationDetailsEduCessByMunicipalId(int municipalId);

    PropertyCalculationDetailsEduCess updatePropertyCalculationDetailsEduCess(Long id, PropertyCalculationDetailsEduCess updatedPropertyCalculationDetailsEduCess, int updatedBy);

    PropertyCalculationDetailsEduCess changeSuspendedStatus(Long id, int status, int updatedBy);

}
