package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface PropertyDemandMasterRepository extends JpaRepository<PropertyDemandMaster, Long> {

    List<PropertyDemandMaster> findByMunicipalPropertyMasterId(Long municipalPropertyMasterId);

    void deleteByMunicipalPropertyMasterId(Long municipalPropertyMasterId);

    List<PropertyDemandMaster> findByMunicipalId(int municipalId);

}
