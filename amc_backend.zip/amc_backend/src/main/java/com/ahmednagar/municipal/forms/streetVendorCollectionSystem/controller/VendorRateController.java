package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorRate;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorRateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorRateController {

    @Autowired
    private VendorRateService vendorRateService;

    @PostMapping("/saveVendorRateMaster")
    public ResponseEntity<VendorRate> saveVendorRateMaster(@RequestBody VendorRate vendorRate) {
        return ResponseEntity.ok(vendorRateService.saveVendorRate(vendorRate));
    }

    @GetMapping("/getAllVendorRateMaster")
    public ResponseEntity<List<VendorRate>> getAllVendorRateMaster() {
        return ResponseEntity.ok(vendorRateService.getAllVendorRates());
    }

    @GetMapping("/findVendorRateById/{id}")
    public ResponseEntity<Optional<VendorRate>> findVendorRateById(@PathVariable("id") Long id) {
        return ResponseEntity.ok(vendorRateService.getByVendorRateId(id));
    }

    @PutMapping("/updateVendorRateMaster/{id}")
    public ResponseEntity<Optional<VendorRate>> updateVendorRateMaster(@PathVariable Long id, @RequestBody VendorRate vendorRate) {
        return ResponseEntity.ok(vendorRateService.updateVendorRate(id, vendorRate));
    }

    @DeleteMapping("/deleteVendorRateMaster/{id}")
    public ResponseEntity<Optional<VendorRate>> deleteVendorRateMaster(@PathVariable Long id) {
        return ResponseEntity.ok(vendorRateService.deleteVendorRate(id));
    }

    @GetMapping("/search")
    public ResponseEntity<List<VendorRate>> getVendorRates(
            @RequestParam("vendorMarketName") String vendorMarketName,
            @RequestParam("vendorNameEng") String vendorNameEng) {
        List<VendorRate> vendorRates = vendorRateService.getVendorRatesByMarketNameAndVendorName(vendorMarketName, vendorNameEng);
        return ResponseEntity.ok(vendorRates);
    }
}
