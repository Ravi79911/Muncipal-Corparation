package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.MunicipalLicensePaymentDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.MunicipalLicensePaymentDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.MunicipalLicensePaymentDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/municipal/license/payments/details")
public class MunicipalLicensePaymentDetailsController {
    @Autowired
    private MunicipalLicensePaymentDetailsService municipalLicensePaymentDetailsService;

    //create Application Form
    @PostMapping("/create")
    public ResponseEntity<MunicipalLicensePaymentDetails> createMunicipalLicensePaymentDetails(@Valid @RequestBody MunicipalLicensePaymentDetails municipalLicensePaymentDetails) {
        MunicipalLicensePaymentDetails createdMunicipalLicensePaymentDetails = municipalLicensePaymentDetailsService.saveMunicipalLicensePaymentDetails(municipalLicensePaymentDetails);
        return ResponseEntity.status(201).body(createdMunicipalLicensePaymentDetails);
    }

    //  to get the Application Form by id for user
    @GetMapping("/get/{id}")
    public ResponseEntity<MunicipalLicensePaymentDetails> getMunicipalLicensePaymentDetailsById(@PathVariable Long id) {
        MunicipalLicensePaymentDetails municipalLicensePaymentDetails = municipalLicensePaymentDetailsService.findMunicipalLicensePaymentDetailsById(id);
        return ResponseEntity.ok(municipalLicensePaymentDetails);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllMunicipalLicensePaymentDetailsByMunicipalId(@PathVariable int municipalId) {
        List<MunicipalLicensePaymentDetailsDto> municipalLicensePaymentDetails = municipalLicensePaymentDetailsService.findAllMunicipalLicensePaymentDetailsByMunicipalId(municipalId);
        if (municipalLicensePaymentDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No MunicipalLicensePaymentDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(municipalLicensePaymentDetails);
    }

    //     Update Application From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<MunicipalLicensePaymentDetails> updateMunicipalLicensePaymentDetails(@PathVariable("id") Long id, @RequestBody MunicipalLicensePaymentDetails updatedMunicipalLicensePaymentDetails) {
        try {
            MunicipalLicensePaymentDetails updated = municipalLicensePaymentDetailsService.updateMunicipalLicensePaymentDetails(id, updatedMunicipalLicensePaymentDetails, 1);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete Application From for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<MunicipalLicensePaymentDetails> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        MunicipalLicensePaymentDetails updatedMunicipalLicensePaymentDetails = municipalLicensePaymentDetailsService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedMunicipalLicensePaymentDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedMunicipalLicensePaymentDetails);
    }


}

