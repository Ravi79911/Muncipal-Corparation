package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbl_user_details")
public class UserMasterDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "user master id can't be null")
    @Column(name = "usermas_id", nullable = false)
    private int usermasId;

    @NotNull(message = "zone id can't be null")
    @Column(name = "zone_id", nullable = false)
    private Long zoneId;

    @NotNull(message = "ward id can't be null")
    @Column(name = "ward_id", nullable = false)
    private Long wardId;

    @Column(name = "created_by", nullable = false)
    private int createdBy;

    @NotNull(message = "created date can't be null")
    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by", nullable = false)
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @NotNull(message = "municipal id cannot be null")
    @Column(name = "municipal_id", nullable = false)
    private Long municipalId;

//    @OneToMany(mappedBy = "userId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    private Set<UserMasterLoginLogOffHistory> userLoginLogoffHistories;

//        @OneToMany(mappedBy = "userId",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
//        //@JsonIgnore
//        private Set<UserMasterPasswordChangeHistory> userPasswordChangeHistories;

}
