package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_user_master_otp_history")
public class UserMasterOtpHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "email")
    private String email;

    @Column(name = "mobile_no")
    private String mobileNumber;

    @Column(name = "email_otp")
    private String emailOtp;

    @Column(name = "mobile_otp")
    private String mobileOtp;

    @Column(name = "email_otp_timestamp")
    private LocalDateTime emailOtpGeneratedDateTime;

    @Column(name = "mobile_otp_timestamp")
    private LocalDateTime mobileOtpGeneratedDateTime;

    public UserMasterOtpHistory(String email, String mobileNumber, String emailOtp, String mobileOtp,
                                LocalDateTime emailOtpGeneratedDateTime, LocalDateTime mobileOtpGeneratedDateTime) {
        this.email = email;
        this.mobileNumber = mobileNumber;
        this.emailOtp = emailOtp;
        this.mobileOtp = mobileOtp;
        this.emailOtpGeneratedDateTime = emailOtpGeneratedDateTime;
        this.mobileOtpGeneratedDateTime = mobileOtpGeneratedDateTime;
    }

}
