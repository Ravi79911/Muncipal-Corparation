package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbls_view_consumer_document_details")
public class ViewConsumerDocumentDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "document_file_name")
    @NotNull
    @Size(max = 150, message = "document file name cannot exceed 150 characters")
    private String documentFileName;

    @Column(name = "document_path")
    @NotNull(message = "document path is required")
    @Size(max = 150, message = "document path cannot exceed 150 characters")
    private String documentPath;

    @NotNull(message = "Status is mandatory")
    @Column(name = "document_no")
    private String documentNum;

    @NotNull(message = "Status is mandatory")
    @Column(name = "status")
    private int status;

    @NotNull(message = "Created By is mandatory")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private int suspendedStatus;

    @NotNull(message = "Municipal ID is mandatory")
    @Column(name = "municipal_id")
    private int municipalId;

    @Column(name = "approved_status")
    private Float approvedStatus;

    @ManyToOne
    @JoinColumn(name = "document_type_mas_id", referencedColumnName = "id", nullable = false)
//    @JsonBackReference
    private ViewWaterDocumentTypeMasters viewWaterDocumentTypeMasters;

    @ManyToOne
    @JoinColumn(name = "appmas_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewNewWaterConnectionFormMaster viewNewWaterConnectionFormMaster;

}
