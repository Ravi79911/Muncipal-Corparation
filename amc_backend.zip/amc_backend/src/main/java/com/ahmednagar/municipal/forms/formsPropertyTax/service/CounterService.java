package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import org.springframework.stereotype.Service;

@Service
public interface CounterService {

    int getNextCounterValue(String counterName);

}
