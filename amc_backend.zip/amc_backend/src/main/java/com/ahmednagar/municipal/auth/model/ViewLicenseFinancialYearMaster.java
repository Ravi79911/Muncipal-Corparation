package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_view_license_financial_year_master")
public class ViewLicenseFinancialYearMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @NotNull(message = "please enter the financial year")
    @Column(name = "Fin_year")
    private String fyYear;

    @Column(name = "created_date")
    private LocalDate createdDate;

//    @OneToMany(mappedBy = "fyYearId", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//    @JsonIgnore
//    private Set<MlRateMaster> mlRateMasters;
//
//    @OneToMany(mappedBy = "fyYearId", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//    @JsonIgnore
//    private Set<ViewRenewalSurrenderAmendmentAppliedDetails> viewRenewalSurrenderAmendmentAppliedDetailsSet;
//
//    @OneToMany(mappedBy = "licenseFinancialYearMasterId", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//    @JsonIgnore
//    private Set<ApplicationFromMaster> applicationFromMasters;

}
