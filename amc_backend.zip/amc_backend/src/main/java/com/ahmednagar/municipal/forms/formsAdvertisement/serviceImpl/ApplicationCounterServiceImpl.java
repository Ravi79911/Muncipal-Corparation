package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.forms.formsAdvertisement.model.ApplicationCounter;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.ApplicationCounterRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.ApplicationCounterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApplicationCounterServiceImpl implements ApplicationCounterService {

    @Autowired
    private ApplicationCounterRepository applicationCounterRepository;

    @Override
    public int getNextCounterValue(String counterName) {
        ApplicationCounter applicationCounter = (ApplicationCounter) applicationCounterRepository.findByCounterName(counterName)
                .orElseThrow(() -> new IllegalStateException("applicationCounter not found: " + counterName));

//        System.out.println("Current counter value: " + counter.getCounterValue());

        int nextValue = applicationCounter.getCounterValue() + 1;
        applicationCounter.setCounterValue(nextValue);

//        System.out.println("New counter value: " + nextValue);

        applicationCounterRepository.saveAndFlush(applicationCounter);
        return nextValue;
    }
}
