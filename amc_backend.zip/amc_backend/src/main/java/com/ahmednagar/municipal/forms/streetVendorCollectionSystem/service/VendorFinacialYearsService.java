package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorFinacialYears;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface VendorFinacialYearsService {

    VendorFinacialYears saveVendorFinacialYears(VendorFinacialYears vendorFinacialYears);
    List<VendorFinacialYears> getAllVendorFinacialYears();
}
