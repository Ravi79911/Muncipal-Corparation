package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.MunicipalLicensePaymentDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.MunicipalLicensePaymentDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MunicipalLicensePaymentDetailsService {
    MunicipalLicensePaymentDetails saveMunicipalLicensePaymentDetails(MunicipalLicensePaymentDetails municipalLicensePaymentDetails);

    MunicipalLicensePaymentDetails findMunicipalLicensePaymentDetailsById(Long id);

    List<MunicipalLicensePaymentDetailsDto> findAllMunicipalLicensePaymentDetailsByMunicipalId(int municipalId);

    MunicipalLicensePaymentDetails updateMunicipalLicensePaymentDetails(Long id, MunicipalLicensePaymentDetails updatedMunicipalLicensePaymentDetails, int updatedBy);

    MunicipalLicensePaymentDetails changeSuspendedStatus(Long id, int status, int updatedBy);
}
