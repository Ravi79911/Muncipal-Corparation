package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.ForgotPassword;
import com.ahmednagar.municipal.auth.model.UserMaster;
import com.ahmednagar.municipal.auth.repository.UserMasterRepository;
import com.ahmednagar.municipal.auth.service.UserMasterService;
import com.ahmednagar.municipal.auth.utils.TokenGeneration;
import com.ahmednagar.municipal.master.propertyTax.exception.EmailNotFoundException;
import com.ahmednagar.municipal.notification.EmailService;
import com.ahmednagar.municipal.notification.OTPService;
import jakarta.mail.MessagingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class UserMasterServiceImpl implements UserMasterService {

    @Autowired
    UserMasterRepository userMasterRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    TokenGeneration tokenGeneration;

    @Autowired
    EmailService emailService;

    @Autowired
    OTPService otpService;

    private static final Logger logger = LoggerFactory.getLogger(UserMasterServiceImpl.class);

    @Value("${upload.base.dir}")
    private String BASE_UPLOAD_DIR;

    private static final long MAX_FILE_SIZE = 200 * 1024;
    private static final int OTP_EXPIRATION_MINUTES = 5;

    @Override
    public UserMaster createUserMaster(UserMaster userMaster, MultipartFile userPicture) {
        if (isEmailExists(userMaster.getEmail())) {
            throw new IllegalArgumentException("email address already exists");
        }

        if (isUserNameExists(userMaster.getUsername())) {
            throw new IllegalArgumentException("username already exists");
        }

        System.out.println("Password being saved: " + userMaster.getPassword());

        userMaster.setUpdatedBy(userMaster.getUpdatedBy() != null ? userMaster.getUpdatedBy() : 0);
        userMaster.setSuspendedStatus(userMaster.getSuspendedStatus() != null ? userMaster.getSuspendedStatus() : 0);

        // handle file upload
        if (userPicture != null && !userPicture.isEmpty()) {
            handleFileUpload(userPicture, userMaster);
        } else {
            System.out.println("uploaded file is null or empty");
        }
        userMaster.setPassword(passwordEncoder.encode(userMaster.getPassword()));
        userMaster.setCreatedDate(LocalDateTime.now());
        userMaster.setUpdatedDate(LocalDateTime.now());
        UserMaster savedUser = userMasterRepository.saveAndFlush(userMaster);

        // after saving the user, send a confirmation email
//        try {
//            emailService.sendSignupConfirmationEmail(savedUser.getEmail());
//        } catch (MessagingException | UnsupportedEncodingException e) {
//            logger.error("Failed to send confirmation email to {}", savedUser.getEmail(), e);
//            throw new RuntimeException("failed to send confirmation email");
//        } // block end for email sending

        generateAndSendOtp(savedUser); // generate otp for email & mobile verification
        return savedUser;
    }

    @Override
    public UserMaster findByUserId(Long id) {
        return userMasterRepository.findById(id).orElse(null);
    }

    @Override
    public void generateAndSendOtp(UserMaster userMaster) {
        // generate email otp
        String emailOtp = otpService.generateOTP();
        userMaster.setEmailOtp(emailOtp);
        userMaster.setEmailOtpGeneratedDateTime(LocalDateTime.now());

        // generate mobile otp
        String mobileOtp = otpService.generateOTP();
        userMaster.setMobileOtp(mobileOtp);
        userMaster.setMobileOtpGeneratedDateTime(LocalDateTime.now());
        userMasterRepository.saveAndFlush(userMaster);

        // send otp via email
        otpService.sendEmailOTP(userMaster.getEmail(), emailOtp);

        // send otp via sms
        otpService.sendSMSOTP(userMaster.getMobileNo(), mobileOtp);
    }

    @Override
    public boolean validateEmailOtp(UserMaster userMaster, String otp) {
        if (userMaster.getEmailOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            return false; // otp expired
        }
        if (userMaster.getEmailOtp().equals(otp)) {
            // otp matches, update email verification status
            userMaster.setEmailVerified(true);
            userMaster.setEmailOtp(null); // clear otp after successful verification
            userMaster.setEmailOtpGeneratedDateTime(null); // clear otp timestamp
            userMaster.setUpdatedDate(LocalDateTime.now());
            userMasterRepository.saveAndFlush(userMaster);

            // check if both email and mobile are verified
            if (userMaster.isEmailVerified() && userMaster.isMobileVerified()) {
                userMaster.setVerified(true); // set overall verified status
                userMasterRepository.saveAndFlush(userMaster);
                // send confirmation email when the user is fully verified
                try {
                    emailService.sendSignupConfirmationEmail(userMaster.getEmail());
                } catch (MessagingException | UnsupportedEncodingException e) {
                    logger.error("Failed to send confirmation email to {}", userMaster.getEmail(), e);
                }
            }
            return true; // verification successful
        }
        return false; // otp mismatch
    }

    @Override
    public boolean validateMobileOtp(UserMaster userMaster, String otp) {
        if (userMaster.getMobileOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            return false; // otp expired
        }
        if (userMaster.getMobileOtp().equals(otp)) {
            // otp matches, update mobile verification status
            userMaster.setMobileVerified(true);
            userMaster.setMobileOtp(null); // clear otp after successful verification
            userMaster.setMobileOtpGeneratedDateTime(null); // clear OTP timestamp
            userMaster.setUpdatedDate(LocalDateTime.now());
            userMasterRepository.saveAndFlush(userMaster);

            // check if both email and mobile are verified
            if (userMaster.isEmailVerified() && userMaster.isMobileVerified()) {
                userMaster.setVerified(true); // set overall verified status
                userMasterRepository.saveAndFlush(userMaster);
                // send confirmation email when the user is fully verified
                try {
                    emailService.sendSignupConfirmationEmail(userMaster.getEmail());
                } catch (MessagingException | UnsupportedEncodingException e) {
                    logger.error("Failed to send confirmation email to {}", userMaster.getEmail(), e);
                }
            }
            return true; // verification successful
        }
        return false; // otp mismatch
    }

    @Override
    public void resendEmailOtp(UserMaster userMaster) {
        // check if the otp has expired
        if (userMaster.getEmailOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            // otp expired, regenerate otp
            String newEmailOtp = otpService.generateOTP();
            userMaster.setEmailOtp(newEmailOtp);
            userMaster.setEmailOtpGeneratedDateTime(LocalDateTime.now());
            userMasterRepository.saveAndFlush(userMaster);

            // send the new otp via email
            otpService.sendEmailOTP(userMaster.getEmail(), newEmailOtp);
        } else {
            // oTP is still valid, so no need to regenerate
            otpService.sendEmailOTP(userMaster.getEmail(), userMaster.getEmailOtp());
        }
    }

    @Override
    public void resendMobileOtp(UserMaster userMaster) {
        // check if the otp has expired
        if (userMaster.getMobileOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            // otp expired, regenerate otp
            String newMobileOtp = otpService.generateOTP();
            userMaster.setMobileOtp(newMobileOtp);
            userMaster.setMobileOtpGeneratedDateTime(LocalDateTime.now());
            userMasterRepository.saveAndFlush(userMaster);

            // send the new otp via sms
            otpService.sendSMSOTP(userMaster.getMobileNo(), newMobileOtp);
        } else {
            // otp is still valid, so no need to regenerate
            otpService.sendSMSOTP(userMaster.getMobileNo(), userMaster.getMobileOtp());
        }
    }

    @Override
    public boolean isEmailExists(String email) {
        return userMasterRepository.existsByEmail(email);
    }

    @Override
    public boolean isUserNameExists(String userName) {
        return userMasterRepository.existsByUserName(userName);
    }

    @Override
    public String forgotPassword(String email) {
        UserMaster userMaster = userMasterRepository.findByEmail(email).orElseThrow(() -> new EmailNotFoundException("email not found" + email));
        String generateToken = tokenGeneration.generateToken();
        try {
            emailService.sendResetPasswordEmail(email, generateToken);
        } catch (Exception e) {
            throw new RuntimeException("unable to send link. Please try again later.");
        }
        userMaster.setToken(generateToken);
        userMaster.setTokenGeneratedDateTime(LocalDateTime.now());
        userMasterRepository.saveAndFlush(userMaster);
        return "please check your mail, a link has been sent to reset your password.";
    }

    @Override
    public String resetPassword(String token, ForgotPassword forgotPassword) {

//        System.out.println("New Password: " + forgotPassword.getNewPassword());
//        System.out.println("Confirm Password: " + forgotPassword.getConfirmPassword());
//        System.out.println("Password matches: " + forgotPassword.getNewPassword().equals(forgotPassword.getConfirmPassword()));

        if (forgotPassword.getNewPassword().equals(forgotPassword.getConfirmPassword())) {
            UserMaster userMaster = userMasterRepository.findByToken(token).orElseThrow(() -> new EmailNotFoundException("email not found "));
            if (userMaster.getToken().equals(token) && Duration.between(userMaster.getTokenGeneratedDateTime(), LocalDateTime.now()).getSeconds() < 5 * 60) {
                userMaster.setPassword(passwordEncoder.encode(forgotPassword.getNewPassword()));
                userMaster.setToken(null);
                userMaster.setTokenGeneratedDateTime(null);
                userMasterRepository.saveAndFlush(userMaster);
                // send email after successful password reset
                try {
                    emailService.sendResetPasswordSuccessEmail(userMaster.getEmail());
                } catch (MessagingException | UnsupportedEncodingException e) {
                    logger.error("Failed to send confirmation email to {}", userMaster.getEmail(), e);
                    return "password reset successful, but we couldn't send the confirmation email at the moment.";
                } // end of send confirmation mail
                return "your password has been changed successfully, please login with your new password, A confirmation email has been sent to your mail.";
            } else {
                return "your session has been expired please try again";
            }
        } else {
            return "new password doesn't match with confirm password";
        }
    }

    private void handleFileUpload(MultipartFile userPicture, UserMaster userMaster) {
        if (userPicture.getSize() > MAX_FILE_SIZE) {
            throw new IllegalArgumentException("file size exceeds 200KB");
        }

        String originalFilename = userPicture.getOriginalFilename();
        if (originalFilename == null || !originalFilename.contains(".")) {
            throw new IllegalArgumentException("invalid file format");
        }

        // generate unique file name using UUID
        String fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
        String newFileName = "userPicture_" + UUID.randomUUID() + fileExtension;

        // define the base directory and folder name
        Path baseDir = Paths.get(BASE_UPLOAD_DIR, "User_Signup_Pic");

        try {
            // ensure the directory exists (create if not)
            if (!Files.exists(baseDir)) {
                Files.createDirectories(baseDir);  // create the directory if it doesn't exist
            }
            // create the full path where the file will be stored
            Path filePath = baseDir.resolve(newFileName);

            // write the file to the disk
            Files.write(filePath, userPicture.getBytes());

            // set the new file name in the user master object
            userMaster.setUserPicture(filePath.getFileName().toString());  // store only the file name
        } catch (IOException e) {
            throw new RuntimeException("failed to store file: " + e.getMessage(), e);
        }
    }

}
