package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.dto.UserMasterZoneWardAllocationDTO;
import com.ahmednagar.municipal.auth.jwt.JwtHelper;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.*;
import com.ahmednagar.municipal.auth.service.UserMasterService;
import com.ahmednagar.municipal.auth.utils.PasswordGeneration;
import com.ahmednagar.municipal.auth.utils.TokenGeneration;
import com.ahmednagar.municipal.exception.*;
import com.ahmednagar.municipal.notification.EmailService;
import com.ahmednagar.municipal.notification.OTPService;
import jakarta.mail.MessagingException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
public class UserMasterServiceImpl implements UserMasterService {

    @Autowired
    UserMasterRepository userMasterRepository;

    @Autowired
    UserMasterOtpHistoryRepository userMasterOtpHistoryRepository;

    @Autowired
    UserMasterPasswordChangeHistoryRepository userMasterPasswordChangeHistoryRepository;

    @Autowired
    UserMasterZoneWardAllocationRepository userMasterZoneWardAllocationRepository;

    @Autowired
    AuthZoneRepository authZoneRepository;

    @Autowired
    AuthWardRepository authWardRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    JwtHelper jwtHelper;

    @Autowired
    TokenGeneration tokenGeneration;

    @Autowired
    EmailService emailService;

//    @Autowired
//    WhatsAppService whatsAppService;

    @Autowired
    OTPService otpService;

    @Value("${upload.base.user.signup.profilePic.dir}")
    private String BASE_UPLOAD_DIR;

    private static final long MAX_FILE_SIZE = 200 * 1024;
    private static final int OTP_EXPIRATION_MINUTES = 5;

    @Override
    public UserMaster createUserMaster(UserMaster userMaster, MultipartFile userPicture, Long zoneId, List<Long> wardIds) {
        if (isEmailExists(userMaster.getEmail())) {
            throw new IllegalArgumentException("email address already exists");
        }

        if (isUserNameExists(userMaster.getUsername())) {
            throw new IllegalArgumentException("username already exists");
        }

        System.out.println("Password being saved: " + userMaster.getPassword());

        // handle file upload
        if (userPicture != null && !userPicture.isEmpty()) {
            handleFileUpload(userPicture, userMaster);
        } else {
            System.out.println("uploaded file is null or empty");
        }

        // generate a random password using the PasswordGeneration.class
        String randomPassword = PasswordGeneration.generateRandomPassword();
        userMaster.setPassword(passwordEncoder.encode(randomPassword));  // encode password
        userMaster.setUpdatedBy(userMaster.getUpdatedBy() != null ? userMaster.getUpdatedBy() : 0);
        userMaster.setSuspendedStatus(userMaster.getSuspendedStatus() != null ? userMaster.getSuspendedStatus() : 0);
        userMaster.setCreatedDate(LocalDateTime.now());
        userMaster.setUpdatedDate(LocalDateTime.now());
        UserMaster savedUser = userMasterRepository.saveAndFlush(userMaster);

        // save zone and ward relationship (this could be your allocation table)
        AuthZoneMaster zone = authZoneRepository.findById(zoneId)
                .orElseThrow(() -> new IllegalArgumentException("invalid zone id"));

        List<UserMasterZoneWardAllocation> allocations = wardIds.stream().map(wardId -> {
            AuthWardMaster ward = authWardRepository.findById(wardId)
                    .orElseThrow(() -> new IllegalArgumentException("invalid ward id"));
            UserMasterZoneWardAllocation allocation = new UserMasterZoneWardAllocation();
            allocation.setUserMaster(savedUser);
            allocation.setZoneMaster(zone);
            allocation.setWardMaster(ward);
//            allocation.setCreatedDate(LocalDateTime.now());
            return allocation;
        }).collect(Collectors.toList());

        userMasterZoneWardAllocationRepository.saveAllAndFlush(allocations);

        // save the first password change history entry
        UserMasterPasswordChangeHistory passwordHistory = new UserMasterPasswordChangeHistory();
        passwordHistory.setUserMasterId(savedUser.getId());
        passwordHistory.setLastPwdChange(savedUser.getPassword());
        passwordHistory.setPwdChangedDateTime(LocalDateTime.now());
        passwordHistory.setIpAddress(savedUser.getIpAddress());
        passwordHistory.setCreatedBy(savedUser.getUpdatedBy());
        passwordHistory.setCreatedDate(LocalDateTime.now());
        passwordHistory.setMunicipalId(savedUser.getMunicipalId());
        userMasterPasswordChangeHistoryRepository.saveAndFlush(passwordHistory); // end of password change history block

        String allocatedZone = zone.getZoneName();
        String allocatedWards = allocations.stream()
                .map(a -> a.getWardMaster().getWardNo())
                .collect(Collectors.joining(", "));

        // after saving the user, send a confirmation email
        try {
            emailService.sendSignupConfirmationEmailBeforeOtpVerificationUserMaster(savedUser.getEmail(), randomPassword, allocatedZone, allocatedWards, savedUser.getNameOfUser());
        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send confirmation email to {}", savedUser.getEmail(), e);
            throw new RuntimeException("failed to send confirmation email");
        } // block end for email sending

        generateAndSendOtp(savedUser); // generate otp for email & mobile verification
        return savedUser;
    }

    @Override
    public List<UserMasterDTO> getAllUserMaster() {
        List<UserMaster> users = userMasterRepository.findAllWithZoneAndWardAllocations();

        return users.stream()
                .map(user -> new UserMasterDTO(
                        user.getId(),
                        user.getNameOfUser(),
                        user.getFatherName(),
                        user.getAddress(),
                        user.getEmail(),
                        user.getMobileNo(),
                        user.getDateOfBirth(),
                        user.getUsername(),
                        user.isEmailVerified(),
                        user.isMobileVerified(),
                        user.isVerified(),
                        user.getUserMasterZoneWardAllocations().stream()
                                .map(allocation -> new UserMasterZoneWardAllocationDTO(
                                        allocation.getZoneMaster().getId(),
                                        allocation.getZoneMaster().getZoneName(),
                                        allocation.getWardMaster().getId(),
                                        allocation.getWardMaster().getWardNo()
                                ))
                                .collect(Collectors.toList()),
                        user.getRoleMaster().getRoleName()
                ))
                .collect(Collectors.toList());
    }

    @Override
    public String getProfilePicUrlFromToken(String token) {
        String jwt = token.replace("Bearer ", "");
        String email;

        try {
            email = jwtHelper.getUsernameFromToken(jwt);
        } catch (Exception e) {
            throw new InvalidTokenException("Invalid or expired token");
        }

        UserMaster userMaster = userMasterRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));

        String profilePicUrl = userMaster.getUserPicture();

        if (profilePicUrl == null || profilePicUrl.isEmpty()) {
            throw new ApiException("Profile picture URL is not available.");
        }
        return profilePicUrl;
    }

    @Override
    public UserMaster findByUserId(Long id) {
        return userMasterRepository.findById(id).orElse(null);
    }

    // find email & mobile number for forgot username
    @Override
    public UserMaster findByEmailOrMobile(String email, String mobile) {
        if (email != null && !email.isEmpty()) {
            return userMasterRepository.findByEmail(email)
                    .orElseThrow(() -> new ApiException("No user found with the provided email: " + email));
        } else if (mobile != null && !mobile.isEmpty()) {
            return userMasterRepository.findByMobileNo(mobile)
                    .orElseThrow(() -> new ApiException("No user found with the provided mobile number: " + mobile));
        } else {
            throw new ApiException("Either email or mobile number must be provided.");
        }
    }

    @Override
    public void generateAndSendOtp(UserMaster userMaster) {
        // generate email otp
        String emailOtp = otpService.generateOTP();
        userMaster.setEmailOtp(emailOtp);
        userMaster.setEmailOtpGeneratedDateTime(LocalDateTime.now());

        // generate mobile otp
        String mobileOtp = otpService.generateOTP();
        userMaster.setMobileOtp(mobileOtp);
        userMaster.setMobileOtpGeneratedDateTime(LocalDateTime.now());
        userMasterRepository.saveAndFlush(userMaster);

        // save otp history
        UserMasterOtpHistory userMasterOtpHistory = new UserMasterOtpHistory(
                userMaster.getEmail(),
                userMaster.getMobileNo(),
                emailOtp,
                mobileOtp,
                userMaster.getEmailOtpGeneratedDateTime(),
                userMaster.getMobileOtpGeneratedDateTime()
        );
        userMasterOtpHistoryRepository.saveAndFlush(userMasterOtpHistory);

        // send otp via email
        otpService.sendEmailOTP(userMaster.getEmail(), emailOtp);

        // send otp via sms
        otpService.sendSMSOTP(userMaster.getMobileNo(), mobileOtp);

        // send otp via whatsapp
        //whatsAppService.sendWhatsAppMessage(userMaster.getMobileNo(), mobileOtp);
    }

    @Override
    public boolean validateEmailOtp(UserMaster userMaster, String otp) {
        if (userMaster.getEmailOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            return false; // otp expired
        }
        if (userMaster.getEmailOtp().equals(otp)) {
            // otp matches, update email verification status
            userMaster.setEmailVerified(true);
            userMaster.setEmailOtp(null); // clear otp after successful verification
            userMaster.setEmailOtpGeneratedDateTime(null); // clear otp timestamp
            userMaster.setUpdatedDate(LocalDateTime.now());
            userMasterRepository.saveAndFlush(userMaster);

            // check if both email and mobile are verified
            if (userMaster.isEmailVerified() && userMaster.isMobileVerified()) {
                userMaster.setVerified(true); // set overall verified status
                userMasterRepository.saveAndFlush(userMaster);
                // send confirmation email when the user is fully verified
                try {
                    emailService.sendSignupConfirmationEmail(userMaster.getEmail(), userMaster.getNameOfUser());
                } catch (MessagingException | UnsupportedEncodingException e) {
                    log.error("Failed to send confirmation email to {}", userMaster.getEmail(), e);
                }
            }
            return true; // verification successful
        }
        return false; // otp mismatch
    }

    @Override
    public boolean validateMobileOtp(UserMaster userMaster, String otp) {
        if (userMaster.getMobileOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            return false; // otp expired
        }
        if (userMaster.getMobileOtp().equals(otp)) {
            // otp matches, update mobile verification status
            userMaster.setMobileVerified(true);
            userMaster.setMobileOtp(null); // clear otp after successful verification
            userMaster.setMobileOtpGeneratedDateTime(null); // clear OTP timestamp
            userMaster.setUpdatedDate(LocalDateTime.now());
            userMasterRepository.saveAndFlush(userMaster);

            // check if both email and mobile are verified
            if (userMaster.isEmailVerified() && userMaster.isMobileVerified()) {
                userMaster.setVerified(true); // set overall verified status
                userMasterRepository.saveAndFlush(userMaster);
                // send confirmation email when the user is fully verified
                try {
                    emailService.sendSignupConfirmationEmail(userMaster.getEmail(), userMaster.getNameOfUser());
                } catch (MessagingException | UnsupportedEncodingException e) {
                    log.error("Failed to send confirmation email to {}", userMaster.getEmail(), e);
                }
            }
            return true; // verification successful
        }
        return false; // otp mismatch
    }

    @Override
    public void resendEmailOtp(UserMaster userMaster) {
        // check if the otp has expired
        if (userMaster.getEmailOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            // otp expired, regenerate otp
            String newEmailOtp = otpService.generateOTP();
            userMaster.setEmailOtp(newEmailOtp);
            userMaster.setEmailOtpGeneratedDateTime(LocalDateTime.now());
            userMasterRepository.saveAndFlush(userMaster);

            // send the new otp via email
            otpService.sendEmailOTP(userMaster.getEmail(), newEmailOtp);

            // save otp history
            UserMasterOtpHistory userMasterOtpHistory = new UserMasterOtpHistory(
                    userMaster.getEmail(),
                    null,
                    newEmailOtp,
                    null,
                    userMaster.getEmailOtpGeneratedDateTime(),
                    null
            );
            userMasterOtpHistoryRepository.saveAndFlush(userMasterOtpHistory);
        } else {
            // otp is still valid, so no need to regenerate
            otpService.sendEmailOTP(userMaster.getEmail(), userMaster.getEmailOtp());
        }
    }

    @Override
    public void resendMobileOtp(UserMaster userMaster) {
        // check if the otp has expired
        if (userMaster.getMobileOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            // otp expired, regenerate otp
            String newMobileOtp = otpService.generateOTP();
            userMaster.setMobileOtp(newMobileOtp);
            userMaster.setMobileOtpGeneratedDateTime(LocalDateTime.now());
            userMasterRepository.saveAndFlush(userMaster);

            // send the new otp via sms
            otpService.sendSMSOTP(userMaster.getMobileNo(), newMobileOtp);

            // save otp history
            UserMasterOtpHistory userMasterOtpHistory = new UserMasterOtpHistory(
                    null,
                    userMaster.getMobileNo(),
                    null,
                    newMobileOtp,
                    null,
                    userMaster.getMobileOtpGeneratedDateTime()
            );
            userMasterOtpHistoryRepository.saveAndFlush(userMasterOtpHistory);
        } else {
            // otp is still valid, so no need to regenerate
            otpService.sendSMSOTP(userMaster.getMobileNo(), userMaster.getMobileOtp());
        }
    }

    @Override
    public boolean isEmailExists(String email) {
        return userMasterRepository.existsByEmail(email);
    }

    @Override
    public boolean isMobileNumberExists(String mobileNo) {
        return userMasterRepository.existsByMobileNo(mobileNo);
    }

    @Override
    public boolean isUserNameExists(String userName) {
        return userMasterRepository.existsByUserName(userName);
    }

    @Override
    public boolean validateEmailOrMobileOtp(Long userId, String otp, ChangeEmailMobileRequest changeEmailMobileRequest) {
        // fetch the user by userId
        UserMaster user = userMasterRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("user not found" + userId));

        // check if the otp matches the one sent to the email or mobile
        boolean isEmailOtpValid = (user.getEmailOtp() != null && user.getEmailOtp().equals(otp));
        boolean isMobileOtpValid = (user.getMobileOtp() != null && user.getMobileOtp().equals(otp));

        // validate the otp expiration time
        if ((isEmailOtpValid && user.getEmailOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) ||
                (isMobileOtpValid && user.getMobileOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now()))) {
            throw new IllegalArgumentException("OTP has expired");
        }

        // perform the update based on which contact (email/mobile) was validated
        if (isEmailOtpValid && changeEmailMobileRequest.getNewEmailMobile() != null) {
            // check if the new email is the same as the existing email
            if (user.getEmail().equals(changeEmailMobileRequest.getNewEmailMobile())) {
                throw new IllegalArgumentException("your existing email and new email are the same");
            }

            // if email otp is valid, update the email
            user.setEmail(changeEmailMobileRequest.getNewEmailMobile());  // update to the new email
            user.setEmailOtp(null); // clear otp after successful validation
            user.setEmailOtpGeneratedDateTime(null); // clear otp timestamp
            user.setUpdatedDate(LocalDateTime.now());
            userMasterRepository.saveAndFlush(user);

            // send confirmation email
            try {
                emailService.sendEmailOrMobileChangeConfirmationEmail(user.getEmail(), user.getUsername(), user.getNameOfUser(), "email");
            } catch (MessagingException | UnsupportedEncodingException e) {
                log.error("Failed to send confirmation email to {}", user.getEmail(), e);
                return false;
            } // end of send confirmation mail
            return true;
        }

        if (isMobileOtpValid && changeEmailMobileRequest.getNewEmailMobile() != null) {
            // check if the new mobile number is the same as the existing mobile number
            if (user.getMobileNo().equals(changeEmailMobileRequest.getNewEmailMobile())) {
                throw new IllegalArgumentException("Your existing mobile number and new mobile number are the same");
            }

            // if mobile otp is valid, update the mobile number
            user.setMobileNo(changeEmailMobileRequest.getNewEmailMobile());  // update to the new mobile number
            user.setMobileOtp(null); // clear otp after successful validation
            user.setMobileOtpGeneratedDateTime(null); // clear otp timestamp
            user.setUpdatedDate(LocalDateTime.now());
            userMasterRepository.saveAndFlush(user);

            // send confirmation email
            try {
                emailService.sendEmailOrMobileChangeConfirmationEmail(user.getEmail(), user.getUsername(), user.getNameOfUser(), "mobile");
            } catch (MessagingException | UnsupportedEncodingException e) {
                log.error("Failed to send confirmation email to {}", user.getEmail(), e);
                return false;
            } // end of send confirmation mail
            return true;
        }
        // if otp do not match, return false
        return false;
    }

    @Override
    public String requestEmailOrMobileChange(Long userId, ChangeEmailMobileRequest changeEmailMobileRequest) {
        // fetch the user from the database
        UserMaster user = userMasterRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("user not found" + userId));

        boolean isEmailChange = changeEmailMobileRequest.getExistingEmailMobile().equals(user.getEmail());
        boolean isMobileChange = changeEmailMobileRequest.getExistingEmailMobile().equals(user.getMobileNo());

        // validate if the existing contact matches the current email or mobile
        if (!isEmailChange && !isMobileChange) {
            throw new IllegalArgumentException("Existing email or mobile does not match");
        }

        // check if the new contact (email or mobile) is valid
        if (isEmailChange && isEmailExists(changeEmailMobileRequest.getNewEmailMobile())) {
            throw new IllegalArgumentException("Email address already exists");
        }

        if (isMobileChange && isMobileNumberExists(changeEmailMobileRequest.getNewEmailMobile())) {
            throw new IllegalArgumentException("Mobile number already exists");
        }

        // generate otp for the new contact (email or mobile)
        String otp = otpService.generateOTP();

        if (isEmailChange) {
            user.setEmailOtp(otp);
            user.setEmailOtpGeneratedDateTime(LocalDateTime.now());
            userMasterRepository.saveAndFlush(user);
            otpService.sendEmailOTP(changeEmailMobileRequest.getNewEmailMobile(), otp);
        } else if (isMobileChange) {
            user.setMobileOtp(otp);
            user.setMobileOtpGeneratedDateTime(LocalDateTime.now());
            userMasterRepository.saveAndFlush(user);
            otpService.sendSMSOTP(changeEmailMobileRequest.getNewEmailMobile(), otp);
        }

        // save otp history
        UserMasterOtpHistory otpHistory = new UserMasterOtpHistory(
                user.getEmail(),
                user.getMobileNo(),
                isEmailChange ? otp : null,
                isMobileChange ? otp : null,
                isEmailChange ? LocalDateTime.now() : null,
                isMobileChange ? LocalDateTime.now() : null
        );
        userMasterOtpHistoryRepository.saveAndFlush(otpHistory);
        return "OTP sent to " + changeEmailMobileRequest.getNewEmailMobile();
    }

    @Override
    public String validateForgotUsernameOtp(UserMaster userMaster, String emailOtp, String mobileOtp) {
        LocalDateTime otpGenerationDateTime = LocalDateTime.now();

        // validate email otp
        if (userMaster.getEmailOtp() == null || !userMaster.getEmailOtp().equals(emailOtp)) {
            throw new ApiException("Invalid email OTP.");
        }

        // validate email otp expiration
        if (userMaster.getEmailOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(otpGenerationDateTime)) {
            throw new ApiException("Email OTP has expired.");
        }

        // validate mobile otp
        if (userMaster.getMobileOtp() == null || !userMaster.getMobileOtp().equals(mobileOtp)) {
            throw new ApiException("Invalid mobile OTP.");
        }

        // validate mobile otp expiration
        if (userMaster.getMobileOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(otpGenerationDateTime)) {
            throw new ApiException("Mobile OTP has expired.");
        }

        // otp are valid, send the username to the user
        try {
            emailService.sendUsernameToUserEmail(userMaster.getEmail(), userMaster.getNameOfUser(), userMaster.getUsername());
            // clear otp after successful verification
            userMaster.setEmailOtp(null);
            userMaster.setMobileOtp(null);
            userMaster.setEmailOtpGeneratedDateTime(null);
            userMaster.setMobileOtpGeneratedDateTime(null);

            // update verification status
            userMaster.setEmailVerified(true);
            userMaster.setMobileVerified(true);
            userMaster.setUpdatedDate(LocalDateTime.now());
            userMasterRepository.saveAndFlush(userMaster);

        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send username email to {}", userMaster.getEmail(), e);
            throw new ApiException("OTP validated, but failed to send the username email. Please try again later.");
        }
        return "OTP validated successfully. Your username has been sent to your email.";
    }

    @Override
    public String forgotUsername(ForgotUserNameRequest forgotUserNameRequest) {
        // validate if the email exists
        UserMaster userMaster = userMasterRepository.findByEmail(forgotUserNameRequest.getEmail())
                .orElseThrow(() -> new EmailNotFoundException("Email not found: " + forgotUserNameRequest.getEmail()));

        // validate if the mobile number exists
        if (!userMaster.getMobileNo().equals(forgotUserNameRequest.getMobileNo())) {
            throw new ApiException("Mobile number doesn't match with the provided email");
        }

        // generate otp for both email and mobile number
        generateAndSendOtp(userMaster);
        return "OTP has been sent to your email and mobile number. Please verify them.";
    }

    @Override
    public String forgotPassword(String email) {
        UserMaster userMaster = userMasterRepository.findByEmail(email).orElseThrow(() -> new EmailNotFoundException("Email not found " + email));
        String generateToken = tokenGeneration.generateToken();
        try {
            emailService.sendResetPasswordEmail(email, generateToken, userMaster.getNameOfUser());
        } catch (Exception e) {
            throw new RuntimeException("unable to send link. Please try again later.");
        }
        userMaster.setToken(generateToken);
        userMaster.setTokenGeneratedDateTime(LocalDateTime.now());
        userMasterRepository.saveAndFlush(userMaster);
        return "please check your mail, a link has been sent to reset your password.";
    }

//    @Override
//    public String resetPassword(String token, ForgotPassword forgotPassword) {
//
////        System.out.println("New Password: " + forgotPassword.getNewPassword());
////        System.out.println("Confirm Password: " + forgotPassword.getConfirmPassword());
////        System.out.println("Password matches: " + forgotPassword.getNewPassword().equals(forgotPassword.getConfirmPassword()));
//
//        if (forgotPassword.getNewPassword().equals(forgotPassword.getConfirmPassword())) {
//            UserMaster userMaster = userMasterRepository.findByToken(token).orElseThrow(() -> new EmailNotFoundException("email not found "));
//            if (userMaster.getToken().equals(token) && Duration.between(userMaster.getTokenGeneratedDateTime(), LocalDateTime.now()).getSeconds() < 5 * 60) {
//
//                // check if new password is same as old password
//                if (passwordEncoder.matches(forgotPassword.getNewPassword(), userMaster.getPassword())) {
//                    return "Your new password can't be the same as your previous password";
//                }
//
//                userMaster.setPassword(passwordEncoder.encode(forgotPassword.getNewPassword()));
//                userMaster.setToken(null);
//                userMaster.setTokenGeneratedDateTime(null);
//                userMasterRepository.saveAndFlush(userMaster);
//
//                // save password change history
//                UserMasterPasswordChangeHistory passwordHistory = new UserMasterPasswordChangeHistory();
//                passwordHistory.setUserMasterId(userMaster.getId());
//                passwordHistory.setLastPwdChange(userMaster.getPassword());
//                passwordHistory.setPwdChangedDateTime(LocalDateTime.now());
//                passwordHistory.setIpAddress("127.0.0.1");
//                passwordHistory.setCreatedBy(userMaster.getUpdatedBy());
//                passwordHistory.setCreatedDate(LocalDateTime.now());
//                passwordHistory.setMunicipalId(userMaster.getMunicipalId());
//                userMasterPasswordChangeHistoryRepository.saveAndFlush(passwordHistory); // end of password change history block
//
//                // send email after successful password reset
//                try {
//                    emailService.sendResetPasswordSuccessEmail(userMaster.getEmail(), userMaster.getNameOfUser());
//                } catch (MessagingException | UnsupportedEncodingException e) {
//                    log.error("Failed to send confirmation email to {}", userMaster.getEmail(), e);
//                    return "password reset successful, but we couldn't send the confirmation email at the moment.";
//                } // end of send confirmation mail
//                return "your password has been changed successfully, please login with your new password, A confirmation email has been sent to your mail.";
//            } else {
//                return "your session has been expired please try again";
//            }
//        } else {
//            return "new password doesn't match with confirm password";
//        }
//    }

    @Override
    public String resetPassword(String token, ForgotPassword forgotPassword) {

        // check if passwords match
        if (!forgotPassword.getNewPassword().equals(forgotPassword.getConfirmPassword())) {
            throw new ApiException("New password doesn't match with confirm password");
        }

        // find user by token
        UserMaster userMaster = userMasterRepository.findByToken(token)
                .orElseThrow(() -> new EmailNotFoundException("Email not found for the provided token"));

        // validate token and expiration
        if (!userMaster.getToken().equals(token)) {
            throw new InvalidTokenException("Invalid token");
        }

        if (Duration.between(userMaster.getTokenGeneratedDateTime(), LocalDateTime.now()).getSeconds() >= 5 * 60) {
            throw new ExpiredTokenException("Your session has expired. Please try again.");
        }

        // check for same password reuse
        if (passwordEncoder.matches(forgotPassword.getNewPassword(), userMaster.getPassword())) {
            throw new ApiException("Your new password can't be the same as your previous password");
        }

        // encode and save new password
        String encodedPassword = passwordEncoder.encode(forgotPassword.getNewPassword());
        userMaster.setPassword(encodedPassword);
        userMaster.setToken(null);
        userMaster.setTokenGeneratedDateTime(null);
        userMasterRepository.saveAndFlush(userMaster);

        // save password history
        UserMasterPasswordChangeHistory history = new UserMasterPasswordChangeHistory();
        history.setUserMasterId(userMaster.getId());
        history.setLastPwdChange(encodedPassword);
        history.setPwdChangedDateTime(LocalDateTime.now());
        history.setIpAddress("127.0.0.1");
        history.setCreatedBy(userMaster.getUpdatedBy());
        history.setCreatedDate(LocalDateTime.now());
        history.setMunicipalId(userMaster.getMunicipalId());
        userMasterPasswordChangeHistoryRepository.saveAndFlush(history);

        // send confirmation email
        try {
            emailService.sendResetPasswordSuccessEmail(userMaster.getEmail(), userMaster.getNameOfUser());
        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send confirmation email to {}", userMaster.getEmail(), e);
            return "Password reset successful, but we couldn't send the confirmation email.";
        }
        return "Your password has been changed successfully. Please login with your new password. A confirmation email has been sent.";
    }

    @Override
    public String changePassword(Long userId, ChangePasswordRequest changePasswordRequest) {
        UserMaster userMaster = userMasterRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("UserMaster", "id", userId));

        // validate old password
        if (!passwordEncoder.matches(changePasswordRequest.getOldPassword(), userMaster.getPassword())) {
            throw new ApiException("old password is incorrect");
        }

        // check if new password & confirm password are same
        if (!changePasswordRequest.getNewPassword().equals(changePasswordRequest.getConfirmPassword())) {
            throw new ApiException("new password and confirm password are not same");
        }

        // check if the new password is different from the old password
        if (passwordEncoder.matches(changePasswordRequest.getNewPassword(), userMaster.getPassword())) {
            throw new ApiException("your new password can't be the same as your old password");
        }

        // update the password
        userMaster.setPassword(passwordEncoder.encode(changePasswordRequest.getNewPassword()));
        userMaster.setUpdatedDate(LocalDateTime.now());
        userMasterRepository.saveAndFlush(userMaster);

        // save password change history
        UserMasterPasswordChangeHistory passwordHistory = new UserMasterPasswordChangeHistory();
        passwordHistory.setUserMasterId(userMaster.getId());
        passwordHistory.setLastPwdChange(userMaster.getPassword());
        passwordHistory.setPwdChangedDateTime(LocalDateTime.now());
        passwordHistory.setIpAddress("127.0.0.1");
        passwordHistory.setCreatedBy(userMaster.getUpdatedBy());
        passwordHistory.setCreatedDate(LocalDateTime.now());
        passwordHistory.setMunicipalId(userMaster.getMunicipalId());
        userMasterPasswordChangeHistoryRepository.saveAndFlush(passwordHistory); // end of password change history block

        // send a confirmation email
        try {
            emailService.sendChangePasswordEmail(userMaster.getEmail(), userMaster.getNameOfUser());
        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send confirmation email to {}", userMaster.getEmail(), e);
            return "password reset successful, but we couldn't send the confirmation email at the moment.";
        } // end of send confirmation mail
        return "your password has been changed successfully";
    }

    private void handleFileUpload(MultipartFile userPicture, UserMaster userMaster) {
        if (userPicture.getSize() > MAX_FILE_SIZE) {
            throw new ApiException("file size exceeds the 200KB limit");
        }

        String originalFilename = userPicture.getOriginalFilename();
        if (originalFilename == null || !originalFilename.contains(".")) {
            throw new ApiException("Invalid file format. Filename must contain an extension.");
        }

        // generate unique file name using UUID
        String fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
        if (!fileExtension.equals(".jpg") && !fileExtension.equals(".png")) {
            throw new ApiException("Unsupported file type. Only JPG and PNG are allowed.");
        }

        String newFileName = "userPicture_" + UUID.randomUUID() + fileExtension;

        // define the base directory and folder name
        String userFolderName = "User_Signup_Pic";
        Path baseDir = Paths.get(BASE_UPLOAD_DIR, "User_Signup_Pic");

        try {
            // ensure the directory exists (create if not)
            if (!Files.exists(baseDir)) {
                Files.createDirectories(baseDir);  // create the directory if it doesn't exist
            }
            // create the full path where the file will be stored
            Path filePath = baseDir.resolve(newFileName);

            // write the file to the disk
            Files.write(filePath, userPicture.getBytes());

            // generate URL for the uploaded file
            String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/userSignupProfilePic/")
                    .path(userFolderName + "/")
                    .path(newFileName)
                    .toUriString();

            // set the new file name in the user master object
            userMaster.setUserPicture(fileUrl);  // store only the file name
            log.info("Uploaded user picture to {} successfully", filePath);
        } catch (IOException e) {
            log.error("File storage failed", e);
            throw new ApiException("Failed to store user picture. Please try again later.");
        }
    }

}
