package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.WaterRolesDataFlowSetup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;


@EnableJpaRepositories
public interface WaterRolesDataFlowSetupRepository extends JpaRepository<WaterRolesDataFlowSetup,Long> {

    Optional<WaterRolesDataFlowSetup> findByCurrentRoleIdAndStatusCodeAndIsActive(
            Long currentRoleId,
            Long statusCode,
            Integer isActive
    );

    List<WaterRolesDataFlowSetup> findAllByCurrentRoleIdAndStatusCodeAndIsActive(Long currentRoleId, Long statusCode, Integer isActive);
}
