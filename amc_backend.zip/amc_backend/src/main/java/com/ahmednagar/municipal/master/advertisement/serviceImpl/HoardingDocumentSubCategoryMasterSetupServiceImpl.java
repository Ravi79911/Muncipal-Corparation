package com.ahmednagar.municipal.master.advertisement.serviceImpl;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingDocumentSubCategoryMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingDocumentSubCategoryMasterSetup;
import com.ahmednagar.municipal.master.advertisement.repository.HoardingDocumentSubCategoryMasterSetupRepository;
import com.ahmednagar.municipal.master.advertisement.service.HoardingDocumentSubCategoryMasterSetupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingDocumentSubCategoryMasterSetupServiceImpl implements HoardingDocumentSubCategoryMasterSetupService {
    @Autowired
    private HoardingDocumentSubCategoryMasterSetupRepository hoardingDocumentSubCategoryMasterSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingDocumentSubCategoryMasterSetup saveHoardingDocumentSubCategoryMasterSetup(HoardingDocumentSubCategoryMasterSetup hoardingDocumentSubCategoryMasterSetup) {
        hoardingDocumentSubCategoryMasterSetup.setCreatedDate(LocalDateTime.now());
        hoardingDocumentSubCategoryMasterSetup.setUpdatedDate(LocalDateTime.now());
        hoardingDocumentSubCategoryMasterSetup.setUpdatedBy(hoardingDocumentSubCategoryMasterSetup.getUpdatedBy() != null ? hoardingDocumentSubCategoryMasterSetup.getUpdatedBy() : 0);
        hoardingDocumentSubCategoryMasterSetup.setSuspendedStatus(hoardingDocumentSubCategoryMasterSetup.getSuspendedStatus() != null ? hoardingDocumentSubCategoryMasterSetup.getSuspendedStatus() : 0);

        return hoardingDocumentSubCategoryMasterSetupRepository.save(hoardingDocumentSubCategoryMasterSetup);

    }

    @Override
    public List<HoardingDocumentSubCategoryMasterSetupDto> findAllHoardingDocumentSubCategoryMasterSetup() {
        List<HoardingDocumentSubCategoryMasterSetup> hoardingDocumentSubCategoryMasterSetups = hoardingDocumentSubCategoryMasterSetupRepository.findAll();
        return hoardingDocumentSubCategoryMasterSetups.stream()
                .map(hoardingDocumentSubCategoryMasterSetup -> modelMapper.map(hoardingDocumentSubCategoryMasterSetup, HoardingDocumentSubCategoryMasterSetupDto.class))
                .collect(Collectors.toList());
    }
    @Override
    public HoardingDocumentSubCategoryMasterSetup findById(Long id) {
        Optional<HoardingDocumentSubCategoryMasterSetup> hoardingDocumentSubCategoryMasterSetup=hoardingDocumentSubCategoryMasterSetupRepository.findById(id);
        return hoardingDocumentSubCategoryMasterSetup.orElse(null);

    }
    @Override
    public List<HoardingDocumentSubCategoryMasterSetup> findAllByMunicipalId(int municipalId) {
        return hoardingDocumentSubCategoryMasterSetupRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingDocumentSubCategoryMasterSetup updateHoardingDocumentSubCategoryMasterSetup(Long id, HoardingDocumentSubCategoryMasterSetup updatedHoardingDocumentSubCategoryMasterSetup, int updatedBy) {
        Optional<HoardingDocumentSubCategoryMasterSetup> hoardingDocumentSubCategoryMasterSetupOptional = hoardingDocumentSubCategoryMasterSetupRepository.findById(id);
        if (hoardingDocumentSubCategoryMasterSetupOptional.isPresent()) {
            HoardingDocumentSubCategoryMasterSetup existingHoardingDocumentSubCategoryMasterSetup = hoardingDocumentSubCategoryMasterSetupOptional.get();
            existingHoardingDocumentSubCategoryMasterSetup.setSubCategoryName(updatedHoardingDocumentSubCategoryMasterSetup.getSubCategoryName());
            existingHoardingDocumentSubCategoryMasterSetup.setUpdatedBy(updatedBy);
            existingHoardingDocumentSubCategoryMasterSetup.setUpdatedDate(LocalDateTime.now());

            return hoardingDocumentSubCategoryMasterSetupRepository.saveAndFlush(existingHoardingDocumentSubCategoryMasterSetup);
        } else {
            throw new RuntimeException("HoardingDocumentSubCategoryMasterSetup not found with id: " + id);
        }
    }

    @Override
    public HoardingDocumentSubCategoryMasterSetup changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingDocumentSubCategoryMasterSetup> hoardingDocumentSubCategoryMasterSetupOpt = hoardingDocumentSubCategoryMasterSetupRepository.findById(id);
        if (hoardingDocumentSubCategoryMasterSetupOpt.isPresent()) {
            HoardingDocumentSubCategoryMasterSetup hoardingDocumentSubCategoryMasterSetup = hoardingDocumentSubCategoryMasterSetupOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingDocumentSubCategoryMasterSetup.setUpdatedDate(currentDateTime);
            hoardingDocumentSubCategoryMasterSetup.setSuspendedStatus(status);      // 1 means suspended
            hoardingDocumentSubCategoryMasterSetup.setUpdatedBy(updatedBy);
            return hoardingDocumentSubCategoryMasterSetupRepository.saveAndFlush(hoardingDocumentSubCategoryMasterSetup);
        }
        return null;
    }
}
