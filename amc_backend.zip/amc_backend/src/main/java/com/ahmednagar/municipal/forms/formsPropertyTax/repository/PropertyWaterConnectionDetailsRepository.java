package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyWaterConnectionDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface PropertyWaterConnectionDetailsRepository extends JpaRepository<PropertyWaterConnectionDetails, Long> {

    List<PropertyWaterConnectionDetails> findByMunicipalPropertyMasterId(Long municipalPropertyMasterId);

    void deleteByMunicipalPropertyMasterId(Long municipalPropertyMasterId);

    List<PropertyWaterConnectionDetails> findByMunicipalId(int municipalId);

}
