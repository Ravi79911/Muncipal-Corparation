package com.ahmednagar.municipal.forms.formsAdvertisement.controller;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingPaymentCollectionMasterDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingPaymentCollectionMaster;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingPaymentCollectionMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/advertisement/hoarding/payment/collection/master/form")
@Validated
@CrossOrigin
public class HoardingPaymentCollectionMasterController {
    @Autowired
    private HoardingPaymentCollectionMasterService hoardingPaymentCollectionMasterService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<HoardingPaymentCollectionMaster> createHoardingPaymentCollectionMaster(@Valid @RequestBody HoardingPaymentCollectionMaster hoardingPaymentCollectionMaster){
        HoardingPaymentCollectionMaster savedHoardingPaymentCollectionMaster=hoardingPaymentCollectionMasterService.saveHoardingPaymentCollectionMaster(hoardingPaymentCollectionMaster);
        return ResponseEntity.status(201).body(savedHoardingPaymentCollectionMaster);

    }

    //for admin users
    @GetMapping("/all")
    public ResponseEntity<List<HoardingPaymentCollectionMasterDto>> getAllHoardingPaymentCollectionMaster(){
        List<HoardingPaymentCollectionMasterDto> hoardingPaymentCollectionMaster=hoardingPaymentCollectionMasterService.findAllHoardingPaymentCollectionMaster();
        return ResponseEntity.ok(hoardingPaymentCollectionMaster);

    }

    //for single user by Id
    @GetMapping("/getHoardingPaymentCollectionMasterById/{id}")
    public ResponseEntity<HoardingPaymentCollectionMaster> getHoardingPaymentCollectionMasterById(@PathVariable Long id){
        HoardingPaymentCollectionMaster hoardingPaymentCollectionMaster=hoardingPaymentCollectionMasterService.findById(id);
        return ResponseEntity.ok(hoardingPaymentCollectionMaster);

    }

    // for MuncipalId
    @GetMapping("/getAllByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllHoardingPaymentCollectionMasterByMunicipalId(@PathVariable int municipalId){
        List<HoardingPaymentCollectionMaster> hoardingPaymentCollectionMasters = hoardingPaymentCollectionMasterService.findAllByMunicipalId(municipalId);
        if (hoardingPaymentCollectionMasters.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No HoardingPaymentCollectionMaster found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(hoardingPaymentCollectionMasters);
    }

    //     Update a MlBusiness for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<HoardingPaymentCollectionMaster> updateHoardingPaymentCollectionMaster(@PathVariable("id") Long id, @RequestBody HoardingPaymentCollectionMaster updatedHoardingPaymentCollectionMaster){
        try{
            HoardingPaymentCollectionMaster updated=hoardingPaymentCollectionMasterService.updateHoardingPaymentCollectionMaster(id,updatedHoardingPaymentCollectionMaster,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //  to update the status of MlBusiness for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<?> changeStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer status){
        hoardingPaymentCollectionMasterService.changeStatus(id,status,1);
        return ResponseEntity.ok().build();

    }
}

