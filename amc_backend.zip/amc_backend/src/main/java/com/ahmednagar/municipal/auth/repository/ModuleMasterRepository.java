package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.ModuleMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ModuleMasterRepository extends JpaRepository<ModuleMaster, Long> {

    List<ModuleMaster> findByMunicipalId(Long municipalId);

}
