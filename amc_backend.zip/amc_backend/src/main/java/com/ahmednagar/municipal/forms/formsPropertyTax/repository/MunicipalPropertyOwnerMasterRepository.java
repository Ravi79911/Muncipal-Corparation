package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyOwnerMaster;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserLoginMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;

@EnableJpaRepositories
public interface MunicipalPropertyOwnerMasterRepository extends JpaRepository<MunicipalPropertyOwnerMaster, Integer> {

    List<MunicipalPropertyOwnerMaster> findByMunicipalId(int municipalId);

    @Query("SELECT mpm.applicationNo FROM MunicipalPropertyMaster mpm WHERE mpm.id = :municipalPropertyMasterId")
    String findApplicationNoByMunicipalPropertyMasterId(@Param("municipalPropertyMasterId") Long municipalPropertyMasterId);

}
