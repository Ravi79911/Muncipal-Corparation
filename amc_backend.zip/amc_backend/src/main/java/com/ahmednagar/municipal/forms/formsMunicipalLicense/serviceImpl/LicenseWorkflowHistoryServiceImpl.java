package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseWorkflowHistory;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.LicenseWorkflowHistoryRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.LicenseWorkflowHistoryService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class LicenseWorkflowHistoryServiceImpl implements LicenseWorkflowHistoryService {
    @Autowired
    private LicenseWorkflowHistoryRepository licenseWorkflowHistoryRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public LicenseWorkflowHistory saveLicenseWorkflowHistory(LicenseWorkflowHistory licenseWorkflowHistory) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        licenseWorkflowHistory.setCreatedDate(currentDateTime);
        licenseWorkflowHistory.setSuspendedStatus(licenseWorkflowHistory.getSuspendedStatus() != null ? licenseWorkflowHistory.getSuspendedStatus() : 0);      // 0 means active
        return licenseWorkflowHistoryRepository.saveAndFlush(licenseWorkflowHistory);
    }
}
