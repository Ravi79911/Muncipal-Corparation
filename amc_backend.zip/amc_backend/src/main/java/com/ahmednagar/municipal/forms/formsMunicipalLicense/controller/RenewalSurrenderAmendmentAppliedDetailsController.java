package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.RenewalSurrenderAmendmentAppliedDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.RenewalSurrenderAmendmentAppliedDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.RenewalSurrenderAmendmentAppliedDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/license/forms/details")
public class RenewalSurrenderAmendmentAppliedDetailsController {
    @Autowired
    private RenewalSurrenderAmendmentAppliedDetailsService renewalSurrenderAmendmentAppliedDetailsService;

    //create Amendment License
    @PostMapping("/create/amendment")
    public ResponseEntity<RenewalSurrenderAmendmentAppliedDetails> createAmendmentAppliedDetails(@Valid @RequestBody RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails, @RequestParam int createdBy){
        RenewalSurrenderAmendmentAppliedDetails createdRenewalSurrenderAmendmentAppliedDetails=renewalSurrenderAmendmentAppliedDetailsService.saveAmendmentAppliedDetails(renewalSurrenderAmendmentAppliedDetails,1);
        if(createdRenewalSurrenderAmendmentAppliedDetails==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdRenewalSurrenderAmendmentAppliedDetails);
    }
    //create Renewal License
    @PostMapping("/create/surrender")
    public ResponseEntity<RenewalSurrenderAmendmentAppliedDetails> createSurrenderAppliedDetails(@Valid @RequestBody RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails, @RequestParam int createdBy){
        RenewalSurrenderAmendmentAppliedDetails createdRenewalSurrenderAmendmentAppliedDetails=renewalSurrenderAmendmentAppliedDetailsService.saveSurrenderAppliedDetails(renewalSurrenderAmendmentAppliedDetails,1);
        if(createdRenewalSurrenderAmendmentAppliedDetails==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdRenewalSurrenderAmendmentAppliedDetails);
    }

    //create Am License
    @PostMapping("/calculateRenewalApplicationFee")
    public ResponseEntity<RenewalSurrenderAmendmentAppliedDetails> calculateRenewalApplicationFees(@Valid @RequestBody RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails){
        RenewalSurrenderAmendmentAppliedDetails createdRenewalSurrenderAmendmentAppliedDetails=renewalSurrenderAmendmentAppliedDetailsService.calculateRenewalApplicationFee(renewalSurrenderAmendmentAppliedDetails);
        if(createdRenewalSurrenderAmendmentAppliedDetails==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdRenewalSurrenderAmendmentAppliedDetails);
    }

    //create Am License
    @PostMapping("/crete/renewal/application")
    public ResponseEntity<RenewalSurrenderAmendmentAppliedDetails> saveRenewalApplication(@Valid @RequestBody RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails){
        RenewalSurrenderAmendmentAppliedDetails createdRenewalSurrenderAmendmentAppliedDetails=renewalSurrenderAmendmentAppliedDetailsService.savedRenewalApplication(renewalSurrenderAmendmentAppliedDetails);
        if(createdRenewalSurrenderAmendmentAppliedDetails==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdRenewalSurrenderAmendmentAppliedDetails);
    }

//    @GetMapping("/latest/{preLicenseNo}")
//    public ResponseEntity<RenewalSurrenderAmendmentAppliedDetails> getLatestDetails(@PathVariable String preLicenseNo) {
//        RenewalSurrenderAmendmentAppliedDetails latestRenewalSurrenderAmendmentAppliedDetails = renewalSurrenderAmendmentAppliedDetailsService.getLatestDetailsByLicenseNo(preLicenseNo);
//        return ResponseEntity.ok(latestRenewalSurrenderAmendmentAppliedDetails);
//    }

//    //for all admin users
//    @GetMapping("/all")
//    public ResponseEntity<List<RenewalSurrenderAmendmentAppliedDetailsDto>> getAllRenewalSurrenderAmendmentAppliedDetails(){
//        List<RenewalSurrenderAmendmentAppliedDetailsDto> renewalSurrenderAmendmentAppliedDetails=renewalSurrenderAmendmentAppliedDetailsService.findAllRenewalSurrenderAmendmentAppliedDetails();
//        return ResponseEntity.ok(renewalSurrenderAmendmentAppliedDetails);
//    }
//
//    //for active users
//    @GetMapping("/active")
//    public ResponseEntity<List<RenewalSurrenderAmendmentAppliedDetails>> getAllActiveRenewalSurrenderAmendmentAppliedDetails(@RequestParam(required = false, defaultValue = "0") Integer status){
//        List<RenewalSurrenderAmendmentAppliedDetails> activeRenewalSurrenderAmendmentAppliedDetails=renewalSurrenderAmendmentAppliedDetailsService.findAllActiveRenewalSurrenderAmendmentAppliedDetails(status);
//        return ResponseEntity.ok(activeRenewalSurrenderAmendmentAppliedDetails);
//
//    }
    //  to get the Application Details by id for user
    @GetMapping("/get/{id}")
    public ResponseEntity<RenewalSurrenderAmendmentAppliedDetails> getRenewalSurrenderAmendmentAppliedDetailsById(@PathVariable int id){
        RenewalSurrenderAmendmentAppliedDetails renewalSurrenderAmendmentAppliedDetails=renewalSurrenderAmendmentAppliedDetailsService.findRenewalSurrenderAmendmentAppliedDetailsById(id);
        return ResponseEntity.ok(renewalSurrenderAmendmentAppliedDetails);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllRenewalSurrenderAmendmentAppliedDetailsByMunicipalId(@PathVariable int municipalId){
        List<RenewalSurrenderAmendmentAppliedDetailsDto> renewalSurrenderAmendmentAppliedDetails=renewalSurrenderAmendmentAppliedDetailsService.findAllRenewalSurrenderAmendmentAppliedDetailsByMunicipalId(municipalId);
        if (renewalSurrenderAmendmentAppliedDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No RenewalSurrenderAmendmentAppliedDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(renewalSurrenderAmendmentAppliedDetails);
    }

    //     Update AppApplication Details From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<RenewalSurrenderAmendmentAppliedDetails> updateRenewalSurrenderAmendmentAppliedDetails(@PathVariable("id") int id, @RequestBody RenewalSurrenderAmendmentAppliedDetails updatedRenewalSurrenderAmendmentAppliedDetails){
        try{
            RenewalSurrenderAmendmentAppliedDetails updated=renewalSurrenderAmendmentAppliedDetailsService.updateRenewalSurrenderAmendmentAppliedDetails(id,updatedRenewalSurrenderAmendmentAppliedDetails,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete AppApplication Details for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<RenewalSurrenderAmendmentAppliedDetails> changeSuspendedStatus(@PathVariable int id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        RenewalSurrenderAmendmentAppliedDetails updatedRenewalSurrenderAmendmentAppliedDetails = renewalSurrenderAmendmentAppliedDetailsService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedRenewalSurrenderAmendmentAppliedDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedRenewalSurrenderAmendmentAppliedDetails);
    }

}
