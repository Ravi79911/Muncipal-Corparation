package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyAdditionalDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface PropertyAdditionalDetailsService {

    List<PropertyAdditionalDetails> createPropertyAdditionalDetails(List<PropertyAdditionalDetails> propertyAdditionalDetails);

    List<PropertyAdditionalDetails> getAllPropertyAdditionalDetails();

    Optional<PropertyAdditionalDetails> getPropertyAdditionalDetailsById(Long id);

    List<PropertyAdditionalDetails> getPropertyAdditionalDetailsByMunicipalId(int municipalId);

    PropertyAdditionalDetails patchPropertyAdditionalDetailsSuspendedStatus(Long id, int suspendedStatus);

}
