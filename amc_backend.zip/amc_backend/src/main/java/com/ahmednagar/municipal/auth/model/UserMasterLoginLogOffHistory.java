package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_user_master_login_logoff_history")
public class UserMasterLoginLogOffHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "login/logoff status cannot be null")
    @Column(name = "login_logoff_status", nullable = false)
    private String loginLogoffStatus;

    @Column(name = "login_logoff_datetime", nullable = false)
    private LocalDateTime loginLogoffDatetime;

    @NotBlank(message = "ip address can't be blank")
    @Size(max = 150, message = "ip address must not exceed 150 characters")
    @Column(name = "ip_address", length = 150, nullable = false)
    private String ipAddress;

    @Column(name = "created_by", nullable = false)
    private Integer createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date", nullable = false)
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id", nullable = false)
    private Long municipalId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false, referencedColumnName = "id")
    private UserMasterDetails userId;

}
