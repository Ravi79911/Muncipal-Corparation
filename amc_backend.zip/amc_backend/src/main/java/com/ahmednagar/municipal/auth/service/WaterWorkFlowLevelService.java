package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.dto.WaterWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.WaterWorkFlowLevel;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface WaterWorkFlowLevelService {

    WaterWorkFlowLevel handleWaterWorkFlowTransition(WaterWorkFlowLevel waterWorkFlowLevel);

    List<WaterWorkFlowLevelDto> findAllWorkFlow();

    WaterWorkFlowLevel createNewApplicationTransation(WaterWorkFlowLevel workFlowRequest);

    List<RemarksDto> getRemarksByApplicationId(Long applicationId);
}
