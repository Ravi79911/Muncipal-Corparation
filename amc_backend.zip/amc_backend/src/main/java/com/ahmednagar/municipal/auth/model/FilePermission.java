package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_file_permission_master")
public class FilePermission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @NotNull(message = "Role ID is required.")
    @Column(name = "role_id", nullable = false)
    private int roleId;

    @NotNull(message = "Is Update flag is required.")
    @Column(name = "is_update", nullable = false)
    private boolean isUpdate;

    @NotNull(message = "Is Delete flag is required.")
    @Column(name = "is_delete", nullable = false)
    private boolean isDelete;

    @NotNull(message = "Is Insert flag is required.")
    @Column(name = "is_insert", nullable = false)
    private boolean isInsert;

    @Column(name = "created_by")
    private int createdBy;

    @NotNull(message = "Created date is required.")
    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @NotNull(message = "Updated date is required.")
    @Column(name = "updated_date", nullable = false)
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required.")
    @Column(name = "municipal_id", nullable = false)
    private Long municipalId;

    @ManyToOne
    @JoinColumn(name = "file_url_id",nullable = false,referencedColumnName = "id")
    private FileUrlMaster fileUrlId;
}
