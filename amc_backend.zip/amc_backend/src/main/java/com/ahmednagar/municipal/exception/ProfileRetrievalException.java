package com.ahmednagar.municipal.exception;

import lombok.Data;

@Data
public class ProfileRetrievalException extends RuntimeException {

    public ProfileRetrievalException(String message) {
        super(message);
    }

    public ProfileRetrievalException(String message, Throwable cause) {
        super(message, cause);
    }

}
