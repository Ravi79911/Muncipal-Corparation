package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationElectricityDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationElectricityDetails;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface ApplicationElectricityDetailsService {
    ApplicationElectricityDetails saveApplicationElectricityDetails(ApplicationElectricityDetails applicationElectricityDetails, int createdBy);

//    List<ApplicationElectricityDetailsDto> findAllApplicationElectricityDetails();
//
//    List<ApplicationElectricityDetails> findAllActiveApplicationElectricityDetails(Integer status);

    ApplicationElectricityDetails findApplicationElectricityDetailsById(int id);

    List<ApplicationElectricityDetailsDto> findAllApplicationElectricDetailsByMunicipalId(int municipalId);

    ApplicationElectricityDetails updateapplicationElectricityDetailsService(int id, ApplicationElectricityDetails updatedApplicationElectricityDetails,int updatedBy);

    ApplicationElectricityDetails changeSuspendedStatus(int id, int status,int updatedBy);
}
