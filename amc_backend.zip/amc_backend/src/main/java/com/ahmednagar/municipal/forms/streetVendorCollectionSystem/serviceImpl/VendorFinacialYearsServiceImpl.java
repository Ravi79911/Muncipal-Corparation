package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorFinacialYears;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorFinacilYearsRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorFinacialYearsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class VendorFinacialYearsServiceImpl implements VendorFinacialYearsService {

    @Autowired
    private VendorFinacilYearsRepository vendorFinacilYearsRepository;

    @Override
    public VendorFinacialYears saveVendorFinacialYears(VendorFinacialYears vendorFinacialYears) {
        vendorFinacialYears.setCreatedDate(LocalDateTime.now());
        vendorFinacialYears.setSuspendedStatus(0);
        return vendorFinacilYearsRepository.saveAndFlush(vendorFinacialYears);
    }

    @Override
    public List<VendorFinacialYears> getAllVendorFinacialYears() {
        return vendorFinacilYearsRepository.findBySuspendedStatus(0);
    }
}
