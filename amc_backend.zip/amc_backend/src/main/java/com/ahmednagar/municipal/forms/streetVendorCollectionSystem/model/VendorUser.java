package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "Tbl_User_Master")
public class VendorUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "email_id")
    private String email;

    @Column(name="marital_status")
    private String maritalStatus;

    @Column(name = "designation")
    private String designation;

    @Column(name = "mobile_no")
    private String mobile;

    @Column(name = "father_name")
    private String fatherName;

    @Column(name = "addrs")
    private String address;

    @Column(name = "gender")
    private String gender;

    @Column(name="municipal_id")
    private Long muncipalId;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private int suspendedStatus;

//    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
//    private Set<TblUserLoginMaster> tblUserLoginMasters;

//    @OneToMany(mappedBy = "userMasId", cascade = CascadeType.ALL, orphanRemoval = true)
//    private Set<UserWardAllotment> userWardAllotments;

//    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
//    private Set<CollectionMaster> collectionMasters;
}
