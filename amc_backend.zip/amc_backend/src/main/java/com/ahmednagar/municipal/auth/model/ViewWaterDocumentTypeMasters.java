package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_view_water_document_type_masters")
public class ViewWaterDocumentTypeMasters {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "document type name cannot be blank")
    @Size(max = 255, message = "document type name cannot be longer than 255 characters")
    @Column(name = "document_type_name")
    private String documentTypeName;

    //    @Min(value = 1, message = "created by must be greater than or equal to 1")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    //    @Min(value = 1, message = "updated by must be greater than or equal to 1")
    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Min(value = 0, message = "suspended status must be 0 (inactive) or 1 (active)")
    @Max(value = 1, message = "suspended status must be 0 (inactive) or 1 (active)")
    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

    @Column(name = "application_type_id")
    private Long ApplicationType;

//    @Column(name = "document_group_masid")
//    private Long DocumentGroupMasters;

    @ManyToOne
    @JoinColumn(name = "document_group_masid", referencedColumnName = "id", nullable = false)
//    @JsonBackReference
    private ViewWaterDocumentGroupMaster viewWaterDocumentGroupMaster;

//    @OneToMany(mappedBy = "viewWaterDocumentTypeMasters", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
////    @JsonManagedReference
//    private Set<ViewConsumerDocumentDetails> viewConsumerDocumentDetails;

}
