package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_view_renewal_surrender_amendment_applied_details")
public class ViewRenewalSurrenderAmendmentAppliedDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    @NotNull(message = "ID is required")
    private int id;

    @Column(name = "prev_application_master_id")
    @NotNull(message = "Previous Application Master ID is required")
    private int prevApplicationMasterId;

    @Column(name = "prev_license_no")
    @NotNull(message = "Previous License Number is required")
    @Size(max = 50, message = "Previous License Number cannot exceed 50 characters")
    private String prevLicenseNo;

    @Column(name = "application_applied_for")
    @NotNull(message = "Application Applied For is required")
    @Size(max = 150, message = "Application Applied For cannot exceed 150 characters")
    private String applicationAppliedFor;

    @Column(name = "application_fee")
    private BigDecimal applicationFee;

    @Column(name = "penalty")
    private BigDecimal penalty;

    @Column(name = "denial_arrear_amount")
    private BigDecimal denialArrearAmount;

    @Column(name = "total_amount")
    private BigDecimal totalAmount;

    @Column(name = "is_license_active")
    private Boolean isLicenseActive;

    @Column(name = "created_by")
    @NotNull(message = "Created By is required")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @Column(name = "municipal_id")
    @NotNull(message = "Municipal ID is required")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "application_master_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewApplicationFromMaster viewApplicationFromMaster;

    @Column(name = "ml_rate_master_id")
    private Long mlRateMaster;

    @ManyToOne
    @JoinColumn(name = "fy_year_id", nullable = false,referencedColumnName = "id")
    private ViewLicenseFinancialYearMaster fyYearId;

    @ManyToOne
    @JoinColumn(name = "application_type_id", nullable = false,referencedColumnName = "id")
    private ViewTradeApplicationTypeMasters applicationTypeId;

}
