package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationDocumentsDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationDocumentsDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationDocumentsDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/license/form/applicationDocumentsDetails")
public class ApplicationDocumentsDetailsController {

    @Autowired
    private ApplicationDocumentsDetailsService applicationDocumentsDetailsService;

    //create ApplicationDocument
    @PostMapping("/create")
    public ResponseEntity<ApplicationDocumentsDetails> createApplicationDocumentsDetails(@Valid @RequestBody ApplicationDocumentsDetails applicationDocumentsDetails){
        ApplicationDocumentsDetails createdApplicationDocumentsDetails=applicationDocumentsDetailsService.saveApplicationDocumentsDetails(applicationDocumentsDetails);
        if(createdApplicationDocumentsDetails==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdApplicationDocumentsDetails);
    }

    @PostMapping("/upload")
    public ResponseEntity<?> uploadDocument(@Valid @RequestParam("documentFileName") MultipartFile file,
                                            @RequestParam("createdBy") int createdBy,
                                            @RequestParam("suspendedStatus") @DefaultValue("0") int suspendedStatus,
                                            @RequestParam("municipalId") int municipalId,
                                            @RequestParam("applicationMasterId") Long applicationMasterId,
                                            @RequestParam("documentsMasterId") int documentsMasterId)
    {

        try {
            ApplicationDocumentsDetails result = applicationDocumentsDetailsService.uploadDocument(file, createdBy, suspendedStatus, municipalId, applicationMasterId, documentsMasterId);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }


//    //for all admin users
//    @GetMapping("/all")
//    public ResponseEntity<List<ApplicationDocumentsDetailsDto>> getAllApplicationDocumentsDetails(){
//        List<ApplicationDocumentsDetailsDto> applicationDocumentsDetails=applicationDocumentsDetailsService.findAllApplicationDocumentsDetails();
//        return ResponseEntity.ok(applicationDocumentsDetails);
//    }
//
//    //for active users
//    @GetMapping("/active")
//    public ResponseEntity<List<ApplicationDocumentsDetails>> getAllActiveApplicationDocumentsDetails(@RequestParam(required = false, defaultValue = "0") Integer status){
//        List<ApplicationDocumentsDetails> activeApplicationDocumentsDetails=applicationDocumentsDetailsService.findAllActiveApplicationDocumentsDetails(status);
//        return ResponseEntity.ok(activeApplicationDocumentsDetails);
//
//    }

    //get Application Documents Detail By Id
    @GetMapping("/get/{id}")
    public ResponseEntity<ApplicationDocumentsDetails> getApplicationDocumentsDetailsById(@PathVariable int id){
        ApplicationDocumentsDetails applicationDocumentsDetails=applicationDocumentsDetailsService.findApplicationDocumentsDetailsById(id);
        return ResponseEntity.ok(applicationDocumentsDetails);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllApplicationDocumentsDetailByMunicipalId(@PathVariable int municipalId){
        List<ApplicationDocumentsDetails> applicationDocumentsDetails=applicationDocumentsDetailsService.findAllApplicationDocumentsDetailByMunicipalId(municipalId);
        if (applicationDocumentsDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No applicationDocumentsDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(applicationDocumentsDetails);
    }

    //     Update AppApplication Details From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<ApplicationDocumentsDetails> updateApplicationDocumentsDetails(@PathVariable("id") int id, @RequestBody ApplicationDocumentsDetails updatedApplicationDocumentsDetails){
        try{
            ApplicationDocumentsDetails updated=applicationDocumentsDetailsService.updateApplicationDocumentsDetails(id,updatedApplicationDocumentsDetails,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete AppApplication Details for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<ApplicationDocumentsDetails> changeSuspendedStatus(@PathVariable int id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        ApplicationDocumentsDetails updatedApplicationDocumentsDetails = applicationDocumentsDetailsService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedApplicationDocumentsDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedApplicationDocumentsDetails);
    }


}

