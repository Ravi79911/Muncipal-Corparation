package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandTransactionMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyDemandTransactionMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/forms")
public class PropertyDemandTransactionMasterController {

    @Autowired
    PropertyDemandTransactionMasterService propertyDemandTransactionMasterService;

    @PostMapping("/createPropertyDemandTransactionMaster")
    public ResponseEntity<PropertyDemandTransactionMaster> createPropertyDemandTransaction(@Valid @RequestBody PropertyDemandTransactionMaster propertyDemandTransactionMaster) {
        PropertyDemandTransactionMaster newPropertyDemandTransaction = propertyDemandTransactionMasterService.createPropertyDemandTransactionMaster(propertyDemandTransactionMaster);
        return ResponseEntity.ok(newPropertyDemandTransaction);
    }

    @GetMapping("/getAllPropertyDemandTransactionMaster")
    public ResponseEntity<List<PropertyDemandTransactionMaster>> getAllPropertyDemandTransaction() {
        return ResponseEntity.ok(propertyDemandTransactionMasterService.getAllPropertyDemandTransactionMaster());
    }

    @GetMapping("/propertyDemandTransactionMaster/{id}")
    public ResponseEntity<Object> getPropertyDemandTransactionById(@PathVariable Long id) {
        Optional<PropertyDemandTransactionMaster> propertyDemandTransaction = propertyDemandTransactionMasterService.getPropertyDemandTransactionMasterById(id);
        if (propertyDemandTransaction.isPresent()) {
            return ResponseEntity.ok(propertyDemandTransaction.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getPropertyDemandTransactionMasterByMunicipalId/{municipalId}")
    public List<PropertyDemandTransactionMaster> getPropertyDemandTransactionByMunicipalId(@PathVariable int municipalId) {
        return propertyDemandTransactionMasterService.getPropertyDemandTransactionMasterByMunicipalId(municipalId);
    }

    @PatchMapping("/propertyDemandTransactionMaster/suspendedStatus/{id}")
    public ResponseEntity<PropertyDemandTransactionMaster> patchPropertyDemandTransactionSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        PropertyDemandTransactionMaster patchedPropertyDemandTransaction = propertyDemandTransactionMasterService.patchPropertyDemandTransactionMasterSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedPropertyDemandTransaction);
    }

}
