package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.dto.WorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.*;
import com.ahmednagar.municipal.auth.service.WorkFlowLevelService;
import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class WorkFlowLevelServiceImpl implements WorkFlowLevelService {

    @Autowired
    private WorkFlowLevelRepository workFlowLevelRepository;

    @Autowired
    private RoleMasterRepository roleMasterRepository;

    @Autowired
    private WorkFlowMasterRepository workFlowMasterRepository;

    @Autowired
    private UserMasterRepository userMasterRepository;

    @Autowired
    private CitizenSignUpRepository citizenSignUpRepository;

    @Autowired
    private ViewMunicipalPropertyDocumentUploadDetailsRepository viewMunicipalPropertyDocumentUploadDetailsRepository;

    @Autowired
    private ViewMunicipalPropertyMasterRepository viewMunicipalPropertyMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    public UserMaster getLipikForCitizen(Long citizenId) {
        Long roleId = 1L; // Role ID for Lipik

        CitizenSignUpMaster citizen = citizenSignUpRepository.findById(citizenId)
                .orElseThrow(() -> new EntityNotFoundException("Citizen not found with ID: " + citizenId));

        // Fetch the first Lipik (UserMaster) matching Zone, Ward, Role
        return userMasterRepository.findFirstByZoneWardAndRole(citizen.getZoneId(), citizen.getWardId(), roleId)
                .orElseThrow(() -> new EntityNotFoundException("No Lipik found for Zone: " + citizen.getZoneId()
                        + " and Ward: " + citizen.getWardId()));
    }

    @Override
    public WorkFlowLevel createNewApplicationTransation(WorkFlowLevel newApplicationWorkFlowRequest) {
        // Validate Application ID
//        ViewMunicipalPropertyMaster application = applicationRepository.findById(
//                        newApplicationWorkFlowRequest.getApplicationId().getId())
//                .orElseThrow(() -> new RuntimeException("Application not found"));

        UserMaster newApplicationLipik = getLipikForCitizen(newApplicationWorkFlowRequest.getCitizenId().getId());

//        // Validate Current User
//        UserMaster currentUser = userMasterRepository.findById(newApplicationWorkFlowRequest.getCurrentUserId().getId())
//                .orElseThrow(() -> new RuntimeException("Current User not found"));

        // Validate WorkFlow Master
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newApplicationWorkFlowRequest.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Master not found"));

        // Build WorkFlowLevel Object with Defaults
        WorkFlowLevel newWorkFlow = WorkFlowLevel.builder()
                .applicationId(newApplicationWorkFlowRequest.getApplicationId())
                .currentUserId(null)
                .nextUserId(newApplicationLipik)
                .workFlowMasterId(workFlowMaster)
                .status("NEW") // Default status for new applications
                .statusCode(1000L) // Example status code
                .createdBy(newApplicationWorkFlowRequest.getCreatedBy())
                .createdDate(LocalDateTime.now())
                .mailStatus(newApplicationWorkFlowRequest.getMailStatus())
                .remarks(newApplicationWorkFlowRequest.getRemarks())
                .suspendedStatus(0) // Default
                .municipalId(newApplicationWorkFlowRequest.getMunicipalId())
                .citizenId(newApplicationWorkFlowRequest.getCitizenId())
                .build();
        updateApprovedStatus(newApplicationWorkFlowRequest.getApplicationId().getId());
        newWorkFlow.setMailStatus(1);

        // Save Workflow to Database
        return workFlowLevelRepository.save(newWorkFlow);
    }

    @Override
    public List<WorkFlowLevelDto> findAllWorkFlows() {
        List<WorkFlowLevel> workFlows = workFlowLevelRepository.findAll();

        return workFlows.stream().map(workflow -> {
            WorkFlowLevelDto dto = modelMapper.map(workflow, WorkFlowLevelDto.class);

            // Manually map UserMaster to UserMasterDTO
            if (workflow.getCurrentUserId() != null) {
                dto.setCurrentUserId(modelMapper.map(workflow.getCurrentUserId(), UserMasterDTO.class));
            }
            if (workflow.getNextUserId() != null) {
                dto.setNextUserId(modelMapper.map(workflow.getNextUserId(), UserMasterDTO.class));
            }

            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public WorkFlowLevel handleWorkFlowsTransition(WorkFlowLevel workFlowLevel) {
        workFlowLevel.setCreatedDate(LocalDateTime.now());
        Long currentRoleMasterId = getCurrentRoleMasterId(workFlowLevel);  // Get RoleMasterId for Current User
        Long nextRoleMasterId = getNextRoleMasterId(workFlowLevel);       // Get RoleMasterId for Next User
        //Long nextRoleCitizenMasterId =getNextRoleCitizenMasterId(workFlowLevel);

        RoleMaster currentRole = roleMasterRepository.findById(currentRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));

        RoleMaster nextRole = roleMasterRepository.findById(nextRoleMasterId)
                .orElseThrow(() -> new RuntimeException("Next Role not found"));

        //Optional<RoleMaster> citizenNextRole=roleMasterRepository.findById(nextRoleCitizenMasterId);

        // Dynamically fetch workflow status from WorkFlowMaster table
        WorkFlowMaster currentStatus = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Status not found"));

        List<Long> rejectDocumentIds = workFlowLevel.getRejectedDocumentIds();

        // Fetch the current status of the application
        Optional<WorkFlowLevel> existingWorkflow = workFlowLevelRepository
                .findTopByApplicationIdOrderByCreatedDateDesc(workFlowLevel.getApplicationId());

        if (existingWorkflow.isPresent()) {
            Long existingStatusCode = existingWorkflow.get().getStatusCode();

            // Check if the application has already been accepted or rejected
            if (existingStatusCode.equals(1002L) || existingStatusCode.equals(1003L)) {
                throw new IllegalStateException("This application has already been " +
                        (existingStatusCode.equals(1002L) ? "Accepted" : "Rejected") +
                        " and cannot be processed further.");
            }
        }

        // Transition based on the current status and role
        switch (currentStatus.getStatus()) {

            case "FORWARDED":
                return handleForwardedStatus(workFlowLevel, currentRole, nextRole);

            case "BACKWARD":
                return handleBackwardStatus(workFlowLevel, currentRole, nextRole);

            case "ACCEPT":
                return handleAcceptStatus(workFlowLevel, currentRole);

            case "REJECT":
                return handleRejectStatus(workFlowLevel, currentRole);

            case "BACK TO CITIZEN":
                return handleBackToCitizenStatus(workFlowLevel, currentRole);

            case "BACK TO CITIZEN IN BACKWARD":
                return handleBackToCitizenInBackWardCaseStatus(workFlowLevel, currentRole,nextRole);

            case "BACK TO BACK OFFICE":
                return handleBackToBackOfficeStatus(workFlowLevel, currentRole, nextRole);

            case "DOCUMENT VERIFICATION ACCEPT":
                return handleDocumentVerificationAccept(workFlowLevel, currentRole, nextRole);

            case "DOCUMENT VERIFICATION REJECT":
                return handleDocumentVerificationReject(workFlowLevel, currentRole, nextRole,rejectDocumentIds);

            default:
                throw new RuntimeException("Invalid Status: " + currentStatus.getStatus());
        }
    }

    private WorkFlowLevel handleForwardedStatus(WorkFlowLevel workFlowLevel, RoleMaster currentRole, RoleMaster nextRole) {

        Long nextUserId = workFlowLevel.getNextUserId().getId();
        Long currentUserId = workFlowLevel.getCurrentUserId().getId();

        // Check the status_code and call the corresponding forward methods
        if (workFlowLevel.getStatusCode() == 1005) {
            // Call forwardFromBackOffice when status_code is 1005
            return forwardFromBackOffice(workFlowLevel);

        } else if (workFlowLevel.getStatusCode() == 1004) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromCitizen(workFlowLevel);

        } else if (workFlowLevel.getStatusCode() == 1001) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromBackWard(workFlowLevel);

        } else {
            // Fetch the next role based on the workFlowMasterId from the database
            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
            workFlowLevel.setStatus(workFlowMaster.getStatus());
            workFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

            // Validate nextRole
            if (nextRole == null && !"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
                throw new IllegalStateException("Next role is required but not provided.");
            }

            // Logic based on the current role and next role
            //if (workFlowMaster.getId().equals(1L))
            //if (workFlowMaster.getId().equals(workFlowLevel.getWorkFlowMasterId().getId()))
            if (workFlowMaster.getId().equals(workFlowLevel.getWorkFlowMasterId().getId())) {  // Only handle Forwarded status (workFlowMasterId = 1)
                switch (currentRole.getRoleName().toLowerCase()) {
                    case "back office":
                        if (nextRole.getRoleName().equalsIgnoreCase("lipik")) {
                            //Long fff = getUserMasterIdByRoleMaster(nextRole);
                            workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));  // Forward to Lipik
                            workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            workFlowLevel.setMailStatus(1);
                        } else {
                            throw new IllegalStateException("Invalid next role for Back Office.");
                        }
                        break;

                    case "lipik":
                        if (nextRole.getRoleName().equalsIgnoreCase("agency")) {
                            System.out.println("workflow ::: "+workFlowLevel);
                            workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to Agency/Field
                            workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            workFlowLevel.setMailStatus(1);
                        } else {
                            throw new IllegalStateException("Invalid next role for Lipik.");
                        }
                        break;

                    case "agency":
                        if (nextRole.getRoleName().equalsIgnoreCase("nagar rachna")) {
                            workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));  // Forward to Nagar Rachna
                            workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            workFlowLevel.setMailStatus(1);
                        } else {
                            throw new IllegalStateException("Invalid next role for Agency/Field.");
                        }
                        break;

                    case "nagar rachna":
                        if (nextRole.getRoleName().equalsIgnoreCase("ASSITANCE TAX SUPERINTENDENT")) {
                            workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));  // Forward to ATS
                            workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            workFlowLevel.setMailStatus(1);

                        } else {
                            throw new IllegalStateException("Invalid next role for Nagar Rachna.");
                        }
                        break;

                    case "assitance tax superintendent":
                        if (nextRole.getRoleName().equalsIgnoreCase("TAX SUPERINTENDENT")) {
                            workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to TS
                            workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                            workFlowLevel.setMailStatus(1);
                        } else {
                            throw new IllegalStateException("Invalid next role for ATS.");
                        }
                        break;

                    case "tax superintendent":
                        workFlowLevel.setNextUserId(null);
                        workFlowLevel.setStatus("Application Successfully Approved");
                        workFlowLevel.setStatusCode(1002L); // Status Code for "Accepted"
                        workFlowLevel.setMailStatus(0);
                }
                if (nextRole == null) {
                    throw new IllegalStateException("Next role is required but not provided.");
                }
                //workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole));
                workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
            }

            //workFlowLevel.setMailStatus(1);
            workFlowLevel.setCreatedDate(LocalDateTime.now());
            updateApprovedStatus(workFlowLevel.getApplicationId().getId());
            return workFlowLevelRepository.save(workFlowLevel);
        }
    }

//    private WorkFlowLevel handleBackwardStatus(WorkFlowLevel workflowlevel, RoleMaster currentRole, RoleMaster previousRole) {
//        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workflowlevel.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));
//
//        System.out.println(" current role{}" + currentRole);
//        System.out.println(" previous role{}" + previousRole);
//
//        if (workFlowMaster.getId().equals(2L)) {  // Backward
//            workflowlevel.setStatus(workFlowMaster.getStatus()); // Set to Backward status
//            workflowlevel.setStatusCode(workFlowMaster.getStatusCode());
//
//            // Validate previousRole
//            if (previousRole == null) {
//                throw new IllegalStateException("Previous role is required but not provided.");
//            }
//            // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
//            if (workflowlevel.getCitizenId() != null) {
//                WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
//                        .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));
//
//                workflowlevel.setWorkFlowMasterId(backToCitizenMaster);
//
////                workflowlevel.setStatusCode(Long.valueOf("1004")); // Set the status code to 1004 when going back to Citizen
//
//                //return handleBackToCitizenStatus(workflowlevel, currentRole);  // Handle transition to citizen
//                return handleBackToCitizenStatus(workflowlevel, currentRole,previousRole);
//            }
//
//
//            WorkFlowMaster backOfficeMaster = workFlowMasterRepository.findById(6L)
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 6 not found"));
//
//            workflowlevel.setWorkFlowMasterId(backOfficeMaster);
//
//            WorkFlowLevel workFlowLevel = handleBackToBackOfficeStatus(workflowlevel, currentRole, previousRole);
//            return workFlowLevel;
//        }
//        return null;
//
//    }

    private WorkFlowLevel handleBackwardStatus(WorkFlowLevel workflowlevel, RoleMaster currentRole, RoleMaster previousRole) {
        // Fetch the next role based on the workFlowMasterId from the database
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workflowlevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = workflowlevel.getNextUserId().getId();
        Long currentUserId = workflowlevel.getCurrentUserId().getId();

        // Set the status from WorkFlowMaster to WorkFlow
        workflowlevel.setStatus(workFlowMaster.getStatus());
        workflowlevel.setStatusCode(workFlowMaster.getStatusCode());

        // Validate nextRole
        if (previousRole == null && !"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Next role is required but not provided.");
        }

        // Logic based on the current role and next role for rejection
        if (workFlowMaster.getId().equals(workflowlevel.getWorkFlowMasterId().getId())) {  // Only handle Backward status (workFlowMasterId = 2)
            switch (currentRole.getRoleName().toLowerCase()) {
                case "lipik":
                    // Lipik can only reject and return to Back Office
                    if ("back office".equalsIgnoreCase(previousRole.getRoleName())) {
                        workflowlevel.setNextUserId(getUserMasterByRoleMaster(previousRole,nextUserId)); // Reject and return to Back Office
                        workflowlevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                        workflowlevel.setStatus("Rejected by Lipik");
                    } else {
                        throw new IllegalStateException("Lipik can only reject and return to Back Office.");
                    }
                    break;
                case "agency":
                    // Agency/Field cannot go backward
                    throw new IllegalStateException("Agency/Field cannot move backward.");
                case "nagar rachna":
                    // Nagar Rachna can reject to Agency/Field, Lipik, or Back Office
                    if (isValidRoleForNagarRachna(previousRole)) {
                        workflowlevel.setNextUserId(getUserMasterByRoleMaster(previousRole,nextUserId)); // Reject and return to the selected role
                        workflowlevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                        workflowlevel.setStatus("Rejected by Nagar Rachna");
                    } else {
                        throw new IllegalStateException("Nagar Rachna can only reject to Agency/Field, Lipik, or Back Office.");
                    }
                    break;
                case "assitance tax superintendent":
                    // ATS can reject to Nagar Rachna, Agency/Field, Lipik, or Back Office
                    if (isValidRoleForATS(previousRole)) {
                        workflowlevel.setNextUserId(getUserMasterByRoleMaster(previousRole,nextUserId)); // Reject and return to the selected role
                        workflowlevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                        workflowlevel.setStatus("Rejected by ATS");
                    } else {
                        throw new IllegalStateException("ATS can only reject to Nagar Rachna, Agency/Field, Lipik, or Back Office.");
                    }
                    break;
                case "tax superintendent":
                    // TS can reject to ATS, Nagar Rachna, Agency/Field, Lipik, or Back Office
                    if (isValidRoleForTS(previousRole)) {
                        workflowlevel.setNextUserId(getUserMasterByRoleMaster(previousRole,nextUserId)); // Reject and return to the selected role
                        workflowlevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                        workflowlevel.setStatus("Rejected by TS");
                    } else {
                        throw new IllegalStateException("TS can only reject to ATS, Nagar Rachna, Agency/Field, Lipik, or Back Office.");
                    }
                    break;
                default:
                    throw new IllegalStateException("Invalid current role for Document Verification Reject: " + currentRole.getRoleName());
            }

            // Set mail status and created date for all cases except TS → ID Generation rejection
            if (!"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
                workflowlevel.setMailStatus(0);  // Assuming 0 means mail sent for rejection
                workflowlevel.setCreatedDate(LocalDateTime.now());
            }

            // Update rejection status for the rejected documents
            //updateRejectStatus(workflowlevel.getApplicationId().getId(), rejectDocumentIds);
            workflowlevel.setMailStatus(2);
        }

        //Validate previousRole
        if (previousRole == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }
        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
        if (workflowlevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            workflowlevel.setWorkFlowMasterId(backToCitizenMaster);

            return handleBackToCitizenInBackWardCaseStatus(workflowlevel, currentRole,previousRole);  // Handle transition to citizen
        }

        return workFlowLevelRepository.save(workflowlevel);
    }


    private WorkFlowLevel handleAcceptStatus(WorkFlowLevel workFlow, RoleMaster currentRole) {

        Long nextUserId = workFlow.getNextUserId().getId();
        Long currentUserId = workFlow.getCurrentUserId().getId();
        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        // Check if the application is already accepted or rejected
        Optional<WorkFlowLevel> existingStatus = workFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(workFlow.getApplicationId().getId(), 1002L);

        if (existingStatus.isPresent()) {
            throw new IllegalStateException("This application has already been accepted and cannot be processed again.");
        }

        if (workFlowMaster.getId().equals(3L)) {  // Only handle Forwarded status (workFlowMasterId = 3)
            workFlow.setStatus("ACCEPT");
            workFlow.setStatusCode(workFlowMaster.getStatusCode());

        }

        // Ensure only TS can accept
        if (!"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only Tax Superintendent can accept the application.");
        }

        // Update status to "Accepted"
//        workFlow.setStatus("Application Successfully Accepted");
//        workFlow.setStatusCode(workFlow.getStatusCode());
        workFlow.setNextUserId(null); // No further forwarding
        workFlow.setMailStatus(0);
        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
        workFlow.setCreatedDate(LocalDateTime.now());

        return workFlowLevelRepository.save(workFlow);
    }


    private WorkFlowLevel handleRejectStatus(WorkFlowLevel workFlow, RoleMaster currentRole) {

        Long nextUserId = workFlow.getNextUserId().getId();
        Long currentUserId = workFlow.getCurrentUserId().getId();
        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        // Check if the application is already accepted or rejected
        Optional<WorkFlowLevel> existingStatus = workFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(workFlow.getApplicationId().getId(), 1003L);

        if (existingStatus.isPresent()) {
            throw new IllegalStateException("This application has already been rejected and cannot be processed again.");
        }

        if (!workFlowMaster.getId().equals(4L)) {
            throw new IllegalStateException("Invalid workflow operation. Expected 'Reject' status.");
        }

        // Ensure only "Tax Superintendent" can reject
        if (!"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only Tax Superintendent can reject the application.");
        }

        // Update status to "Rejected"
        workFlow.setStatus("Application Rejected");
        workFlow.setStatusCode(workFlowMaster.getStatusCode());
        workFlow.setNextUserId(null); // No further processing
        workFlow.setMailStatus(1);
        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
        workFlow.setCreatedDate(LocalDateTime.now());

        // Mark application as inactive or non-processable
        ViewMunicipalPropertyMaster application = viewMunicipalPropertyMasterRepository.findById(workFlow.getApplicationId().getId())
                .orElseThrow(() -> new RuntimeException("Application not found"));

        //application.setActive(false); // Mark application as inactive
        viewMunicipalPropertyMasterRepository.save(application);

        return workFlowLevelRepository.save(workFlow);
    }

    private WorkFlowLevel handleBackToCitizenStatus(WorkFlowLevel workFlow, RoleMaster currentRole) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = workFlow.getNextUserId().getId();
        Long currentUserId = workFlow.getCurrentUserId().getId();

        if (workFlowMaster.getId().equals(5L)) {
            workFlow.setStatus(workFlowMaster.getStatus());
            workFlow.setStatusCode(workFlowMaster.getStatusCode());

            workFlow.setNextUserId(null);
            workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
            workFlow.setCitizenId(workFlow.getCitizenId());
        }
        workFlow.setMailStatus(1);
        workFlow.setCreatedDate(LocalDateTime.now());
        return workFlowLevelRepository.save(workFlow);
    }

    private WorkFlowLevel handleBackToCitizenInBackWardCaseStatus(WorkFlowLevel workFlow, RoleMaster currentRole, RoleMaster nextRole) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = workFlow.getNextUserId() != null ? workFlow.getNextUserId().getId() : null;
        Long currentUserId = workFlow.getCurrentUserId().getId();

        if (workFlowMaster.getId().equals(5L)) {  // Backward Flow for WorkFlowMasterId = 5

            workFlow.setStatus(workFlowMaster.getStatus());
            workFlow.setStatusCode(workFlowMaster.getStatusCode());

            switch (currentRole.getRoleName().toLowerCase()) {
                case "lipik":
                    // Lipik can only go backward to "Back to Citizen"
                    workFlow.setNextUserId(null);
                    workFlow.setCitizenId(workFlow.getCitizenId());
                    workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                    workFlow.setStatus("Backward to Citizen");
                    break;

                case "agency":
                    // Agency cannot go backward
                    throw new IllegalStateException("Agency cannot move backward.");

                case "nagar rachna":
                    // Nagar Rachna can go backward to "Agency" or "Lipik", or "Back to Citizen"
                    if (isValidRolesForNagarRachna(nextRole)) {
                        workFlow.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward from " + currentRole.getRoleName());
                    } else {
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                case "assitance tax superintendent":
                    // ATS can go backward to "Nagar Rachna", "Agency", "Lipik", or "Back to Citizen"
                    if (isValidRolesForATS(nextRole)) {
                        workFlow.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward from " + currentRole.getRoleName());
                    } else {
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                case "tax superintendent":
                    // TS can go backward to "ATS", "Nagar Rachna", "Agency", "Lipik", or "Back to Citizen"
                    if (isValidRolesForTS(nextRole)) {
                        workFlow.setNextUserId(getUserMasterByRoleMaster(nextRole, nextUserId));
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward from " + currentRole.getRoleName());
                    } else {
                        workFlow.setNextUserId(null);
                        workFlow.setCitizenId(workFlow.getCitizenId());
                        workFlow.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
                        workFlow.setStatus("Backward to Citizen");
                    }
                    break;

                default:
                    throw new IllegalStateException("Invalid current role for Backward Flow: " + currentRole.getRoleName());
            }
        }

        // Set the mail status and created date after the operation
        workFlow.setMailStatus(1);  // Assuming 1 means mail sent for rejection
        workFlow.setCreatedDate(LocalDateTime.now());

        return workFlowLevelRepository.save(workFlow);
    }

    private boolean isValidRolesForNagarRachna(RoleMaster nextRole) {
        // Nagar Rachna can go back to "Agency" or "Lipik", or "Back to Citizen"
        return "agency".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName());
    }

    private boolean isValidRolesForATS(RoleMaster nextRole) {
        // ATS can go back to "Nagar Rachna", "Agency", "Lipik", or "Back to Citizen"
        return "nagar rachna".equalsIgnoreCase(nextRole.getRoleName()) ||
                "agency".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName());
    }

    private boolean isValidRolesForTS(RoleMaster nextRole) {
        // TS can go back to "ATS", "Nagar Rachna", "Agency", "Lipik", or "Back to Citizen"
        return "assitance tax superintendent".equalsIgnoreCase(nextRole.getRoleName()) ||
                "nagar rachna".equalsIgnoreCase(nextRole.getRoleName()) ||
                "agency".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName());
    }




    private WorkFlowLevel handleBackToBackOfficeStatus(WorkFlowLevel workflowlevel, RoleMaster currentRole, RoleMaster nextRole) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workflowlevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = workflowlevel.getNextUserId().getId();
        Long currentUserId = workflowlevel.getCurrentUserId().getId();

        if (workFlowMaster.getId().equals(6L)) {  // Backward
            workflowlevel.setStatus(workFlowMaster.getStatus()); // Set to Backward status
            workflowlevel.setStatusCode(workFlowMaster.getStatusCode());

            // Validate nextRole
            if (nextRole == null) {
                throw new IllegalStateException("Previous role is required but not provided.");
            }

            // Special case for TS - can backward to multiple roles
            if (currentRole.getRoleName().equalsIgnoreCase("tax superintendent")) {
                if (List.of("assitance tax superintendent", "nagar rachna", "agency/field", "lipik", "back office")
                        .contains(nextRole.getRoleName().toLowerCase())) {
                    workflowlevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));
                    workflowlevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                } else {
                    throw new IllegalStateException("TS cannot backward from " + nextRole.getRoleName());
                }
            } else {
                // All other roles always send backward to Back Office
                if (!nextRole.getRoleName().equalsIgnoreCase("back office")) {
                    throw new IllegalStateException(currentRole.getRoleName() + " can only backward from Back Office.");
                }
                workflowlevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));  // Back to Back Office
                workflowlevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
            }

        } else {
            throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
        }

        // Set mail status and created date
        if (!"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
            workflowlevel.setMailStatus(1); // Mail status to sent
            workflowlevel.setCreatedDate(LocalDateTime.now());
        }
        // Set mail status and created date
        workflowlevel.setMailStatus(1);
        workflowlevel.setCreatedDate(LocalDateTime.now());
        return workFlowLevelRepository.save(workflowlevel);
    }

    private WorkFlowLevel handleDocumentVerificationAccept(WorkFlowLevel workFlowLevel, RoleMaster currentRole, RoleMaster nextRole) {
        // Fetch the next role based on the workFlowMasterId from the database
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        Long nextUserId = workFlowLevel.getNextUserId().getId();
        Long currentUserId = workFlowLevel.getCurrentUserId().getId();
        // Set the status from WorkFlowMaster to WorkFlow
        workFlowLevel.setStatus(workFlowMaster.getStatus());
        workFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        // Validate nextRole
        if (nextRole == null && !"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Next role is required but not provided.");
        }

        // Logic based on the current role and next role
        //if (workFlowMaster.getId().equals(workFlow.getWorkFlowMasterId().getId()))
        if (workFlowMaster.getId().equals(7L)) {  // Only handle Forwarded status (workFlowMasterId = 1)
            switch (currentRole.getRoleName().toLowerCase()) {
                case "back office":
                    if (nextRole.getRoleName().equalsIgnoreCase("lipik")) {
                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to Lipik
                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                        workFlowLevel.setMailStatus(0);
                    } else {
                        throw new IllegalStateException("Invalid next role for Back Office.");
                    }
                    break;
                case "lipik":
                    if (nextRole.getRoleName().equalsIgnoreCase("agency")) {
                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));  // Forward to Agency/Field
                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                        workFlowLevel.setMailStatus(0);
                    } else {
                        throw new IllegalStateException("Invalid next role for Lipik.");
                    }
                    break;
                case "agency":
                    if (nextRole.getRoleName().equalsIgnoreCase("nagar rachna")) {
                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to Nagar Rachna
                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                        workFlowLevel.setMailStatus(0);
                    } else {
                        throw new IllegalStateException("Invalid next role for Agency/Field.");
                    }
                    break;
                case "nagar rachna":
                    if (nextRole.getRoleName().equalsIgnoreCase("assitance tax superintendent")) {
                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Forward to ATS
                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                        workFlowLevel.setMailStatus(0);
                    } else {
                        throw new IllegalStateException("Invalid next role for Nagar Rachna.");
                    }
                    break;
                case "assitance tax superintendent":
                    if (nextRole.getRoleName().equalsIgnoreCase("tax superintendent")) {
                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId));  // Forward to TS
                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                        workFlowLevel.setMailStatus(0);
                    } else {
                        throw new IllegalStateException("Invalid next role for ATS.");
                    }
                    break;

                case "tax superintendent":
                workFlowLevel.setStatus("Application Document Successfully Accepted");
                workFlowLevel.setStatusCode(1002L); // Status Code for "Accepted"
                workFlowLevel.setNextUserId(null); // No further processing
                workFlowLevel.setMailStatus(0);

                if (nextRole == null) {
                    throw new IllegalStateException("Next role is required but not provided.");
                }
                workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
                workFlowLevel.setCreatedDate(LocalDateTime.now());

            }
            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(workFlowLevel.getApplicationId().getId());

        }
        return workFlowLevelRepository.save(workFlowLevel);
    }
    private void updateApprovedStatus(Long applicationId) {

        List<ViewMunicipalPropertyDocumentUploadDetails> documentDetails =
                viewMunicipalPropertyDocumentUploadDetailsRepository.findByViewMunicipalPropertyMaster_Id(applicationId);

        if (documentDetails.isEmpty()) {
            System.out.println("No matching documents found for rejection.");
            return;
        }

        documentDetails.forEach(details -> details.setApprovedStatus(1f)); // Set approved_status to 0

        // Save all updates in batch
        viewMunicipalPropertyDocumentUploadDetailsRepository.saveAll(documentDetails);

        System.out.println("Updated " + documentDetails.size() + " documents to rejected status.");
    }

//    private void updateApprovedStatus(Long applicationId) {
//        List<ViewMunicipalPropertyDocumentUploadDetails> documentDetails =
//                viewMunicipalPropertyDocumentUploadDetailsRepository.findByViewMunicipalPropertyMaster_Id(applicationId);
//
//        for(ViewMunicipalPropertyDocumentUploadDetails details : documentDetails){
//
//            details.setApprovedStatus(1f); // Set approved_status to 1
//            viewMunicipalPropertyDocumentUploadDetailsRepository.save(details);
//        };
//    }


//    private WorkFlowLevel handleDocumentVerificationReject(WorkFlowLevel workFlowLevel, RoleMaster currentRole, RoleMaster nextRole,List<Long> rejectDocumentIds) {
//        // Fetch the next role based on the workFlowMasterId from the database
//        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));
//        // Set the status from WorkFlowMaster to WorkFlow
//        workFlowLevel.setStatus(workFlowMaster.getStatus());
//        workFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
//        // Validate nextRole
//        if (nextRole == null && !"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
//            throw new IllegalStateException("Next role is required but not provided.");
//        }
//        // Logic based on the current role and next role for rejection
//        if (workFlowMaster.getId().equals(workFlowLevel.getWorkFlowMasterId().getId())) {  // Only handle Forwarded status (workFlowMasterId = 7)
//            switch (currentRole.getRoleName().toLowerCase()) {
//                case "back office":
//                    if ("citizen".equalsIgnoreCase(nextRole.getRoleName())) {
//                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole)); // Reject and return to Citizen
//                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole));
//                        workFlowLevel.setStatus("Rejected by Back Office");
//                    } else {
//                        throw new IllegalStateException("Back Office can only reject and return to Citizen.");
//                    }
//                    break;
//                case "lipik":
//                    if ("back office".equalsIgnoreCase(nextRole.getRoleName())) {
//                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole)); // Reject and return to Back Office
//                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole));
//                        workFlowLevel.setStatus("Rejected by Lipik");
//                    } else {
//                        throw new IllegalStateException("Lipik can only reject and return to Back Office.");
//                    }
//                    break;
//                case "agency":
//                    if ("lipik".equalsIgnoreCase(nextRole.getRoleName())) {
//                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole)); // Reject and return to Lipik
//                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole));
//                        workFlowLevel.setStatus("Rejected by Agency/Field");
//                    } else {
//                        throw new IllegalStateException("Agency/Field can only reject and return to Lipik.");
//                    }
//                    break;
//                case "nagar rachna":
//                    if ("agency".equalsIgnoreCase(nextRole.getRoleName())) {
//                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole));  // Reject and return to Agency/Field
//                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole));
//                        workFlowLevel.setStatus("Rejected by Nagar Rachna");
//                    } else {
//                        throw new IllegalStateException("Nagar Rachna can only reject and return to Agency/Field.");
//                    }
//                    break;
//                case "assitance tax superintendent":
//                    if ("nagar rachna".equalsIgnoreCase(nextRole.getRoleName())) {
//                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole)); // Reject and return to Nagar Rachna
//                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole));
//                        workFlowLevel.setStatus("Rejected by ATS");
//                    } else {
//                        throw new IllegalStateException("ATS can only reject and return to Nagar Rachna.");
//                    }
//                    break;
//                case "tax superintendent":
//                    if ("assitance tax superintendent".equalsIgnoreCase(nextRole.getRoleName())) {
//                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole)); // Reject and return to ATS
//                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole));
//                        workFlowLevel.setStatus("Rejected by TS");
//                    } else {
//                        throw new IllegalStateException("TS can only reject and return to ATS.");
//                    }
//                    break;
//                default:
//                    throw new IllegalStateException("Invalid current role for Document Verification Reject: " + currentRole.getRoleName());
//            }
//            // Set mail status and created date for all cases except TS → ID Generation rejection
//            if (!"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
//                workFlowLevel.setMailStatus(0);  // Assuming 0 means mail sent for rejection
//                workFlowLevel.setCreatedDate(LocalDateTime.now());
//            }
//            updateRejectStatus(workFlowLevel.getApplicationId().getId(),rejectDocumentIds);
//        }
//        return workFlowLevelRepository.save(workFlowLevel);
//    }
//    private void updateRejectStatus(Long applicationId,List<Long> rejectDocumentIds) {
//        List<ViewMunicipalPropertyDocumentUploadDetails> documentDetails =
//                viewMunicipalPropertyDocumentUploadDetailsRepository.findAllById(rejectDocumentIds);
//
//        for(ViewMunicipalPropertyDocumentUploadDetails details : documentDetails){
//
//            details.setApprovedStatus(0f); // Set approved_status to 0
//            viewMunicipalPropertyDocumentUploadDetailsRepository.save(details);
//        };
//    }

   private WorkFlowLevel handleDocumentVerificationReject(WorkFlowLevel workFlowLevel, RoleMaster currentRole, RoleMaster nextRole,List<Long> rejectDocumentIds) {
       WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
               .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

       System.out.println("Current role: " + currentRole);
       System.out.println("Previous role: " + nextRole);

       if (workFlowMaster.getId().equals(8L)) {  // Backward
           workFlowLevel.setStatus(workFlowMaster.getStatus()); // Set to Backward status
           workFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

           // Validate previousRole
           if (nextRole == null) {
               throw new IllegalStateException("Previous role is required but not provided.");
           }
           // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
           if (workFlowLevel.getCitizenId() != null) {
               WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                       .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

               workFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

               updateRejectStatus(workFlowLevel.getApplicationId().getId(), rejectDocumentIds);

               return handleBackToCitizenStatus(workFlowLevel, currentRole);  // Handle transition to citizen
           }

           WorkFlowMaster backOfficeMaster = workFlowMasterRepository.findById(6L)
                   .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 6 not found"));

           workFlowLevel.setWorkFlowMasterId(backOfficeMaster);

           // Call handleBackToBackOfficeStatus for BackOffice rejections
           WorkFlowLevel workFlowLevel1 = handleBackToBackOfficeStatus(workFlowLevel, currentRole, nextRole);


           // Update reject status after returning to back office
           updateRejectStatus(workFlowLevel.getApplicationId().getId(), rejectDocumentIds);

           return workFlowLevel1;
       }

       // Update rejected documents for all other roles
       updateRejectStatus(workFlowLevel.getApplicationId().getId(), rejectDocumentIds);
       workFlowLevel.setMailStatus(2);

       return workFlowLevelRepository.save(workFlowLevel);
   }

    /**
     * Update approved_status to 0 for rejected documents
     */
    private void updateRejectStatus(Long applicationId, List<Long> rejectDocumentIds) {
        if (rejectDocumentIds == null || rejectDocumentIds.isEmpty()) {
            System.out.println("No documents to update for rejection.");
            return;
        }

        List<ViewMunicipalPropertyDocumentUploadDetails> documentDetails =
                viewMunicipalPropertyDocumentUploadDetailsRepository.findAllById(rejectDocumentIds);

        if (documentDetails.isEmpty()) {
            System.out.println("No matching documents found for rejection.");
            return;
        }

        documentDetails.forEach(details -> details.setApprovedStatus(0f)); // Set approved_status to 0

        // Save all updates in batch
        viewMunicipalPropertyDocumentUploadDetailsRepository.saveAll(documentDetails);

        System.out.println("Updated " + documentDetails.size() + " documents to rejected status.");
    }

//    private WorkFlowLevel handleDocumentVerificationReject(WorkFlowLevel workFlowLevel, RoleMaster currentRole, RoleMaster nextRole, List<Long> rejectDocumentIds) {
//        // Fetch the next role based on the workFlowMasterId from the database
//        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));
//
//        Long nextUserId = workFlowLevel.getNextUserId().getId();
//        Long currentUserId = workFlowLevel.getCurrentUserId().getId();
//
//        // Set the status from WorkFlowMaster to WorkFlow
//        workFlowLevel.setStatus(workFlowMaster.getStatus());
//        workFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
//
//        // Validate nextRole
//        if (nextRole == null && !"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
//            throw new IllegalStateException("Next role is required but not provided.");
//        }
//
//        // Logic based on the current role and next role for rejection
//        if (workFlowMaster.getId().equals(workFlowLevel.getWorkFlowMasterId().getId())) {  // Only handle Backward status (workFlowMasterId = 2)
//            switch (currentRole.getRoleName().toLowerCase()) {
//                case "lipik":
//                    // Lipik can only reject and return to Back Office
//                    if ("back office".equalsIgnoreCase(nextRole.getRoleName())) {
//                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Reject and return to Back Office
//                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
//                        workFlowLevel.setStatus("Rejected by Lipik");
//                    } else {
//                        throw new IllegalStateException("Lipik can only reject and return to Back Office.");
//                    }
//                    break;
//                case "agency":
//                    // Agency/Field cannot go backward
//                    throw new IllegalStateException("Agency/Field cannot move backward.");
//                case "nagar rachna":
//                    // Nagar Rachna can reject to Agency/Field, Lipik, or Back Office
//                    if (isValidRoleForNagarRachna(nextRole)) {
//                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Reject and return to the selected role
//                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
//                        workFlowLevel.setStatus("Rejected by Nagar Rachna");
//                    } else {
//                        throw new IllegalStateException("Nagar Rachna can only reject to Agency/Field, Lipik, or Back Office.");
//                    }
//                    break;
//                case "assitance tax superintendent":
//                    // ATS can reject to Nagar Rachna, Agency/Field, Lipik, or Back Office
//                    if (isValidRoleForATS(nextRole)) {
//                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Reject and return to the selected role
//                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
//                        workFlowLevel.setStatus("Rejected by ATS");
//                    } else {
//                        throw new IllegalStateException("ATS can only reject to Nagar Rachna, Agency/Field, Lipik, or Back Office.");
//                    }
//                    break;
//                case "tax superintendent":
//                    // TS can reject to ATS, Nagar Rachna, Agency/Field, Lipik, or Back Office
//                    if (isValidRoleForTS(nextRole)) {
//                        workFlowLevel.setNextUserId(getUserMasterByRoleMaster(nextRole,nextUserId)); // Reject and return to the selected role
//                        workFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole,currentUserId));
//                        workFlowLevel.setStatus("Rejected by TS");
//                    } else {
//                        throw new IllegalStateException("TS can only reject to ATS, Nagar Rachna, Agency/Field, Lipik, or Back Office.");
//                    }
//                    break;
//                default:
//                    throw new IllegalStateException("Invalid current role for Document Verification Reject: " + currentRole.getRoleName());
//            }
//
//            // Set mail status and created date for all cases except TS → ID Generation rejection
//            if (!"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
//                workFlowLevel.setMailStatus(0);  // Assuming 0 means mail sent for rejection
//                workFlowLevel.setCreatedDate(LocalDateTime.now());
//            }
//
//            // Update rejection status for the rejected documents
//            updateRejectStatus(workFlowLevel.getApplicationId().getId(), rejectDocumentIds);
//            workFlowLevel.setMailStatus(2);
//        }
//
//         //Validate previousRole
//           if (nextRole == null) {
//               throw new IllegalStateException("Previous role is required but not provided.");
//           }
//           // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
//           if (workFlowLevel.getCitizenId() != null) {
//               WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
//                       .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));
//
//               workFlowLevel.setWorkFlowMasterId(backToCitizenMaster);
//
//               updateRejectStatus(workFlowLevel.getApplicationId().getId(), rejectDocumentIds);
//
//               return handleBackToCitizenStatus(workFlowLevel, currentRole,nextRole);  // Handle transition to citizen
//           }
//
//        return workFlowLevelRepository.save(workFlowLevel);
//    }
//
    private boolean isValidRoleForNagarRachna(RoleMaster nextRole) {
        // Nagar Rachna can go back to Agency/Field, Lipik, or Back Office
        return "agency".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName()) ||
                "back office".equalsIgnoreCase(nextRole.getRoleName());
    }

    private boolean isValidRoleForATS(RoleMaster nextRole) {
        // ATS can go back to Nagar Rachna, Agency/Field, Lipik, or Back Office
        return "nagar rachna".equalsIgnoreCase(nextRole.getRoleName()) ||
                "agency".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName()) ||
                "back office".equalsIgnoreCase(nextRole.getRoleName());
    }

    private boolean isValidRoleForTS(RoleMaster nextRole) {
        // TS can go back to ATS, Nagar Rachna, Agency/Field, Lipik, or Back Office
        return "assitance tax superintendent".equalsIgnoreCase(nextRole.getRoleName()) ||
                "nagar rachna".equalsIgnoreCase(nextRole.getRoleName()) ||
                "agency".equalsIgnoreCase(nextRole.getRoleName()) ||
                "lipik".equalsIgnoreCase(nextRole.getRoleName()) ||
                "back office".equalsIgnoreCase(nextRole.getRoleName());
    }
//
//    private void updateRejectStatus(Long applicationId, List<Long> rejectDocumentIds) {
//        if (rejectDocumentIds == null || rejectDocumentIds.isEmpty()) {
//            System.out.println("No documents to update for rejection.");
//            return;
//        }
//        // Update the reject status for the provided document IDs
//        List<ViewMunicipalPropertyDocumentUploadDetails> documentDetails =
//                viewMunicipalPropertyDocumentUploadDetailsRepository.findAllById(rejectDocumentIds);
//
//        for (ViewMunicipalPropertyDocumentUploadDetails details : documentDetails) {
//            details.setApprovedStatus(0f); // Set approved_status to 0 (rejected)
//            viewMunicipalPropertyDocumentUploadDetailsRepository.save(details);
//        }
//    }




    public Long getNextRoleCitizenMasterId(WorkFlowLevel workFlowLevel) {
        if (workFlowLevel == null || workFlowLevel.getCurrentUserId() == null) {
            throw new IllegalArgumentException("WorkFlow or CurrentUserId cannot be null");
        }

        // Fetch CitizenSignUpMaster based on nextUserId
        CitizenSignUpMaster nextUserId = citizenSignUpRepository.findById(workFlowLevel.getNextUserId().getId())
                .orElseThrow(() -> new RuntimeException("Citizen not found for User ID: " + workFlowLevel.getCurrentUserId().getId()));

        // Fetch the RoleMaster associated with this CitizenSignUpMaster
        RoleMaster roleMaster = nextUserId.getRoleMaster();
        if (roleMaster == null) {
            throw new RuntimeException("RoleMaster not found for Citizen ID: " + nextUserId.getId());
        }

        // Return the RoleMaster ID
        return roleMaster.getId();
    }

    public Long getCurrentRoleMasterId(WorkFlowLevel workFlowLevel) {
//        if (workFlowLevel == null || workFlowLevel.getCurrentUserId() == null) {
//            throw new IllegalArgumentException("WorkFlow or CurrentUserId cannot be null");
//        }

        return userMasterRepository.findById(workFlowLevel.getCurrentUserId().getId())
                .map(UserMaster::getRoleMaster)  // Get RoleMaster directly
                .map(RoleMaster::getId)         // Extract RoleMaster ID
                .orElseThrow(() -> new RuntimeException("RoleMaster not found for User ID: " + workFlowLevel.getCurrentUserId().getId()));
    }

    public Long getNextRoleMasterId(WorkFlowLevel workFlowLevel) {
//        if (workFlowLevel == null || workFlowLevel.getNextUserId() == null) {
//            throw new IllegalArgumentException("WorkFlow or NextUserId cannot be null");
//        }
        if (workFlowLevel.getNextUserId() == null) {
            return null;
        } else {
            UserMaster nextUserId = userMasterRepository.findById(workFlowLevel.getNextUserId().getId())
                    .orElseThrow(() -> new RuntimeException("next User not found"));
            Long NextRoleId = nextUserId.getRoleMaster().getId();
            RoleMaster roleMaster = roleMasterRepository.findById(NextRoleId)
                    .orElseThrow(() -> new RuntimeException("next Role not found"));

            System.out.println(roleMaster);
            System.out.println(nextUserId);
            if (roleMaster == null) {
                throw new RuntimeException("RoleMaster not found for NextUser ID: " + workFlowLevel.getNextUserId().getId());
            }
            return roleMaster.getId();
        }
    }

    public UserMaster getUserMasterByRoleMaster(RoleMaster roleMaster, Long userId) {
        if (roleMaster == null || roleMaster.getId() == null) {
            throw new IllegalArgumentException("RoleMaster or RoleMasterId cannot be null");
        }

//        return userMasterRepository.findFirstByRoleMaster(roleMaster)
//                .orElseThrow(() -> new RuntimeException("No UserMaster found for RoleMaster: " + roleMaster.getRoleName()));
        return userMasterRepository.findFirstByRoleMasterAndId(roleMaster, userId)
                .orElseThrow(() -> new RuntimeException(
                        "No UserMaster found for RoleMaster: " + roleMaster.getRoleName() + " and User ID: " + userId));
    }

    private WorkFlowLevel forwardFromBackOffice(WorkFlowLevel workFlowLevel) {

        Long applicationId = workFlowLevel.getApplicationId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = workFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        WorkFlowLevel latestWorkFlow = workFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1005) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            workFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            workFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
//        workFlowLevel.setStatus(workFlowMaster.getStatus());
            workFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            workFlowLevel.setStatus("Forwarded from Back Office");
            workFlowLevel.setMailStatus(1);
            workFlowLevel.setCreatedDate(LocalDateTime.now());

            updateApprovedStatus(workFlowLevel.getApplicationId().getId());
            return workFlowLevelRepository.save(workFlowLevel);

        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private WorkFlowLevel forwardFromBackWard(WorkFlowLevel workFlowLevel) {

        Long applicationId = workFlowLevel.getApplicationId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = workFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        WorkFlowLevel latestWorkFlow = workFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1001) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            workFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            workFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
//        workFlowLevel.setStatus(workFlowMaster.getStatus());
            workFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            workFlowLevel.setStatus("Forwarded from Back Office");
            workFlowLevel.setMailStatus(1);
            workFlowLevel.setCreatedDate(LocalDateTime.now());

            updateApprovedStatus(workFlowLevel.getApplicationId().getId());
            return workFlowLevelRepository.save(workFlowLevel);

        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private WorkFlowLevel forwardFromCitizen(WorkFlowLevel workFlowLevel) {

        Long applicationId = workFlowLevel.getApplicationId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = workFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        WorkFlowLevel latestWorkFlow = workFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1004) {
//            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(latestWorkFlow.getWorkFlowMasterId().getId())
//                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            workFlowLevel.setNextUserId(latestWorkFlow.getCurrentUserId());
            workFlowLevel.setCurrentUserId(latestWorkFlow.getNextUserId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            // Set the status from WorkFlowMaster to WorkFlow
//        workFlowLevel.setStatus(workFlowMaster.getStatus());
            workFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            workFlowLevel.setStatus("Forwarded from Citizen");
            workFlowLevel.setMailStatus(1);
            workFlowLevel.setCreatedDate(LocalDateTime.now());

            updateApprovedStatus(workFlowLevel.getApplicationId().getId());
            return workFlowLevelRepository.save(workFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    @Override
    public List<RemarksDto> getRemarksByApplicationId(Long applicationId) {
        return workFlowLevelRepository.findByApplicationId_Id(applicationId).stream()
                .filter(level -> level.getRemarks() != null)
                .sorted(Comparator.comparing(WorkFlowLevel::getCreatedDate))
                .map(level -> new RemarksDto(
                        level.getRemarks(),
                        level.getCreatedDate(),
                        level.getCurrentUserId() != null ? level.getCurrentUserId().getRoleMaster().getRoleName(): "UNKNOWN",
                        level.getCurrentUserId() != null ? level.getCurrentUserId().getNameOfUser(): "UNKNOWN",
                        level.getNextUserId() != null ? level.getNextUserId().getRoleMaster().getRoleName(): "UNKNOWN",
                        level.getNextUserId() != null ? level.getNextUserId().getNameOfUser(): "UNKNOWN"
                ))
                .collect(Collectors.toList());
    }
}


