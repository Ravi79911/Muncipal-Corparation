package com.ahmednagar.municipal.forms.formsWaterManagement.model;

import com.ahmednagar.municipal.master.waterManagement.modal.*;
import jakarta.persistence.*;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbls_consumer_property_details")
public class ConsumerPropertyDetails {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "id")
        private int id;

//        @NotNull(message = "Application ID cannot be null")
//        @Column(name = "appmas_id", nullable = false)
//        private int appmasId;

        @NotNull(message = "Zone ID cannot be null")
        @Column(name = "zone_id", nullable = false)
        private int zoneId;

        @NotNull(message = "Ward ID cannot be null")
        @Column(name = "ward_id", nullable = false)
        private int wardId;

        @Size(max = 50, message = "Holding number cannot exceed 50 characters")
        @Column(name = "holding_no", nullable = false)
        private String holdingNo;

        @Size(max = 50, message = "Khata number cannot exceed 50 characters")
        @Column(name = "khata_no", nullable = false)
        private String khataNo;

        @Size(max = 50, message = "Plot number cannot exceed 50 characters")
        @Column(name = "plot_no", nullable = false)
        private String plotNo;

//        @NotNull(message = "Usage type ID cannot be null")
//        @Column(name = "uses_type_id", nullable = false)
//        private int usesTypeId;

        @Digits(integer = 18, fraction = 2, message = "Length area must be a valid decimal number")
        @Column(name = "length_area", nullable = false)
        private BigDecimal lengthArea;

        @Digits(integer = 18, fraction = 2, message = "Breath area must be a valid decimal number")
        @Column(name = "breath_area", nullable = false)
        private BigDecimal breathArea;

        @Digits(integer = 18, fraction = 2, message = "Buildup area in square feet must be a valid decimal number")
        @Column(name = "buildup_area_sqft", nullable = false)
        private BigDecimal buildupAreaSqft;

        @Digits(integer = 18, fraction = 2, message = "Buildup area in square meters must be a valid decimal number")
        @Column(name = "buildup_area_sqmtr", nullable = false)
        private BigDecimal buildupAreaSqmtr;

//        @NotNull(message = "Area ID cannot be null")
//        @Column(name = "sub_uses_type_id", nullable = false)
//        private int subUsesTypeId;

        @NotNull(message = "Number of flats cannot be null")
        @Column(name = "nosOfFlats", nullable = false)
        private int nosOfFlats;

//        @Size(max = 1000, message = "Address cannot exceed 1000 characters")
//        @Column(name = "address", nullable = false)
//        private String address;

//        @NotNull(message = "Ownership type ID cannot be null")
//        @Column(name = "ownership_type_id", nullable = false)
//        private int ownershipTypeId;

        @NotNull(message = "Property master ID cannot be null")
        @Column(name = "property_mas_id", nullable = false)
        private int propertyMasId;

        @NotNull(message = "Created by cannot be null")
        @Column(name = "created_by", nullable = false)
        private int createdBy;

//        @NotNull(message = "Created date cannot be null")
        @Column(name = "created_date", nullable = false)
        private LocalDateTime createdDate;

        @NotNull(message = "Suspended status cannot be null")
        @Column(name = "suspended_status", nullable = false)
        private Integer suspendedStatus;

        @NotNull(message = "Municipal ID cannot be null")
        @Column(name = "municipal_id", nullable = false)
        private int municipalId;

        // Newly added fields
        @Size(max = 500, message = "Property address cannot exceed 500 characters")
        @Column(name = "property_address", nullable = false)
        private String propertyAddress;

        @Size(max = 50, message = "City cannot exceed 50 characters")
        @Column(name = "city", nullable = false)
        private String city;

        @Size(max = 50, message = "District cannot exceed 50 characters")
        @Column(name = "district", nullable = false)
        private String district;

        @Size(max = 50, message = "State cannot exceed 50 characters")
        @Column(name = "state", nullable = false)
        private String state;

        @Digits(integer = 6, fraction = 0, message = "Pincode must be a 6-digit number")
        @Column(name = "pincode", nullable = false)
        private long pincode;

        @Size(max = 100, message = "Landmark cannot exceed 100 characters")
        @Column(name = "landmark", nullable = false)
        private String landmark;

        @ManyToOne
        @JoinColumn(name = "appmas_id", referencedColumnName = "id", nullable = false)
        private NewConnectionFormShubham newConnectionFormId;

//        @ManyToOne
//        @JoinColumn(name = "area_id", referencedColumnName = "id", nullable = false)
//        private BuildupAreaMasters buildupAreaMastersId;

        @ManyToOne
        @JoinColumn(name = "ownership_type_id", referencedColumnName = "id", nullable = false)
        private OwnershipType ownershipTypeId;

        @ManyToOne
        @JoinColumn(name="sub_uses_type_id", referencedColumnName = "id",nullable = false)
        private DDWaterPropertySubCategoryUsesType waterPropertySubCategoryUsesType_ddMasterId;

        @ManyToOne
        @JoinColumn(name="uses_type_id", referencedColumnName = "id",nullable = false)
        private DDWaterPropertyUsesType waterPropertyUsesType_ddMasterId;

        @ManyToOne
        @JoinColumn(name="roadtype_id", referencedColumnName = "id",nullable = false)
        private DDWaterRoadType waterRoadType_ddMasterId;

}
