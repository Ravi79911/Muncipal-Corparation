package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationLicenseDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface ApplicationLicenseDetailsRepository extends JpaRepository<ApplicationLicenseDetails, Long> {

    List<ApplicationLicenseDetails> findBySuspendedStatus(Integer status);

    List<ApplicationLicenseDetails> findByMunicipalId(Long municipalId);

    Optional<ApplicationLicenseDetails> findByLicenseNo(String LicenseNo);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM tbl2_application_license_details WHERE application_master_id = :applicationMasterId", nativeQuery = true)
    void deleteApplicationLicenseDetailsByApplicationMasterId(@Param("applicationMasterId") Long ApplicationFromMaster);

}
