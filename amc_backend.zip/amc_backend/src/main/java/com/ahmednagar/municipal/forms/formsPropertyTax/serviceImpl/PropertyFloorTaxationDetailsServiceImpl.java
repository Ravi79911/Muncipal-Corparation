package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.dto.PropertyFloorTaxationDetailsDto;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyFloorTaxationDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyFloorTaxationDetailsRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyFloorTaxationDetailsService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PropertyFloorTaxationDetailsServiceImpl implements PropertyFloorTaxationDetailsService {

    @Autowired
    PropertyFloorTaxationDetailsRepository propertyFloorTaxationDetailsRepository;

    @Autowired
    ModelMapper modelMapper;

    @Override
    public PropertyFloorTaxationDetails createPropertyFloorTaxationDetails(PropertyFloorTaxationDetails propertyFloorTaxationDetails) {
        if (propertyFloorTaxationDetails.getSuspendedStatus() == null) {
            propertyFloorTaxationDetails.setSuspendedStatus(0);
        }
        propertyFloorTaxationDetails.setCreatedDate(LocalDateTime.now());
        return propertyFloorTaxationDetailsRepository.saveAndFlush(propertyFloorTaxationDetails);
    }

    @Override
    public PropertyFloorTaxationDetails findPropertyFloorTaxationDetailsById(Long id) {
        Optional<PropertyFloorTaxationDetails> propertyFloorTaxationDetails = propertyFloorTaxationDetailsRepository.findById(id);
        return propertyFloorTaxationDetails.orElse(null);
    }

    @Override
    public List<PropertyFloorTaxationDetailsDto> findAllPropertyFloorTaxationDetailsByMunicipalId(int municipalId) {
        List<PropertyFloorTaxationDetails> propertyFloorTaxationDetails = propertyFloorTaxationDetailsRepository.findByMunicipalId(municipalId);
        return propertyFloorTaxationDetails.stream()
                .map(propertyFloorTaxationDetail -> modelMapper.map(propertyFloorTaxationDetail, PropertyFloorTaxationDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public PropertyFloorTaxationDetails updatePropertyFloorTaxationDetails(Long id, PropertyFloorTaxationDetails updatedPropertyFloorTaxationDetails, int updatedBy) {
        Optional<PropertyFloorTaxationDetails> propertyFloorTaxationDetailsOptional = propertyFloorTaxationDetailsRepository.findById(id);
        if (propertyFloorTaxationDetailsOptional.isPresent()) {
            PropertyFloorTaxationDetails existingPropertyFloorTaxationDetails = propertyFloorTaxationDetailsOptional.get();
            existingPropertyFloorTaxationDetails.setSuspendedStatus(updatedPropertyFloorTaxationDetails.getSuspendedStatus());
            existingPropertyFloorTaxationDetails.setMunicipalId(updatedPropertyFloorTaxationDetails.getMunicipalId());

            return propertyFloorTaxationDetailsRepository.saveAndFlush(existingPropertyFloorTaxationDetails);
        } else {
            throw new RuntimeException("property floor taxation details not found with id: " + id);
        }
    }

    @Override
    public PropertyFloorTaxationDetails changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<PropertyFloorTaxationDetails> propertyFloorTaxationDetailsOptional = propertyFloorTaxationDetailsRepository.findById(id);
        if (propertyFloorTaxationDetailsOptional.isPresent()) {
            PropertyFloorTaxationDetails propertyFloorTaxationDetails = propertyFloorTaxationDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            propertyFloorTaxationDetails.setSuspendedStatus(status);
            return propertyFloorTaxationDetailsRepository.saveAndFlush(propertyFloorTaxationDetails);
        }
        return null;
    }

}
