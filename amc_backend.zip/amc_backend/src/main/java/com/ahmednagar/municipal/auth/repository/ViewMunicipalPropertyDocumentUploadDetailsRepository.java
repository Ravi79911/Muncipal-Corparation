package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.ViewMunicipalPropertyDocumentUploadDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface ViewMunicipalPropertyDocumentUploadDetailsRepository extends JpaRepository<ViewMunicipalPropertyDocumentUploadDetails,Long> {

    List<ViewMunicipalPropertyDocumentUploadDetails> findByViewMunicipalPropertyMaster_Id(Long id);
}
