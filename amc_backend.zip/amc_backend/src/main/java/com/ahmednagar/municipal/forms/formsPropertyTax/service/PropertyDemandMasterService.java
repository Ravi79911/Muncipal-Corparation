package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface PropertyDemandMasterService {

    // single entity creation
    PropertyDemandMaster createPropertyDemandMaster(PropertyDemandMaster propertyDemandMaster);

    // list of entity creation
    List<PropertyDemandMaster> createPropertyDemandMasterList(List<PropertyDemandMaster> propertyDemandMasterList);

    List<PropertyDemandMaster> getAllPropertyDemandMaster();

    Optional<PropertyDemandMaster> getPropertyDemandMasterById(Long id);

    List<PropertyDemandMaster> getPropertyDemandMasterByMunicipalId(int municipalId);

    PropertyDemandMaster patchPropertyDemandMasterSuspendedStatus(Long id, int suspendedStatus);

}
