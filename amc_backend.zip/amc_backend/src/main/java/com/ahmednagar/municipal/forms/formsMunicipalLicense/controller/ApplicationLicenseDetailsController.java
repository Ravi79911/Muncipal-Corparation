package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationLicenseDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationLicenseDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationLicenseDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/license/forms/ApplicationLicenseDetails")
public class ApplicationLicenseDetailsController {

    @Autowired
    private ApplicationLicenseDetailsService applicationLicenseDetailsService;

    //create AppApplicantDetails
    @PostMapping("/create")
    public ResponseEntity<ApplicationLicenseDetails> createApplicationLicenseDetails(@Valid @RequestBody ApplicationLicenseDetails applicationLicenseDetails, @RequestParam int createdBy) {
        ApplicationLicenseDetails createdApplicationLicenseDetails = applicationLicenseDetailsService.saveApplicationLicenseDetails(applicationLicenseDetails, 1);
        if (createdApplicationLicenseDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdApplicationLicenseDetails);
    }

    //  to get the Application Details by id for user
    @GetMapping("/get/{id}")
    public ResponseEntity<ApplicationLicenseDetails> getApplicationLicenseDetailsById(@PathVariable Long id) {
        ApplicationLicenseDetails applicationLicenseDetails = applicationLicenseDetailsService.findApplicationLicenseDetailsById(id);
        return ResponseEntity.ok(applicationLicenseDetails);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllApplicationLicenseDetailsByMunicipalId(@PathVariable Long municipalId) {
        List<ApplicationLicenseDetailsDto> applicationLicenseDetails = applicationLicenseDetailsService.findAllApplicationLicenseDetailsByMunicipalId(municipalId);
        if (applicationLicenseDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No ApplicationLicenseDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(applicationLicenseDetails);
    }

    //get Application Fee Pay By prevLicenseNo
    @GetMapping("/Municipal/LicenseNo")
    public ResponseEntity<?> getAllApplicationLicenseDetailsByPrevLicenseNo(@RequestParam String LicenseNo) {
        //ApplicationLicenseDetailsService renewalSurrenderAmendmentAppliedDetailsService;
        List<ApplicationLicenseDetailsDto> applicationLicenseDetails = applicationLicenseDetailsService.findAllApplicationLicenseDetailsByLicenseNo(LicenseNo);
        if (applicationLicenseDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No ApplicationLicenseDetails found with prevLicenseNo : " + LicenseNo);
        }
        return ResponseEntity.ok(applicationLicenseDetails);
    }

    //     Update AppApplication Details From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<ApplicationLicenseDetails> updateApplicationLicenseDetails(@PathVariable("id") Long id, @RequestBody ApplicationLicenseDetails updatedApplicationLicenseDetails) {
        try {
            ApplicationLicenseDetails updated = applicationLicenseDetailsService.updateApplicationLicenseDetails(id, updatedApplicationLicenseDetails, 1);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete AppApplication Details for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<ApplicationLicenseDetails> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        ApplicationLicenseDetails updatedApplicationLicenseDetails = applicationLicenseDetailsService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedApplicationLicenseDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedApplicationLicenseDetails);
    }

}
