package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.UserPasswordChangeHistoryDto;
import com.ahmednagar.municipal.auth.model.UserPasswordChangeHistory;
import com.ahmednagar.municipal.auth.repository.UserPasswordChangeHistoryRepository;
import com.ahmednagar.municipal.auth.service.UserPasswordChangeHistoryService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserPasswordChangeHistoryServiceImpl implements UserPasswordChangeHistoryService {
    @Autowired
    private UserPasswordChangeHistoryRepository userPasswordChangeHistoryRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public UserPasswordChangeHistory savedUserPasswordChangeHistory(UserPasswordChangeHistory userPasswordChangeHistory) {
        userPasswordChangeHistory.setCreatedDate(LocalDateTime.now());
        userPasswordChangeHistory.setUpdatedDate(LocalDateTime.now());
        userPasswordChangeHistory.setPwdChangedDateTime(LocalDateTime.now());
        userPasswordChangeHistory.setUpdatedBy(userPasswordChangeHistory.getUpdatedBy() != null ? userPasswordChangeHistory.getUpdatedBy() : 0);
        userPasswordChangeHistory.setSuspendedStatus(userPasswordChangeHistory.getSuspendedStatus() != null ? userPasswordChangeHistory.getSuspendedStatus() : 0);

        return userPasswordChangeHistoryRepository.save(userPasswordChangeHistory);

    }

    @Override
    public List<UserPasswordChangeHistoryDto> findAllUserPasswordChangeHistory() {
        List<UserPasswordChangeHistory> userPasswordChangeHistories = userPasswordChangeHistoryRepository.findAll();
        return userPasswordChangeHistories.stream()
                .map(userPasswordChangeHistory -> modelMapper.map(userPasswordChangeHistory, UserPasswordChangeHistoryDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<UserPasswordChangeHistoryDto> findAllUserPasswordChangeHistoryByMunicipalId(Long municipalId) {
        List<UserPasswordChangeHistory> userPasswordChangeHistories = userPasswordChangeHistoryRepository.findByMunicipalId(municipalId);
        return userPasswordChangeHistories.stream()
                .map(userPasswordChangeHistory -> modelMapper.map(userPasswordChangeHistory, UserPasswordChangeHistoryDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public UserPasswordChangeHistory updateUserPasswordChangeHistory(Long id, UserPasswordChangeHistory updatedUserPasswordChangeHistory) {
        Optional<UserPasswordChangeHistory> userPasswordChangeHistoryOptional = userPasswordChangeHistoryRepository.findById(id);
        if (userPasswordChangeHistoryOptional.isPresent()) {
            UserPasswordChangeHistory existingUserPasswordChangeHistory = userPasswordChangeHistoryOptional.get();
            existingUserPasswordChangeHistory.setUpdatedBy(updatedUserPasswordChangeHistory.getUpdatedBy());
            existingUserPasswordChangeHistory.setUpdatedDate(LocalDateTime.now());
            if (existingUserPasswordChangeHistory.getSuspendedStatus() == null) {
                existingUserPasswordChangeHistory.setSuspendedStatus(0);
            }
            //existingUserPasswordChangeHistory.setSuspendedStatus(updatedUserPasswordChangeHistory.getSuspendedStatus());
            existingUserPasswordChangeHistory.setMunicipalId(updatedUserPasswordChangeHistory.getMunicipalId());

            return userPasswordChangeHistoryRepository.saveAndFlush(existingUserPasswordChangeHistory);
        } else {
            throw new RuntimeException("UserPasswordChangeHistory type not found with id: " + id);
        }
    }
    @Override
    public UserPasswordChangeHistory changeStatus(Long id, Integer status) {
        Optional<UserPasswordChangeHistory> userPasswordChangeHistoryOpt = userPasswordChangeHistoryRepository.findById(id);
        if (userPasswordChangeHistoryOpt.isPresent()) {
            UserPasswordChangeHistory userPasswordChangeHistory = userPasswordChangeHistoryOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            userPasswordChangeHistory.setUpdatedDate(currentDateTime);
            userPasswordChangeHistory.setSuspendedStatus(status);      // 1 means suspended
            userPasswordChangeHistory.setUpdatedBy(userPasswordChangeHistory.getUpdatedBy());
            return userPasswordChangeHistoryRepository.saveAndFlush(userPasswordChangeHistory);
        }
        return null;
    }
}
