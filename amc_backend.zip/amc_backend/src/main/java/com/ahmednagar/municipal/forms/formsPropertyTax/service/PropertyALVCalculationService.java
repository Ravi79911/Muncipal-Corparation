package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyALVCalculation;
import org.springframework.stereotype.Service;

@Service
public interface PropertyALVCalculationService {

    PropertyALVCalculation calculatePropertyALV(PropertyALVCalculation propertyALVCalculation);

}
