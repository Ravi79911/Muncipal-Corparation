package com.ahmednagar.municipal.forms.formsMunicipalLicense.model;

import com.ahmednagar.municipal.master.municipalLicence.model.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_application_from_master")
public class ApplicationFromMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

//    @Column(name = "applied_fy_year_id")
//    @NotNull(message = "Applied FY Year is required")
//    private int appliedFyYearId;

    @Column(name = "application_no")
    private String applicationNo;

    @Column(name = "application_applied_from")
    @NotNull(message = "Application Applied From is required")
    @Size(max = 50, message = "Application Applied From cannot exceed 50 characters")
    private String applicationAppliedFrom;

    @Column(name = "application_date")
    @NotNull(message = "Application Date is required")
    private LocalDateTime applicationDate;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "application_type_id", nullable = false, referencedColumnName = "id")
    private TradeApplicationType applicationTypeId;

    @ManyToOne
    @JoinColumn(name = "firm_type_id", nullable = false)
    private MlFirmType firmTypeId;

    @ManyToOne
    @JoinColumn(name = "permisses_ownership_id", nullable = false)
    private MlBusinessPremises permissesOwnershipId;

    @ManyToOne
    @JoinColumn(name = "business_cat_id", nullable = false, referencedColumnName = "id")
    private MlTradeType businessCatId;

    @ManyToOne
    @JoinColumn(name = "nature_of_business_id", nullable = false, referencedColumnName = "id")
    private MlBusinessNature natureOfBusinessId;

    @OneToMany(mappedBy = "applicationMasterId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<AppApplicantDetails> appApplicantDetails;

    @OneToMany(mappedBy = "applicationMasterId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<ApplicationDocumentsDetails> applicationDocumentsDetails;

    @OneToMany(mappedBy = "applicationMasterId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<ApplicationElectricityDetails> applicationElectricityDetails;

    @OneToMany(mappedBy = "applicationMasterId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<ApplicationFeePayMaster> applicationFeePayMasters;

    @OneToMany(mappedBy = "applicationMasterId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<ApplicationFirmDetails> applicationFirmDetails;

    @OneToMany(mappedBy = "applicationMasterId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<ApplicationLicenseDetails> applicationLicenseDetails;

    @OneToMany(mappedBy = "applicationMasterId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<ApplicationPermisesDetails> applicationPermisesDetails;

    @OneToMany(mappedBy = "applicationMasterId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<RenewalSurrenderAmendmentAppliedDetails> renewalSurrenderAmendmentAppliedDetails;

    @ManyToOne
    @JoinColumn(name = "applied_fy_year_id", nullable = false)
    private LicenseFinancialYearMaster licenseFinancialYearMasterId ;

}
