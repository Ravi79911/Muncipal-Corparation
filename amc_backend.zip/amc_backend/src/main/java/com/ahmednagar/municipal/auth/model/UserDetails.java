package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbl_user_details")
public class UserDetails {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "id")
        private Long id;

        @NotNull(message = "User Master ID cannot be null")
        @Column(name = "usermas_id", nullable = false)
        private int usermasId;

        @NotNull(message = "Zone ID cannot be null")
        @Min(value = 1, message = "Zone ID must be a positive number")
        @Column(name = "zone_id", nullable = false)
        private Long zoneId;

        @NotNull(message = "Ward ID cannot be null")
        @Min(value = 1, message = "Ward ID must be a positive number")
        @Column(name = "ward_id", nullable = false)
        private Long wardId;

        @Min(value = 1, message = "Updated By must be a positive number")
        @Column(name = "created_by", nullable = false)
        private int createdBy;

        @NotNull(message = "Created Date cannot be null")
        @PastOrPresent(message = "Created Date cannot be in the future")
        @Column(name = "created_date")
        private LocalDateTime createdDate;

        @Min(value = 1, message = "Updated By must be a positive number")
        @Column(name = "updated_by", nullable = false)
        private Integer updatedBy;

        @NotNull(message = "Updated Date cannot be null")
        @PastOrPresent(message = "Updated Date cannot be in the future")
        @Column(name = "updated_date")
        private LocalDateTime updatedDate;

        @NotNull(message = "Suspended Status cannot be null")
        @Column(name = "suspended_status", nullable = false)
        private Integer suspendedStatus;

        @NotNull(message = "Municipal ID cannot be null")
        @Min(value = 1, message = "Municipal ID must be a positive number")
        @Column(name = "municipal_id", nullable = false)
        private Long municipalId;

        @OneToMany(mappedBy = "userId",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
        @JsonIgnore
        private Set<UserLoginLogoffHistory> userLoginLogoffHistories;

        @OneToMany(mappedBy = "userId",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
        @JsonIgnore
        private Set<UserPasswordChangeHistory> userPasswordChangeHistories;

}
