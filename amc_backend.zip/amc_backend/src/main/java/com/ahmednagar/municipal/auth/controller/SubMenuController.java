package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.SubMenuDto;
import com.ahmednagar.municipal.auth.model.SubMenu;
import com.ahmednagar.municipal.auth.service.SubMenuService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class SubMenuController {
    @Autowired
    private SubMenuService subMenuService;

    //create sub menu
    @PostMapping("/createSubMenu")
    public ResponseEntity<SubMenu> createRole(@Valid @RequestBody SubMenu subMenu){
        SubMenu createdSubMenu=subMenuService.saveSubMenu(subMenu);
        if(createdSubMenu==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdSubMenu);
    }
    //for all admin users
    @GetMapping("/allSubMenu")
    public ResponseEntity<List<SubMenuDto>> getAllSubMenu(){
        List<SubMenuDto> subMenu=subMenuService.findAllSubMenu();
        return ResponseEntity.ok(subMenu);
    }

    //get sub menu By MunicipalId
    @GetMapping("/MunicipalSubMenu/{municipalId}")
    public ResponseEntity<?> getAllSubMenuByMunicipalId(@PathVariable Long municipalId){
        List<SubMenuDto> subMenu=subMenuService.findAllSubMenuByMunicipalId(municipalId);
        if (subMenu.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No subMenu found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(subMenu);
    }

    //     Update sub menu for admin
    @PutMapping("/updatedSubMenu/{id}")
    public ResponseEntity<SubMenu> updateSubMenu(@PathVariable("id") Long id, @RequestBody SubMenu updatedSubMenu){
        try{
            SubMenu updated=subMenuService.updateSubMenu(id,updatedSubMenu);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete submenu for admin
    @PatchMapping("/deleteSubMenu/{id}")
    public ResponseEntity<SubMenu> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        SubMenu updatedSubMenu = subMenuService.changeSuspendedStatus(id, status);         // updatedBy is always 1 for now as it is the admin
        if (updatedSubMenu== null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedSubMenu);
    }

}

