package com.ahmednagar.municipal.forms.formsMunicipalLicense.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb3_license_application_workflow")
public class LicenseApplicationWorkflow {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @NotNull(message = "Document Uploaded value cannot be null")
    @Column(name = "document_uploaded")
    private boolean documentUploaded;

    @NotNull(message = "Current Stage cannot be null")
    @Size(max = 255, message = "Current Stage cannot exceed 255 characters")
    @Column(name = "current_stage")
    private String currentStage;

    @NotNull(message = "Status cannot be null")
    @Size(max = 255, message = "Status cannot exceed 255 characters")
    @Column(name = "status")
    private String status;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private Long municipalId;

    @OneToMany(mappedBy = "applicationWorkflowId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<LicenseWorkflowHistory> licenseWorkflowHistories;

    @OneToMany(mappedBy = "applicationWorkflowId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<LicenseApplicationAutoTransfer> licenseApplicationAutoTransfers;

    @ManyToOne
    @JoinColumn(name = "stage_id",nullable = false,referencedColumnName = "id")
    private LicenseLabelStage stageId;
}
