package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "Tbl_user_ward_allotment")
public class VendorUserWardAllotment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "zone_no", nullable = false)
    private String zoneNo;

    @Column(name = "ward_no", nullable = false)
    private String wardNo;

    @Column(name = "municipal_id")
    private Long municipalId;

    @Column(name = "created_by", nullable = false)
    private Long createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "user_ids", referencedColumnName = "id", nullable = false)
    private VendorUser vendorUserMasId;

}