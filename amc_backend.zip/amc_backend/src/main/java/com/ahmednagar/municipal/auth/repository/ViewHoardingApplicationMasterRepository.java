package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.ViewHoardingApplicationMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

@Service
public interface ViewHoardingApplicationMasterRepository extends JpaRepository<ViewHoardingApplicationMaster,Long> {
}
