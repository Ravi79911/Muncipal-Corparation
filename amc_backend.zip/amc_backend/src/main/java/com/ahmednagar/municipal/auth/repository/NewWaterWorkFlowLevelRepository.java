package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.NewLicenseWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.NewWaterWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.ViewNewWaterConnectionFormMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface NewWaterWorkFlowLevelRepository extends JpaRepository<NewWaterWorkFlowLevel,Long> {
    List<NewWaterWorkFlowLevel> findByWaterApplicationId(ViewNewWaterConnectionFormMaster waterApplicationId);

    @Query(value = "SELECT TOP 1 * FROM tbl_new_water_work_flow_level WHERE water_application_id = :waterApplicationId AND status_code = :statusCode ORDER BY created_date DESC", nativeQuery = true)
    Optional<NewWaterWorkFlowLevel> findLatestWorkFlowByApplicationIdAndStatusCode(@Param("waterApplicationId") Long applicationId, @Param("statusCode") Long statusCode);

}
