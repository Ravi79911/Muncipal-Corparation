package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.DDWorkFlowMasterDto;
import com.ahmednagar.municipal.auth.service.DDWorkFlowMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("dd/work/flow/master")
public class DDWorkFlowMasterController {

    @Autowired
    private DDWorkFlowMasterService ddWorkFlowMasterService;

    @GetMapping("/all")
    public ResponseEntity<List<DDWorkFlowMasterDto>> getAllDDWorkFlowMaster(){
        List<DDWorkFlowMasterDto> ddWorkFlowMaster=ddWorkFlowMasterService.findAllDDWorkFlowMaster();
        return ResponseEntity.ok(ddWorkFlowMaster);
    }
}
