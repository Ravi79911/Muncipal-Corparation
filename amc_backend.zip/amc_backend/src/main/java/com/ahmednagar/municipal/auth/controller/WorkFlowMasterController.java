package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.WorkFlowMaster;
import com.ahmednagar.municipal.auth.service.WorkFlowMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@CrossOrigin
@RequestMapping("/work/flow/master")
public class WorkFlowMasterController {

    @Autowired
    private WorkFlowMasterService workFlowMasterService;

    //for create new user
    @PostMapping("/create")
    public ResponseEntity<WorkFlowMaster> createWorkFlowMaster(@Valid @RequestBody WorkFlowMaster workFlowMaster){
        WorkFlowMaster savedWorkFlowMaster=workFlowMasterService.saveWorkFlowMaster(workFlowMaster);
        return ResponseEntity.status(201).body(savedWorkFlowMaster);

    }
    //for single user by Id
    @GetMapping("/getWorkFlowMasterById/{id}")
    public ResponseEntity<WorkFlowMaster> getWorkFlowMasterById(@PathVariable Long id){
        WorkFlowMaster workFlowMaster=workFlowMasterService.findById(id);
        return ResponseEntity.ok(workFlowMaster);

    }
}


