package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.LicenseWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.model.LicenseWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.WorkFlowLevel;
import com.ahmednagar.municipal.auth.service.LicenseWorkFlowLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/license/work/flow/level")
public class LicenseWorkFlowLevelController {

    @Autowired
    private LicenseWorkFlowLevelService licenseWorkFlowLevelService;

    // Endpoint to handle workflow transitions
    @PostMapping("/transition")
    public ResponseEntity<LicenseWorkFlowLevel> handleWorkFlowTransition(@RequestBody LicenseWorkFlowLevel licenseWorkFlowLevel) {
        LicenseWorkFlowLevel updatedLicenseWorkFlowLevel = licenseWorkFlowLevelService.handleWorkFlowTransition(licenseWorkFlowLevel);
        return ResponseEntity.ok(updatedLicenseWorkFlowLevel);
    }

    //for admin all users
    @GetMapping("/all")
    public ResponseEntity<List<LicenseWorkFlowLevelDto>> getAllWorkFlow() {
        List<LicenseWorkFlowLevelDto> workFlow = licenseWorkFlowLevelService.findAllWorkFlow();
        return ResponseEntity.ok(workFlow);
    }

    @PostMapping("/new-application")
    public ResponseEntity<LicenseWorkFlowLevel> createNewLicenseWorkflow(@RequestBody LicenseWorkFlowLevel workFlowRequest) {
        LicenseWorkFlowLevel savedWorkflow = licenseWorkFlowLevelService.createNewApplicationTransation(workFlowRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedWorkflow);
    }

    @GetMapping("/getAllRemarks/{applicationId}")
    public ResponseEntity<List<RemarksDto>> getRemarksByApplicationId(@RequestParam Long applicationId) {
        List<RemarksDto> remarks = licenseWorkFlowLevelService.getRemarksByApplicationId(applicationId);
        return ResponseEntity.ok(remarks);
    }

}
