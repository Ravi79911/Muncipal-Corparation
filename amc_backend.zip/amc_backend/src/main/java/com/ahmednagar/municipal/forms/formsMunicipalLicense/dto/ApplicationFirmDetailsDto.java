package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ApplicationFirmDetailsDto {

    private Long id;
    private Long adharNumber;
    private ApplicationFromMasterDto applicationMasterId;
    private String wardNo;
    private String zoneNo;
    private String firmName;
    private Date firmEstdDate;
//    private int totalCarpetAreaSqft;
//    private int totalCarpetAreaSqMtr;
    private int totalBuildupAreaOfBusiness;
    //private int totalBuildupAreaSqMtr;
    private int propertyNo;
    private Long businessContactNumber;
    private String panNumber;
    private String tanNumber;
    private String gstNumber;
    private String businessAddressLine1;
    private String businessAddressLine2;
    private String businessCity;
    private String businessState;
    private String businessPincode;
    private String landmark;
    private String businessDescription;
    private int noOfWorkers;
    private boolean dangerousTypeFlag;
    private String tradeType;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;

}
