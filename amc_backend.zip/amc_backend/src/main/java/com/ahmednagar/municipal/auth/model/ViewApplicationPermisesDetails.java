package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl2_view_application_permises_details")
public class ViewApplicationPermisesDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    @NotNull(message = "ID is required")
    private int id;

    @Column(name = "permisses_ownership_id")
    @NotNull(message = "Premises Ownership ID is required")
    private int permissesOwnershipId;

    @Column(name = "rent_agreement_date")
    //@NotNull(message = "Rent Agreement Date is required")
    private LocalDateTime rentAgreementDate;

    @Column(name = "agreement_no")
    //@NotNull(message = "Agreement Number is required")
    @Size(max = 150, message = "Agreement Number cannot exceed 150 characters")
    private String agreementNo;

    @Column(name = "agreement_valid_from")
    //@NotNull(message = "Agreement Valid From Date is required")
    private Date agreementValidFrom;

    @Column(name = "agreement_valid_upto")
    //@NotNull(message = "Agreement Valid Upto Date is required")
    private Date agreementValidUpto;

    @Column(name = "agreement_between_first_party_name")
    //@NotNull(message = "First Party Name is required")
    @Size(max = 150, message = "First Party Name cannot exceed 150 characters")
    private String agreementBetweenFirstPartyName;

    @Column(name = "agreement_between_second_party_name")
    //@NotNull(message = "Second Party Name is required")
    @Size(max = 150, message = "Second Party Name cannot exceed 150 characters")
    private String agreementBetweenSecondPartyName;

    @Column(name = "holding_property_no")
    @NotNull(message = "Holding Property Number is required")
    @Size(max = 150, message = "Holding Property Number cannot exceed 150 characters")
    private String holdingPropertyNo;

    @Column(name = "lease_rented_period")
    //@NotNull(message = "Lease/Rented Period is required")
    @Size(max = 150, message = "Lease/Rented Period cannot exceed 150 characters")
    private String leaseRentedPeriod;

    @Column(name = "created_by")
    @NotNull(message = "Created By is required")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @Column(name = "municipal_id")
    @NotNull(message = "Municipal ID is required")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "application_master_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewApplicationFromMaster viewApplicationFromMaster;

}
