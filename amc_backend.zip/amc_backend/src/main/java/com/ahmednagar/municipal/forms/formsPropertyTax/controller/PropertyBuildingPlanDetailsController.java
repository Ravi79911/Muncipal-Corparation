package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyBuildingPlanDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyBuildingPlanDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/forms")
public class PropertyBuildingPlanDetailsController {

    @Autowired
    PropertyBuildingPlanDetailsService propertyBuildingPlanDetailsService;

    @PostMapping("/createPropertyBuildingPlanDetails")
    public ResponseEntity<PropertyBuildingPlanDetails> createPropertyBuildingPlan(@Valid @RequestBody PropertyBuildingPlanDetails propertyBuildingPlanDetails) {
        PropertyBuildingPlanDetails newPropertyBuildingPlan = propertyBuildingPlanDetailsService.createPropertyBuildingPlanDetails(propertyBuildingPlanDetails);
        return ResponseEntity.ok(newPropertyBuildingPlan);
    }

    @GetMapping("/getAllPropertyBuildingPlanDetails")
    public ResponseEntity<List<PropertyBuildingPlanDetails>> getAllPropertyBuildingPlan() {
        return ResponseEntity.ok(propertyBuildingPlanDetailsService.getAllPropertyBuildingPlanDetails());
    }

    @GetMapping("/propertyBuildingPlanDetails/{id}")
    public ResponseEntity<Object> getPropertyBuildingPlanById(@PathVariable Long id) {
        Optional<PropertyBuildingPlanDetails> propertyBuildingPlan = propertyBuildingPlanDetailsService.getPropertyBuildingPlanDetailsById(id);
        if (propertyBuildingPlan.isPresent()) {
            return ResponseEntity.ok(propertyBuildingPlan.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getPropertyBuildingPlanByMunicipalId/{municipalId}")
    public List<PropertyBuildingPlanDetails> getPropertyBuildingPlanByMunicipalId(@PathVariable int municipalId) {
        return propertyBuildingPlanDetailsService.getPropertyBuildingPlanDetailsByMunicipalId(municipalId);
    }

    @PatchMapping("/propertyBuildingPlanDetails/suspendedStatus/{id}")
    public ResponseEntity<PropertyBuildingPlanDetails> patchPropertyBuildingPlanSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        PropertyBuildingPlanDetails patchedPropertyBuildingPlanDetails = propertyBuildingPlanDetailsService.patchPropertyBuildingPlanDetailsSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedPropertyBuildingPlanDetails);
    }

    @PutMapping("/updatePropertyBuildingPlanDetailsById/{id}")
    public ResponseEntity<ApiResponse> updatePropertyBuildingPlanDetailsById(@PathVariable Long id,
                                                                             @RequestBody PropertyBuildingPlanDetails propertyBuildingPlanDetails) {
        try {
            if (propertyBuildingPlanDetails.getUpdatedBy() == null) {
                return new ResponseEntity<>(new ApiResponse("updated by is mandatory and can't be null", false), HttpStatus.BAD_REQUEST);
            }
            PropertyBuildingPlanDetails updatedDetails = propertyBuildingPlanDetailsService.updatePropertyBuildingPlanDetailsById(id, propertyBuildingPlanDetails);
            return ResponseEntity.ok(new ApiResponse("Property Building Plan Details updated successfully!", true, updatedDetails));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An internal error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/deletePropertyBuildingPlanDetails/{municipalPropertyMasterId}")
    public ResponseEntity<String> deletePropertyBuildingPlanDetails(@PathVariable Long municipalPropertyMasterId) {
        try {
            propertyBuildingPlanDetailsService.deletePropertyBuildingPlanDetailsByMunicipalPropertyMasterId(municipalPropertyMasterId);
            return ResponseEntity.ok("PropertyBuildingPlanDetails details records deleted successfully for MunicipalPropertyMaster id: " + municipalPropertyMasterId);
        } catch (Exception ex) {
            return ResponseEntity.status(500).body("An unexpected error occurred: " + ex.getMessage());
        }
    }

}
