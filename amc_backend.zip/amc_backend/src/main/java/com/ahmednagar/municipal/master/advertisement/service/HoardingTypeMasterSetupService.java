package com.ahmednagar.municipal.master.advertisement.service;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingTypeMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeMasterSetup;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingTypeMasterSetupService {
    HoardingTypeMasterSetup saveHoardingTypeMasterSetup(HoardingTypeMasterSetup hoardingTypeMasterSetup);

    List<HoardingTypeMasterSetupDto> findAllHoardingTypeMasterSetup();

    HoardingTypeMasterSetup findById(Long id);

    List<HoardingTypeMasterSetup> findAllByMunicipalId(int municipalId);

    HoardingTypeMasterSetup updateHoardingTypeMasterSetup(Long id, HoardingTypeMasterSetup updatedHoardingTypeMasterSetup,int updatedBy);

    HoardingTypeMasterSetup changeStatus(Long id, Integer status,int updatedBy);
}
