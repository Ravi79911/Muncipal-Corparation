package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.NewWaterWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.*;
import com.ahmednagar.municipal.auth.service.NewWaterWorkFlowLevelService;
import com.ahmednagar.municipal.auth.service.WaterRolesDataFlowSetupService;
import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class NewWaterWorkFlowLevelServiceImpl implements NewWaterWorkFlowLevelService {

    @Autowired
    private NewWaterWorkFlowLevelRepository newWaterWorkFlowLevelRepository;

    @Autowired
    private WorkFlowMasterRepository workFlowMasterRepository;

    @Autowired
    private ViewNewWaterConnectionFormMasterRepository viewNewWaterConnectionFormMasterRepository;

    @Autowired
    private ViewConsumerPropertyDetailsRepository viewConsumerPropertyDetailsRepository;

    @Autowired
    private WaterRolesDataFlowSetupService waterRolesDataFlowSetupService;

    @Autowired
    private RoleMasterRepository roleMasterRepository;

    @Autowired
    private UserMasterRepository userMasterRepository;

    @Autowired
    private ViewConsumerDocumentDetailsRepository viewConsumerDocumentDetailsRepository;

    @Autowired
    private CitizenSignUpRepository citizenSignUpRepository;

    @Autowired
    private ModelMapper modelMapper;

    public UserMaster getLipikForCitizen(Long citizenId) {
        Long roleId = 1L; // Role ID for Lipik

        CitizenSignUpMaster citizen = citizenSignUpRepository.findById(citizenId)
                .orElseThrow(() -> new EntityNotFoundException("Citizen not found with ID: " + citizenId));

        // Fetch the first Lipik (UserMaster) matching Zone, Ward, Role
        return userMasterRepository.findFirstByZoneWardAndRole(citizen.getZoneId(), citizen.getWardId(), roleId)
                .orElseThrow(() -> new EntityNotFoundException("No Lipik found for Zone: " + citizen.getZoneId()
                        + " and Ward: " + citizen.getWardId()));
    }

    @Override
    public NewWaterWorkFlowLevel createNewApplicationTransation(NewWaterWorkFlowLevel newWaterWorkFlowLevelRequest) {

        UserMaster newApplicationLipik = getLipikForCitizen(newWaterWorkFlowLevelRequest.getCitizenId().getId());

        // Fetch next role dynamically (e.g., based on workflow or hardcoded logic)
        RoleMaster currentRole = roleMasterRepository.findByRoleName("CITIZEN")
                .orElseThrow(() -> new RuntimeException("Role 'CITIZEN' not found"));

        // Validate WorkFlow Master
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWaterWorkFlowLevelRequest.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Master not found"));

        ViewNewWaterConnectionFormMaster existingApplication = viewNewWaterConnectionFormMasterRepository.findById(newWaterWorkFlowLevelRequest.getWaterApplicationId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newWaterWorkFlowLevelRequest.getWaterApplicationId().getId()));

        ViewConsumerPropertyDetails existingWaterPropertyDetails =  viewConsumerPropertyDetailsRepository.findByViewNewWaterConnectionFormMaster(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Consumer Property Details not found with ID: " + newWaterWorkFlowLevelRequest.getWaterApplicationId().getId()));

        // Build WorkFlowLevel Object with Defaults
        NewWaterWorkFlowLevel newWorkFlow = NewWaterWorkFlowLevel.builder()
                .waterApplicationId(newWaterWorkFlowLevelRequest.getWaterApplicationId())
                .currentUserId(null)
                .nextUserId(newApplicationLipik)
                .workFlowMasterId(workFlowMaster)
                .status("NEW") // Default status for new applications
                .currentRoleId(currentRole)
                .statusCode(1000L) // Example status code
                .createdBy(newWaterWorkFlowLevelRequest.getCreatedBy())
                .createdDate(LocalDateTime.now())
                .mailStatus(newWaterWorkFlowLevelRequest.getMailStatus())
                .remarks(newWaterWorkFlowLevelRequest.getRemarks())
                .municipalId(newWaterWorkFlowLevelRequest.getMunicipalId())
                .wardId(existingWaterPropertyDetails.getAuthWardMaster().getId())
                .zoneId(existingWaterPropertyDetails.getAuthZoneMaster().getId())
                .citizenId(newWaterWorkFlowLevelRequest.getCitizenId())
                .build();
        //updateApprovedStatus(newWaterWorkFlowLevelRequest.getWaterApplicationId().getId());
        newWorkFlow.setMailStatus(1);

        // Save Workflow to Database
        return newWaterWorkFlowLevelRepository.save(newWorkFlow);
    }

    @Override
    public List<NewWaterWorkFlowLevelDto> getAllNewWaterWorkFlowLevel() {
        List<NewWaterWorkFlowLevel> workFlows = newWaterWorkFlowLevelRepository.findAll();

        return workFlows.stream().map(workflow -> {
            NewWaterWorkFlowLevelDto dto = modelMapper.map(workflow, NewWaterWorkFlowLevelDto.class);

            // Manually map UserMaster to UserMasterDTO
            if (workflow.getCurrentUserId() != null) {
                dto.setCurrentUserId(modelMapper.map(workflow.getCurrentUserId(), UserMasterDTO.class));
            }
//            if (workflow.getNextUserId() != null) {
//                dto.setNextUserId(modelMapper.map(workflow.getNextUserId(), UserMasterDTO.class));
//            }
            return dto;
        }).collect(Collectors.toList());
    }

    public UserMaster getNextRoleForApplication(ViewConsumerPropertyDetails existingApplication, RoleMaster nextRoleId) {

        Long roleId = nextRoleId.getId(); // Role ID for Lipik

//        ViewFormsPropertyMaster existingApplication = propertyMasterRepository.findById(applicationId)
//                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + applicationId));

        // Fetch the first UserId matching with Zone, Ward, Role provided
        return userMasterRepository.findFirstByZoneWardAndRole(existingApplication.getAuthZoneMaster().getId(), existingApplication.getAuthWardMaster().getId(), roleId)
                .orElseThrow(() -> new EntityNotFoundException("No "+ nextRoleId.getRoleName() +" found for Zone: " + existingApplication.getAuthZoneMaster()+ " and Ward: " + existingApplication.getAuthWardMaster()));
    }

    private RoleMaster loadRoleOrThrow(RoleMaster role, String label) {                                                 // check if role exists
        if (role == null || role.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return roleMasterRepository.findById(role.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + role.getId() + " not found"));
    }

    private UserMaster loadUserOrThrow(UserMaster user, String label) {                                                  // check if user exists
        if (user == null || user.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return userMasterRepository.findById(user.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + user.getId() + " not found"));
    }

    private WorkFlowMaster loadWorkflowMasterOrThrow(WorkFlowMaster workflow, String label) {                           // check if workflow exists
        if (workflow == null || workflow.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return workFlowMasterRepository.findById(workflow.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + workflow.getId() + " not found"));
    }

    private void validateNoTerminalStateExists(NewWaterWorkFlowLevel newWaterWorkFlowLevel) {                                     //check application "Accept or "Reject" status
        List<NewWaterWorkFlowLevel> existingWorkflows =
                newWaterWorkFlowLevelRepository.findByWaterApplicationId(newWaterWorkFlowLevel.getWaterApplicationId());

        for (NewWaterWorkFlowLevel wf : existingWorkflows) {
            if (wf.getStatusCode() == null) continue;

            switch (wf.getStatusCode().intValue()) {
                case 1002 -> throw new IllegalStateException("This application has already been Accepted.");
                case 1003 -> throw new IllegalStateException("This application has already been Rejected.");
            }
        }
    }

    @Override
    public NewWaterWorkFlowLevel handleWorkFlowsTransition(NewWaterWorkFlowLevel newWaterWorkFlowLevel) {
        // 1. Validate and Load Current Role
        RoleMaster currentRole = loadRoleOrThrow(
                newWaterWorkFlowLevel.getCurrentRoleId(), "Current Role");

        // 2. Optionally Load Next Role
        RoleMaster nextRole = null;
        if (newWaterWorkFlowLevel.getNextRoleId() != null && newWaterWorkFlowLevel.getNextRoleId().getId() != null) {
            nextRole = loadRoleOrThrow(newWaterWorkFlowLevel.getNextRoleId(), "Next Role");
        }

        // 3. Load Current User
        UserMaster currentUser = loadUserOrThrow(
                newWaterWorkFlowLevel.getCurrentUserId(), "Current User");

        List<Long> rejectedDocumentIds = newWaterWorkFlowLevel.getRejectedDocumentIds();

        // 4. Prevent redundant transitions
        validateNoTerminalStateExists(newWaterWorkFlowLevel);

        // 5. Load Workflow Status
        WorkFlowMaster currentStatus = loadWorkflowMasterOrThrow(
                newWaterWorkFlowLevel.getWorkFlowMasterId(), "Workflow Master");

        // 6. Handle transition based on status
        return switch (currentStatus.getStatus().toUpperCase()) {
            case "FORWARDED" -> forward(newWaterWorkFlowLevel, currentStatus, currentRole, currentUser);

            case "BACKWARD" -> handleBackward(newWaterWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser);

            case "ACCEPT" -> handleAcceptStatus(newWaterWorkFlowLevel, currentRole, currentUser);

            case "REJECT" -> handleRejectStatus(newWaterWorkFlowLevel, currentRole, currentUser);

            case "BACK TO CITIZEN" -> handleBackToCitizenStatus(newWaterWorkFlowLevel, currentRole);

            case "BACK TO BACK OFFICE" -> handleBackToBackOfficeStatus(newWaterWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser);

            case "DOCUMENT VERIFICATION ACCEPT" -> handleDocumentVerificationAccept(newWaterWorkFlowLevel, currentStatus, currentRole, currentUser);

            case "DOCUMENT VERIFICATION REJECT" -> handleDocumentVerificationReject(newWaterWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser, rejectedDocumentIds);

            default -> throw new IllegalArgumentException("Unsupported workflow status: " + currentStatus.getStatus());
        };
    }
    private NewWaterWorkFlowLevel forward(NewWaterWorkFlowLevel workFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (workFlowLevel.getStatusCode() == 1001) {
            return forwardFromBackWard(workFlowLevel);
        } else if (workFlowLevel.getStatusCode() == 1007) {
            return forwardFromBackOffice(workFlowLevel);
        } else if (workFlowLevel.getStatusCode() == 1004) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromCitizen(workFlowLevel);
        } else {

            if (currentRole == null) {
                throw new IllegalStateException("Current role is required for forward action.");
            }

            if (currentUser == null || currentUser.getRoleMaster() == null) {
                throw new IllegalStateException("Current user or user's role is missing.");
            }

            if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
                String username = currentUser.getUsername();
                throw new SecurityException("User '" + username + "' is not authorized to perform forward action.");
            }

            WaterRolesDataFlowSetup NextRoleSetUpForForward = waterRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

            if (NextRoleSetUpForForward == null || NextRoleSetUpForForward.getNextRoleId() == null) {
                throw new IllegalStateException("No next role found for forward action.");
            }

            RoleMaster nextRole = roleMasterRepository.findById(NextRoleSetUpForForward.getNextRoleId())
                    .orElseThrow(() -> new RuntimeException("Next role not found for forward action."));

            ViewNewWaterConnectionFormMaster existingApplication = viewNewWaterConnectionFormMasterRepository.findById(workFlowLevel.getWaterApplicationId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + workFlowLevel.getWaterApplicationId().getId()));

            ViewConsumerPropertyDetails existingWaterPropertyDetails = viewConsumerPropertyDetailsRepository.findByViewNewWaterConnectionFormMaster(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Consumer Property Details not found with ID: " + workFlowLevel.getWaterApplicationId().getId()));

            UserMaster nextUser = getNextRoleForApplication(existingWaterPropertyDetails, nextRole);

            workFlowLevel.setNextUserId(nextUser);
            workFlowLevel.setWardId(existingWaterPropertyDetails.getAuthWardMaster().getId());
            workFlowLevel.setZoneId(existingWaterPropertyDetails.getAuthZoneMaster().getId());
            workFlowLevel.setNextRoleId(nextRole);
            workFlowLevel.setCreatedDate(LocalDateTime.now());
            workFlowLevel.setStatusCode(currentStatus.getStatusCode());
            workFlowLevel.setStatus(currentStatus.getStatus());
            workFlowLevel.setMailStatus(1);

            return newWaterWorkFlowLevelRepository.save(workFlowLevel);
        }
    }

    private NewWaterWorkFlowLevel handleBackward(NewWaterWorkFlowLevel newWaterWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWaterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }


        List<WaterRolesDataFlowSetup> validNextRoles = waterRolesDataFlowSetupService.getNextRoleListForListSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);
        boolean isValidNextRole = validNextRoles.stream()
                .anyMatch(role -> role.getNextRoleId().equals(nextRole.getId()));

        if (!isValidNextRole) {
            throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() + ") is not valid for backward action from currentRoleId (" + currentRole.getId() + ")");
        }

        List<Long> roleIds = validNextRoles.stream()
                .map(WaterRolesDataFlowSetup::getNextRoleId)
                .collect(Collectors.toList());

        List<RoleMaster> nextRoles = roleMasterRepository.findAllById(roleIds);

        ViewNewWaterConnectionFormMaster existingApplication = viewNewWaterConnectionFormMasterRepository.findById(newWaterWorkFlowLevel.getWaterApplicationId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));

        ViewConsumerPropertyDetails existingWaterPropertyDetails =  viewConsumerPropertyDetailsRepository.findByViewNewWaterConnectionFormMaster(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Consumer Property Details not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));

        UserMaster nextUser = getNextRoleForApplication(existingWaterPropertyDetails, nextRole);

        // Validate previousRole
        if (nextRoles == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }
        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
        if (newWaterWorkFlowLevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            newWaterWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

            //updateRejectStatus(licenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);

            return handleBackToCitizenStatus(newWaterWorkFlowLevel, nextRole);  // Handle transition to citizen
        }

        newWaterWorkFlowLevel.setNextUserId(nextUser);
        newWaterWorkFlowLevel.setWardId(existingWaterPropertyDetails.getAuthWardMaster().getId());
        newWaterWorkFlowLevel.setZoneId(existingWaterPropertyDetails.getAuthZoneMaster().getId());
        newWaterWorkFlowLevel.setNextRoleId(nextRole);
        newWaterWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        newWaterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        newWaterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newWaterWorkFlowLevel.setMailStatus(2);

        return newWaterWorkFlowLevelRepository.save(newWaterWorkFlowLevel);
    }

    private NewWaterWorkFlowLevel handleAcceptStatus(NewWaterWorkFlowLevel newWaterWorkFlowLevel, RoleMaster currentRole,UserMaster currentUser) {

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Accept action.");
        }

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWaterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (workFlowMaster.getId().equals(3L)) {  // Accept
            newWaterWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            newWaterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        }

        // Ensure only TS can accept
        if (!"EXECUTIVE ENGINEER".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only EXECUTIVE ENGINEER can accept the application.");
        }

        newWaterWorkFlowLevel.setNextRoleId(null); // No further forwarding
        newWaterWorkFlowLevel.setMailStatus(0);
        //newWaterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUser));
        newWaterWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return newWaterWorkFlowLevelRepository.save(newWaterWorkFlowLevel);
    }

    private NewWaterWorkFlowLevel handleRejectStatus(NewWaterWorkFlowLevel newWaterWorkFlowLevel, RoleMaster currentRole,UserMaster currentUser) {

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Accept action.");
        }

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWaterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));


        if (workFlowMaster.getId().equals(4L)) {  // Accept
            newWaterWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            newWaterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        }

        // Ensure only TS can accept
        if (!"EXECUTIVE ENGINEER".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only EXECUTIVE ENGINEER can accept the application.");
        }

        // Update status to "Rejected"
        newWaterWorkFlowLevel.setNextRoleId(null); // No further forwarding
        newWaterWorkFlowLevel.setMailStatus(0);
        newWaterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        //newWaterWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
        newWaterWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        // Mark application as inactive or non-processable
        ViewNewWaterConnectionFormMaster application = viewNewWaterConnectionFormMasterRepository.findById(newWaterWorkFlowLevel.getWaterApplicationId().getId())
                .orElseThrow(() -> new RuntimeException("Application not found"));

        //application.setActive(false); // Mark application as inactive
        viewNewWaterConnectionFormMasterRepository.save(application);

        return newWaterWorkFlowLevelRepository.save(newWaterWorkFlowLevel);
    }

    private NewWaterWorkFlowLevel handleBackToBackOfficeStatus(NewWaterWorkFlowLevel newWaterWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWaterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }


        // 5. ✅ Call service method correctly (only one result expected)
        WaterRolesDataFlowSetup validNextRole = waterRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

        if (!validNextRole.getNextRoleId().equals(nextRole.getId())) {
            throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() +
                    ") is not valid for backward action from currentRoleId (" + currentRole.getId() + ")");
        }

        newWaterWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        newWaterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        newWaterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newWaterWorkFlowLevel.setMailStatus(2);

        return newWaterWorkFlowLevelRepository.save(newWaterWorkFlowLevel);
    }

    private NewWaterWorkFlowLevel handleDocumentVerificationAccept(NewWaterWorkFlowLevel newWaterWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWaterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform forward action.");
        }

        WaterRolesDataFlowSetup NextRoleSetUpForDocumentVerificationAccept = waterRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

        if (NextRoleSetUpForDocumentVerificationAccept == null || NextRoleSetUpForDocumentVerificationAccept.getNextRoleId() == null) {
            throw new IllegalStateException("No next role found for forward action.");
        }

        RoleMaster nextRole = roleMasterRepository.findById(NextRoleSetUpForDocumentVerificationAccept.getNextRoleId())
                .orElseThrow(() -> new RuntimeException("Next role not found for forward action."));

        ViewNewWaterConnectionFormMaster existingApplication = viewNewWaterConnectionFormMasterRepository.findById(newWaterWorkFlowLevel.getWaterApplicationId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));

        ViewConsumerPropertyDetails existingWaterPropertyDetails =  viewConsumerPropertyDetailsRepository.findByViewNewWaterConnectionFormMaster(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Consumer Property Details not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));


        UserMaster nextUser = getNextRoleForApplication(existingWaterPropertyDetails, nextRole);

        newWaterWorkFlowLevel.setNextUserId(nextUser);
        newWaterWorkFlowLevel.setWardId(existingWaterPropertyDetails.getAuthWardMaster().getId());
        newWaterWorkFlowLevel.setZoneId(existingWaterPropertyDetails.getAuthZoneMaster().getId());
        newWaterWorkFlowLevel.setNextRoleId(nextRole);
        newWaterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newWaterWorkFlowLevel.setStatusCode(currentStatus.getStatusCode());
        newWaterWorkFlowLevel.setStatus(currentStatus.getStatus());
        newWaterWorkFlowLevel.setMailStatus(0);
        // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
        updateApprovedStatus(newWaterWorkFlowLevel.getWaterApplicationId().getId());

        return newWaterWorkFlowLevelRepository.save(newWaterWorkFlowLevel);
    }

    private void updateApprovedStatus(Long applicationMasterId) {
        List<ViewConsumerDocumentDetails> documentDetails =
                viewConsumerDocumentDetailsRepository.findByViewNewWaterConnectionFormMaster_Id(applicationMasterId);

        for (ViewConsumerDocumentDetails details : documentDetails) {

            details.setApprovedStatus(1f); // Set approved_status to 1
            viewConsumerDocumentDetailsRepository.save(details);
        }
    }

    private NewWaterWorkFlowLevel handleDocumentVerificationReject(NewWaterWorkFlowLevel newWaterWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser,List<Long> rejectDocumentIds) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWaterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (nextRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }

        List<WaterRolesDataFlowSetup> validNextRoles = waterRolesDataFlowSetupService.getNextRoleListForListSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);
        boolean isValidNextRole = validNextRoles.stream()
                .anyMatch(role -> role.getNextRoleId().equals(nextRole.getId()));

        if (!isValidNextRole) {
            throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() + ") is not valid for backward action from currentRoleId (" + currentRole.getId() + ")");
        }

        List<Long> roleIds = validNextRoles.stream()
                .map(WaterRolesDataFlowSetup::getNextRoleId)
                .collect(Collectors.toList());

        List<RoleMaster> nextRoles = roleMasterRepository.findAllById(roleIds);

//        RoleMaster nextRole = roleMasterRepository.findById(NextRoleSetUpForDocumentVerificationAccept.getNextRoleId())
//                .orElseThrow(() -> new RuntimeException("Next role not found for forward action."));

        ViewNewWaterConnectionFormMaster existingApplication = viewNewWaterConnectionFormMasterRepository.findById(newWaterWorkFlowLevel.getWaterApplicationId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));

        ViewConsumerPropertyDetails existingWaterPropertyDetails =  viewConsumerPropertyDetailsRepository.findByViewNewWaterConnectionFormMaster(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Consumer Property Details not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));

        UserMaster nextUser = getNextRoleForApplication(existingWaterPropertyDetails, nextRole);

        // Validate previousRole
        if (nextRole == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }

        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
        if (newWaterWorkFlowLevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            newWaterWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

            updateRejectStatus(newWaterWorkFlowLevel.getWaterApplicationId().getId(), rejectDocumentIds);

            return handleBackToCitizenStatus(newWaterWorkFlowLevel, currentRole);  // Handle transition to citizen
        }

        newWaterWorkFlowLevel.setNextUserId(nextUser);
        newWaterWorkFlowLevel.setWardId(existingWaterPropertyDetails.getAuthWardMaster().getId());
        newWaterWorkFlowLevel.setZoneId(existingWaterPropertyDetails.getAuthZoneMaster().getId());
        newWaterWorkFlowLevel.setNextRoleId(nextRole);
        newWaterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newWaterWorkFlowLevel.setStatusCode(currentStatus.getStatusCode());
        newWaterWorkFlowLevel.setStatus(currentStatus.getStatus());
        newWaterWorkFlowLevel.setMailStatus(2);

        updateRejectStatus(newWaterWorkFlowLevel.getWaterApplicationId().getId(), rejectDocumentIds);

        return newWaterWorkFlowLevelRepository.save(newWaterWorkFlowLevel);
    }

    /**
     * Update approved_status to 0 for rejected documents
     */
    private void updateRejectStatus(Long applicationId, List<Long> rejectDocumentIds) {
        if (rejectDocumentIds == null || rejectDocumentIds.isEmpty()) {
            System.out.println("No documents to update for rejection.");
            return;
        }

        List<ViewConsumerDocumentDetails> documentDetails =
                viewConsumerDocumentDetailsRepository.findAllById(rejectDocumentIds);

        if (documentDetails.isEmpty()) {
            System.out.println("No matching documents found for rejection.");
            return;
        }

        documentDetails.forEach(details -> details.setApprovedStatus(0f)); // Set approved_status to 0

        // Save all updates in batch
        viewConsumerDocumentDetailsRepository.saveAll(documentDetails);

        System.out.println("Updated " + documentDetails.size() + " documents to rejected status.");
    }

    private NewWaterWorkFlowLevel handleBackToCitizenStatus(NewWaterWorkFlowLevel newWaterWorkFlowLevel, RoleMaster currentRole) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWaterWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        ViewNewWaterConnectionFormMaster existingApplication = viewNewWaterConnectionFormMasterRepository.findById(newWaterWorkFlowLevel.getWaterApplicationId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));

        ViewConsumerPropertyDetails existingWaterPropertyDetails =  viewConsumerPropertyDetailsRepository.findByViewNewWaterConnectionFormMaster(existingApplication)
                .orElseThrow(() -> new EntityNotFoundException("Consumer Property Details not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));


//        Long nextUserId = newWaterWorkFlowLevel.getNextUserId().getId();
        Long currentUserId = newWaterWorkFlowLevel.getCurrentUserId().getId();

        if (workFlowMaster.getId().equals(5L)) {
            newWaterWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            newWaterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

            newWaterWorkFlowLevel.setWardId(existingWaterPropertyDetails.getAuthWardMaster().getId());
            newWaterWorkFlowLevel.setZoneId(existingWaterPropertyDetails.getAuthZoneMaster().getId());
            newWaterWorkFlowLevel.setNextUserId(null);
            newWaterWorkFlowLevel.setNextRoleId(null);
            newWaterWorkFlowLevel.setCurrentRoleId(newWaterWorkFlowLevel.getCurrentRoleId());
            //newWaterWorkFlowLevel.setNextRoleId(newWaterWorkFlowLevel.getNextRoleId());
            newWaterWorkFlowLevel.setCurrentUserId(newWaterWorkFlowLevel.getCurrentUserId());
            newWaterWorkFlowLevel.setCitizenId(newWaterWorkFlowLevel.getCitizenId());
        }
        newWaterWorkFlowLevel.setMailStatus(1);
        newWaterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        return newWaterWorkFlowLevelRepository.save(newWaterWorkFlowLevel);
    }

    private NewWaterWorkFlowLevel forwardFromBackWard(NewWaterWorkFlowLevel newWaterWorkFlowLevel) {

        Long currentRoleId = newWaterWorkFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));

        Long applicationId = newWaterWorkFlowLevel.getWaterApplicationId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = newWaterWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewWaterWorkFlowLevel latestWorkFlow = newWaterWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1001) {

            newWaterWorkFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWaterWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewNewWaterConnectionFormMaster existingApplication = viewNewWaterConnectionFormMasterRepository.findById(newWaterWorkFlowLevel.getWaterApplicationId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));

            ViewConsumerPropertyDetails existingWaterPropertyDetails =  viewConsumerPropertyDetailsRepository.findByViewNewWaterConnectionFormMaster(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Consumer Property Details not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));



            UserMaster nextUser = getNextRoleForApplication(existingWaterPropertyDetails, newWaterWorkFlowLevel.getNextRoleId());

            newWaterWorkFlowLevel.setNextUserId(nextUser);
            newWaterWorkFlowLevel.setWardId(existingWaterPropertyDetails.getAuthWardMaster().getId());
            newWaterWorkFlowLevel.setZoneId(existingWaterPropertyDetails.getAuthZoneMaster().getId());
            newWaterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            newWaterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            newWaterWorkFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            newWaterWorkFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(newWaterWorkFlowLevel.getWaterApplicationId().getId());
            return newWaterWorkFlowLevelRepository.save(newWaterWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private NewWaterWorkFlowLevel forwardFromBackOffice(NewWaterWorkFlowLevel newWaterWorkFlowLevel) {

        Long currentRoleId = newWaterWorkFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));

        Long applicationId = newWaterWorkFlowLevel.getWaterApplicationId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = newWaterWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewWaterWorkFlowLevel latestWorkFlow = newWaterWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1007) {

            newWaterWorkFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWaterWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewNewWaterConnectionFormMaster existingApplication = viewNewWaterConnectionFormMasterRepository.findById(newWaterWorkFlowLevel.getWaterApplicationId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));

            ViewConsumerPropertyDetails existingWaterPropertyDetails =  viewConsumerPropertyDetailsRepository.findByViewNewWaterConnectionFormMaster(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Consumer Property Details not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));


            UserMaster nextUser = getNextRoleForApplication(existingWaterPropertyDetails, newWaterWorkFlowLevel.getNextRoleId());

            newWaterWorkFlowLevel.setNextUserId(nextUser);
            newWaterWorkFlowLevel.setWardId(existingWaterPropertyDetails.getAuthWardMaster().getId());
            newWaterWorkFlowLevel.setZoneId(existingWaterPropertyDetails.getAuthZoneMaster().getId());
            newWaterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            newWaterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            newWaterWorkFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            newWaterWorkFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(newWaterWorkFlowLevel.getWaterApplicationId().getId());
            return newWaterWorkFlowLevelRepository.save(newWaterWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private NewWaterWorkFlowLevel forwardFromCitizen(NewWaterWorkFlowLevel newWaterWorkFlowLevel) {

        Long currentRoleId = newWaterWorkFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));

        Long applicationId = newWaterWorkFlowLevel.getWaterApplicationId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = newWaterWorkFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewWaterWorkFlowLevel latestWorkFlow = newWaterWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1004) {

            newWaterWorkFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWaterWorkFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewNewWaterConnectionFormMaster existingApplication = viewNewWaterConnectionFormMasterRepository.findById(newWaterWorkFlowLevel.getWaterApplicationId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));

            ViewConsumerPropertyDetails existingWaterPropertyDetails =  viewConsumerPropertyDetailsRepository.findByViewNewWaterConnectionFormMaster(existingApplication)
                    .orElseThrow(() -> new EntityNotFoundException("Consumer Property Details not found with ID: " + newWaterWorkFlowLevel.getWaterApplicationId().getId()));

            UserMaster nextUser = getNextRoleForApplication(existingWaterPropertyDetails, newWaterWorkFlowLevel.getNextRoleId());

            newWaterWorkFlowLevel.setNextUserId(nextUser);
            newWaterWorkFlowLevel.setWardId(existingWaterPropertyDetails.getAuthWardMaster().getId());
            newWaterWorkFlowLevel.setZoneId(existingWaterPropertyDetails.getAuthZoneMaster().getId());
            newWaterWorkFlowLevel.setCreatedDate(LocalDateTime.now());
            newWaterWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            newWaterWorkFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            newWaterWorkFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(newWaterWorkFlowLevel.getWaterApplicationId().getId());
            return newWaterWorkFlowLevelRepository.save(newWaterWorkFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

}






