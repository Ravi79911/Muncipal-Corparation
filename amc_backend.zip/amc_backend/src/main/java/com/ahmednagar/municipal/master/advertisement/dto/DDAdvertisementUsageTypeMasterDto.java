package com.ahmednagar.municipal.master.advertisement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class DDAdvertisementUsageTypeMasterDto {

    private Long id;
    private String usageTypeName;

}
