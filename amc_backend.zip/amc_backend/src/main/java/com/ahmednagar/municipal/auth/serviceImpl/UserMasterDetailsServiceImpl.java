package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.UserMasterDetails;
import com.ahmednagar.municipal.auth.repository.UserMasterDetailsRepository;
import com.ahmednagar.municipal.auth.service.UserMasterDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserMasterDetailsServiceImpl implements UserMasterDetailsService {

    @Autowired
    UserMasterDetailsRepository userMasterDetailsRepository;

    @Override
    public UserMasterDetails createUserDetails(UserMasterDetails userMasterDetails, int createdBy) {
        if (userMasterDetails != null) {
            userMasterDetails.setUpdatedBy(createdBy);
            userMasterDetails.setCreatedBy(createdBy);
            userMasterDetails.setCreatedDate(LocalDateTime.now());
            userMasterDetails.setUpdatedDate(LocalDateTime.now());
            userMasterDetails.setSuspendedStatus(userMasterDetails.getSuspendedStatus() != null ? userMasterDetails.getSuspendedStatus() : 0);
            userMasterDetailsRepository.saveAndFlush(userMasterDetails);
            return userMasterDetails;
        }
        return null;
    }

    @Override
    public UserMasterDetails updateUserDetails(Long id, UserMasterDetails updatedUserMasterDetails) {
        Optional<UserMasterDetails> userDetailsChanges = userMasterDetailsRepository.findById(id);
        if (userDetailsChanges.isPresent()) {
            UserMasterDetails userMasterDetailsEntity = userDetailsChanges.get();
            userMasterDetailsEntity.setUsermasId(updatedUserMasterDetails.getUsermasId());
            userMasterDetailsEntity.setZoneId(updatedUserMasterDetails.getZoneId());
            userMasterDetailsEntity.setWardId(updatedUserMasterDetails.getWardId());
            userMasterDetailsEntity.setUpdatedDate(LocalDateTime.now());
            userMasterDetailsEntity.setUpdatedBy(userMasterDetailsEntity.getUpdatedBy());
            userMasterDetailsRepository.saveAndFlush(userMasterDetailsEntity);
            return userMasterDetailsEntity;
        }
        return null;
    }

    @Override
    public UserMasterDetails changeSuspendedStatus(Long id, int status) {
        Optional<UserMasterDetails> userDetailsStatusChanges = userMasterDetailsRepository.findById(id);
        if (userDetailsStatusChanges.isPresent()) {
            UserMasterDetails userMasterDetailsEntity = userDetailsStatusChanges.get();
            userMasterDetailsEntity.setSuspendedStatus(status);
            userMasterDetailsEntity.setUpdatedDate(LocalDateTime.now());
            userMasterDetailsEntity.setUpdatedBy(userMasterDetailsEntity.getUpdatedBy());
            userMasterDetailsRepository.saveAndFlush(userMasterDetailsEntity);
            return userMasterDetailsEntity;
        }
        return null;
    }

    @Override
    public List<UserMasterDetails> getUserDetailsByMunicipalId(Long municipalId) {
        return userMasterDetailsRepository.findByMunicipalId(municipalId);
    }

}
