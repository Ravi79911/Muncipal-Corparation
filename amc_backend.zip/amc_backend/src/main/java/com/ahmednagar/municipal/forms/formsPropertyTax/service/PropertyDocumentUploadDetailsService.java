package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDocumentUploadDetails;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public interface PropertyDocumentUploadDetailsService {

    PropertyDocumentUploadDetails createPropertyDocumentUploadDetails(PropertyDocumentUploadDetails propertyDocumentUploadDetails, MultipartFile documentPath);

    List<String> getDocumentUrlsByMunicipalPropertyId(Long municipalPropertyMasterId); // only for get all document urls

    List<PropertyDocumentUploadDetails> getAllDocumentDetailsByPropertyMasterId(Long municipalPropertyMasterId); // fetch all document details by property master id

//    Resource loadPropertyDocumentUploadDetails(Long id) throws IOException;

    List<PropertyDocumentUploadDetails> getAllPropertyDocumentUploadDetails();

    Optional<PropertyDocumentUploadDetails> getPropertyDocumentUploadDetailsById(Long id);

    List<PropertyDocumentUploadDetails> getPropertyDocumentUploadDetailsByMunicipalId(int municipalId);

    PropertyDocumentUploadDetails updatePropertyDocumentUploadDetailsById(Long id, MultipartFile documentPath, Integer updatedBy);

    PropertyDocumentUploadDetails patchPropertyDocumentUploadDetailsSuspendedStatus(Long id, int suspendedStatus);

}
