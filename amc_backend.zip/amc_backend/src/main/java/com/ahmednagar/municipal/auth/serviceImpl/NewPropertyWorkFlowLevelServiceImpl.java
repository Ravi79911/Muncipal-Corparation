package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.NewPropertyWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.*;
import com.ahmednagar.municipal.auth.service.NewPropertyWorkFlowLevelService;
import com.ahmednagar.municipal.auth.service.PropertyRolesDataFlowSetupService;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class NewPropertyWorkFlowLevelServiceImpl implements NewPropertyWorkFlowLevelService {

    @Autowired
    private NewPropertyWorkFlowLevelRepository newPropertyWorkFlowLevelRepository;

    @Autowired
    private WorkFlowMasterRepository workFlowMasterRepository;

//    @Autowired
//    private ViewMunicipalPropertyMasterRepository propertyMasterRepository;
//
//    @Autowired
//    private MunicipalPropertyMasterRepository viewMunicipalPropertyMasterRepository;

    @Autowired
    private ViewMunicipalPropertyMasterRepository viewMunicipalPropertyMasterRepository;

    @Autowired
    private MunicipalPropertyMasterRepository municipalPropertyMasterRepository;

    @Autowired
    private PropertyRolesDataFlowSetupService propertyRolesDataFlowSetupService;

    @Autowired
    private RoleMasterRepository roleMasterRepository;

    @Autowired
    private UserMasterRepository userMasterRepository;

    @Autowired
    private ViewMunicipalPropertyDocumentUploadDetailsRepository viewMunicipalPropertyDocumentUploadDetailsRepository;

    @Autowired
    private CitizenSignUpRepository citizenSignUpRepository;

    @Autowired
    private ModelMapper modelMapper;

    public UserMaster getLipikForCitizen(Long citizenId) {
        Long roleId = 1L; // Role ID for Lipik

        CitizenSignUpMaster citizen = citizenSignUpRepository.findById(citizenId)
                .orElseThrow(() -> new EntityNotFoundException("Citizen not found with ID: " + citizenId));

        // Fetch the first Lipik (UserMaster) matching Zone, Ward, Role
        return userMasterRepository.findFirstByZoneWardAndRole(citizen.getZoneId(), citizen.getWardId(), roleId)
                .orElseThrow(() -> new EntityNotFoundException("No Lipik found for Zone: " + citizen.getZoneId()
                        + " and Ward: " + citizen.getWardId()));
    }

    @Override
    public NewPropertyWorkFlowLevel createNewApplicationTransation(NewPropertyWorkFlowLevel newPropertyWorkFlowLevelRequest) {
        // Validate Application ID
//        ViewMunicipalPropertyMaster application = applicationRepository.findById(
//                        newWorkFlowLevelRequest.getApplicationId().getId())
//                .orElseThrow(() -> new RuntimeException("Application not found"));

        UserMaster newApplicationLipik = getLipikForCitizen(newPropertyWorkFlowLevelRequest.getCitizenId().getId());

//        // Validate Current User
//        UserMaster currentUser = userMasterRepository.findById(newWorkFlowLevelRequest.getCurrentUserId().getId())
//                .orElseThrow(() -> new RuntimeException("Current User not found"));

//        // Fetch current user
//        UserMaster currentUser = userMasterRepository.findById(newWorkFlowLevelRequest.getCurrentUserId().getId())
//                .orElseThrow(() -> new RuntimeException("Current User not found"));
//
//        // Fetch next role
//        RoleMaster nextRole = roleMasterRepository.findById(newWorkFlowLevelRequest.getNextRoleId().getId())
//                .orElseThrow(() -> new RuntimeException("Next Role not found"));
        // Fetch next role dynamically (e.g., based on workflow or hardcoded logic)
        RoleMaster currentRole = roleMasterRepository.findByRoleName("CITIZEN")
                .orElseThrow(() -> new RuntimeException("Role 'CITIZEN' not found"));

        // Validate WorkFlow Master
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newPropertyWorkFlowLevelRequest.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("Workflow Master not found"));

        ViewMunicipalPropertyMaster existingApplication = viewMunicipalPropertyMasterRepository.findById(newPropertyWorkFlowLevelRequest.getApplicationId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newPropertyWorkFlowLevelRequest.getApplicationId().getId()));


        // Build WorkFlowLevel Object with Defaults
        NewPropertyWorkFlowLevel newWorkFlow = NewPropertyWorkFlowLevel.builder()
                .applicationId(newPropertyWorkFlowLevelRequest.getApplicationId())
                .currentUserId(null)
                .nextUserId(newApplicationLipik)
                .workFlowMasterId(workFlowMaster)
                .status("NEW") // Default status for new applications
                .currentRoleId(currentRole)
                .statusCode(1000L) // Example status code
                .createdBy(newPropertyWorkFlowLevelRequest.getCreatedBy())
                .createdDate(LocalDateTime.now())
                .mailStatus(newPropertyWorkFlowLevelRequest.getMailStatus())
                .remarks(newPropertyWorkFlowLevelRequest.getRemarks())
                .municipalId(newPropertyWorkFlowLevelRequest.getMunicipalId())
                .wardId(existingApplication.getAuthWardMaster().getId())
                .zoneId(existingApplication.getAuthZoneMaster().getId())
                .citizenId(newPropertyWorkFlowLevelRequest.getCitizenId())
                .build();
        updateApprovedStatus(newPropertyWorkFlowLevelRequest.getApplicationId().getId());
        newWorkFlow.setMailStatus(1);

        // Save Workflow to Database
        return newPropertyWorkFlowLevelRepository.save(newWorkFlow);
    }

    @Override
    public List<NewPropertyWorkFlowLevelDto> getAllNewWorkFlows() {
        List<NewPropertyWorkFlowLevel> workFlows = newPropertyWorkFlowLevelRepository.findAll();

        return workFlows.stream().map(workflow -> {
            NewPropertyWorkFlowLevelDto dto = modelMapper.map(workflow, NewPropertyWorkFlowLevelDto.class);

            // Manually map UserMaster to UserMasterDTO
            if (workflow.getCurrentUserId() != null) {
                dto.setCurrentUserId(modelMapper.map(workflow.getCurrentUserId(), UserMasterDTO.class));
            }
//            if (workflow.getNextUserId() != null) {
//                dto.setNextUserId(modelMapper.map(workflow.getNextUserId(), UserMasterDTO.class));
//            }
            return dto;
        }).collect(Collectors.toList());
    }

    public UserMaster getNextRoleForApplication(ViewMunicipalPropertyMaster existingApplication, RoleMaster nextRoleId) {

        Long roleId = nextRoleId.getId(); // Role ID for Lipik

//        ViewFormsPropertyMaster existingApplication = propertyMasterRepository.findById(applicationId)
//                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + applicationId));

        // Fetch the first UserId matching with Zone, Ward, Role provided
        return userMasterRepository.findFirstByZoneWardAndRole(existingApplication.getAuthZoneMaster().getId(), existingApplication.getAuthWardMaster().getId(), roleId)
                .orElseThrow(() -> new EntityNotFoundException("No "+ nextRoleId.getRoleName() +" found for Zone: " + existingApplication.getAuthZoneMaster().getId() + " and Ward: " + existingApplication.getAuthWardMaster().getId()));
    }

    private RoleMaster loadRoleOrThrow(RoleMaster role, String label) {                                                 // check if role exists
        if (role == null || role.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return roleMasterRepository.findById(role.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + role.getId() + " not found"));
    }

    private UserMaster loadUserOrThrow(UserMaster user, String label) {                                                  // check if user exists
        if (user == null || user.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return userMasterRepository.findById(user.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + user.getId() + " not found"));
    }

    private WorkFlowMaster loadWorkflowMasterOrThrow(WorkFlowMaster workflow, String label) {                           // check if workflow exists
        if (workflow == null || workflow.getId() == null) {
            throw new IllegalArgumentException(label + " is required and must contain a valid ID.");
        }

        return workFlowMasterRepository.findById(workflow.getId())
                .orElseThrow(() -> new EntityNotFoundException(label + " with ID " + workflow.getId() + " not found"));
    }

    private void validateNoTerminalStateExists(NewPropertyWorkFlowLevel newPropertyWorkFlowLevel) {                                     //check application "Accept or "Reject" status
        List<NewPropertyWorkFlowLevel> existingWorkflows =
                newPropertyWorkFlowLevelRepository.findByApplicationId(newPropertyWorkFlowLevel.getApplicationId());

        for (NewPropertyWorkFlowLevel wf : existingWorkflows) {
            if (wf.getStatusCode() == null) continue;

            switch (wf.getStatusCode().intValue()) {
                case 1002 -> throw new IllegalStateException("This application has already been Accepted.");
                case 1003 -> throw new IllegalStateException("This application has already been Rejected.");
            }
        }
    }

    @Override
    public NewPropertyWorkFlowLevel handleWorkFlowsTransition(NewPropertyWorkFlowLevel newPropertyWorkFlowLevel) {

        // 1. Validate and Load Current Role
        RoleMaster currentRole = loadRoleOrThrow(
                newPropertyWorkFlowLevel.getCurrentRoleId(), "Current Role");

        // 2. Optionally Load Next Role
        RoleMaster nextRole = null;
        if (newPropertyWorkFlowLevel.getNextRoleId() != null && newPropertyWorkFlowLevel.getNextRoleId().getId() != null) {
            nextRole = loadRoleOrThrow(newPropertyWorkFlowLevel.getNextRoleId(), "Next Role");
        }

        // 3. Load Current User
        UserMaster currentUser = loadUserOrThrow(
                newPropertyWorkFlowLevel.getCurrentUserId(), "Current User");

        List<Long> rejectedDocumentIds = newPropertyWorkFlowLevel.getRejectedDocumentIds();

        // 4. Prevent redundant transitions
        validateNoTerminalStateExists(newPropertyWorkFlowLevel);

        // 5. Load Workflow Status
        WorkFlowMaster currentStatus = loadWorkflowMasterOrThrow(
                newPropertyWorkFlowLevel.getWorkFlowMasterId(), "Workflow Master");

        // 6. Handle transition based on status
        return switch (currentStatus.getStatus().toUpperCase()) {
            case "FORWARDED" -> forward(newPropertyWorkFlowLevel, currentStatus, currentRole, currentUser);
            case "BACKWARD" -> handleBackward(newPropertyWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser);
            case "ACCEPT" -> handleAcceptStatus(newPropertyWorkFlowLevel, currentRole, currentUser);
            case "REJECT" -> handleRejectStatus(newPropertyWorkFlowLevel, currentRole, currentUser);
            case "BACK TO CITIZEN" -> handleBackToCitizenStatus(newPropertyWorkFlowLevel, currentRole);
//            case "BACK TO CITIZEN IN BACKWARD" -> handleBackToCitizenInBackWardCaseStatus(newWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser);
            case "BACK TO BACK OFFICE" ->
                    handleBackToBackOfficeStatus(newPropertyWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser);
            case "DOCUMENT VERIFICATION ACCEPT" ->
                    handleDocumentVerificationAccept(newPropertyWorkFlowLevel, currentStatus, currentRole, currentUser);
            case "DOCUMENT VERIFICATION REJECT" ->
                    handleDocumentVerificationReject(newPropertyWorkFlowLevel, currentStatus, currentRole, nextRole, currentUser, rejectedDocumentIds);
            default -> throw new IllegalArgumentException("Unsupported workflow status: " + currentStatus.getStatus());
        };
    }

    private NewPropertyWorkFlowLevel forward(NewPropertyWorkFlowLevel workFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (workFlowLevel.getStatusCode() == 1001) {
            return forwardFromBackWard(workFlowLevel);
        }
        else if (workFlowLevel.getStatusCode() == 1007) {
            return forwardFromBackOffice(workFlowLevel);
        }else if (workFlowLevel.getStatusCode() == 1004) {
            // Call forwardFromCitizen when status_code is 1004
            return forwardFromCitizen(workFlowLevel);
        }
        else {

            if (currentRole == null) {
                throw new IllegalStateException("Current role is required for forward action.");
            }

            if (currentUser == null || currentUser.getRoleMaster() == null) {
                throw new IllegalStateException("Current user or user's role is missing.");
            }

            if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
                String username = currentUser.getUsername();
                throw new SecurityException("User '" + username + "' is not authorized to perform forward action.");
            }

            PropertyRolesDataFlowSetup NextRoleSetUpForForward = propertyRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

            if (NextRoleSetUpForForward == null || NextRoleSetUpForForward.getNextRoleId() == null) {
                throw new IllegalStateException("No next role found for forward action.");
            }

            RoleMaster nextRole = roleMasterRepository.findById(NextRoleSetUpForForward.getNextRoleId())
                    .orElseThrow(() -> new RuntimeException("Next role not found for forward action."));

            ViewMunicipalPropertyMaster existingApplication = viewMunicipalPropertyMasterRepository.findById(workFlowLevel.getApplicationId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + workFlowLevel.getApplicationId().getId()));

            UserMaster nextUser = getNextRoleForApplication(existingApplication, nextRole);

            workFlowLevel.setNextUserId(nextUser);
            workFlowLevel.setWardId(existingApplication.getAuthWardMaster().getId());
            workFlowLevel.setZoneId(existingApplication.getAuthZoneMaster().getId());
            workFlowLevel.setNextRoleId(nextRole);
            workFlowLevel.setCreatedDate(LocalDateTime.now());
            workFlowLevel.setStatusCode(currentStatus.getStatusCode());
            workFlowLevel.setStatus(currentStatus.getStatus());
            workFlowLevel.setMailStatus(1);

            return newPropertyWorkFlowLevelRepository.save(workFlowLevel);
        }
    }


    private NewPropertyWorkFlowLevel handleBackward(NewPropertyWorkFlowLevel newPropertyWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newPropertyWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }


        List<PropertyRolesDataFlowSetup> validNextRoles = propertyRolesDataFlowSetupService.getNextRoleListForListSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);
        boolean isValidNextRole = validNextRoles.stream()
                .anyMatch(role -> role.getNextRoleId().equals(nextRole.getId()));

        if (!isValidNextRole) {
            throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() + ") is not valid for backward action from currentRoleId (" + currentRole.getId() + ")");
        }

        List<Long> roleIds = validNextRoles.stream()
                .map(PropertyRolesDataFlowSetup::getNextRoleId)
                .collect(Collectors.toList());

        List<RoleMaster> nextRoles = roleMasterRepository.findAllById(roleIds);

        ViewMunicipalPropertyMaster existingApplication = viewMunicipalPropertyMasterRepository.findById(newPropertyWorkFlowLevel.getApplicationId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newPropertyWorkFlowLevel.getApplicationId().getId()));

        UserMaster nextUser = getNextRoleForApplication(existingApplication, nextRole);

        // Validate previousRole
        if (nextRoles == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }
        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
        if (newPropertyWorkFlowLevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            newPropertyWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

            //updateRejectStatus(licenseWorkFlowLevel.getApplicationMasterId().getId(), rejectDocumentIdes);

            return handleBackToCitizenStatus(newPropertyWorkFlowLevel, nextRole);  // Handle transition to citizen
        }

        newPropertyWorkFlowLevel.setNextUserId(nextUser);
        newPropertyWorkFlowLevel.setWardId(existingApplication.getAuthWardMaster().getId());
        newPropertyWorkFlowLevel.setZoneId(existingApplication.getAuthZoneMaster().getId());
        newPropertyWorkFlowLevel.setNextRoleId(nextRole);
        newPropertyWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        newPropertyWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        newPropertyWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newPropertyWorkFlowLevel.setMailStatus(2);

        return newPropertyWorkFlowLevelRepository.save(newPropertyWorkFlowLevel);
    }

    private NewPropertyWorkFlowLevel handleAcceptStatus(NewPropertyWorkFlowLevel newPropertyWorkFlowLevel, RoleMaster currentRole, UserMaster currentUser) {

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Accept action.");
        }

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newPropertyWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (workFlowMaster.getId().equals(3L)) {  // Accept
            newPropertyWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            newPropertyWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        }

        // Ensure only TS can accept
        if (!"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only Tax Superintendent can accept the application.");
        }




        newPropertyWorkFlowLevel.setNextRoleId(null); // No further forwarding
        newPropertyWorkFlowLevel.setMailStatus(0);
        //newWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUser));
        newPropertyWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        return newPropertyWorkFlowLevelRepository.save(newPropertyWorkFlowLevel);
    }


    private NewPropertyWorkFlowLevel handleRejectStatus(NewPropertyWorkFlowLevel newPropertyWorkFlowLevel, RoleMaster currentRole, UserMaster currentUser) {

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Accept action.");
        }

        // Fetch WorkFlowMaster from DB
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newPropertyWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));


        if (workFlowMaster.getId().equals(4L)) {  // Accept
            newPropertyWorkFlowLevel.setStatus(workFlowMaster.getStatus());
            newPropertyWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());

        }

        // Ensure only TS can accept
        if (!"tax superintendent".equalsIgnoreCase(currentRole.getRoleName())) {
            throw new IllegalStateException("Only Tax Superintendent can accept the application.");
        }

        // Update status to "Rejected"
        newPropertyWorkFlowLevel.setNextRoleId(null); // No further forwarding
        newPropertyWorkFlowLevel.setMailStatus(0);
        newPropertyWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        //newWorkFlowLevel.setCurrentUserId(getUserMasterByRoleMaster(currentRole, currentUserId));
        newPropertyWorkFlowLevel.setCreatedDate(LocalDateTime.now());

        // Mark application as inactive or non-processable
        MunicipalPropertyMaster application = municipalPropertyMasterRepository.findById(newPropertyWorkFlowLevel.getApplicationId().getId())
                .orElseThrow(() -> new RuntimeException("Application not found"));

        //application.setActive(false); // Mark application as inactive
        municipalPropertyMasterRepository.save(application);

        return newPropertyWorkFlowLevelRepository.save(newPropertyWorkFlowLevel);
    }

    private NewPropertyWorkFlowLevel handleBackToBackOfficeStatus(NewPropertyWorkFlowLevel newPropertyWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newPropertyWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }


        // 5. ✅ Call service method correctly (only one result expected)
        PropertyRolesDataFlowSetup validNextRole = propertyRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

        if (!validNextRole.getNextRoleId().equals(nextRole.getId())) {
            throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() +
                    ") is not valid for backward action from currentRoleId (" + currentRole.getId() + ")");
        }

        newPropertyWorkFlowLevel.setStatus(workFlowMaster.getStatus());
        newPropertyWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
        newPropertyWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newPropertyWorkFlowLevel.setMailStatus(2);

        return newPropertyWorkFlowLevelRepository.save(newPropertyWorkFlowLevel);
    }

    private NewPropertyWorkFlowLevel handleDocumentVerificationAccept(NewPropertyWorkFlowLevel newPropertyWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, UserMaster currentUser) {

        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newPropertyWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (currentRole == null) {
            throw new IllegalStateException("Current role is required for forward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform forward action.");
        }

        PropertyRolesDataFlowSetup NextRoleSetUpForDocumentVerificationAccept = propertyRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);

        if (NextRoleSetUpForDocumentVerificationAccept == null || NextRoleSetUpForDocumentVerificationAccept.getNextRoleId() == null) {
            throw new IllegalStateException("No next role found for forward action.");
        }

        RoleMaster nextRole = roleMasterRepository.findById(NextRoleSetUpForDocumentVerificationAccept.getNextRoleId())
                .orElseThrow(() -> new RuntimeException("Next role not found for forward action."));

        ViewMunicipalPropertyMaster existingApplication = viewMunicipalPropertyMasterRepository.findById(newPropertyWorkFlowLevel.getApplicationId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newPropertyWorkFlowLevel.getApplicationId().getId()));

        UserMaster nextUser = getNextRoleForApplication(existingApplication, nextRole);

        newPropertyWorkFlowLevel.setNextUserId(nextUser);
        newPropertyWorkFlowLevel.setWardId(existingApplication.getAuthWardMaster().getId());
        newPropertyWorkFlowLevel.setZoneId(existingApplication.getAuthZoneMaster().getId());
        newPropertyWorkFlowLevel.setNextRoleId(nextRole);
        newPropertyWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newPropertyWorkFlowLevel.setStatusCode(currentStatus.getStatusCode());
        newPropertyWorkFlowLevel.setStatus(currentStatus.getStatus());
        newPropertyWorkFlowLevel.setMailStatus(0);
        // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
        updateApprovedStatus(newPropertyWorkFlowLevel.getApplicationId().getId());

        return newPropertyWorkFlowLevelRepository.save(newPropertyWorkFlowLevel);
    }

    private void updateApprovedStatus(Long applicationId) {
        List<ViewMunicipalPropertyDocumentUploadDetails> documentDetails =
                viewMunicipalPropertyDocumentUploadDetailsRepository.findByViewMunicipalPropertyMaster_Id(applicationId);

        for (ViewMunicipalPropertyDocumentUploadDetails details : documentDetails) {

            details.setApprovedStatus(1f); // Set approved_status to 1
            viewMunicipalPropertyDocumentUploadDetailsRepository.save(details);
        }
    }

    private NewPropertyWorkFlowLevel handleDocumentVerificationReject(NewPropertyWorkFlowLevel newPropertyWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser, List<Long> rejectDocumentIds) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newPropertyWorkFlowLevel.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        if (nextRole == null) {
            throw new IllegalStateException("Current role is required for Backward action.");
        }

        if (currentUser == null || currentUser.getRoleMaster() == null) {
            throw new IllegalStateException("Current user or user's role is missing.");
        }

        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
            String username = currentUser.getUsername();
            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
        }

        List<PropertyRolesDataFlowSetup> validNextRoles = propertyRolesDataFlowSetupService.getNextRoleListForListSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);
        boolean isValidNextRole = validNextRoles.stream()
                .anyMatch(role -> role.getNextRoleId().equals(nextRole.getId()));

        if (!isValidNextRole) {
            throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() + ") is not valid for backward action from currentRoleId (" + currentRole.getId() + ")");
        }

        List<Long> roleIds = validNextRoles.stream()
                .map(PropertyRolesDataFlowSetup::getNextRoleId)
                .collect(Collectors.toList());

        List<RoleMaster> nextRoles = roleMasterRepository.findAllById(roleIds);

//        RoleMaster nextRole = roleMasterRepository.findById(NextRoleSetUpForDocumentVerificationAccept.getNextRoleId())
//                .orElseThrow(() -> new RuntimeException("Next role not found for forward action."));

        ViewMunicipalPropertyMaster existingApplication = viewMunicipalPropertyMasterRepository.findById(newPropertyWorkFlowLevel.getApplicationId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newPropertyWorkFlowLevel.getApplicationId().getId()));

        UserMaster nextUser = getNextRoleForApplication(existingApplication, nextRole);

        // Validate previousRole
        if (nextRole == null) {
            throw new IllegalStateException("Previous role is required but not provided.");
        }

        // Check if citizenId is provided (since workflowMasterId is 2, we need to handle the citizen case)
        if (newPropertyWorkFlowLevel.getCitizenId() != null) {
            WorkFlowMaster backToCitizenMaster = workFlowMasterRepository.findById(5L)
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster with ID 5 not found"));

            newPropertyWorkFlowLevel.setWorkFlowMasterId(backToCitizenMaster);

            updateRejectStatus(newPropertyWorkFlowLevel.getApplicationId().getId(), rejectDocumentIds);

            return handleBackToCitizenStatus(newPropertyWorkFlowLevel, currentRole);  // Handle transition to citizen
        }

        newPropertyWorkFlowLevel.setNextUserId(nextUser);
        newPropertyWorkFlowLevel.setWardId(existingApplication.getAuthWardMaster().getId());
        newPropertyWorkFlowLevel.setZoneId(existingApplication.getAuthZoneMaster().getId());
        newPropertyWorkFlowLevel.setNextRoleId(nextRole);
        newPropertyWorkFlowLevel.setCreatedDate(LocalDateTime.now());
        newPropertyWorkFlowLevel.setStatusCode(currentStatus.getStatusCode());
        newPropertyWorkFlowLevel.setStatus(currentStatus.getStatus());
        newPropertyWorkFlowLevel.setMailStatus(2);

        updateRejectStatus(newPropertyWorkFlowLevel.getApplicationId().getId(), rejectDocumentIds);

        return newPropertyWorkFlowLevelRepository.save(newPropertyWorkFlowLevel);
    }

    /**
     * Update approved_status to 0 for rejected documents
     */
    private void updateRejectStatus(Long applicationId, List<Long> rejectDocumentIds) {
        if (rejectDocumentIds == null || rejectDocumentIds.isEmpty()) {
            System.out.println("No documents to update for rejection.");
            return;
        }

        List<ViewMunicipalPropertyDocumentUploadDetails> documentDetails =
                viewMunicipalPropertyDocumentUploadDetailsRepository.findAllById(rejectDocumentIds);

        if (documentDetails.isEmpty()) {
            System.out.println("No matching documents found for rejection.");
            return;
        }

        documentDetails.forEach(details -> details.setApprovedStatus(0f)); // Set approved_status to 0

        // Save all updates in batch
        viewMunicipalPropertyDocumentUploadDetailsRepository.saveAll(documentDetails);

        System.out.println("Updated " + documentDetails.size() + " documents to rejected status.");
    }


    private NewPropertyWorkFlowLevel handleBackToCitizenStatus(NewPropertyWorkFlowLevel workFlow, RoleMaster currentRole) {
        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlow.getWorkFlowMasterId().getId())
                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

        ViewMunicipalPropertyMaster existingApplication = viewMunicipalPropertyMasterRepository.findById(workFlow.getApplicationId().getId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + workFlow.getApplicationId().getId()));


//        Long nextUserId = workFlow.getNextUserId().getId();
        Long currentUserId = workFlow.getCurrentUserId().getId();

        if (workFlowMaster.getId().equals(5L)) {
            workFlow.setStatus(workFlowMaster.getStatus());
            workFlow.setStatusCode(workFlowMaster.getStatusCode());

            workFlow.setWardId(existingApplication.getAuthWardMaster().getId());
            workFlow.setZoneId(existingApplication.getAuthZoneMaster().getId());
            workFlow.setNextUserId(null);
            workFlow.setNextRoleId(null);
            workFlow.setCurrentRoleId(workFlow.getCurrentRoleId());
            //workFlow.setNextRoleId(workFlow.getNextRoleId());
            workFlow.setCurrentUserId(workFlow.getCurrentUserId());
            workFlow.setCitizenId(workFlow.getCitizenId());
        }
        workFlow.setMailStatus(1);
        workFlow.setCreatedDate(LocalDateTime.now());
        return newPropertyWorkFlowLevelRepository.save(workFlow);
    }

//    private NewWorkFlowLevel handleBackToCitizenInBackWardCaseStatus(NewWorkFlowLevel newWorkFlowLevel, WorkFlowMaster currentStatus, RoleMaster currentRole, RoleMaster nextRole, UserMaster currentUser) {
//        WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(newWorkFlowLevel.getWorkFlowMasterId().getId())
//                .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));
//
//        if (currentRole == null) {
//            throw new IllegalStateException("Current role is required for Backward action.");
//        }
//
//        if (currentUser == null || currentUser.getRoleMaster() == null) {
//            throw new IllegalStateException("Current user or user's role is missing.");
//        }
//
//        if (!currentUser.getRoleMaster().getId().equals(currentRole.getId())) {
//            String username = currentUser.getUsername();
//            throw new SecurityException("User '" + username + "' is not authorized to perform Backward action.");
//        }
//
//
//        List<PropertyRolesDataFlowSetup> validNextRoles = propertyRolesDataFlowSetupService.getNextRoleListForListSelection(currentRole.getId(), workFlowMaster.getStatusCode(), 1);
//        boolean isValidNextRole = validNextRoles.stream()
//                .anyMatch(role -> role.getNextRoleId().equals(nextRole.getId()));
//
//        if (!isValidNextRole) {
//            throw new IllegalArgumentException("Provided nextRoleId (" + nextRole.getId() + ") is not valid for backward action from currentRoleId (" + currentRole.getId() + ")");
//        }
//
//        List<Long> roleIds = validNextRoles.stream()
//                .map(PropertyRolesDataFlowSetup::getNextRoleId)
//                .collect(Collectors.toList());
//
//        List<RoleMaster> nextRoles = roleMasterRepository.findAllById(roleIds);
//
//        ViewMunicipalPropertyMaster existingApplication = viewMunicipalPropertyMasterRepository.findById(newWorkFlowLevel.getApplicationId().getId())
//                .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + newWorkFlowLevel.getApplicationId().getId()));
//
//        UserMaster nextUser = getNextRoleForApplication(existingApplication, nextRole);
//
//        newWorkFlowLevel.setNextUserId(nextUser);
//        newWorkFlowLevel.setWardId(existingApplication.getAuthWardMaster().getId());
//        newWorkFlowLevel.setZoneId(existingApplication.getAuthZoneMaster().getId());
//        newWorkFlowLevel.setNextRoleId(nextRole);
//        newWorkFlowLevel.setStatus(workFlowMaster.getStatus());
//        newWorkFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
//        newWorkFlowLevel.setCreatedDate(LocalDateTime.now());
//        newWorkFlowLevel.setMailStatus(2);
//
//        return newWorkFlowLevelRepository.save(newWorkFlowLevel);
//    }


    private NewPropertyWorkFlowLevel forwardFromBackWard(NewPropertyWorkFlowLevel workFlowLevel) {

        Long currentRoleId = workFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));
        Long applicationId = workFlowLevel.getApplicationId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = workFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewPropertyWorkFlowLevel latestWorkFlow = newPropertyWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1001) {

            workFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewMunicipalPropertyMaster existingApplication = viewMunicipalPropertyMasterRepository.findById(workFlowLevel.getApplicationId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + workFlowLevel.getApplicationId().getId()));

            UserMaster nextUser = getNextRoleForApplication(existingApplication, workFlowLevel.getNextRoleId());

            workFlowLevel.setNextUserId(nextUser);
            workFlowLevel.setWardId(existingApplication.getAuthWardMaster().getId());
            workFlowLevel.setZoneId(existingApplication.getAuthZoneMaster().getId());
            workFlowLevel.setCreatedDate(LocalDateTime.now());
            workFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            workFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            workFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(workFlowLevel.getApplicationId().getId());
            return newPropertyWorkFlowLevelRepository.save(workFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private NewPropertyWorkFlowLevel forwardFromBackOffice(NewPropertyWorkFlowLevel workFlowLevel) {

        Long currentRoleId = workFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));
        Long applicationId = workFlowLevel.getApplicationId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = workFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewPropertyWorkFlowLevel latestWorkFlow = newPropertyWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1007) {

            workFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewMunicipalPropertyMaster existingApplication = viewMunicipalPropertyMasterRepository.findById(workFlowLevel.getApplicationId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + workFlowLevel.getApplicationId().getId()));

            UserMaster nextUser = getNextRoleForApplication(existingApplication, workFlowLevel.getNextRoleId());

            workFlowLevel.setNextUserId(nextUser);
            workFlowLevel.setWardId(existingApplication.getAuthWardMaster().getId());
            workFlowLevel.setZoneId(existingApplication.getAuthZoneMaster().getId());
            workFlowLevel.setCreatedDate(LocalDateTime.now());
            workFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            workFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            workFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(workFlowLevel.getApplicationId().getId());
            return newPropertyWorkFlowLevelRepository.save(workFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }

    private NewPropertyWorkFlowLevel forwardFromCitizen(NewPropertyWorkFlowLevel workFlowLevel) {

        Long currentRoleId = workFlowLevel.getCurrentRoleId().getId();  // Get RoleMasterId for Current User
        RoleMaster currentRole = roleMasterRepository.findById(currentRoleId)
                .orElseThrow(() -> new RuntimeException("Current Role not found"));
        Long applicationId = workFlowLevel.getApplicationId().getId();
        if (applicationId == null) {
            throw new IllegalArgumentException("Application ID cannot be null");
        }
        Long statusCode = workFlowLevel.getStatusCode();
        // Fetch the latest WorkFlowLevel entry for the given applicationId and statusCode
        NewPropertyWorkFlowLevel latestWorkFlow = newPropertyWorkFlowLevelRepository
                .findLatestWorkFlowByApplicationIdAndStatusCode(applicationId, statusCode)
                .orElseThrow(() -> new RuntimeException("No workflow found for application ID: " + applicationId));

        System.out.println("latestWorkFlow: " + latestWorkFlow);

        if (latestWorkFlow.getStatusCode() == 1004) {

            workFlowLevel.setNextRoleId(latestWorkFlow.getCurrentRoleId());

            WorkFlowMaster workFlowMaster = workFlowMasterRepository.findById(workFlowLevel.getWorkFlowMasterId().getId())
                    .orElseThrow(() -> new RuntimeException("WorkFlowMaster not found"));

            ViewMunicipalPropertyMaster existingApplication = viewMunicipalPropertyMasterRepository.findById(workFlowLevel.getApplicationId().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with ID: " + workFlowLevel.getApplicationId().getId()));

            UserMaster nextUser = getNextRoleForApplication(existingApplication, workFlowLevel.getNextRoleId());

            workFlowLevel.setNextUserId(nextUser);
            workFlowLevel.setWardId(existingApplication.getAuthWardMaster().getId());
            workFlowLevel.setZoneId(existingApplication.getAuthZoneMaster().getId());
            workFlowLevel.setCreatedDate(LocalDateTime.now());
            workFlowLevel.setStatusCode(workFlowMaster.getStatusCode());
            workFlowLevel.setStatus("Forwarded from " + currentRole.getRoleName());
            workFlowLevel.setMailStatus(1);

            // Update approved_status in ViewMunicipalPropertyDocumentUploadDetails
            updateApprovedStatus(workFlowLevel.getApplicationId().getId());
            return newPropertyWorkFlowLevelRepository.save(workFlowLevel);
        }
        throw new IllegalStateException("Invalid workflow operation. Expected Backward or Forwarded status.");
    }


}