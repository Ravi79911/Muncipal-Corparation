package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyWaterConnectionDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyWaterConnectionDetailsRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyWaterConnectionDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyWaterConnectionDetailsServiceImpl implements PropertyWaterConnectionDetailsService {

    @Autowired
    PropertyWaterConnectionDetailsRepository propertyWaterConnectionDetailsRepository;

    @Override
    public PropertyWaterConnectionDetails createPropertyWaterConnectionDetails(PropertyWaterConnectionDetails propertyWaterConnectionDetails) {
        propertyWaterConnectionDetails.setCreatedDate(LocalDateTime.now());
        return propertyWaterConnectionDetailsRepository.saveAndFlush(propertyWaterConnectionDetails);
    }

    @Override
    public List<PropertyWaterConnectionDetails> getAllPropertyWaterConnectionDetails() {
        return propertyWaterConnectionDetailsRepository.findAll();
    }

    @Override
    public Optional<PropertyWaterConnectionDetails> getPropertyWaterConnectionDetailsById(Long id) {
        return propertyWaterConnectionDetailsRepository.findById(id);
    }

    @Override
    public List<PropertyWaterConnectionDetails> getPropertyWaterConnectionDetailsByMunicipalId(int municipalId) {
        return propertyWaterConnectionDetailsRepository.findByMunicipalId(municipalId);
    }

    @Override
    public PropertyWaterConnectionDetails patchPropertyWaterConnectionDetailsSuspendedStatus(Long id, int suspendedStatus) {
        Optional<PropertyWaterConnectionDetails> patchPropertyWaterConnection = propertyWaterConnectionDetailsRepository.findById(id);
        if (patchPropertyWaterConnection.isPresent()) {
            PropertyWaterConnectionDetails existingPropertyWaterConnection = patchPropertyWaterConnection.get();
            existingPropertyWaterConnection.setSuspendedStatus(suspendedStatus);
            return propertyWaterConnectionDetailsRepository.saveAndFlush(existingPropertyWaterConnection);
        } else {
            throw new RuntimeException("property water connection details not found with id: " + id);
        }
    }
}
