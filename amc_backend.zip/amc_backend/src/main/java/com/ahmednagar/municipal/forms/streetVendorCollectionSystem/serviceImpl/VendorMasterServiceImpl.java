package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorMaster;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorMasterRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VendorMasterServiceImpl implements VendorMasterService {

    @Autowired
    private VendorMasterRepository vendorMasterRepository;

    @Override
    public VendorMaster saveVendorMaster(VendorMaster vendorMaster) {
        vendorMaster.setCreatedDate(LocalDateTime.now());
        vendorMaster.setSuspendedStatus(0);
        return vendorMasterRepository.saveAndFlush(vendorMaster);
    }

    @Override
    public Optional<VendorMaster> findByIdVendorMaster(Long id) {
        return vendorMasterRepository.findById(id);
    }

    @Override
    public Optional<VendorMaster> updateVendorMaster(Long id, VendorMaster vendorMaster) {
        Optional<VendorMaster> updateVendorMaster=vendorMasterRepository.findById(id);
        if(updateVendorMaster.isPresent()) {
            updateVendorMaster.get().setVendorNameEng(vendorMaster.getVendorNameEng());
            updateVendorMaster.get().setVendorNameMrathi(vendorMaster.getVendorNameMrathi());
            updateVendorMaster.get().setVendorAddrs(vendorMaster.getVendorAddrs());
            updateVendorMaster.get().setMobileNo(vendorMaster.getMobileNo());
            updateVendorMaster.get().setEmailId(vendorMaster.getEmailId());
            updateVendorMaster.get().setShopName(vendorMaster.getShopName());
            updateVendorMaster.get().setStreetName(vendorMaster.getStreetName());
            updateVendorMaster.get().setMarketNameId(vendorMaster.getMarketNameId());
            updateVendorMaster.get().setVendorTypeId(vendorMaster.getVendorTypeId());
            updateVendorMaster.get().setNatureBussinesId(vendorMaster.getNatureBussinesId());
            updateVendorMaster.get().setUpdatedDate(LocalDateTime.now());
            updateVendorMaster.get().setUpdatedBy(vendorMaster.getUpdatedBy());
            return Optional.of(vendorMasterRepository.saveAndFlush(updateVendorMaster.get()));
        }
        return updateVendorMaster;
    }

    @Override
    public List<VendorMaster> getAllVendorMasters() {
        return vendorMasterRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<VendorMaster> deleteVendorMaster(Long id) {
        Optional<VendorMaster> vendorMaster = vendorMasterRepository.findById(id);
        if(vendorMaster.isPresent()){
            vendorMaster.get().setSuspendedStatus(1);
            return Optional.of(vendorMasterRepository.saveAndFlush(vendorMaster.get()));
        }
        return vendorMaster;
    }

    @Override
    public List<VendorMaster> getVendors(Long marketNameId, String vendorNameEng) {
        return vendorMasterRepository.findByMarketNameIdAndVendorNameEng(marketNameId, vendorNameEng);
    }
}
