package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationFeePayMasterDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFeePayMaster;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface ApplicationFeePayMasterService {
    ApplicationFeePayMaster saveApplicationFeePayMaster(ApplicationFeePayMaster applicationFeePayMaster, int createdBy);

//    List<ApplicationFeePayMasterDto> findAllApplicationFeePayMaster();
//
//    List<ApplicationFeePayMaster> findAllActiveApplicationFeePayMaster(Integer status);

    ApplicationFeePayMaster findApplicationFeePayMasterById(int id);

    List<ApplicationFeePayMasterDto> findAllApplicationFeePayMasterByMunicipalId(int municipalId);

    ApplicationFeePayMaster updateApplicationFeePayMaster(int id, ApplicationFeePayMaster updatedApplicationFeePayMaster, int updatedBy);

    ApplicationFeePayMaster changeSuspendedStatus(int id, int status, int updatedBy);
}
