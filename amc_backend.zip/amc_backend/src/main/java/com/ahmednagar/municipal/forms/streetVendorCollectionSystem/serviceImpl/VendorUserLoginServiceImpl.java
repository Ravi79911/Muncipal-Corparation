package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;


import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserLoginMaster;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorUserLoginMasterRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorUserLoginService;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.util.VendorGenerateStrongPassword;
import com.ahmednagar.municipal.notification.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;


import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class VendorUserLoginServiceImpl implements VendorUserLoginService {

    @Autowired
    private VendorUserLoginMasterRepository vendorUserLoginMasterRepository;

    @Autowired
    EmailService emailService;

    private final BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

    @Override
    public VendorUserLoginMaster login(String userName, String password) {
        Optional<VendorUserLoginMaster> user = vendorUserLoginMasterRepository.findByUserName(userName);
        if (user.isPresent() && bCryptPasswordEncoder.matches(password, user.get().getPassword())) {
            return user.get();
        } else {
            throw new RuntimeException("Invalid username or password");
        }
    }

    public VendorUserLoginMaster createUser(VendorUserLoginMaster user) {
        // Generate a random strong password
        String generatedPassword = VendorGenerateStrongPassword.generateStrongPassword();

        // Set up other fields
        user.setPassword(bCryptPasswordEncoder.encode(generatedPassword));
        user.setCreatedDate(LocalDateTime.now());
        user.setSuspendedStatus(0);

        // Save the user in the database
        VendorUserLoginMaster savedUser = vendorUserLoginMasterRepository.saveAndFlush(user);

        // Retrieve associated VendorUser details
        VendorUserLoginMaster userWithVendorUser = vendorUserLoginMasterRepository.findByIdWithVendorUser(savedUser.getId());
        String vendorUserName = userWithVendorUser.getVendorUser().getName();

        // Send notification with the generated password
        sendNotifications(savedUser, generatedPassword, vendorUserName);

        return savedUser;
    }

    @Override
    public void updateUserPassword(Long userId, String oldPassword, String newPassword) {
        // Fetch the user by ID
        VendorUserLoginMaster user = vendorUserLoginMasterRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Validate the old password
        if (!bCryptPasswordEncoder.matches(oldPassword, user.getPassword())) {
            throw new RuntimeException("Old password is incorrect");
        }

        // Update the password fields
        user.setPreviousPassword(user.getPassword());
        user.setPassword(bCryptPasswordEncoder.encode(newPassword));
        user.setLoginFlag(1);
        // Update the user in the database
        // Save the updated user
        vendorUserLoginMasterRepository.save(user);
        String vendorUserName = user.getVendorUser().getName();
        sendPasswordUpdateNotification(user, vendorUserName);
    }


//    private void sendNotifications(VendorUserLoginMaster vendorUserLoginMaster, String plainPassword, String vendorUserName) {
//        String messageContent =
//                "Dear " + vendorUserName + ",\n\n" +
//                        "We are excited to inform you that your registration has been successfully completed in Street Vendor Payment Collection System.\nBelow are your login credentials:\n\n" +
//                        "Username: " + vendorUserLoginMaster.getUserName() + "\n" +
//                        "Password: " + plainPassword + "\n\n" +
//                        "Please make sure to keep this information secure.\n\n" +
//                        "You can now log in to your account and start exploring our services.\n\n" +
//                        "Thank you for joining us!\n\n" +
//                        "Best regards,\n" +
//                        "Swati Industries\n" +
//                        "https://swatiind.com/";
//        emailService.sendEmail(vendorUserLoginMaster.getUserName(), "User Registration Successful", messageContent);
//    }

    private void sendNotifications(VendorUserLoginMaster vendorUserLoginMaster, String plainPassword, String vendorUserName) {
        String htmlMessageContent = buildHtmlEmailContent(vendorUserName, vendorUserLoginMaster.getUserName(), plainPassword);
        try {
            emailService.sendEmail(
                    vendorUserLoginMaster.getUserName(),
                    "User Registration Successful",
                    htmlMessageContent
            );
        } catch (Exception e) {
            throw new RuntimeException("Failed to send email: " + e.getMessage(), e);
        }
    }

    private String buildHtmlEmailContent(String vendorUserName, String username, String password) {
        return "<div style='font-family:Arial, sans-serif; line-height:1.5;'>"
                + "<h3>Dear " + vendorUserName + ",</h3>"
                + "<p>We are excited to inform you that your registration has been successfully completed in Street Vendor Payment Collection System.</p>"
                + "<p><b>Below are your login credentials:</b></p>"
                + "<p><b>Username:</b> " + username + "<br>"
                + "<b>Password:</b> " + password + "</p>"
                + "<p>Please make sure to keep this information secure.</p>"
                + "<p>You can now log in to your account and start exploring our services.</p>"
                + "<p>Thank you for joining us!</p>"
                + "<p style='margin-top:20px;'>Best regards,<br>Swati Industries<br>"
                + "<a href='https://swatiind.com/' target='_blank'>https://swatiind.com/</a></p>"
                + "</div>";
    }

    //for update password email
    private void sendPasswordUpdateNotification(VendorUserLoginMaster vendorUserLoginMaster, String vendorUserName) {
        String htmlMessageContent = buildPasswordUpdateEmailContent(vendorUserName, vendorUserLoginMaster.getUserName());
        try {
            emailService.sendEmail(
                    vendorUserLoginMaster.getUserName(),
                    "Password Updated Successfully",
                    htmlMessageContent
            );
        } catch (Exception e) {
            throw new RuntimeException("Failed to send email: " + e.getMessage(), e);
        }
    }

    private String buildPasswordUpdateEmailContent(String vendorUserName, String username) {
        return "<div style='font-family:Arial, sans-serif; line-height:1.5;'>"
                + "<h3>Dear " + vendorUserName + ",</h3>"
                + "<p>We wanted to let you know that your password for the Street Vendor Payment Collection System has been successfully updated.</p>"
                + "<p>If you did not request this change, please contact our support team immediately.</p>"
                + "<p>For your reference:</p>"
                + "<p><b>Username:</b> " + username + "</p>"
                + "<p>If you encounter any issues logging into your account, feel free to reach out to us.</p>"
                + "<p>Thank you for using our services!</p>"
                + "<p style='margin-top:20px;'>Best regards,<br>Swati Industries<br>"
                + "<a href='https://swatiind.com/' target='_blank'>https://swatiind.com/</a></p>"
                + "</div>";
    }

}
