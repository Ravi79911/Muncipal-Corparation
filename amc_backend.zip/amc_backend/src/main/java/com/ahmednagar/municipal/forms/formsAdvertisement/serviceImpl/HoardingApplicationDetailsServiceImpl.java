package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingApplicationDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingApplicationDetailsRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingApplicationDetailsService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingApplicationDetailsServiceImpl implements HoardingApplicationDetailsService {
    @Autowired
    private HoardingApplicationDetailsRepository hoardingApplicationDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingApplicationDetails saveHoardingApplicationDetails(HoardingApplicationDetails hoardingApplicationDetails) {
        hoardingApplicationDetails.setCreatedDate(LocalDateTime.now());
        hoardingApplicationDetails.setUpdatedDate(LocalDateTime.now());
        hoardingApplicationDetails.setUpdatedBy(hoardingApplicationDetails.getUpdatedBy() != null ? hoardingApplicationDetails.getUpdatedBy() : 0);
        hoardingApplicationDetails.setSuspendedStatus(hoardingApplicationDetails.getSuspendedStatus() != null ? hoardingApplicationDetails.getSuspendedStatus() : 0);

        return hoardingApplicationDetailsRepository.save(hoardingApplicationDetails);

    }

    @Override
    public List<HoardingApplicationDetailsDto> findAllHoardingApplicationDetails() {
        List<HoardingApplicationDetails> hoardingApplicationDetails = hoardingApplicationDetailsRepository.findAll();
        return hoardingApplicationDetails.stream()
                .map(hoardingApplicationDetails1 -> modelMapper.map(hoardingApplicationDetails1, HoardingApplicationDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingApplicationDetails findById(Long id) {
        Optional<HoardingApplicationDetails> hoardingApplicationDetails=hoardingApplicationDetailsRepository.findById(id);
        return hoardingApplicationDetails.orElse(null);

    }

    @Override
    public List<HoardingApplicationDetails> findAllByMunicipalId(int municipalId) {
        return hoardingApplicationDetailsRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingApplicationDetails updateHoardingApplicationDetails(Long id, HoardingApplicationDetails updatedHoardingApplicationDetails, int updatedBy) {
        Optional<HoardingApplicationDetails> hoardingApplicationDetailsOptional = hoardingApplicationDetailsRepository.findById(id);
        if (hoardingApplicationDetailsOptional.isPresent()) {
            HoardingApplicationDetails existingHoardingApplicationDetails = hoardingApplicationDetailsOptional.get();
            //existingHoardingApplicationDetails.setHoardingCategoryTypeName(updatedHoardingApplicationDetails.getHoardingCategoryTypeName());
            existingHoardingApplicationDetails.setUpdatedBy(updatedBy);
            existingHoardingApplicationDetails.setUpdatedDate(LocalDateTime.now());
            return hoardingApplicationDetailsRepository.saveAndFlush(existingHoardingApplicationDetails);
        } else {
            throw new RuntimeException("hoardingApplicationDetails not found with id: " + id);
        }
    }

    @Override
    public HoardingApplicationDetails changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingApplicationDetails> hoardingApplicationDetailsOpt = hoardingApplicationDetailsRepository.findById(id);
        if (hoardingApplicationDetailsOpt.isPresent()) {
            HoardingApplicationDetails hoardingApplicationDetails = hoardingApplicationDetailsOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingApplicationDetails.setUpdatedDate(currentDateTime);
            hoardingApplicationDetails.setSuspendedStatus(status);      // 1 means suspended
            hoardingApplicationDetails.setUpdatedBy(updatedBy);
            return hoardingApplicationDetailsRepository.saveAndFlush(hoardingApplicationDetails);
        }
        return null;
    }
}