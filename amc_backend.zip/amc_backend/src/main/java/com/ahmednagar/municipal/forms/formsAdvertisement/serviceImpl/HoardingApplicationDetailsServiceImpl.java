package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingApplicationDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingAllottedDemand;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingAllottedDemandRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingApplicationDetailsRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingApplicationDetailsService;
import com.ahmednagar.municipal.forms.formsAdvertisement.utils.AdvertisementApplicationNumberGenerator;
import com.ahmednagar.municipal.master.advertisement.model.HoardingCategoryTypeMasterSetup;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeMasterSetup;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeRateMasterSetup;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeSizeMasterSetup;
import com.ahmednagar.municipal.master.advertisement.repository.*;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingApplicationDetailsServiceImpl implements HoardingApplicationDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(HoardingApplicationMasterServiceImpl.class);

    @Autowired
    private HoardingApplicationDetailsRepository hoardingApplicationDetailsRepository;

    @Autowired
    private HoardingTypeRateMasterSetupRepository hoardingTypeRateMasterSetupRepository;

    @Autowired
    private HoardingTypeSizeMasterSetupRepository hoardingTypeSizeMasterSetupRepository;

    @Autowired
    private HoardingTypeMasterSetupRepository hoardingTypeMasterSetupRepository;

    @Autowired
    private ViewAdvertisementZoneMasterRepository viewAdvertisementZoneMasterRepository;

    @Autowired
    private ViewAdvertisementWardMasterRepository viewAdvertisementWardMasterRepository;

    @Autowired
    private HoardingAllottedDemandRepository hoardingAllottedDemandRepository;

    @Autowired
    private HoardingCategoryTypeMasterSetupRepository hoardingCategoryTypeMasterSetupRepository;

    @Autowired
    private AdvertisementApplicationNumberGenerator advertisementApplicationNumberGenerator;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingApplicationDetails saveHoardingApplicationDetails(HoardingApplicationDetails hoardingApplicationDetails) {
        hoardingApplicationDetails.setCreatedDate(LocalDateTime.now());
        hoardingApplicationDetails.setUpdatedDate(LocalDateTime.now());
        hoardingApplicationDetails.setUpdatedBy(hoardingApplicationDetails.getUpdatedBy() != null ? hoardingApplicationDetails.getUpdatedBy() : 0);
        hoardingApplicationDetails.setSuspendedStatus(hoardingApplicationDetails.getSuspendedStatus() != null ? hoardingApplicationDetails.getSuspendedStatus() : 0);

        // check if the provided zone id exists
        if (!viewAdvertisementZoneMasterRepository.existsById(hoardingApplicationDetails.getZoneId().getId())) {
            throw new IllegalArgumentException("invalid zone id: " + hoardingApplicationDetails.getZoneId() + ". zone doesn't exist.");
        }

        // check if the provided ward id exists and belongs to the provided zone id
        boolean wardBelongsToZone = viewAdvertisementWardMasterRepository.existsByIdAndZoneMasId(hoardingApplicationDetails.getWardId().getId(), hoardingApplicationDetails.getZoneId().getId());
        if (!wardBelongsToZone) {
            throw new IllegalArgumentException("invalid ward id: " + hoardingApplicationDetails.getWardId() +
                    " or it does not belong to the provided zone id: " + hoardingApplicationDetails.getZoneId() + ".");
        }

        // Fetch the Hoarding Rate Master based on HoardingTypeRateMasterId
        HoardingTypeRateMasterSetup hoardingTypeRateMasterSetup = hoardingTypeRateMasterSetupRepository.findByIdWithNullHandling(hoardingApplicationDetails.getHoardingTypeRateMasterId().getId())
                .orElseThrow(() -> new IllegalArgumentException("HoardingRateMaster not found"));

//            HoardingTypeSizeMasterSetup hoardingTypeSizeMasterSetup = hoardingTypeSizeMasterSetupRepository.findById(hoardingApplicationDetails.getHoardingTypeSizeMasterId().getId())
//                    .orElseThrow(() -> new IllegalArgumentException("HoardingTypeSizeMaster not found for ID: " + hoardingApplicationDetails.getHoardingTypeSizeMasterId().getId()));

        // Compare hoarding_category_type_master_id
        if (!hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId().equals(hoardingApplicationDetails.getHoardingCategoryTypeMasterId().getId())) {
            throw new IllegalArgumentException("Mismatch between hoarding_category_type_master_id in HoardingTypeRateMasterSetup and the passed parameter");
        }

        // Compare usage_type_id
        if (!hoardingTypeRateMasterSetup.getUsageTypeId().getId().equals(hoardingApplicationDetails.getUsageTypeId().getId())) {
            throw new IllegalArgumentException("Mismatch between usage_type_id in HoardingTypeRateMasterSetup and the passed parameter");
        }

        // Calculate period days and months
        if (hoardingApplicationDetails.getAllocatedFromDate() != null && hoardingApplicationDetails.getAllocatedUptoDate() != null) {
            LocalDate fromDate = hoardingApplicationDetails.getAllocatedFromDate();
            LocalDate uptoDate = hoardingApplicationDetails.getAllocatedUptoDate();

            // Calculate the period in days
            long calculatedPeriodDays = ChronoUnit.DAYS.between(fromDate, uptoDate)+1;

            // Calculate the period in months (based on 30 days per month)
            long calculatedPeriodMonths = (calculatedPeriodDays > 0)
                    ? ((calculatedPeriodDays - 1) / 30) + 1
                    : 0;

            // Calculate the period in years (based on 365 days per year)
            long calculatedPeriodYears = (calculatedPeriodDays > 0)
                    ? ((calculatedPeriodDays - 1) / 365) + 1
                    : 0;

            hoardingApplicationDetails.setCalculatedPeriodDays(calculatedPeriodDays);
            hoardingApplicationDetails.setCalculatedPeriodMonths(calculatedPeriodMonths);
            hoardingApplicationDetails.setCalculatedPeriodYears(calculatedPeriodYears);

            // Fetch calculation type from the hoarding_type_master_setup table
            Long hoardingTypeMasterId = hoardingApplicationDetails.getHoardingTypeMasterId().getId();
            HoardingTypeMasterSetup typeMaster = hoardingTypeMasterSetupRepository.findById(hoardingTypeMasterId)
                    .orElseThrow(() -> new IllegalArgumentException("Invalid Hoarding Type Master ID"));

            String calculationType = typeMaster.getCalculationType();

            // If the calculation type is VARIABLE, calculate the area_in_variable
            if ("VARIABLE".equalsIgnoreCase(calculationType)) {
                BigDecimal areaInVariable = BigDecimal.valueOf(0.0);

                // Fetch length and width for VARIABLE calculation
                BigDecimal hoardingLengthSqft = hoardingApplicationDetails.getHoardingLengthSqft();
                BigDecimal hoardingWidthSqft = hoardingApplicationDetails.getHoardingWidthSqft();

                // Calculate the area in VARIABLE based on length and width
                areaInVariable = hoardingLengthSqft.multiply(hoardingWidthSqft);
                hoardingApplicationDetails.setHoardingSize(areaInVariable);

                // Set hoarding_type_size_master_id to a default value (e.g., 0 or a placeholder ID)
                hoardingApplicationDetails.setHoardingTypeSizeMasterId(null); // Set to empty object or default ID

            } else {
                // Use the area fetched from the size master setup if calculation type is not VARIABLE
                Optional<HoardingTypeSizeMasterSetup> fixedhordingtypemaster = hoardingTypeSizeMasterSetupRepository.findById(hoardingApplicationDetails.getHoardingTypeSizeMasterId().getId());
                if (fixedhordingtypemaster.isPresent()) {
                    HoardingTypeSizeMasterSetup fixedHording = fixedhordingtypemaster.get();
                    hoardingApplicationDetails.setHoardingSize(fixedHording.getArea());
                }
            }

            // Calculate the amount based on (rate * area) * calculatedPeriodDays
            BigDecimal rate = hoardingTypeRateMasterSetup.getRateInSqft();
//            BigDecimal area = hoardingTypeSizeMasterSetup.getArea();
            BigDecimal area = hoardingApplicationDetails.getHoardingSize();
            hoardingApplicationDetails.setHoardingRateSqft(rate);
            hoardingApplicationDetails.setHoardingSize(area);

            BigDecimal calculatedAmount;

            System.out.println(hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId());
            // Calculate based on hoarding_category_type_master_id
            if (hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId() != null &&
                    hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId().equals(1L)) {
                // Calculate amount for hoarding_category_type_master_id = 1 (monthly calculation)
                calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(calculatedPeriodMonths));

            } else if (hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId() != null &&
                    hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId().equals(2L)) {
                // Retrieve the calculation method
                String calculationMethod = hoardingTypeRateMasterSetup.getCalculationMethod(); // e.g., "DAYS", "MONTHS", or "YEARS"

                switch (calculationMethod) {
                    case "DAYS":
                        calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(calculatedPeriodDays));
                        break;

                    case "MONTHS":
                        calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(calculatedPeriodMonths));
                        break;

                    case "YEARS":
                        calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(calculatedPeriodYears));
                        break;

                    default:
                        throw new IllegalArgumentException("Invalid calculation method in hoarding_type_rate_master_setup");
                }
            } else {
                throw new IllegalArgumentException("Invalid hoarding_category_type_master_id");
            }
            hoardingApplicationDetails.setCalculatedAmount(calculatedAmount.toPlainString());
        } else {
            throw new IllegalArgumentException("Allocated from date and upto date must not be null");
        }

        HoardingApplicationDetails hoardingApplicationDetails1 = hoardingApplicationDetailsRepository.saveAndFlush(hoardingApplicationDetails);

        // validate and set hoarding category type id
        HoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterSetup = hoardingCategoryTypeMasterSetupRepository.findById(
                        hoardingApplicationDetails.getHoardingCategoryTypeMasterId().getId())
                .orElseThrow(() -> new IllegalArgumentException("invalid hoardingCategoryTypeMaster id"));

        hoardingApplicationDetails.setHoardingCategoryTypeMasterId(hoardingCategoryTypeMasterSetup);

        // normalize application type name for case-insensitive comparison
        String hoardingCategoryTypeName = hoardingCategoryTypeMasterSetup.getHoardingCategoryTypeName().trim().toLowerCase();

        // generate and set license number based on application type name
        String generatedDemandNumber = switch (hoardingCategoryTypeName.toLowerCase()) {
            case "permanent hoarding" ->
                    advertisementApplicationNumberGenerator.generatePermanentDemandNo(hoardingCategoryTypeMasterSetup.getId());
            case "temporary hoarding" ->
                    advertisementApplicationNumberGenerator.generateTemporaryDemandNo(hoardingCategoryTypeMasterSetup.getId());
            default -> {
                logger.error("Unknown Application Type Name: {}", hoardingCategoryTypeName);
                throw new IllegalArgumentException("Unknown application type name: " + hoardingCategoryTypeName);
            }
        };

        HoardingAllottedDemand hoardingAllottedDemand = new HoardingAllottedDemand();

        hoardingAllottedDemand.setHoardingApplicationDetailsId(hoardingApplicationDetails1);
        hoardingAllottedDemand.setCreatedDate(LocalDateTime.now());
        hoardingAllottedDemand.setCreatedBy(hoardingApplicationDetails1.getCreatedBy());
        hoardingAllottedDemand.setUpdatedBy(hoardingApplicationDetails1.getCreatedBy());
        hoardingAllottedDemand.setDemandAmount(hoardingApplicationDetails1.getCalculatedAmount());
        hoardingAllottedDemand.setUpdatedDate(LocalDateTime.now());
        hoardingAllottedDemand.setMunicipalId(hoardingApplicationDetails1.getMunicipalId());
        hoardingAllottedDemand.setSuspendedStatus(hoardingApplicationDetails1.getSuspendedStatus());

//        AdvertisementApplicationNumberGenerator demandNumber = new AdvertisementApplicationNumberGenerator();
        //hoardingAllottedDemand.setAutogenDemandNo("PAAP898989");
        hoardingAllottedDemand.setAutogenDemandNo(generatedDemandNumber);

        hoardingAllottedDemandRepository.saveAndFlush(hoardingAllottedDemand);

        return hoardingApplicationDetails1;
    }

    @Override
    public List<HoardingApplicationDetails> createHoardingApplicationDetailsList(List<HoardingApplicationDetails> hoardingApplicationDetailsList) {
        if (hoardingApplicationDetailsList.isEmpty()) {
            throw new IllegalArgumentException("the list of hoardingApplicationDetailsList can't be empty");
        }
        Long firstApplicationMasterId = hoardingApplicationDetailsList.get(0).getHoardingApplicationMasterId().getId();
        boolean allSameApplicationMasterId = hoardingApplicationDetailsList.stream()
                .allMatch(appApplicantDetails -> Objects.equals(appApplicantDetails
                        .getHoardingApplicationMasterId().getId(), firstApplicationMasterId));
        if (!allSameApplicationMasterId) {
            throw new IllegalArgumentException("all application details must have same application form master id");
        }
        LocalDateTime currentDate = LocalDateTime.now();
        List<HoardingApplicationDetails> hoardingApplicationDetailsListToSave = hoardingApplicationDetailsList.stream()
                .peek(hoardingApplicationDetails -> {
                    // Set createdDate and updatedDate
                    hoardingApplicationDetails.setCreatedDate(currentDate);
                    hoardingApplicationDetails.setUpdatedDate(currentDate);

                    // Set updatedBy (default 0 if null)
                    hoardingApplicationDetails.setUpdatedBy(
                            hoardingApplicationDetails.getUpdatedBy() != null ? hoardingApplicationDetails.getUpdatedBy() : 0);

                    // Set suspendedStatus (default 0 if null)
                    hoardingApplicationDetails.setSuspendedStatus(
                            hoardingApplicationDetails.getSuspendedStatus() != null ? hoardingApplicationDetails.getSuspendedStatus() : 0);

                    // Check if the provided zone id exists
                    if (!viewAdvertisementZoneMasterRepository.existsById(hoardingApplicationDetails.getZoneId().getId())) {
                        throw new IllegalArgumentException("Invalid zone id: " + hoardingApplicationDetails.getZoneId() + ". Zone doesn't exist.");
                    }

                    // Check if the provided ward id exists and belongs to the provided zone id
                    boolean wardBelongsToZone = viewAdvertisementWardMasterRepository.existsByIdAndZoneMasId(
                            hoardingApplicationDetails.getWardId().getId(), hoardingApplicationDetails.getZoneId().getId());
                    if (!wardBelongsToZone) {
                        throw new IllegalArgumentException("Invalid ward id: " + hoardingApplicationDetails.getWardId() +
                                " or it does not belong to the provided zone id: " + hoardingApplicationDetails.getZoneId() + ".");
                    }

                    // Fetch the Hoarding Rate Master based on HoardingTypeRateMasterId
                    HoardingTypeRateMasterSetup hoardingTypeRateMasterSetup = hoardingTypeRateMasterSetupRepository.findByIdWithNullHandling(
                                    hoardingApplicationDetails.getHoardingTypeRateMasterId().getId())
                            .orElseThrow(() -> new IllegalArgumentException("HoardingRateMaster not found"));

                    // Compare hoarding_category_type_master_id
                    if (!hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId()
                            .equals(hoardingApplicationDetails.getHoardingCategoryTypeMasterId().getId())) {
                        throw new IllegalArgumentException("Mismatch between hoarding_category_type_master_id in HoardingTypeRateMasterSetup and the passed parameter");
                    }

                    // Compare usage_type_id
                    if (!hoardingTypeRateMasterSetup.getUsageTypeId().getId()
                            .equals(hoardingApplicationDetails.getUsageTypeId().getId())) {
                        throw new IllegalArgumentException("Mismatch between usage_type_id in HoardingTypeRateMasterSetup and the passed parameter");
                    }

                    // Calculate period days and months
                    if (hoardingApplicationDetails.getAllocatedFromDate() != null && hoardingApplicationDetails.getAllocatedUptoDate() != null) {
                        LocalDate fromDate = hoardingApplicationDetails.getAllocatedFromDate();
                        LocalDate uptoDate = hoardingApplicationDetails.getAllocatedUptoDate();

                        // Calculate the period in days
                        long calculatedPeriodDays = ChronoUnit.DAYS.between(fromDate, uptoDate);

                        // Calculate the period in months (based on 30 days per month)
                        long calculatedPeriodMonths = (calculatedPeriodDays > 0) ? ((calculatedPeriodDays - 1) / 30) + 1 : 0;

                        // Calculate the period in years (based on 365 days per year)
                        long calculatedPeriodYears = calculatedPeriodDays / 365;

                        hoardingApplicationDetails.setCalculatedPeriodDays(calculatedPeriodDays);
                        hoardingApplicationDetails.setCalculatedPeriodMonths(calculatedPeriodMonths);
                        hoardingApplicationDetails.setCalculatedPeriodYears(calculatedPeriodYears);

                        // Fetch calculation type from the hoarding_type_master_setup table
                        Long hoardingTypeMasterId = hoardingApplicationDetails.getHoardingTypeMasterId().getId();
                        HoardingTypeMasterSetup typeMaster = hoardingTypeMasterSetupRepository.findById(hoardingTypeMasterId)
                                .orElseThrow(() -> new IllegalArgumentException("Invalid Hoarding Type Master ID"));

                        String calculationType = typeMaster.getCalculationType();

                        // If the calculation type is VARIABLE, calculate the area_in_variable
                        if ("VARIABLE".equalsIgnoreCase(calculationType)) {
                            BigDecimal areaInVariable = BigDecimal.valueOf(0.0);

                            // Fetch length and width for VARIABLE calculation
                            BigDecimal hoardingLengthSqft = hoardingApplicationDetails.getHoardingLengthSqft();
                            BigDecimal hoardingWidthSqft = hoardingApplicationDetails.getHoardingWidthSqft();

                            // Calculate the area in VARIABLE based on length and width
                            areaInVariable = hoardingLengthSqft.multiply(hoardingWidthSqft);
                            hoardingApplicationDetails.setHoardingSize(areaInVariable);

                            // Set hoarding_type_size_master_id to null (if variable calculation)
                            hoardingApplicationDetails.setHoardingTypeSizeMasterId(null);
                        } else {
                            // Use the area fetched from the size master setup if calculation type is not VARIABLE
                            Optional<HoardingTypeSizeMasterSetup> fixedHoardingTypeMaster = hoardingTypeSizeMasterSetupRepository.findById(
                                    hoardingApplicationDetails.getHoardingTypeSizeMasterId().getId());
                            if (fixedHoardingTypeMaster.isPresent()) {
                                HoardingTypeSizeMasterSetup fixedHoarding = fixedHoardingTypeMaster.get();
                                hoardingApplicationDetails.setHoardingSize(fixedHoarding.getArea());
                            }
                        }

                        // Calculate the amount based on rate * area * period
                        BigDecimal rate = hoardingTypeRateMasterSetup.getRateInSqft();
                        BigDecimal area = hoardingApplicationDetails.getHoardingSize();
                        hoardingApplicationDetails.setHoardingRateSqft(rate);
                        hoardingApplicationDetails.setHoardingSize(area);

                        BigDecimal calculatedAmount;

                        // Calculate based on hoarding_category_type_master_id
                        if (hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId().equals(1L)) {
                            // Monthly calculation
                            calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(hoardingApplicationDetails.getCalculatedPeriodMonths()));
                        } else if (hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId().equals(2L)) {
                            String calculationMethod = hoardingTypeRateMasterSetup.getCalculationMethod();
                            switch (calculationMethod) {
                                case "DAYS":
                                    calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(hoardingApplicationDetails.getCalculatedPeriodDays()));
                                    break;
                                case "MONTHS":
                                    calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(hoardingApplicationDetails.getCalculatedPeriodMonths()));
                                    break;
                                case "YEARS":
                                    calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(hoardingApplicationDetails.getCalculatedPeriodYears()));
                                    break;
                                default:
                                    throw new IllegalArgumentException("Invalid calculation method");
                            }
                        } else {
                            throw new IllegalArgumentException("Invalid hoarding_category_type_master_id");
                        }

                        hoardingApplicationDetails.setCalculatedAmount(calculatedAmount.toPlainString());
                    } else {
                        throw new IllegalArgumentException("Allocated from date and upto date must not be null");
                    }
                })
                .collect(Collectors.toList());
        // Save all hoarding application details
        List<HoardingApplicationDetails> savedHoardingDetails = hoardingApplicationDetailsRepository.saveAllAndFlush(hoardingApplicationDetailsListToSave);

        // Save demand records
        for (HoardingApplicationDetails hoardingApplicationDetails : savedHoardingDetails) {
            // Generate the demand number
            HoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterSetup = hoardingCategoryTypeMasterSetupRepository.findById(
                            hoardingApplicationDetails.getHoardingCategoryTypeMasterId().getId())
                    .orElseThrow(() -> new IllegalArgumentException("invalid hoardingCategoryTypeMaster id"));

            String hoardingCategoryTypeName = hoardingCategoryTypeMasterSetup.getHoardingCategoryTypeName().trim().toLowerCase();
            String generatedDemandNumber = switch (hoardingCategoryTypeName) {
                case "permanent hoarding" ->
                        advertisementApplicationNumberGenerator.generatePermanentDemandNo(hoardingCategoryTypeMasterSetup.getId());
                case "temporary hoarding" ->
                        advertisementApplicationNumberGenerator.generateTemporaryDemandNo(hoardingCategoryTypeMasterSetup.getId());
                default -> {
                    logger.error("Unknown Application Type Name: {}", hoardingCategoryTypeName);
                    throw new IllegalArgumentException("Unknown application type name: " + hoardingCategoryTypeName);
                }
            };

            HoardingAllottedDemand hoardingAllottedDemand = new HoardingAllottedDemand();

            hoardingAllottedDemand.setHoardingApplicationDetailsId(hoardingApplicationDetails);
            hoardingAllottedDemand.setCreatedDate(LocalDateTime.now());
            hoardingAllottedDemand.setCreatedBy(hoardingApplicationDetails.getCreatedBy());
            hoardingAllottedDemand.setUpdatedBy(hoardingApplicationDetails.getCreatedBy());
            hoardingAllottedDemand.setDemandAmount(hoardingApplicationDetails.getCalculatedAmount());
            hoardingAllottedDemand.setUpdatedDate(LocalDateTime.now());
            hoardingAllottedDemand.setMunicipalId(hoardingApplicationDetails.getMunicipalId());
            hoardingAllottedDemand.setSuspendedStatus(hoardingApplicationDetails.getSuspendedStatus());

            hoardingAllottedDemand.setAutogenDemandNo(generatedDemandNumber);

            hoardingAllottedDemandRepository.saveAndFlush(hoardingAllottedDemand);
        }

        return savedHoardingDetails;
    }

    @Override
    public List<HoardingApplicationDetailsDto> findAllHoardingApplicationDetails() {
        List<HoardingApplicationDetails> hoardingApplicationDetails = hoardingApplicationDetailsRepository.findAll();
        return hoardingApplicationDetails.stream()
                .map(hoardingApplicationDetails1 -> modelMapper.map(hoardingApplicationDetails1, HoardingApplicationDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingApplicationDetails findById(Long id) {
        Optional<HoardingApplicationDetails> hoardingApplicationDetails = hoardingApplicationDetailsRepository.findById(id);
        return hoardingApplicationDetails.orElse(null);

    }

    @Override
    public List<HoardingApplicationDetails> findAllByMunicipalId(int municipalId) {
        return hoardingApplicationDetailsRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingApplicationDetails updateHoardingApplicationDetails(Long id, HoardingApplicationDetails updatedHoardingApplicationDetails) {
        Optional<HoardingApplicationDetails> hoardingApplicationDetailsOptional = hoardingApplicationDetailsRepository.findById(id);
        if (hoardingApplicationDetailsOptional.isPresent()) {
            HoardingApplicationDetails existingHoardingApplicationDetails = hoardingApplicationDetailsOptional.get();
            existingHoardingApplicationDetails.setCalculatedAmount(updatedHoardingApplicationDetails.getCalculatedAmount());
            existingHoardingApplicationDetails.setCalculatedPeriodDays(updatedHoardingApplicationDetails.getCalculatedPeriodDays());
            existingHoardingApplicationDetails.setCalculatedPeriodMonths(updatedHoardingApplicationDetails.getCalculatedPeriodMonths());
            existingHoardingApplicationDetails.setCalculatedPeriodYears(updatedHoardingApplicationDetails.getCalculatedPeriodYears());
            existingHoardingApplicationDetails.setHoardingLengthSqft(updatedHoardingApplicationDetails.getHoardingLengthSqft());
            existingHoardingApplicationDetails.setHoardingWidthSqft(updatedHoardingApplicationDetails.getHoardingWidthSqft());
            existingHoardingApplicationDetails.setAllocatedFromDate(updatedHoardingApplicationDetails.getAllocatedFromDate());
            existingHoardingApplicationDetails.setAllocatedUptoDate(updatedHoardingApplicationDetails.getAllocatedUptoDate());
            existingHoardingApplicationDetails.setHoardingSize(updatedHoardingApplicationDetails.getHoardingSize());
            existingHoardingApplicationDetails.setHoardingFullSiteAddress(updatedHoardingApplicationDetails.getHoardingFullSiteAddress());
            existingHoardingApplicationDetails.setHoardingRateSqft(updatedHoardingApplicationDetails.getHoardingRateSqft());
            existingHoardingApplicationDetails.setZoneId(updatedHoardingApplicationDetails.getZoneId());
            existingHoardingApplicationDetails.setWardId(updatedHoardingApplicationDetails.getWardId());
            existingHoardingApplicationDetails.setUpdatedBy(updatedHoardingApplicationDetails.getUpdatedBy());
            existingHoardingApplicationDetails.setMunicipalId(updatedHoardingApplicationDetails.getMunicipalId());
//            existingHoardingApplicationDetails.setCreatedDate(LocalDateTime.now());
//            existingHoardingApplicationDetails.setUpdatedDate(LocalDateTime.now());
//            existingHoardingApplicationDetails.setUpdatedBy(updatedHoardingApplicationDetails.getUpdatedBy());
//            existingHoardingApplicationDetails.setSuspendedStatus(updatedHoardingApplicationDetails.getSuspendedStatus() != null ? existingHoardingApplicationDetails.getSuspendedStatus() : 0);

            return hoardingApplicationDetailsRepository.saveAndFlush(existingHoardingApplicationDetails);
        } else {
            throw new RuntimeException("hoardingApplicationDetails not found with id: " + id);
        }
    }

    @Override
    public HoardingApplicationDetails changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingApplicationDetails> hoardingApplicationDetailsOpt = hoardingApplicationDetailsRepository.findById(id);
        if (hoardingApplicationDetailsOpt.isPresent()) {
            HoardingApplicationDetails hoardingApplicationDetails = hoardingApplicationDetailsOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingApplicationDetails.setUpdatedDate(currentDateTime);
            hoardingApplicationDetails.setSuspendedStatus(status);      // 1 means suspended
            hoardingApplicationDetails.setUpdatedBy(updatedBy);
            return hoardingApplicationDetailsRepository.saveAndFlush(hoardingApplicationDetails);
        }
        return null;
    }

    @Override
    public HoardingApplicationDetails calculateHoardingApplicationDetailsFee(HoardingApplicationDetails hoardingApplicationDetails) {
        hoardingApplicationDetails.setCreatedDate(LocalDateTime.now());
        hoardingApplicationDetails.setUpdatedDate(LocalDateTime.now());
        hoardingApplicationDetails.setUpdatedBy(hoardingApplicationDetails.getUpdatedBy() != null ? hoardingApplicationDetails.getUpdatedBy() : 0);
        hoardingApplicationDetails.setSuspendedStatus(hoardingApplicationDetails.getSuspendedStatus() != null ? hoardingApplicationDetails.getSuspendedStatus() : 0);

        // check if the provided zone id exists
        if (!viewAdvertisementZoneMasterRepository.existsById(hoardingApplicationDetails.getZoneId().getId())) {
            throw new IllegalArgumentException("invalid zone id: " + hoardingApplicationDetails.getZoneId() + ". zone doesn't exist.");
        }

        // check if the provided ward id exists and belongs to the provided zone id
        boolean wardBelongsToZone = viewAdvertisementWardMasterRepository.existsByIdAndZoneMasId(hoardingApplicationDetails.getWardId().getId(), hoardingApplicationDetails.getZoneId().getId());
        if (!wardBelongsToZone) {
            throw new IllegalArgumentException("invalid ward id: " + hoardingApplicationDetails.getWardId() +
                    " or it does not belong to the provided zone id: " + hoardingApplicationDetails.getZoneId() + ".");
        }

        // Fetch the Hoarding Rate Master based on HoardingTypeRateMasterId
        HoardingTypeRateMasterSetup hoardingTypeRateMasterSetup = hoardingTypeRateMasterSetupRepository.findByIdWithNullHandling(hoardingApplicationDetails.getHoardingTypeRateMasterId().getId())
                .orElseThrow(() -> new IllegalArgumentException("HoardingRateMaster not found"));

//            HoardingTypeSizeMasterSetup hoardingTypeSizeMasterSetup = hoardingTypeSizeMasterSetupRepository.findById(hoardingApplicationDetails.getHoardingTypeSizeMasterId().getId())
//                    .orElseThrow(() -> new IllegalArgumentException("HoardingTypeSizeMaster not found for ID: " + hoardingApplicationDetails.getHoardingTypeSizeMasterId().getId()));

        // Compare hoarding_category_type_master_id
        if (!hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId().equals(hoardingApplicationDetails.getHoardingCategoryTypeMasterId().getId())) {
            throw new IllegalArgumentException("Mismatch between hoarding_category_type_master_id in HoardingTypeRateMasterSetup and the passed parameter");
        }

        // Compare usage_type_id
        if (!hoardingTypeRateMasterSetup.getUsageTypeId().getId().equals(hoardingApplicationDetails.getUsageTypeId().getId())) {
            throw new IllegalArgumentException("Mismatch between usage_type_id in HoardingTypeRateMasterSetup and the passed parameter");
        }

        // Calculate period days and months
        if (hoardingApplicationDetails.getAllocatedFromDate() != null && hoardingApplicationDetails.getAllocatedUptoDate() != null) {
            LocalDate fromDate = hoardingApplicationDetails.getAllocatedFromDate();
            LocalDate uptoDate = hoardingApplicationDetails.getAllocatedUptoDate();

            // Calculate the period in days
            long calculatedPeriodDays = ChronoUnit.DAYS.between(fromDate, uptoDate);

            // Calculate the period in months (based on 30 days per month)
            long calculatedPeriodMonths = (calculatedPeriodDays > 0)
                    ? ((calculatedPeriodDays - 1) / 30) + 1
                    : 0;

            // Calculate the period in years (based on 365 days per year)
            long calculatedPeriodYears = calculatedPeriodDays / 365;

            hoardingApplicationDetails.setCalculatedPeriodDays(calculatedPeriodDays);
            hoardingApplicationDetails.setCalculatedPeriodMonths(calculatedPeriodMonths);
            hoardingApplicationDetails.setCalculatedPeriodYears(calculatedPeriodYears);

            // Fetch calculation type from the hoarding_type_master_setup table
            Long hoardingTypeMasterId = hoardingApplicationDetails.getHoardingTypeMasterId().getId();
            HoardingTypeMasterSetup typeMaster = hoardingTypeMasterSetupRepository.findById(hoardingTypeMasterId)
                    .orElseThrow(() -> new IllegalArgumentException("Invalid Hoarding Type Master ID"));

            String calculationType = typeMaster.getCalculationType();

            // If the calculation type is VARIABLE, calculate the area_in_variable
            if ("VARIABLE".equalsIgnoreCase(calculationType)) {
                BigDecimal areaInVariable = BigDecimal.valueOf(0.0);

                // Fetch length and width for VARIABLE calculation
                BigDecimal hoardingLengthSqft = hoardingApplicationDetails.getHoardingLengthSqft();
                BigDecimal hoardingWidthSqft = hoardingApplicationDetails.getHoardingWidthSqft();

                // Calculate the area in VARIABLE based on length and width
                areaInVariable = hoardingLengthSqft.multiply(hoardingWidthSqft);
                hoardingApplicationDetails.setHoardingSize(areaInVariable);  // Set the calculated variable area
            } else {
                // Use the area fetched from the size master setup if calculation type is not VARIABLE
                Optional<HoardingTypeSizeMasterSetup> fixedhordingtypemaster = hoardingTypeSizeMasterSetupRepository.findById(hoardingApplicationDetails.getHoardingTypeSizeMasterId().getId());
                if (fixedhordingtypemaster.isPresent()) {
                    HoardingTypeSizeMasterSetup fixedHording = fixedhordingtypemaster.get();
                    hoardingApplicationDetails.setHoardingSize(fixedHording.getArea());
                }
            }

            // Calculate the amount based on (rate * area) * calculatedPeriodDays
            BigDecimal rate = hoardingTypeRateMasterSetup.getRateInSqft();
//            BigDecimal area = hoardingTypeSizeMasterSetup.getArea();
            BigDecimal area = hoardingApplicationDetails.getHoardingSize();
            hoardingApplicationDetails.setHoardingRateSqft(rate);
            hoardingApplicationDetails.setHoardingSize(area);

            BigDecimal calculatedAmount;

            System.out.println(hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId());
            // Calculate based on hoarding_category_type_master_id
            if (hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId() != null &&
                    hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId().equals(1L)) {
                // Calculate amount for hoarding_category_type_master_id = 1 (monthly calculation)
                calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(calculatedPeriodMonths));

            } else if (hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId() != null &&
                    hoardingTypeRateMasterSetup.getHoardingCategoryTypeMasterId().getId().equals(2L)) {
                // Retrieve the calculation method
                String calculationMethod = hoardingTypeRateMasterSetup.getCalculationMethod(); // e.g., "DAYS", "MONTHS", or "YEARS"

                switch (calculationMethod) {
                    case "DAYS":
                        calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(calculatedPeriodDays));
                        break;

                    case "MONTHS":
                        calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(calculatedPeriodMonths));
                        break;

                    case "YEARS":
                        calculatedAmount = rate.multiply(area).multiply(BigDecimal.valueOf(calculatedPeriodYears));
                        break;

                    default:
                        throw new IllegalArgumentException("Invalid calculation method in hoarding_type_rate_master_setup");
                }
            } else {
                throw new IllegalArgumentException("Invalid hoarding_category_type_master_id");
            }
            hoardingApplicationDetails.setCalculatedAmount(calculatedAmount.toPlainString());
        } else {
            throw new IllegalArgumentException("Allocated from date and upto date must not be null");
        }

        return hoardingApplicationDetails;

    }

    @Transactional
    @Override
    public void deleteHoardingApplicationDetailsByHoardingApplicationMasterId(Long hoardingApplicationMasterId) {
        try {
            hoardingApplicationDetailsRepository.deleteHoardingApplicationDetailsByHoardingApplicationMasterId(hoardingApplicationMasterId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}