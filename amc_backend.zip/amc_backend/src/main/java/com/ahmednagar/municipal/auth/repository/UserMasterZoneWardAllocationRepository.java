package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.UserMasterZoneWardAllocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface UserMasterZoneWardAllocationRepository extends JpaRepository<UserMasterZoneWardAllocation, Long> {

}
