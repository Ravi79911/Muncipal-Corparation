package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.MunicipalPropertyMasterService;
import com.ahmednagar.municipal.forms.formsPropertyTax.utils.ApplicationNumberGenerator;
import com.ahmednagar.municipal.master.propertyTax.model.PropertyAssismentType;
import com.ahmednagar.municipal.master.propertyTax.model.PropertyType;
import com.ahmednagar.municipal.master.propertyTax.model.ZoneWard;
import com.ahmednagar.municipal.master.propertyTax.repository.PropertyAssismentTypeRepository;
import com.ahmednagar.municipal.master.propertyTax.repository.PropertyTypeRepository;
import com.ahmednagar.municipal.master.propertyTax.repository.ZoneWardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class MunicipalPropertyMasterServiceImpl implements MunicipalPropertyMasterService {

    @Autowired
    MunicipalPropertyMasterRepository municipalPropertyMasterRepository;

    @Autowired
    PropertyAssismentTypeRepository propertyAssismentTypeRepository;

    @Autowired
    ZoneWardRepository zoneWardRepository;

    @Autowired
    PropertyTypeRepository propertyTypeRepository;

    @Override
    public MunicipalPropertyMaster createPropertyMaster(MunicipalPropertyMaster municipalPropertyMaster) {
        // validate and set assessment type
        PropertyAssismentType assessmentType = propertyAssismentTypeRepository.findById(
                        municipalPropertyMaster.getPropertyAssismentType().getId())
                .orElseThrow(() -> new IllegalArgumentException("invalid assessment type id"));
        municipalPropertyMaster.setPropertyAssismentType(assessmentType);

        // validate and set zone ward
        ZoneWard zoneWard = zoneWardRepository.findById(
                        municipalPropertyMaster.getZoneWard().getId())
                .orElseThrow(() -> new IllegalArgumentException("invalid zone ward id"));
        municipalPropertyMaster.setZoneWard(zoneWard);

        // generate and set application number
        String applicationNumber = ApplicationNumberGenerator.generateApplicationNo(
                String.format("%02d", assessmentType.getId()), zoneWard.getWardNo());
        municipalPropertyMaster.setApplicationNo(applicationNumber);

        // validate property type
        PropertyType propertyType = propertyTypeRepository.findById(
                        municipalPropertyMaster.getPropertyType().getId())
                .orElseThrow(() -> new IllegalArgumentException("invalid property type id"));

        // determine and set holding number
        boolean isVacantLand = propertyTypeRepository.findByPropertyTypeName("Vacant Land")
                .map(vacantType -> vacantType.getId().equals(propertyType.getId()))
                .orElse(false);
        String holdingNumber = isVacantLand
                ? ApplicationNumberGenerator.generateHoldingNoForVacantLand(zoneWard.getWardNo())
                : ApplicationNumberGenerator.generateHoldingNo(zoneWard.getWardNo());
        municipalPropertyMaster.setHoldingNo(holdingNumber);

        // set default values
        municipalPropertyMaster.setSuspendedStatus(
                municipalPropertyMaster.getSuspendedStatus() != null
                        ? municipalPropertyMaster.getSuspendedStatus()
                        : 0);
        municipalPropertyMaster.setApplicationDate(LocalDateTime.now());
        municipalPropertyMaster.setCreatedDate(LocalDateTime.now());
        return municipalPropertyMasterRepository.saveAndFlush(municipalPropertyMaster);
    }

    @Override
    public List<MunicipalPropertyMaster> getPropertyMasterByApplicationNumber(String applicationNo) {
        return municipalPropertyMasterRepository.findByApplicationNo(applicationNo);
    }

    @Override
    public List<MunicipalPropertyMaster> getAllPropertyMaster() {
        return municipalPropertyMasterRepository.findAll();
    }

    @Override
    public Optional<MunicipalPropertyMaster> getMunicipalPropertyMasterById(Long id) {
        return municipalPropertyMasterRepository.findById(id);
    }

    @Override
    public List<MunicipalPropertyMaster> getByMunicipalId(int municipalId) {
        return municipalPropertyMasterRepository.findByMunicipalId(municipalId);
    }

    @Override
    public List<MunicipalPropertyMaster> getByZoneWardHoldingNo(Long zoneId, Long zoneWard, String holdingNo) {
        return municipalPropertyMasterRepository.findByZoneIdAndZoneWardIdAndHoldingNo(zoneId, zoneWard, holdingNo);
    }

    @Override
    public MunicipalPropertyMaster patchMunicipalPropertyMasterSuspendedStatus(Long id, int suspendedStatus) {
        Optional<MunicipalPropertyMaster> patchMunicipalPropertyMaster = municipalPropertyMasterRepository.findById(id);
        if (patchMunicipalPropertyMaster.isPresent()) {
            MunicipalPropertyMaster existingMunicipalPropertyMaster = patchMunicipalPropertyMaster.get();
            existingMunicipalPropertyMaster.setSuspendedStatus(suspendedStatus);
            return municipalPropertyMasterRepository.saveAndFlush(existingMunicipalPropertyMaster);
        } else {
            throw new RuntimeException("municipal property master not found with id: " + id);
        }
    }

}
