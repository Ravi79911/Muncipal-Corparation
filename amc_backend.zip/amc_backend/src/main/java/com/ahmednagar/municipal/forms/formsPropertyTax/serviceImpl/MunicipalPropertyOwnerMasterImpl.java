package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyOwnerMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyOwnerMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.MunicipalPropertyOwnerMasterService;
import com.ahmednagar.municipal.master.propertyTax.repository.OwnerShipRepository;
import com.ahmednagar.municipal.notification.EmailService;
import com.ahmednagar.municipal.notification.SMSService;
import com.ahmednagar.municipal.notification.WhatsAppService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class MunicipalPropertyOwnerMasterImpl implements MunicipalPropertyOwnerMasterService {

    //    private static final String BASE_UPLOAD_DIR = "C:\\Users\\swati\\OneDrive\\Desktop\\ahmednagar_muncipal\\src\\main\\resources\\propertyDocumentUploads";
    @Value("${upload.base.dir}")
    private String BASE_UPLOAD_DIR;
    private static final List<String> ALLOWED_EXTENSIONS = Arrays.asList(".jpg", ".jpeg", ".png");
    private static final long MAX_FILE_SIZE = 200 * 1024;

    private static final Logger logger = LoggerFactory.getLogger(MunicipalPropertyOwnerMasterImpl.class);

    @Autowired
    MunicipalPropertyOwnerMasterRepository municipalPropertyOwnerMasterRepository;

    @Autowired
    MunicipalPropertyMasterRepository municipalPropertyMasterRepository;

    @Autowired
    OwnerShipRepository ownerShipRepository;

    @Autowired
    EmailService emailService;

//    @Autowired
//    WhatsAppService whatsAppService;
//
//    @Autowired
//    SMSService smsService;

    @Override
    public List<MunicipalPropertyOwnerMaster> createMunicipalPropertyOwnerMasterList(List<MunicipalPropertyOwnerMaster> municipalPropertyOwnerMaster,
                                                                                     List<MultipartFile> ownerPhotographUpload) {
        if (ownerPhotographUpload != null && municipalPropertyOwnerMaster.size() != ownerPhotographUpload.size()) {
            throw new IllegalArgumentException("number of owners and photographs must match");
        }

        // initialize variables to store the expected IDs
        Long expectedMunicipalPropertyMasterId = null;
        Long expectedOwnerShipId = null;

        List<MunicipalPropertyOwnerMaster> savedMasters = new ArrayList<>();

        for (int i = 0; i < municipalPropertyOwnerMaster.size(); i++) {
            MunicipalPropertyOwnerMaster master = municipalPropertyOwnerMaster.get(i);
            MultipartFile photograph = ownerPhotographUpload != null ? ownerPhotographUpload.get(i) : null;

            // check consistency of MunicipalPropertyMaster and OwnerShip IDs
            if (i == 0) {
                // for the first entity, store the expected IDs
                expectedMunicipalPropertyMasterId = master.getMunicipalPropertyMaster().getId();
                expectedOwnerShipId = master.getOwnerShips().getId();

                // check if the MunicipalPropertyMaster and OwnerShip IDs exist in the database
                if (!municipalPropertyMasterRepository.existsById(expectedMunicipalPropertyMasterId)) {
                    throw new IllegalArgumentException("municipal property master id " + expectedMunicipalPropertyMasterId + " doesn't exist");
                }

                if (!ownerShipRepository.existsById(expectedOwnerShipId)) {
                    throw new IllegalArgumentException("owner ship id " + expectedOwnerShipId + " doesn't exist");
                }
            } else {
                // compare current entity's IDs with the expected IDs
                if (!expectedMunicipalPropertyMasterId.equals(master.getMunicipalPropertyMaster().getId())) {
                    throw new IllegalArgumentException("municipal property master id mismatch. All owners must belong to the same property master");
                }
                if (!expectedOwnerShipId.equals(master.getOwnerShips().getId())) {
                    throw new IllegalArgumentException("owner ship id mismatch. All owners must belong to the same ownership");
                }
            }

            if (photograph != null && !photograph.isEmpty()) {
                // validate file size
                if (photograph.getSize() > MAX_FILE_SIZE) {
                    throw new IllegalArgumentException("file size exceeds 200KB for owner: " + master.getOwnerName());
                }

                // validate file extension
                String originalFilename = photograph.getOriginalFilename();
                String fileExtension = "";
                if (originalFilename != null && originalFilename.contains(".")) {
                    fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
                }
                if (!ALLOWED_EXTENSIONS.contains(fileExtension.toLowerCase())) {
                    throw new IllegalArgumentException("invalid file extension for owner: " + master.getOwnerName() +
                            ". allowed extensions are: " + ALLOWED_EXTENSIONS);
                }

                // save file
                String userFolderName = "Owner_Photograph";
                Path userFolderPath = Paths.get(BASE_UPLOAD_DIR, userFolderName);
                try {
                    Files.createDirectories(userFolderPath);
                    String newFileName = "Owner_Photograph_" + UUID.randomUUID() + fileExtension;
                    Path filePath = userFolderPath.resolve(newFileName);
                    Files.write(filePath, photograph.getBytes());
                    master.setOwnerPhotographUpload(Paths.get(userFolderName, newFileName).toString());
                    logger.info("file uploaded for owner: {}", master.getOwnerName());
                } catch (IOException e) {
                    throw new RuntimeException("error while saving the file for owner: " + master.getOwnerName(), e);
                }
            } else {
                master.setOwnerPhotographUpload(null);
            }
            master.setCreatedDate(LocalDateTime.now());
            savedMasters.add(municipalPropertyOwnerMasterRepository.saveAndFlush(master));

            // retrieve the application number
            String applicationNumber = municipalPropertyOwnerMasterRepository.findApplicationNoByMunicipalPropertyMasterId(expectedMunicipalPropertyMasterId);
            logger.info("Application Number: {}", applicationNumber);
            sendOwnerRegistrationNotification(master, applicationNumber);
        }
        return savedMasters;
    }

    // method to send SMS, email, and WhatsApp messages
//    private void sendNotifications(MunicipalPropertyOwnerMaster ownerMaster) {
//        String messageContent = "Your New Property Registration is Successful. Your Application Number is: " + ownerMaster.getId();
//        smsService.sendSMS(ownerMaster.getOwnerMobileNo(), messageContent);
//        emailService.sendEmail(ownerMaster.getOwnerEmailId(), "Property Registration Successful", messageContent);
//        whatsAppService.sendWhatsAppMessage(ownerMaster.getOwnerMobileNo(), messageContent);
//    }

    @Override
    public Resource loadOwnerPhotograph(int id) throws IOException {
        MunicipalPropertyOwnerMaster municipalOwner = municipalPropertyOwnerMasterRepository.findById(id)
                .orElseThrow(() -> new IOException("municipal property owner master not found with id: " + id));
        String filePathStr = municipalOwner.getOwnerPhotographUpload();
        if (filePathStr == null || filePathStr.isEmpty()) {
            throw new IOException("owner photograph not found for id: " + id);
        }
        Path path = Paths.get(BASE_UPLOAD_DIR, filePathStr);
        return new FileSystemResource(path.toFile());
    }

    @Override
    public List<MunicipalPropertyOwnerMaster> getAllMunicipalPropertyOwnerMaster() {
        return municipalPropertyOwnerMasterRepository.findAll();
    }

    @Override
    public Optional<MunicipalPropertyOwnerMaster> getMunicipalPropertyOwnerMasterById(int id) {
        return municipalPropertyOwnerMasterRepository.findById(id);
    }

    @Override
    public List<MunicipalPropertyOwnerMaster> getByMunicipalId(int municipalId) {
        return municipalPropertyOwnerMasterRepository.findByMunicipalId(municipalId);
    }

    @Override
    public MunicipalPropertyOwnerMaster patchMunicipalPropertyOwnerMasterSuspendedStatus(int id, int suspendedStatus) {
        Optional<MunicipalPropertyOwnerMaster> patchMunicipalPropertyOwnerMaster = municipalPropertyOwnerMasterRepository.findById(id);
        if (patchMunicipalPropertyOwnerMaster.isPresent()) {
            MunicipalPropertyOwnerMaster existingMunicipalPropertyOwnerMaster = patchMunicipalPropertyOwnerMaster.get();
            existingMunicipalPropertyOwnerMaster.setSuspendedStatus(suspendedStatus);
            return municipalPropertyOwnerMasterRepository.saveAndFlush(existingMunicipalPropertyOwnerMaster);
        } else {
            throw new RuntimeException("municipal property owner master not found with id: " + id);
        }
    }

    // method to send SMS, email, and WhatsApp messages
    private void sendOwnerRegistrationNotification(MunicipalPropertyOwnerMaster ownerMaster, String applicationNumber) {
        String ownerName = ownerMaster.getOwnerName();
        String htmlMessageContent = buildOwnerRegistrationEmailContent(ownerName, applicationNumber);
        logger.info("sending email to {}", ownerMaster.getOwnerEmailId());
        try {
            emailService.sendEmail(
                    ownerMaster.getOwnerEmailId(),
                    "Property Registration Successful",
                    htmlMessageContent
            );
            // Optional: Send SMS or WhatsApp notifications (if needed)
            // sendSMSNotification(ownerMaster);
            // sendWhatsAppNotification(ownerMaster);
        } catch (Exception e) {
            throw new RuntimeException("failed to send email to " + ownerMaster.getOwnerEmailId() + ": " + e.getMessage(), e);
        }
    }

    private String buildOwnerRegistrationEmailContent(String ownerName, String applicationNumber) {
        return "<div style='font-family:Arial, sans-serif; background-color:#f4f4f9; padding:30px; border-radius:10px; max-width:600px; margin:auto;'>"
                + "<div style='text-align:center; margin-bottom:20px;'>"
                + "<img src='https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png' alt='Swati Industries' style='max-width:150px; height:auto;' />"
                + "</div>"
                + "<div style='background-color:#ffffff; padding:20px; border-radius:10px; box-shadow:0 4px 8px rgba(0, 0, 0, 0.1);'>"
                + "<h2 style='color:#333333;'>Dear " + ownerName + ",</h2>"
                + "<p style='font-size:16px; color:#555555;'>Congratulations! Your property ownership registration has been successfully completed.</p>"
                + "<p style='font-size:16px; color:#555555;'><b>Application Number:</b> <span style='color:#007bff;'>" + applicationNumber + "</span></p>"
                + "<p style='font-size:16px; color:#555555;'>Please retain this application number for future reference. You can use it for tracking application status or related inquiries.</p>"
                + "<p style='font-size:16px; color:#555555;'>We appreciate your association with us and are happy to assist you further.</p>"
                + "<p style='font-size:16px; color:#555555;'>If you have any questions, feel free to reach out to us.</p>"
                + "</div>"
                + "<div style='text-align:center; margin-top:30px;'>"
                + "<p style='font-size:14px; color:#888888;'>Best regards,</p>"
                + "<p style='font-size:16px; color:#333333;'>Swati Industries</p>"
                + "<a href='https://swatiind.com/' target='_blank' style='color:#007bff; text-decoration:none; font-size:16px;'>Visit our website</a>"
                + "</div>"
                + "</div>";
    }

}
