package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDemandMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyDemandMasterService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/forms")
public class PropertyDemandMasterController {

    @Autowired
    PropertyDemandMasterService propertyDemandMasterService;

    private static final Logger logger = LoggerFactory.getLogger(PropertyDemandMasterController.class);

    // single entity creation method
    @PostMapping("/createPropertyDemandMasterSingle")
    public ResponseEntity<PropertyDemandMaster> createPropertyDemand(@Valid @RequestBody PropertyDemandMaster propertyDemandMaster) {
        PropertyDemandMaster newPropertyDemand = propertyDemandMasterService.createPropertyDemandMaster(propertyDemandMaster);
        return ResponseEntity.ok(newPropertyDemand);
    }

    // list of entity creation method
    @PostMapping("/createPropertyDemandMaster")
    public ResponseEntity<?> createPropertyDemandMasters(@Valid @RequestBody List<PropertyDemandMaster> propertyDemandMaster) {
        try {
            List<PropertyDemandMaster> newPropertyDemandMasterList = propertyDemandMasterService.createPropertyDemandMasterList(propertyDemandMaster);
            return ResponseEntity.ok(newPropertyDemandMasterList);
        } catch (IllegalArgumentException e) {
            logger.error("error creating PropertyDemandMaster: " + e.getMessage(), e);
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            logger.error("unexpected error: " + e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "An unexpected error occurred"));
        }
    }

    @GetMapping("/getAllPropertyDemandMaster")
    public ResponseEntity<List<PropertyDemandMaster>> getAllPropertyDemand() {
        return ResponseEntity.ok(propertyDemandMasterService.getAllPropertyDemandMaster());
    }

    @GetMapping("/propertyDemandMaster/{id}")
    public ResponseEntity<Object> getPropertyDemandById(@PathVariable Long id) {
        Optional<PropertyDemandMaster> propertyDemandMaster = propertyDemandMasterService.getPropertyDemandMasterById(id);
        if (propertyDemandMaster.isPresent()) {
            return ResponseEntity.ok(propertyDemandMaster.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getPropertyDemandMasterByMunicipalId/{municipalId}")
    public List<PropertyDemandMaster> getPropertyDemandByMunicipalId(@PathVariable int municipalId) {
        return propertyDemandMasterService.getPropertyDemandMasterByMunicipalId(municipalId);
    }

    @PatchMapping("/propertyDemandMaster/suspendedStatus/{id}")
    public ResponseEntity<PropertyDemandMaster> patchPropertyDemandSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        PropertyDemandMaster patchedPropertyDemandMaster = propertyDemandMasterService.patchPropertyDemandMasterSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedPropertyDemandMaster);
    }
}
