package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_zone_master")
public class VendorZone {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "zone name is required")
    @Column(name = "zone_name")
    private String zoneName;

    @Column(name = "createddate")
    private LocalDateTime createdDate;

    @Column(name = "updateddate")
    private LocalDateTime updatedDate;

    @NotNull(message = "created by is required")
    @Column(name = "createdby")
    private Integer createdBy;

    @Column(name = "updatedby")
    private Integer updatedBy;

    @Column(name = "suspendedstatus")
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

//    @OneToMany(mappedBy = "vendorZone", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    private Set<VendorZoneWard> vendorZoneWards;



//    @OneToMany(mappedBy = "zone", cascade = CascadeType.ALL)
//    private Set<CollectionMaster> collectionMasters;


}
