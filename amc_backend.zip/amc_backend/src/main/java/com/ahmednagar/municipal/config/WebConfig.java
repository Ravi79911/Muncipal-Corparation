package com.ahmednagar.municipal.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {

        registry.addMapping("/master/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

//        registry.addMapping("/api/**")
//                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090")
//                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
//                .allowedHeaders("*")
//                .allowCredentials(true);

        registry.addMapping("/water/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/tradeLicence/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/advertisement/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/streetVendorCollectionSystem/**")
                .allowedOrigins("http://192.168.29.245:9092", "http://localhost:3000", "http://www.swatiind.co.in:9092")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/forms/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/auth/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/dd/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }
}
