package com.ahmednagar.municipal.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {

        registry.addMapping("/master/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090", "http://www.swatiind.co.in:9090/amc/ws")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/water/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090", "http://www.swatiind.co.in:9090/amc/ws")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/tradeLicence/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090", "http://www.swatiind.co.in:9090/amc/ws")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/advertisement/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090", "http://www.swatiind.co.in:9090/amc/ws")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/streetVendorCollectionSystem/**")
                .allowedOrigins("http://192.168.29.245:9092", "http://localhost:3000", "http://www.swatiind.co.in:9092", "http://www.swatiind.co.in:9090/amc/ws")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/formsOwner/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090", "http://www.swatiind.co.in:9090/amc/ws")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

//        registry.addMapping("/static/forms/**")
//                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090")
//                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
//                .allowedHeaders("*")
//                .allowCredentials(true);
//
        registry.addMapping("/auth/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090", "http://www.swatiind.co.in:9090/amc/ws")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/dd/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090", "http://www.swatiind.co.in:9090/amc/ws")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

        registry.addMapping("/shopRent/**")
                .allowedOrigins("http://192.168.29.245:9090", "http://localhost:3000", "http://www.swatiind.co.in:9090", "http://www.swatiind.co.in:9090/amc/ws")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }

    // add resource handler for static files
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler(
                        "/userSignupProfilePic/**",
                        "/citizenSignupProfilePic/**",
                        "propertyDocumentUploads/**",
                        "/propertyDocumentUploads/**",
                        "/licenseDocumentUpload/**",
                        "/advertisementDocumentUpload/**",
                        "/transferLetter/**",
                        "/waterDocumentUpload/**"
                )
                .addResourceLocations(
                        "file:D:/Backend_Project/amc_backend/src/main/resources/static/propertyDocumentUploads/",
                        "file:D:/Backend_Project/amc_backend/src/main/resources/static/licenseDocumentUpload/",
                        "file:D:/Backend_Project/amc_backend/src/main/resources/static/advertisementDocumentUpload/",
                        //"file:C:/Users/swati/OneDrive/Desktop/amc_backend/src/main/resources/static/advertisementDocumentUploads",
                        "file:D:/Backend_Project/amc_backend/src/main/resources/static/transferLetter/Transfer_Letters/",
                        "file:D:/Backend_Project/amc_backend/src/main/resources/static/waterDocumentUpload/",
                        "file:C:/Users/swati/OneDrive/Desktop/amc_backend/src/main/resources/static/propertyDocumentUploads/",
                        "file:D:/Backend_Project/amc_backend/src/main/resources/static/userSignupProfilePic/",
                        "file:D:/Backend_Project/amc_backend/src/main/resources/static/citizenSignupProfilePic/"
                );
    }

}