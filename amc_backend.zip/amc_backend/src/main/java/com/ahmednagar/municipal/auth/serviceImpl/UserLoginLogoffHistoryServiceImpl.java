package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.UserLoginLogoffHistoryDto;
import com.ahmednagar.municipal.auth.model.UserLoginLogoffHistory;
import com.ahmednagar.municipal.auth.repository.UserLoginLogoffHistoryRepository;
import com.ahmednagar.municipal.auth.service.UserLoginLogoffHistoryService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserLoginLogoffHistoryServiceImpl implements UserLoginLogoffHistoryService {
    @Autowired
    private UserLoginLogoffHistoryRepository userLoginLogoffHistoryRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public UserLoginLogoffHistory savedUserLoginLogoffHistory(UserLoginLogoffHistory userLoginLogoffHistory) {
        userLoginLogoffHistory.setCreatedDate(LocalDateTime.now());
        userLoginLogoffHistory.setUpdatedDate(LocalDateTime.now());
        userLoginLogoffHistory.setLoginLogoffDatetime(LocalDateTime.now());
        userLoginLogoffHistory.setUpdatedBy(userLoginLogoffHistory.getUpdatedBy() != null ? userLoginLogoffHistory.getUpdatedBy() : 0);
        userLoginLogoffHistory.setSuspendedStatus(userLoginLogoffHistory.getSuspendedStatus() != null ? userLoginLogoffHistory.getSuspendedStatus() : 0);

        return userLoginLogoffHistoryRepository.save(userLoginLogoffHistory);

    }

    @Override
    public List<UserLoginLogoffHistoryDto> findAllUserLoginLogoffHistory() {
        List<UserLoginLogoffHistory> userLoginLogoffHistories = userLoginLogoffHistoryRepository.findAll();
        return userLoginLogoffHistories.stream()
                .map(userLoginLogoffHistory -> modelMapper.map(userLoginLogoffHistory, UserLoginLogoffHistoryDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<UserLoginLogoffHistoryDto> findAllUserLoginLogoffHistoryByMunicipalId(Long municipalId) {
        List<UserLoginLogoffHistory> userLoginLogoffHistories = userLoginLogoffHistoryRepository.findByMunicipalId(municipalId);
        return userLoginLogoffHistories.stream()
                .map(userLoginLogoffHistory -> modelMapper.map(userLoginLogoffHistory, UserLoginLogoffHistoryDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public UserLoginLogoffHistory updateUserLoginLogoffHistory(Long id, UserLoginLogoffHistory updatedUserLoginLogoffHistory) {
        Optional<UserLoginLogoffHistory> userLoginLogoffHistoryOptional = userLoginLogoffHistoryRepository.findById(id);
        if (userLoginLogoffHistoryOptional.isPresent()) {
            UserLoginLogoffHistory existingUserLoginLogoffHistory = userLoginLogoffHistoryOptional.get();
            existingUserLoginLogoffHistory.setUpdatedBy(existingUserLoginLogoffHistory.getUpdatedBy());
            existingUserLoginLogoffHistory.setUpdatedDate(LocalDateTime.now());
            existingUserLoginLogoffHistory.setSuspendedStatus(updatedUserLoginLogoffHistory.getSuspendedStatus());
            existingUserLoginLogoffHistory.setMunicipalId(updatedUserLoginLogoffHistory.getMunicipalId());

            return userLoginLogoffHistoryRepository.saveAndFlush(existingUserLoginLogoffHistory);
        } else {
            throw new RuntimeException("UserLoginLogoffHistory not found with id: " + id);
        }
    }

    @Override
    public UserLoginLogoffHistory changeStatus(Long id, Integer status, int updatedBy) {
        Optional<UserLoginLogoffHistory> userLoginLogoffHistoryOpt = userLoginLogoffHistoryRepository.findById(id);
        if (userLoginLogoffHistoryOpt.isPresent()) {
            UserLoginLogoffHistory userLoginLogoffHistory = userLoginLogoffHistoryOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            userLoginLogoffHistory.setUpdatedDate(currentDateTime);
            userLoginLogoffHistory.setSuspendedStatus(status);      // 1 means suspended
            userLoginLogoffHistory.setUpdatedBy(updatedBy);
            return userLoginLogoffHistoryRepository.saveAndFlush(userLoginLogoffHistory);
        }
        return null;
    }
}
