package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.UserMasterDTO;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.RoleMasterRepository;
import com.ahmednagar.municipal.auth.service.UserMasterService;
import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.exception.EmailNotFoundException;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class UserMasterController {

    @Autowired
    UserMasterService userMasterService;

    @Autowired
    RoleMasterRepository roleMasterRepository;

    @PostMapping("/createUserMaster")
    public ResponseEntity<UserMaster> createUserMaster(@Valid @RequestParam(value = "userPicture", required = false) MultipartFile userPicture,
                                                       @RequestParam("roleMasId") Long roleMasId,
                                                       @RequestParam("zoneId") Long zoneId,
                                                       @RequestParam("wardIds") String wardIds,
                                                       @RequestParam("nameOfUser") String nameOfUser,
                                                       @RequestParam("fatherName") String fatherName,
                                                       @RequestParam("address") String address,
                                                       @RequestParam("email") String email,
                                                       @RequestParam("mobileNo") String mobileNo,
                                                       @RequestParam("dateOfBirth") LocalDate dateOfBirth,
                                                       @RequestParam("userName") String userName,
                                                       @RequestParam("ipAddress") String ipAddress,
                                                       @RequestParam("createdBy") int createdBy,
                                                       @RequestParam("municipalId") int municipalId) {

        List<Long> wardIdList = Arrays.stream(wardIds.split(","))
                .map(Long::parseLong)
                .distinct()
                .collect(Collectors.toList());

        UserMaster userMasters = new UserMaster();
        userMasters.setRoleMaster(roleMasterRepository.findById(roleMasId)
                .orElseThrow(() -> new EntityNotFoundException("role not found")));
        userMasters.setNameOfUser(nameOfUser);
        userMasters.setFatherName(fatherName);
        userMasters.setAddress(address);
        userMasters.setEmail(email);
        userMasters.setMobileNo(mobileNo);
        userMasters.setDateOfBirth(dateOfBirth);
        userMasters.setUserName(userName);
        userMasters.setIpAddress(ipAddress);
        userMasters.setCreatedBy(createdBy);
        userMasters.setMunicipalId(municipalId);

        UserMaster createUserMasters = userMasterService.createUserMaster(userMasters, userPicture, zoneId, wardIdList);
        return ResponseEntity.status(HttpStatus.CREATED).body(createUserMasters);
    }

    @GetMapping("/getAllUserMaster")
    public ResponseEntity<List<UserMasterDTO>> getAllUserMasters() {
        return ResponseEntity.ok(userMasterService.getAllUserMaster());
    }

    @GetMapping("/getUserMasterProfilePicURL")
    public ResponseEntity<ApiResponse> getProfilePicUrl(@RequestHeader("Authorization") String token) {
        String url = userMasterService.getProfilePicUrlFromToken(token);
        return ResponseEntity.ok(ApiResponse.success("Profile picture URL fetched successfully.", Collections.singletonMap("profilePicUrl", url)));
    }

    @PostMapping("/validateEmailOtp")
    public ResponseEntity<String> validateEmailOtp(@RequestParam("userId") Long userId, @RequestParam("otp") String otp) {
        UserMaster userMaster = userMasterService.findByUserId(userId);

        if (userMaster != null && userMasterService.validateEmailOtp(userMaster, otp)) {
            return ResponseEntity.ok("email otp validated successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid or expired email otp");
        }
    }

    @PostMapping("/validateMobileOtp")
    public ResponseEntity<String> validateMobileOtp(@RequestParam("userId") Long userId, @RequestParam("otp") String otp) {
        UserMaster userMaster = userMasterService.findByUserId(userId);

        if (userMaster != null && userMasterService.validateMobileOtp(userMaster, otp)) {
            return ResponseEntity.ok("mobile otp validated successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid or expired mobile otp");
        }
    }

    @PostMapping("/resendEmailOtp")
    public ResponseEntity<String> resendEmailOtp(@RequestParam("userId") Long userId) {
        UserMaster userMaster = userMasterService.findByUserId(userId);

        if (userMaster != null) {
            userMasterService.resendEmailOtp(userMaster);
            return ResponseEntity.ok("email otp has been resent successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("user not found.");
        }
    }

    @PostMapping("/resendMobileOtp")
    public ResponseEntity<String> resendMobileOtp(@RequestParam("userId") Long userId) {
        UserMaster userMaster = userMasterService.findByUserId(userId);

        if (userMaster != null) {
            userMasterService.resendMobileOtp(userMaster);
            return ResponseEntity.ok("mobile otp has been resent successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("user not found.");
        }
    }

    @PostMapping("/requestChangeEmailOrMobile/{userId}")
    public ResponseEntity<String> requestEmailOrMobileChange(
            @PathVariable("userId") Long userId,
            @Valid @RequestBody ChangeEmailMobileRequest changeEmailMobileRequest) {

        try {
            String response = userMasterService.requestEmailOrMobileChange(userId, changeEmailMobileRequest);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/validateChangeEmailOrMobileOtp/{userId}")
    public ResponseEntity<String> validateEmailOrMobileOtp(
            @PathVariable("userId") Long userId,
            @RequestParam("otp") String otp,
            @RequestBody ChangeEmailMobileRequest changeEmailMobileRequest) {

        try {
            boolean isUpdated = userMasterService.validateEmailOrMobileOtp(userId, otp, changeEmailMobileRequest);

            if (isUpdated) {
                return ResponseEntity.ok("Email or mobile number successfully updated.");
            } else {
                return ResponseEntity.badRequest().body("OTP validation failed or expired.");
            }
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

//    @PostMapping("/requestForgotUserName")
//    public ResponseEntity<String> forgotUserName(@RequestBody ForgotUserNameRequest forgotUserNameRequest) {
//        try {
//            String response = userMasterService.forgotUsername(forgotUserNameRequest);
//            return ResponseEntity.ok(response);
//        } catch (Exception e) {
//            return ResponseEntity.badRequest().body(e.getMessage());
//        }
//    }

    @PostMapping("/requestForgotUserName")
    public ResponseEntity<ApiResponse> forgotUserName(@RequestBody ForgotUserNameRequest forgotUserNameRequest) {
        String response = userMasterService.forgotUsername(forgotUserNameRequest);
        return ResponseEntity.ok(ApiResponse.success(response, null));
    }

//    @PostMapping("/validateForgotUserNameOtp")
//    public ResponseEntity<String> validateForgotUserNameOtp(@RequestParam Long userId,
//                                                            @RequestParam String emailOtp,
//                                                            @RequestParam String mobileOtp) {
//        UserMaster userMaster = userMasterService.findByUserId(userId);
//        try {
//            String response = userMasterService.validateForgotUsernameOtp(userMaster, emailOtp, mobileOtp);
//            return ResponseEntity.ok(response);
//        } catch (Exception e) {
//            return ResponseEntity.badRequest().body(e.getMessage());
//        }
//    }

    @PostMapping("/validateForgotUserNameOtp")
    public ResponseEntity<ApiResponse> validateForgotUserNameOtp(@RequestParam String email,
                                                                 @RequestParam String mobile,
                                                                 @RequestParam String emailOtp,
                                                                 @RequestParam String mobileOtp) {
        if (email == null || email.trim().isEmpty() || mobile == null || mobile.trim().isEmpty()) {
            throw new IllegalArgumentException("Both email and mobile number are required.");
        }

        UserMaster userMaster = userMasterService.findByEmailOrMobile(email, mobile);
        if (userMaster == null) {
            throw new EmailNotFoundException("No user found with the provided email and mobile number.");
        }

        String message = userMasterService.validateForgotUsernameOtp(userMaster, emailOtp, mobileOtp);
        return ResponseEntity.ok(ApiResponse.success(message, null));
    }

    @PostMapping("/forgotPassword")
    public ResponseEntity<String> forgotPasswords(@RequestParam String email) {
        String message = userMasterService.forgotPassword(email);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

//    @PutMapping("/resetPassword")
//    public ResponseEntity<String> resetPasswords(@RequestParam String token, @RequestBody ForgotPassword forgotPassword) {
//        String message = userMasterService.resetPassword(token, forgotPassword);
//        return new ResponseEntity<>(message, HttpStatus.OK);
//    }

    @PutMapping("/resetPassword")
    public ResponseEntity<ApiResponse> resetPasswords(@RequestParam String token, @RequestBody ForgotPassword forgotPassword) {
        String message = userMasterService.resetPassword(token, forgotPassword);
        return ResponseEntity.ok(new ApiResponse(message, true));
    }

    @PutMapping("/changePassword/{userId}")
    public ResponseEntity<ApiResponse> changePasswords(@PathVariable Long userId, @RequestBody ChangePasswordRequest changePasswordRequest) {
        String message = userMasterService.changePassword(userId, changePasswordRequest);
        return ResponseEntity.ok(new ApiResponse(message, true));
    }

//    @GetMapping("/lipik-filter")
//    public ResponseEntity<List<UserMaster>> getUsersByZoneWardAndRole(
//            @RequestParam Long zoneId,
//            @RequestParam Long wardId,
//            @RequestParam Long roleId) {
//        List<UserMaster> users = userMasterService.getUsersByZoneWardAndRole(zoneId, wardId, roleId);
//        return ResponseEntity.ok(users);
//    }

}
