package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.ForgotPassword;
import com.ahmednagar.municipal.auth.model.UserMaster;
import com.ahmednagar.municipal.auth.repository.RoleMasterRepository;
import com.ahmednagar.municipal.auth.service.UserMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class UserMasterController {

    @Autowired
    UserMasterService userMasterService;

    @Autowired
    RoleMasterRepository roleMasterRepository;

    @PostMapping("/createUserMaster")
    public ResponseEntity<UserMaster> createUserMaster(@Valid @RequestParam(value = "userPicture", required = false)
                                                       MultipartFile userPicture,
                                                       @RequestParam("roleMasId") Long roleMasId,
                                                       @RequestParam("nameOfUser") String nameOfUser,
                                                       @RequestParam("fatherName") String fatherName,
                                                       @RequestParam("address") String address,
                                                       @RequestParam("email") String email,
                                                       @RequestParam("mobileNo") String mobileNo,
                                                       @RequestParam("dateOfBirth") LocalDate dateOfBirth,
                                                       @RequestParam("userName") String userName,
                                                       @RequestParam("password") String password,
                                                       @RequestParam("createdBy") int createdBy,
                                                       @RequestParam("updatedBy") Integer updatedBy,
                                                       @RequestParam("suspendedStatus") Integer suspendedStatus,
                                                       @RequestParam("municipalId") int municipalId) {

        UserMaster userMasters = new UserMaster();
        userMasters.setRoleMaster(roleMasterRepository.findById(roleMasId).get());
        userMasters.setNameOfUser(nameOfUser);
        userMasters.setFatherName(fatherName);
        userMasters.setAddress(address);
        userMasters.setEmail(email);
        userMasters.setMobileNo(mobileNo);
        userMasters.setDateOfBirth(dateOfBirth);
        userMasters.setUserName(userName);
        userMasters.setPassword(password);
        userMasters.setCreatedBy(createdBy);
        userMasters.setUpdatedBy(updatedBy);
        userMasters.setMunicipalId(municipalId);
        userMasters.setSuspendedStatus(suspendedStatus);

        UserMaster createUserMasters = userMasterService.createUserMaster(userMasters, userPicture);
        return ResponseEntity.status(HttpStatus.CREATED).body(createUserMasters);
    }

    @PostMapping("/validateEmailOtp")
    public ResponseEntity<String> validateEmailOtp(@RequestParam("userId") Long userId, @RequestParam("otp") String otp) {
        UserMaster userMaster = userMasterService.findByUserId(userId);

        if (userMaster != null && userMasterService.validateEmailOtp(userMaster, otp)) {
            return ResponseEntity.ok("email otp validated successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid or expired email otp");
        }
    }

    @PostMapping("/validateMobileOtp")
    public ResponseEntity<String> validateMobileOtp(@RequestParam("userId") Long userId, @RequestParam("otp") String otp) {
        UserMaster userMaster = userMasterService.findByUserId(userId);

        if (userMaster != null && userMasterService.validateMobileOtp(userMaster, otp)) {
            return ResponseEntity.ok("mobile otp validated successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid or expired mobile otp");
        }
    }

    @PostMapping("/resendEmailOtp")
    public ResponseEntity<String> resendEmailOtp(@RequestParam("userId") Long userId) {
        UserMaster userMaster = userMasterService.findByUserId(userId);

        if (userMaster != null) {
            userMasterService.resendEmailOtp(userMaster);
            return ResponseEntity.ok("email otp has been resent successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("user not found.");
        }
    }

    @PostMapping("/resendMobileOtp")
    public ResponseEntity<String> resendMobileOtp(@RequestParam("userId") Long userId) {
        UserMaster userMaster = userMasterService.findByUserId(userId);

        if (userMaster != null) {
            userMasterService.resendMobileOtp(userMaster);
            return ResponseEntity.ok("mobile otp has been resent successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("user not found.");
        }
    }

    @PostMapping("/forgotPassword")
    public ResponseEntity<String> forgotPasswords(@RequestParam String email) {
        String message = userMasterService.forgotPassword(email);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

    @PutMapping("/resetPassword")
    public ResponseEntity<String> resetPasswords(@RequestParam String token, @RequestBody ForgotPassword forgotPassword) {
        String message = userMasterService.resetPassword(token, forgotPassword);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

}
