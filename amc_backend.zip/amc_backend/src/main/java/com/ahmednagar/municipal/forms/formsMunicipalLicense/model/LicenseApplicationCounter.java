package com.ahmednagar.municipal.forms.formsMunicipalLicense.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_application_counter")
public class LicenseApplicationCounter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "counter_name")
    private String counterName;

    @Column(name = "counter_value")
    private int counterValue;

}
