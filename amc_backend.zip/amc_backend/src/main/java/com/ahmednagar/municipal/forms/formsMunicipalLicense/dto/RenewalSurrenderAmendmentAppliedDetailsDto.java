package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import com.ahmednagar.municipal.master.municipalLicence.dto.LicenseFinancialYearMasterDto;
import com.ahmednagar.municipal.master.municipalLicence.dto.MlRateMasterDto;
import com.ahmednagar.municipal.master.municipalLicence.dto.TradeApplicationTypeDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class RenewalSurrenderAmendmentAppliedDetailsDto {
    private int id;
    private MlRateMasterDto mlRateMasterId;
    private LicenseFinancialYearMasterDto fyYearId;
    private TradeApplicationTypeDto applicationTypeId;
    //private ApplicationFromMasterDto applicationMasterId;
    private int prevApplicationMasterId;
    private String prevLicenseNo;
    private String applicationAppliedFor;
    private BigDecimal applicationFee;
    private BigDecimal penalty;
    private BigDecimal denialArrearAmount;
    private BigDecimal totalAmount;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
    private int municipalId;
}
