package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.NewPropertyWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.NewPropertyWorkFlowLevel;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface NewPropertyWorkFlowLevelService {


    NewPropertyWorkFlowLevel handleWorkFlowsTransition(NewPropertyWorkFlowLevel newPropertyWorkFlowLevel);

    NewPropertyWorkFlowLevel createNewApplicationTransation(NewPropertyWorkFlowLevel newPropertyWorkFlowLevelRequest);

    List<NewPropertyWorkFlowLevelDto> getAllNewWorkFlows();

}
