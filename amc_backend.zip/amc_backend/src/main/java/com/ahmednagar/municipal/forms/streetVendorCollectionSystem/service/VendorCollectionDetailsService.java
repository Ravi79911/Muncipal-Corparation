package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionDetail;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public interface VendorCollectionDetailsService {

    VendorCollectionDetail saveCollectionDetail(VendorCollectionDetail vendorCollectionDetail);
    Optional<VendorCollectionDetail> findById(Long id);
    List<VendorCollectionDetail> getDetailsByVendorUserIdAndCreatedDate(Long vendorUserId, LocalDate createdDate);
    List<VendorCollectionDetail> getAllVendorCollectionDetails();
}
