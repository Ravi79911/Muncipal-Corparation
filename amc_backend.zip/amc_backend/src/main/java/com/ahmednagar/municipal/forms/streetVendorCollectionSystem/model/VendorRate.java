package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "Tbl_Vendor_Rate")
public class VendorRate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "fixed_rate")
    private Double fixedRate;

    @Column(name = "rate_in_days")
    private Integer rateInDays;

    @Column(name = "effective_date")
    private LocalDate effectiveDate;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "vendor_mas_id", referencedColumnName = "id")
    private VendorMaster vendorMasId;
}
