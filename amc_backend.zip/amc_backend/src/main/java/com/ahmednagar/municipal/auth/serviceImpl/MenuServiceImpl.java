package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.MenuDto;
import com.ahmednagar.municipal.auth.model.Menu;
import com.ahmednagar.municipal.auth.repository.MenuRepository;
import com.ahmednagar.municipal.auth.service.MenuService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MenuServiceImpl implements MenuService {
    @Autowired
    private MenuRepository menuRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Menu saveMenu(Menu menu) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        menu.setCreatedDate(currentDateTime);
        menu.setUpdatedDate(LocalDateTime.now());
        menu.setUpdatedBy(menu.getUpdatedBy() != null ? menu.getUpdatedBy() : 0);
        menu.setSuspendedStatus(menu.getSuspendedStatus() != null ? menu.getSuspendedStatus() : 0);      // 0 means active// 1 means admin
        return menuRepository.saveAndFlush(menu);
    }

    @Override
    public List<MenuDto> findAllMenu() {
        List<Menu> menus = menuRepository.findAll();
        return menus.stream()
                .map(menu -> modelMapper.map(menu, MenuDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<MenuDto> findAllMenuByMunicipalId(Long municipalId) {
        List<Menu> menus = menuRepository.findByMunicipalId(municipalId);
        return menus.stream()
                .map(menu -> modelMapper.map(menu, MenuDto.class))
                .collect(Collectors.toList());
    }
    @Override
    public Menu updateMenu(Long id, Menu updatedMenu) {
        Optional<Menu> menuOptional = menuRepository.findById(id);
        if (menuOptional.isPresent()) {
            Menu existingMenu = menuOptional.get();
            existingMenu.setSuspendedStatus(updatedMenu.getSuspendedStatus());
            existingMenu.setMunicipalId(updatedMenu.getMunicipalId());

            return menuRepository.saveAndFlush(existingMenu);
        } else {
            throw new RuntimeException("menu not found with id: " + id);
        }
    }

    @Override
    public Menu changeSuspendedStatus(Long id, int status) {
        Optional<Menu> menuOptional = menuRepository.findById(id);
        if (menuOptional.isPresent()) {
            Menu menu = menuOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            menu.setUpdatedDate(currentDateTime);
            menu.setSuspendedStatus(status);      // 1 means suspended
            menu.setUpdatedBy(menu.getUpdatedBy());
            return menuRepository.saveAndFlush(menu);
        }
        return null;
    }
}
