package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_sub_menu_master")
public class SubMenuMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Size(max = 50, message = "Sub Menu Name must be less than or equal to 50 characters")
    @Column(name = "sub_menu_name")
    private String subMenuName;

    @Size(max = 100, message = "UI Page URL must be less than or equal to 100 characters")
    @Column(name = "ui_page_url")
    private String uiPageUrl;

    @Size(max = 100, message = "Get Method URL must be less than or equal to 100 characters")
    @Column(name = "get_method_url")
    private String getMethodUrl;

    @Size(max = 100, message = "Post Method URL must be less than or equal to 100 characters")
    @Column(name = "post_method_url")
    private String postMethodUrl;

    @Size(max = 100, message = "Update Method URL must be less than or equal to 100 characters")
    @Column(name = "update_method_url")
    private String updateMethodUrl;

    @Size(max = 100, message = "Delete Method URL must be less than or equal to 100 characters")
    @Column(name = "delete_method_url")
    private String deleteMethodUrl;

    @NotNull(message = "Created By cannot be null")
    @Min(value = 1, message = "Created By must be a positive integer")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Min(value = 1, message = "Updated By must be a positive integer")
    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Min(value = 0, message = "Suspended Status must be a non-negative integer")
    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID cannot be null")
    @Column(name = "municipal_id")
    private Long municipalId;

//    @OneToMany(mappedBy = "subMenuId",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
//    //@JsonIgnore
//    private Set<SubMenuPermission> subMenuPermissions;

    @ManyToOne
    @JoinColumn(name = "menu_id", nullable = false, referencedColumnName = "id")
    private MenuMaster menuMasterId;

}
