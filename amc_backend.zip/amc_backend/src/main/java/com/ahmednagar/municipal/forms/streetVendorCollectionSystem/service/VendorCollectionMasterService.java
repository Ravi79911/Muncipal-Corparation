package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface VendorCollectionMasterService {

    VendorCollectionMaster saveCollectionMaster(VendorCollectionMaster vendorCollectionMaster);
    List<VendorCollectionMaster> getAllCollectionMaster();
    Optional<VendorCollectionMaster> deleteCollectionMaster(Long id);

}
