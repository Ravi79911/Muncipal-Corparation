package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingPaymentCollectionMasterDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingPaymentCollectionMaster;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingPaymentCollectionMasterRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingPaymentCollectionMasterService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingPaymentCollectionMasterServiceImpl implements HoardingPaymentCollectionMasterService {
    @Autowired
    private HoardingPaymentCollectionMasterRepository hoardingPaymentCollectionMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingPaymentCollectionMaster saveHoardingPaymentCollectionMaster(HoardingPaymentCollectionMaster hoardingPaymentCollectionMaster) {
        hoardingPaymentCollectionMaster.setCreatedDate(LocalDateTime.now());
        hoardingPaymentCollectionMaster.setUpdatedDate(LocalDateTime.now());
        hoardingPaymentCollectionMaster.setUpdatedBy(hoardingPaymentCollectionMaster.getUpdatedBy() != null ? hoardingPaymentCollectionMaster.getUpdatedBy() : 0);
        hoardingPaymentCollectionMaster.setSuspendedStatus(hoardingPaymentCollectionMaster.getSuspendedStatus() != null ? hoardingPaymentCollectionMaster.getSuspendedStatus() : 0);

        return hoardingPaymentCollectionMasterRepository.save(hoardingPaymentCollectionMaster);

    }

    @Override
    public List<HoardingPaymentCollectionMasterDto> findAllHoardingPaymentCollectionMaster() {
        List<HoardingPaymentCollectionMaster> hoardingPaymentCollectionMasters = hoardingPaymentCollectionMasterRepository.findAll();
        return hoardingPaymentCollectionMasters.stream()
                .map(hoardingPaymentCollectionMaster -> modelMapper.map(hoardingPaymentCollectionMaster, HoardingPaymentCollectionMasterDto.class))
                .collect(Collectors.toList());
    }
    @Override
    public HoardingPaymentCollectionMaster findById(Long id) {
        Optional<HoardingPaymentCollectionMaster> hoardingPaymentCollectionMaster=hoardingPaymentCollectionMasterRepository.findById(id);
        return hoardingPaymentCollectionMaster.orElse(null);

    }

    @Override
    public List<HoardingPaymentCollectionMaster> findAllByMunicipalId(int municipalId) {
        return hoardingPaymentCollectionMasterRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingPaymentCollectionMaster updateHoardingPaymentCollectionMaster(Long id, HoardingPaymentCollectionMaster updatedHoardingPaymentCollectionMaster, int updatedBy) {
        Optional<HoardingPaymentCollectionMaster> hoardingPaymentCollectionMasterOptional = hoardingPaymentCollectionMasterRepository.findById(id);
        if (hoardingPaymentCollectionMasterOptional.isPresent()) {
            HoardingPaymentCollectionMaster existingHoardingPaymentCollectionMaster = hoardingPaymentCollectionMasterOptional.get();
            //existingHoardingPaymentCollectionMaster.setHoardingCategoryTypeName(updatedHoardingPaymentCollectionMaster.getHoardingCategoryTypeName());
            existingHoardingPaymentCollectionMaster.setUpdatedBy(updatedBy);
            existingHoardingPaymentCollectionMaster.setUpdatedDate(LocalDateTime.now());
            return hoardingPaymentCollectionMasterRepository.saveAndFlush(existingHoardingPaymentCollectionMaster);
        } else {
            throw new RuntimeException("hoardingPaymentCollectionMaster not found with id: " + id);
        }
    }

    @Override
    public HoardingPaymentCollectionMaster changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingPaymentCollectionMaster> hoardingPaymentCollectionMasterOpt = hoardingPaymentCollectionMasterRepository.findById(id);
        if (hoardingPaymentCollectionMasterOpt.isPresent()) {
            HoardingPaymentCollectionMaster hoardingPaymentCollectionMaster = hoardingPaymentCollectionMasterOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingPaymentCollectionMaster.setUpdatedDate(currentDateTime);
            hoardingPaymentCollectionMaster.setSuspendedStatus(status);      // 1 means suspended
            hoardingPaymentCollectionMaster.setUpdatedBy(updatedBy);
            return hoardingPaymentCollectionMasterRepository.saveAndFlush(hoardingPaymentCollectionMaster);
        }
        return null;
    }
}
