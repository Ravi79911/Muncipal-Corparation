package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PropertyDemandTransactionMasterDto {

    private Long id;
    private int propertyMasId;
    private String transactionNo;
    private LocalDate transactionDate;
    private float amount;
    private String rebatesAny;
    private String penaltyCalcuAny;
    private LocalDate penaltyDurationFrom;
    private LocalDate penaltyDurationUpto;
    private LocalDate collectDemandIdFrom;
    private LocalDate collectDemandIdUpto;
    private String transactionTypeCashChequeOnline;
    private String bankReconciliationStatus;
    private String paymentStatusPaidBal;
    private String remarksAny;
    private String bankReconcileId;
    private String reconciliationStatus;
    private int municipalId;
    private int createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;
}
