package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationFromMasterDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFromMaster;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationFromMasterRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationFromMasterService;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.utils.TradeLicenseApplicationNumberGenerator;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ApplicationFromMasterServiceImpl implements ApplicationFromMasterService {

    @Autowired
    private ApplicationFromMasterRepository applicationFromMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ApplicationFromMaster saveapplicationFromMasterService(ApplicationFromMaster applicationFromMaster, int createdBy) {
        // Generate application number
       // String generatedApplicationNumber = ApplicationNumberGenerator.generateApplicationNo(applicationFromMaster.getApplicationTypeId().intValue());

        String generatedApplicationNumber = TradeLicenseApplicationNumberGenerator.generateApplicationNo(applicationFromMaster.getApplicationTypeId().getId());
        applicationFromMaster.setApplicationNo(generatedApplicationNumber);
        if (applicationFromMaster.getCreatedDate() == null) {
            applicationFromMaster.setApplicationDate(LocalDateTime.now());
            applicationFromMaster.setCreatedDate(LocalDateTime.now());
        }
        return applicationFromMasterRepository.saveAndFlush(applicationFromMaster);
    }

    //    @Override
//    public List<ApplicationFromMasterDto> findAllApplicationFromMaster() {
//        List<ApplicationFromMaster> applicationFromMasters = applicationFromMasterRepository.findAll();
//        return applicationFromMasters.stream()
//                .map(applicationFromMaster -> modelMapper.map(applicationFromMaster, ApplicationFromMasterDto.class))
//                .collect(Collectors.toList());
//    }
//    @Override
//    public List<ApplicationFromMaster> findAllActiveApplicationFromMaster(Integer status) {
//        return applicationFromMasterRepository.findBySuspendedStatus(status);
//    }
    @Override
    public ApplicationFromMaster findApplicationFromMasterById(Long id) {
        Optional<ApplicationFromMaster> applicationFromMaster = applicationFromMasterRepository.findById(id);
        return applicationFromMaster.orElse(null);

    }

    @Override
    public List<ApplicationFromMasterDto> findAllApplicationFromMasterByMunicipalId(int municipalId) {
        List<ApplicationFromMaster> applicationFromMasters = applicationFromMasterRepository.findByMunicipalId(municipalId);
        return applicationFromMasters.stream()
                .map(applicationFromMaster -> modelMapper.map(applicationFromMaster, ApplicationFromMasterDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public ApplicationFromMaster updateApplicationFromMaster(Long id, ApplicationFromMaster updatedApplicationFromMaster, int updatedBy) {
        Optional<ApplicationFromMaster> applicationFromMasterOptional = applicationFromMasterRepository.findById(id);
        if (applicationFromMasterOptional.isPresent()) {
            ApplicationFromMaster existingApplicationFromMaster = applicationFromMasterOptional.get();
            existingApplicationFromMaster.setSuspendedStatus(updatedApplicationFromMaster.getSuspendedStatus());
            existingApplicationFromMaster.setMunicipalId(updatedApplicationFromMaster.getMunicipalId());

            return applicationFromMasterRepository.saveAndFlush(updatedApplicationFromMaster);
        } else {
            throw new RuntimeException("app application Details not found with id: " + id);
        }
    }

    @Override
    public ApplicationFromMaster changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<ApplicationFromMaster> applicationFromMasterOptional = applicationFromMasterRepository.findById(id);
        if (applicationFromMasterOptional.isPresent()) {
            ApplicationFromMaster applicationFromMaster = applicationFromMasterOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            applicationFromMaster.setSuspendedStatus(status);      // 1 means suspended
            return applicationFromMasterRepository.saveAndFlush(applicationFromMaster);
        }
        return null;
    }
}
