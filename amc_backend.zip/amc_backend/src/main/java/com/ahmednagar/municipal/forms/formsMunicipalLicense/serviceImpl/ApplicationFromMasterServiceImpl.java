package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationFromMasterDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFirmDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFromMaster;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationFromMasterRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationFromMasterService;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.utils.TradeLicenseApplicationNumberGenerator;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ApplicationFromMasterServiceImpl implements ApplicationFromMasterService {

    @Autowired
    private ApplicationFromMasterRepository applicationFromMasterRepository;

    @Autowired
    private TradeLicenseApplicationNumberGenerator tradeLicenseApplicationNumberGenerator;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ApplicationFromMaster saveapplicationFromMasterService(ApplicationFromMaster applicationFromMaster) {
        // Generate application number
       // String generatedApplicationNumber = ApplicationNumberGenerator.generateApplicationNo(applicationFromMaster.getApplicationTypeId().intValue());

        String generatedApplicationNumber = tradeLicenseApplicationNumberGenerator.generateApplicationNo(applicationFromMaster.getApplicationTypeId().getId());
        applicationFromMaster.setApplicationNo(generatedApplicationNumber);
            applicationFromMaster.setApplicationDate(LocalDate.now());
            applicationFromMaster.setCreatedDate(LocalDateTime.now());

        return applicationFromMasterRepository.saveAndFlush(applicationFromMaster);
    }

        @Override
    public List<ApplicationFromMasterDto> findAllApplicationFromMaster() {
        List<ApplicationFromMaster> applicationFromMasters = applicationFromMasterRepository.findAll();
        return applicationFromMasters.stream()
                .map(applicationFromMaster -> modelMapper.map(applicationFromMaster, ApplicationFromMasterDto.class))
                .collect(Collectors.toList());
    }

//    @Override
//    public List<ApplicationFromMaster> findAllActiveApplicationFromMaster(Integer status) {
//        return applicationFromMasterRepository.findBySuspendedStatus(status);
//    }
    @Override
    public ApplicationFromMaster findApplicationFromMasterById(Long id) {
        Optional<ApplicationFromMaster> applicationFromMaster = applicationFromMasterRepository.findById(id);
        return applicationFromMaster.orElse(null);

    }

    @Override
    public List<ApplicationFromMasterDto> findAllApplicationFromMasterByMunicipalId(int municipalId) {
        List<ApplicationFromMaster> applicationFromMasters = applicationFromMasterRepository.findByMunicipalId(municipalId);
        return applicationFromMasters.stream()
                .map(applicationFromMaster -> modelMapper.map(applicationFromMaster, ApplicationFromMasterDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public ApplicationFromMaster updateApplicationFromMaster(Long id, ApplicationFromMaster updatedApplicationFromMaster, int updatedBy) {
        Optional<ApplicationFromMaster> applicationFromMasterOptional = applicationFromMasterRepository.findById(id);
        if (applicationFromMasterOptional.isPresent()) {
            ApplicationFromMaster existingApplicationFromMaster = applicationFromMasterOptional.get();
            existingApplicationFromMaster.setFirmTypeId(updatedApplicationFromMaster.getFirmTypeId());
            existingApplicationFromMaster.setPermissesOwnershipId(updatedApplicationFromMaster.getPermissesOwnershipId());
            existingApplicationFromMaster.setBusinessCatId(updatedApplicationFromMaster.getBusinessCatId());
            existingApplicationFromMaster.setSuspendedStatus(updatedApplicationFromMaster.getSuspendedStatus());
            existingApplicationFromMaster.setMunicipalId(updatedApplicationFromMaster.getMunicipalId());

            return applicationFromMasterRepository.saveAndFlush(existingApplicationFromMaster);
        } else {
            throw new RuntimeException("app application Details not found with id: " + id);
        }
    }

    @Override
    public ApplicationFromMaster changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<ApplicationFromMaster> applicationFromMasterOptional = applicationFromMasterRepository.findById(id);
        if (applicationFromMasterOptional.isPresent()) {
            ApplicationFromMaster applicationFromMaster = applicationFromMasterOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            applicationFromMaster.setSuspendedStatus(status);      // 1 means suspended
            return applicationFromMasterRepository.saveAndFlush(applicationFromMaster);
        }
        return null;
    }

    @Transactional
    @Override
    public void deleteApplicationFromMasterById(Long id) {
        applicationFromMasterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ApplicationFromMaster", "id", id));
        applicationFromMasterRepository.deleteById(id);
    }
}
