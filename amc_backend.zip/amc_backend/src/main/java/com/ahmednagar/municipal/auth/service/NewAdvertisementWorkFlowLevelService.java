package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.NewAdvertisementWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.NewAdvertisementWorkFlowLevel;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface NewAdvertisementWorkFlowLevelService {

    NewAdvertisementWorkFlowLevel handleWorkFlowTransition(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevel);

    List<NewAdvertisementWorkFlowLevelDto> findAllWorkFlow();

    NewAdvertisementWorkFlowLevel createNewApplicationTransation(NewAdvertisementWorkFlowLevel newAdvertisementWorkFlowLevelRequest);

}
