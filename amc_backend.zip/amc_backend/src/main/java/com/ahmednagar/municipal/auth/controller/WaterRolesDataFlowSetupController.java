package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.WaterRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.WaterRolesDataFlowSetup;
import com.ahmednagar.municipal.auth.service.WaterRolesDataFlowSetupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/water/roles/data/flow/setup")
public class WaterRolesDataFlowSetupController {

    @Autowired
    private WaterRolesDataFlowSetupService waterRolesDataFlowSetupService;

    @GetMapping("/getAllRole")
    public ResponseEntity<List<WaterRolesDataFlowSetupDto>> getAllRolesDataFlowSetup() {
        List<WaterRolesDataFlowSetupDto> role = waterRolesDataFlowSetupService.findAllRolesDataFlowSetup();
        return ResponseEntity.ok(role);
    }

    @GetMapping("/document/verification/accept/next-role")
    public ResponseEntity<?> getNextRoleIdForDocumentVerificationAccept(@RequestParam Long currentRoleId,@RequestParam Long statusCode, @RequestParam Integer isActive) {
        WaterRolesDataFlowSetup waterRolesDataFlowSetup = waterRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRoleId, statusCode, isActive);
        return ResponseEntity.ok(waterRolesDataFlowSetup);

    }

    @GetMapping("/document/verification/reject/next-role")
    public ResponseEntity<List<WaterRolesDataFlowSetup>> getNextRoleIdForDocumentVerificationReject(@RequestParam Long currentRoleId, @RequestParam Long statusCode, @RequestParam Integer isActive) {
        List<WaterRolesDataFlowSetup> nextRoles = waterRolesDataFlowSetupService.getNextRoleListForListSelection(currentRoleId, statusCode, isActive);
        return ResponseEntity.ok(nextRoles);
    }

}
