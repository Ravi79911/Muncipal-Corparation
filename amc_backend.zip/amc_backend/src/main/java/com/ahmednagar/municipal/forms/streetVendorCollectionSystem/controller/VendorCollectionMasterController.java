package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;


import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionMaster;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorCollectionMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorCollectionMasterController {

    @Autowired
    private VendorCollectionMasterService vendorCollectionMasterService;

    @PostMapping("/saveCollectionMaster")
    public ResponseEntity<VendorCollectionMaster> createCollectionMaster(@RequestBody VendorCollectionMaster vendorCollectionMaster) {
        return ResponseEntity.ok(vendorCollectionMasterService.saveCollectionMaster(vendorCollectionMaster));
    }

    @GetMapping("/getAllCollectionMaster")
    public ResponseEntity<List<VendorCollectionMaster>> getAllCollectionMaster() {
        return ResponseEntity.ok(vendorCollectionMasterService.getAllCollectionMaster());
    }

    @PatchMapping("/deleteCollectionMaster/{id}")
    public ResponseEntity<Optional<VendorCollectionMaster>> deleteCollectionMaster(@PathVariable Long id) {
        return ResponseEntity.ok(vendorCollectionMasterService.deleteCollectionMaster(id));
    }
}
