package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_user_password_change_history")
public class UserPasswordChangeHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "Last password change cannot be blank")
    @Size(max = 50, message = "Last password change must not exceed 50 characters")
    @Column(name = "last_pwdchange", length = 50, nullable = false)
    private String lastPwdChange;

    @Column(name = "pwd_changed_datetime", nullable = false)
    private LocalDateTime pwdChangedDateTime;

    @NotBlank(message = "IP address cannot be blank")
    @Size(max = 150, message = "IP address must not exceed 150 characters")
    @Column(name = "ip_address", length = 150, nullable = false)
    private String ipAddress;

    @Min(value = 1, message = "created by must be a positive number")
    @Column(name = "created_by", nullable = false)
    private int createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date", nullable = false)
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status", nullable = false)
    @Min(value = 0, message = "suspended status must be 0 (inactive) or 1 (active)")
    @Max(value = 1, message = "suspended status must be 0 (inactive) or 1 (active)")
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id", nullable = false)
    private Long municipalId;

    @ManyToOne
    @JoinColumn(name = "user_id",nullable = false,referencedColumnName = "id")
    private UserDetails userId;
}

