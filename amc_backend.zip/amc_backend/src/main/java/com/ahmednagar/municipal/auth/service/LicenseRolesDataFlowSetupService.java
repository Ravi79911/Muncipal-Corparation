package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.LicenseRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.LicenseRolesDataFlowSetup;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface LicenseRolesDataFlowSetupService {

    List<LicenseRolesDataFlowSetupDto> findAllRolesDataFlowSetup();

    List<LicenseRolesDataFlowSetup> getNextRoleListForListSelection(Long currentRoleId, Long statusCode, Integer isActive);

    LicenseRolesDataFlowSetup getNextRoleForSingleSelection(Long currentRoleId, Long statusCode, Integer isActive);

}
