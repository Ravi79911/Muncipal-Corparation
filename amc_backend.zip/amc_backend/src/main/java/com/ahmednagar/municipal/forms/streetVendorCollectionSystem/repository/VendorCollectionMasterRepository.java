package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface VendorCollectionMasterRepository extends JpaRepository<VendorCollectionMaster, Long> {

    List<VendorCollectionMaster> findBySuspendedStatus(int suspendedStatus);
}
