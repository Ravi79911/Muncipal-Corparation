package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;



import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorZone;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorZoneWard;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorZoneRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorZoneWardRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorZoneWardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VendorZoneWardServiceImpl implements VendorZoneWardService {

    @Autowired
    private VendorZoneWardRepository vendorZoneWardRepository;


    @Override
    public List<VendorZoneWard> getByZoneWardByZoneId(Long zoneId) {
        return vendorZoneWardRepository.findByZoneMasId(zoneId);
    }
}
