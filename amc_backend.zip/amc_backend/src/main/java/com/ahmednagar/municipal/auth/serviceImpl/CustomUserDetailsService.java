package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.UserMaster;
import com.ahmednagar.municipal.auth.repository.UserMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    UserMasterRepository userMasterRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//        UserMaster userMaster = userMasterRepository.findByEmail(username).orElseThrow(() -> new RuntimeException("user not found with username: " + username));
//        return userMaster;

        // first check if the username is an email
        UserMaster userMaster = userMasterRepository.findByEmail(username)
                .orElse(null);

        // if not found by email, check if it's a mobile number
        if (userMaster == null) {
            userMaster = userMasterRepository.findByMobileNo(username)
                    .orElseThrow(() -> new UsernameNotFoundException("user not found with username (email or mobile): " + username));
        }

        // since roleMaster is a single object, no need to use stream.
        // directly get the role name
        String roleName = userMaster.getRoleMaster().getRoleName();

        // map the roles associated with the user (in this case, a single role)
        List<GrantedAuthority> authorities = Collections.singletonList(new SimpleGrantedAuthority(roleName));

        // return a Spring Security User object with authorities (roles)
        return new User(userMaster.getEmail(), userMaster.getPassword(), authorities);
    }

}
