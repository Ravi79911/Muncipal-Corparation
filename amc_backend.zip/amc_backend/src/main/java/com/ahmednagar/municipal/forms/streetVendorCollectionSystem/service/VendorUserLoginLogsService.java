package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorUserLoginLogs;
import org.springframework.stereotype.Service;

@Service
public interface VendorUserLoginLogsService {

    VendorUserLoginLogs saveUserLoginLogs(VendorUserLoginLogs vendorUserLoginLogs);
}
