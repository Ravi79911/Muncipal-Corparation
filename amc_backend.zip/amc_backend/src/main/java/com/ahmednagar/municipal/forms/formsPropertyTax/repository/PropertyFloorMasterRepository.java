package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyFloorMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface PropertyFloorMasterRepository extends JpaRepository<PropertyFloorMaster, Long> {

    List<PropertyFloorMaster> findByMunicipalId(int municipalId);

}
