package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationPermisesDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationPermisesDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationPermisesDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/forms/license/ApplicationPeremisesDetails")
public class ApplicationPermisesDetailsController {

    @Autowired
    private ApplicationPermisesDetailsService applicationPermisesDetailsService;

    //create AppApplicantDetails
    @PostMapping("/create")
    public ResponseEntity<ApplicationPermisesDetails> createApplicationPermisesDetails(@Valid @RequestBody ApplicationPermisesDetails applicationPermisesDetails, @RequestParam int createdBy){
        ApplicationPermisesDetails createdApplicationPermisesDetails=applicationPermisesDetailsService.saveApplicationPermisesDetails(applicationPermisesDetails,1);
        if(createdApplicationPermisesDetails==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdApplicationPermisesDetails);
    }
//    //for all admin users
//    @GetMapping("/all")
//    public ResponseEntity<List<ApplicationPermisesDetailsDto>> getAllApplicationPermisesDetails(){
//        List<ApplicationPermisesDetailsDto> applicationPermisesDetails=applicationPermisesDetailsService.findAllApplicationPermisesDetails();
//        return ResponseEntity.ok(applicationPermisesDetails);
//    }
//
//    //for active users
//    @GetMapping("/active")
//    public ResponseEntity<List<ApplicationPermisesDetails>> getAllActiveApplicationPermisesDetails(@RequestParam(required = false, defaultValue = "0") Integer status){
//        List<ApplicationPermisesDetails> activeApplicationPermisesDetails=applicationPermisesDetailsService.findAllActiveApplicationPermisesDetails(status);
//        return ResponseEntity.ok(activeApplicationPermisesDetails);
//
//    }
    //  to get the Application Details by id for user
    @GetMapping("/get/{id}")
    public ResponseEntity<ApplicationPermisesDetails> getApplicationDetailsById(@PathVariable Long id){
        ApplicationPermisesDetails applicationPermisesDetails=applicationPermisesDetailsService.findAppApplicationPermisesDetailsById(id);
        return ResponseEntity.ok(applicationPermisesDetails);
    }

    //get Application Fee Pay By MunicipalId
    @GetMapping("/Municipal/{municipalId}")
    public ResponseEntity<?> getAllApplicationPermisesDetailsByMunicipalId(@PathVariable int municipalId){
        List<ApplicationPermisesDetailsDto> applicationPermisesDetails=applicationPermisesDetailsService.findAllApplicationPermisesDetailsByMunicipalId(municipalId);
        if (applicationPermisesDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No ApplicationPermisesDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(applicationPermisesDetails);
    }
    //     Update AppApplication Details From for admin
    @PutMapping("/updated/{id}")
    public ResponseEntity<ApplicationPermisesDetails> updateApplicationPermisesDetails(@PathVariable("id") Long id, @RequestBody ApplicationPermisesDetails updatedApplicationPermisesDetails){
        try{
            ApplicationPermisesDetails updated=applicationPermisesDetailsService.updateApplicationPermisesDetails(id,updatedApplicationPermisesDetails,1);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete AppApplication Details for admin
    @PatchMapping("/delete/{id}")
    public ResponseEntity<ApplicationPermisesDetails> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status, int updatedBy) {
        ApplicationPermisesDetails updatedApplicationPermisesDetails = applicationPermisesDetailsService.changeSuspendedStatus(id, status, 1);         // updatedBy is always 1 for now as it is the admin
        if (updatedApplicationPermisesDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedApplicationPermisesDetails);
    }

    @DeleteMapping("/deleteApplicationPermisesDetails/{applicationMasterId}")
    public ResponseEntity<String> deleteApplicationPermisesDetails(@PathVariable Long applicationMasterId) {
        try {
            applicationPermisesDetailsService.deleteApplicationPermisesDetailsByApplicationMasterId(applicationMasterId);
            return ResponseEntity.ok("ApplicationPermisesDetails details records deleted successfully for MunicipalPropertyMaster id: " + applicationMasterId);
        } catch (Exception ex) {
            return ResponseEntity.status(500).body("An unexpected error occurred: " + ex.getMessage());
        }
    }

}
