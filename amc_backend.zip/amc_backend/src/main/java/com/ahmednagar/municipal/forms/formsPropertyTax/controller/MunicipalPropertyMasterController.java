package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.exception.ApiException;
import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.MunicipalPropertyMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RequestMapping("/forms")
@RestController
@CrossOrigin
public class MunicipalPropertyMasterController {

    @Autowired
    MunicipalPropertyMasterService municipalPropertyMasterService;

    @PostMapping("/createPropertyMaster")
    public ResponseEntity<ApiResponse> createPropertyMasters(@Valid @RequestBody MunicipalPropertyMaster municipalPropertyMaster) {
        try {
            MunicipalPropertyMaster newPropertyMaster = municipalPropertyMasterService.createPropertyMaster(municipalPropertyMaster);
            return ResponseEntity.ok(new ApiResponse("Property master created successfully!", true, newPropertyMaster));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An internal error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/updatePropertyMaster/{id}")
    public ResponseEntity<ApiResponse> updatePropertyMasters(@PathVariable Long id, @Valid @RequestBody MunicipalPropertyMaster updatedPropertyMaster) {
        try {
            MunicipalPropertyMaster updatedEntity = municipalPropertyMasterService.updatePropertyMaster(id, updatedPropertyMaster);
            return ResponseEntity.ok(new ApiResponse("Property master updated successfully!", true, updatedEntity));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An internal error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getPropertyMasterByApplicationNo/{applicationNo}")
    public List<MunicipalPropertyMaster> findByPropertyApplicationNumbers(@PathVariable String applicationNo) {
        return municipalPropertyMasterService.getPropertyMasterByApplicationNumber(applicationNo);
    }

    @GetMapping("/getAllPropertyMaster")
    public List<MunicipalPropertyMaster> getAllPropertyMaster() {
        return municipalPropertyMasterService.getAllPropertyMaster();
    }

    @GetMapping("/propertyMaster/{id}")
    public ResponseEntity<Object> getMunicipalPropertyMasterById(@PathVariable Long id) {
        Optional<MunicipalPropertyMaster> municipalProperty = municipalPropertyMasterService.getMunicipalPropertyMasterById(id);
        if (municipalProperty.isPresent()) {
            return ResponseEntity.ok(municipalProperty.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getMunicipalPropertyMasterByMunicipalId/{municipalId}")
    public List<MunicipalPropertyMaster> getMunicipalPropertyMasterByMunicipalId(@PathVariable int municipalId) {
        return municipalPropertyMasterService.getByMunicipalId(municipalId);
    }

    @GetMapping("/checkPropertyHoldingNo")
    public ResponseEntity<Boolean> checkHoldingNoExists(@RequestParam String holdingNo) {
        boolean holdingNumberExists = municipalPropertyMasterService.isHoldingNoExists(holdingNo);
        return ResponseEntity.ok(holdingNumberExists);
    }

    @GetMapping("/getPropertyByZoneWardHoldingNo")
    public ResponseEntity<List<MunicipalPropertyMaster>> getPropertyByZoneWardHoldingNo(@RequestParam Long zoneId, @RequestParam Long zoneWard,
                                                                                        @RequestParam String holdingNo) {
        List<MunicipalPropertyMaster> properties = municipalPropertyMasterService.getByZoneWardHoldingNo(zoneId, zoneWard, holdingNo);
        return ResponseEntity.ok(properties);
    }

    @PatchMapping("/municipalPropertyMaster/suspendedStatus/{id}")
    public ResponseEntity<MunicipalPropertyMaster> patchMunicipalPropertyMasterSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        MunicipalPropertyMaster patchedMunicipalPropertyMaster = municipalPropertyMasterService.patchMunicipalPropertyMasterSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedMunicipalPropertyMaster);
    }

    @DeleteMapping("/deletePropertyMasterById/{id}")
    public ResponseEntity<ApiResponse> deletePropertyMaster(@PathVariable Long id) {
        try {
            municipalPropertyMasterService.deletePropertyMasterById(id);
            ApiResponse apiResponse = new ApiResponse("property master deleted successfully", true, LocalDateTime.now(), "SUCCESS", null, null);
            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (ResourceNotFoundException ex) {
            ApiResponse apiResponse = new ApiResponse(ex.getMessage(), false, LocalDateTime.now(), "RESOURCE_NOT_FOUND", null, null);
            return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            throw new ApiException("Error occurred while deleting property master");
        }
    }

}
