package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.MunicipalPropertyMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/forms")
@RestController
@CrossOrigin
public class MunicipalPropertyMasterController {

    @Autowired
    MunicipalPropertyMasterService municipalPropertyMasterService;

    @PostMapping("/createPropertyMaster")
    public ResponseEntity<MunicipalPropertyMaster> createPropertyMasters(@Valid @RequestBody MunicipalPropertyMaster municipalPropertyMaster) {
        MunicipalPropertyMaster newPropertyMaster = municipalPropertyMasterService.createPropertyMaster(municipalPropertyMaster);
        return ResponseEntity.ok(newPropertyMaster);
    }

    @GetMapping("/getPropertyMasterByApplicationNo/{applicationNo}")
    public List<MunicipalPropertyMaster> findByPropertyApplicationNumbers(@PathVariable String applicationNo) {
        return municipalPropertyMasterService.getPropertyMasterByApplicationNumber(applicationNo);
    }

    @GetMapping("/getAllPropertyMaster")
    public List<MunicipalPropertyMaster> getAllPropertyMaster() {
        return municipalPropertyMasterService.getAllPropertyMaster();
    }

    @GetMapping("/propertyMaster/{id}")
    public ResponseEntity<Object> getMunicipalPropertyMasterById(@PathVariable Long id) {
        Optional<MunicipalPropertyMaster> municipalProperty = municipalPropertyMasterService.getMunicipalPropertyMasterById(id);
        if (municipalProperty.isPresent()) {
            return ResponseEntity.ok(municipalProperty.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getMunicipalPropertyMasterByMunicipalId/{municipalId}")
    public List<MunicipalPropertyMaster> getMunicipalPropertyMasterByMunicipalId(@PathVariable int municipalId) {
        return municipalPropertyMasterService.getByMunicipalId(municipalId);
    }

    @GetMapping("/getPropertyByZoneWardHoldingNo")
    public ResponseEntity<List<MunicipalPropertyMaster>> getPropertyByZoneWardHoldingNo(@RequestParam Long zoneId, @RequestParam Long zoneWard,
                                                                                        @RequestParam String holdingNo) {
        List<MunicipalPropertyMaster> properties = municipalPropertyMasterService.getByZoneWardHoldingNo(zoneId, zoneWard, holdingNo);
        return ResponseEntity.ok(properties);
    }

    @PatchMapping("/municipalPropertyMaster/suspendedStatus/{id}")
    public ResponseEntity<MunicipalPropertyMaster> patchMunicipalPropertyMasterSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        MunicipalPropertyMaster patchedMunicipalPropertyMaster = municipalPropertyMasterService.patchMunicipalPropertyMasterSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedMunicipalPropertyMaster);
    }

}
