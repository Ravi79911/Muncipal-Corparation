package com.ahmednagar.municipal.auth.model;

import com.ahmednagar.municipal.master.waterManagement.modal.ApplicationType;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "tbl4_view_new_connection_form_Master")
public class ViewNewWaterConnectionFormMaster {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "id")
        private Long id;

        @Size(max = 150, message = "Consumer number cannot exceed 150 characters")
        @Column(name = "consumer_number", nullable = false)
        private String consumerNumber;

        @Column(name = "entry_date", nullable = false)
        private LocalDate entryDate;

        @Size(max = 50, message = "Status cannot exceed 50 characters")
        @Column(name = "status", nullable = false)
        private String status;

        @Size(max = 200, message = "Auto-generated form number cannot exceed 200 characters")
        @Column(name = "application_number", nullable = false)
        private String applicationNumber;

        @Column(name = "is_working_meter", nullable = false)
        private int isWorkingMeter;

        @Digits(integer = 20, fraction = 2, message = "Fixed unit (KL) must be a valid decimal number")
        @Column(name = "fixed_unit_kl", nullable = false)
        private BigDecimal fixedUnitKl;

        @Digits(integer = 20, fraction = 2, message = "Fixed unit (GAL) must be a valid decimal number")
        @Column(name = "fixed_unit_gal", nullable = false)
        private BigDecimal fixedUnitGal;

        @Column(name = "category_type", nullable = false)  // should map to category type masters at the time of calculation
        private int categoryType;

        @Column(name = "is_regularization", nullable = false)
        private int isRegularization;

        @Size(max = 50, message = "Apply from cannot exceed 50 characters")
        @Column(name = "apply_from")
        private String applyFrom;

        @Size(max = 200, message = "Connection through cannot exceed 200 characters")
        @Column(name = "connection_through", nullable = false)
        private String connectionThrough;

        @Column(name = "rate_id", nullable = false)
        private int rateId;

        @NotNull(message = "Created by is required")
        @Column(name = "created_by")
        private int createdBy;

        @Column(name = "created_date")
        private LocalDateTime createdDate;

        @Column(name = "suspended_status")
        private Integer suspendedStatus;

        @NotNull(message = "Municipal ID is required")
        @Column(name = "municipal_id", nullable = false)
        private int municipalId;

        @Column(name = "fy_id")
        private Long fin_id;

        @Column(name = "ferual_type_id")
        private Long pipelineTypeId;

        @ManyToOne
        @JoinColumn(name = "application_type_id",referencedColumnName = "application_type_id", nullable = false)
        private ViewWaterApplicationTypeMasters viewWaterApplicationTypeMasters;

        @Column(name = "water_disconnection_reason_id")
        private Long ddWaterDisconnectionReasonId;

        @Column(name = "remarks")
        private String remarks;

        @ToString.Exclude
        @OneToMany(mappedBy = "viewNewWaterConnectionFormMaster", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
        @JsonManagedReference
        private List<ViewConsumerBasicDetailMaster> viewConsumerBasicDetailMasters=null;

        @ToString.Exclude
        @OneToMany(mappedBy = "viewNewWaterConnectionFormMaster", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
        @JsonManagedReference
        private List<ViewConsumerElectricityDetails> viewConsumerElectricityDetails=null;

        @ToString.Exclude
        @OneToMany(mappedBy = "viewNewWaterConnectionFormMaster", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
        @JsonManagedReference
        private List<ViewConsumerPropertyDetails> viewConsumerPropertyDetails=null;

        @ToString.Exclude
        @OneToMany(mappedBy = "viewNewWaterConnectionFormMaster", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
        @JsonManagedReference
        private List<ViewConsumerDocumentDetails> viewConsumerDocumentDetails=null;

}
