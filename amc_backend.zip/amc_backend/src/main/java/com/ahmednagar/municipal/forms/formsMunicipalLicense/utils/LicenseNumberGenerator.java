package com.ahmednagar.municipal.forms.formsMunicipalLicense.utils;

import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicInteger;

public class LicenseNumberGenerator {

    private static final String NEWLICENSEPREFIX = "AMCNW";
    private static final String TEMPORAYLICENSEPREFIX = "AMCTEM";
    private static final String RENEWLICENSEPREFIX = "AMCRN";
    private static final String SURRENDERLICENSEPREFIX = "AMCSUR";
    private static final String AMENDMENTLICENSEPREFIX = "AMCAMD";

    private static final AtomicInteger counter = new AtomicInteger();

    public static String generateNewLicenseNo(Long applicationTypeId) {
        // Application type ID as two digits
        String applicationTypePart = String.format("%02d", applicationTypeId);

        // Current year and month
        LocalDateTime now = LocalDateTime.now();
        String yearPart = String.format("%02d", now.getYear() % 100); // Last two digits of the year
        String monthPart = String.format("%02d", now.getMonthValue()); // Two-digit month

        // Serial number padded to six digits
        int serialNumber = counter.incrementAndGet();
        String serialNumberPart = String.format("%06d", serialNumber);

        // Concatenate parts to form the application number
        return NEWLICENSEPREFIX + applicationTypePart + yearPart + monthPart + serialNumberPart;
    }

    public static String generateTemporaryLicenseNo(Long applicationTypeId) {
        // Application type ID as two digits
        String applicationTypePart = String.format("%02d", applicationTypeId);

        // Current year and month
        LocalDateTime now = LocalDateTime.now();
        String yearPart = String.format("%02d", now.getYear() % 100); // Last two digits of the year
        String monthPart = String.format("%02d", now.getMonthValue()); // Two-digit month

        // Serial number padded to six digits
        int serialNumber = counter.incrementAndGet();
        String serialNumberPart = String.format("%06d", serialNumber);

        // Concatenate parts to form the application number
        return TEMPORAYLICENSEPREFIX + applicationTypePart + yearPart + monthPart + serialNumberPart;
    }

    public static String generateRenewLicenseNo(Long applicationTypeId) {
        // Application type ID as two digits
        String applicationTypePart = String.format("%02d", applicationTypeId);

        // Current year and month
        LocalDateTime now = LocalDateTime.now();
        String yearPart = String.format("%02d", now.getYear() % 100); // Last two digits of the year
        String monthPart = String.format("%02d", now.getMonthValue()); // Two-digit month

        // Serial number padded to six digits
        int serialNumber = counter.incrementAndGet();
        String serialNumberPart = String.format("%06d", serialNumber);

        // Concatenate parts to form the application number
        return RENEWLICENSEPREFIX + applicationTypePart + yearPart + monthPart + serialNumberPart;
    }

    public static String generateSurrenderLicenseNo(Long applicationTypeId) {
        // Application type ID as two digits
        String applicationTypePart = String.format("%02d", applicationTypeId);

        // Current year and month
        LocalDateTime now = LocalDateTime.now();
        String yearPart = String.format("%02d", now.getYear() % 100); // Last two digits of the year
        String monthPart = String.format("%02d", now.getMonthValue()); // Two-digit month

        // Serial number padded to six digits
        int serialNumber = counter.incrementAndGet();
        String serialNumberPart = String.format("%06d", serialNumber);

        // Concatenate parts to form the application number
        return SURRENDERLICENSEPREFIX + applicationTypePart + yearPart + monthPart + serialNumberPart;
    }

    public static String generateAmendmentLicenseNo(Long applicationTypeId) {
        // Application type ID as two digits
        String applicationTypePart = String.format("%02d", applicationTypeId);

        // Current year and month
        LocalDateTime now = LocalDateTime.now();
        String yearPart = String.format("%02d", now.getYear() % 100); // Last two digits of the year
        String monthPart = String.format("%02d", now.getMonthValue()); // Two-digit month

        // Serial number padded to six digits
        int serialNumber = counter.incrementAndGet();
        String serialNumberPart = String.format("%06d", serialNumber);

        // Concatenate parts to form the application number
        return AMENDMENTLICENSEPREFIX + applicationTypePart + yearPart + monthPart + serialNumberPart;
    }
}

