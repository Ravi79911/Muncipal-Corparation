package com.ahmednagar.municipal.forms.formsMunicipalLicense.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb3_license_workflow_history")
public class LicenseWorkflowHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    //@NotNull(message = "Application Master ID cannot be null")
    @Column(name = "application_master_id")
    private Long applicationMasterId;

    //@NotNull(message = "Current Stage cannot be null")
    @Size(max = 50, message = "Current Stage cannot exceed 50 characters")
    @Column(name = "current_stage")
    private String currentStage;

    //@NotNull(message = "Status cannot be null")
    @Size(max = 50, message = "Status cannot exceed 50 characters")
    @Column(name = "status")
    private String status;

    @Column(name = "action_taken", nullable = false, length = 50)
    //@NotBlank(message = "Action Taken is required")
    @Size(max = 50, message = "Action Taken cannot exceed 50 characters")
    private String actionTaken;

    @Column(name = "action_by", nullable = false, length = 50)
    @NotBlank(message = "Action By is required")
    @Size(max = 50, message = "Action By cannot exceed 50 characters")
    private String actionBy;

    @Column(name = "action_date")
    @Temporal(TemporalType.TIMESTAMP)
    private LocalDateTime actionDate;

    @Column(name = "comment", nullable = false, length = 250)
    //@NotBlank(message = "Comment is required")
    @Size(max = 250, message = "Comment cannot exceed 250 characters")
    private String comment;

    //@NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private int updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    //@NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private Long municipalId;

    @ManyToOne
    @JoinColumn(name = "application_workflow_id",nullable = false,referencedColumnName = "id")
    private LicenseApplicationWorkflow applicationWorkflowId;

}
