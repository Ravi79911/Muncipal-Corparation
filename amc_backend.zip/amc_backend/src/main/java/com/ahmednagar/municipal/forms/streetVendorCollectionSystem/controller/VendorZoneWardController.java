package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.master.propertyTax.model.ZoneWard;
import com.ahmednagar.municipal.master.propertyTax.service.ZoneWardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorZoneWardController {

    @Autowired
    private ZoneWardService zoneWardService;

    @GetMapping("/getAllZoneWardsByZoneId")
    public ResponseEntity<List<ZoneWard>> getAllZoneWardsByZoneId(Long zoneId) {
        return ResponseEntity.ok(zoneWardService.getByZoneWardByZone(zoneId));
    }
}
