package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.SubMenuDto;
import com.ahmednagar.municipal.auth.model.SubMenu;
import com.ahmednagar.municipal.auth.repository.SubMenuRepository;
import com.ahmednagar.municipal.auth.service.SubMenuService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SubMenuServiceImpl implements SubMenuService {
    @Autowired
    private SubMenuRepository subMenuRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public SubMenu saveSubMenu(SubMenu subMenu) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        subMenu.setCreatedDate(currentDateTime);
        subMenu.setUpdatedDate(LocalDateTime.now());
        subMenu.setUpdatedBy(subMenu.getUpdatedBy() != null ? subMenu.getUpdatedBy() : 0);
        subMenu.setSuspendedStatus(subMenu.getSuspendedStatus() != null ? subMenu.getSuspendedStatus() : 0);      // 0 means active// 1 means admin
        return subMenuRepository.saveAndFlush(subMenu);
    }

    @Override
    public List<SubMenuDto> findAllSubMenu() {
        List<SubMenu> subMenus = subMenuRepository.findAll();
        return subMenus.stream()
                .map(subMenu -> modelMapper.map(subMenu, SubMenuDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<SubMenuDto> findAllSubMenuByMunicipalId(Long municipalId) {
        List<SubMenu> subMenus = subMenuRepository.findByMunicipalId(municipalId);
        return subMenus.stream()
                .map(subMenu -> modelMapper.map(subMenu, SubMenuDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public SubMenu updateSubMenu(Long id, SubMenu updatedSubMenu) {
        Optional<SubMenu> subMenuOptional = subMenuRepository.findById(id);
        if (subMenuOptional.isPresent()) {
            SubMenu existingSubMenu = subMenuOptional.get();
            existingSubMenu.setSuspendedStatus(updatedSubMenu.getSuspendedStatus());
            existingSubMenu.setMunicipalId(updatedSubMenu.getMunicipalId());

            return subMenuRepository.saveAndFlush(existingSubMenu);
        } else {
            throw new RuntimeException("subMenu not found with id: " + id);
        }
    }

    @Override
    public SubMenu changeSuspendedStatus(Long id, int status) {
        Optional<SubMenu> subMenuOptional = subMenuRepository.findById(id);
        if (subMenuOptional.isPresent()) {
            SubMenu subMenu = subMenuOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            subMenu.setUpdatedDate(currentDateTime);
            subMenu.setSuspendedStatus(status);      // 1 means suspended
            subMenu.setUpdatedBy(subMenu.getUpdatedBy());
            return subMenuRepository.saveAndFlush(subMenu);
        }
        return null;
    }
}

