package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingPaymentCollectionDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingPaymentCollectionDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingPaymentCollectionDetailsRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingPaymentCollectionDetailsService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingPaymentCollectionDetailsServiceImpl implements HoardingPaymentCollectionDetailsService {
    @Autowired
    private HoardingPaymentCollectionDetailsRepository hoardingPaymentCollectionDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingPaymentCollectionDetails saveHoardingPaymentCollectionDetails(HoardingPaymentCollectionDetails hoardingPaymentCollectionDetails) {
        hoardingPaymentCollectionDetails.setCreatedDate(LocalDateTime.now());
        hoardingPaymentCollectionDetails.setUpdatedDate(LocalDateTime.now());
        hoardingPaymentCollectionDetails.setUpdatedBy(hoardingPaymentCollectionDetails.getUpdatedBy() != null ? hoardingPaymentCollectionDetails.getUpdatedBy() : 0);
        hoardingPaymentCollectionDetails.setSuspendedStatus(hoardingPaymentCollectionDetails.getSuspendedStatus() != null ? hoardingPaymentCollectionDetails.getSuspendedStatus() : 0);

        return hoardingPaymentCollectionDetailsRepository.save(hoardingPaymentCollectionDetails);

    }

    @Override
    public List<HoardingPaymentCollectionDetailsDto> findAllHoardingPaymentCollectionDetails() {
        List<HoardingPaymentCollectionDetails> hoardingPaymentCollectionDetails = hoardingPaymentCollectionDetailsRepository.findAll();
        return hoardingPaymentCollectionDetails.stream()
                .map(hoardingPaymentCollectionDetails1 -> modelMapper.map(hoardingPaymentCollectionDetails1, HoardingPaymentCollectionDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingPaymentCollectionDetails findById(Long id) {
        Optional<HoardingPaymentCollectionDetails> hoardingPaymentCollectionDetails=hoardingPaymentCollectionDetailsRepository.findById(id);
        return hoardingPaymentCollectionDetails.orElse(null);

    }

    @Override
    public List<HoardingPaymentCollectionDetails> findAllByMunicipalId(int municipalId) {
        return hoardingPaymentCollectionDetailsRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingPaymentCollectionDetails updateHoardingPaymentCollectionDetails(Long id, HoardingPaymentCollectionDetails updatedHoardingPaymentCollectionDetails, int updatedBy) {
        Optional<HoardingPaymentCollectionDetails> hoardingPaymentCollectionDetailsOptional = hoardingPaymentCollectionDetailsRepository.findById(id);
        if (hoardingPaymentCollectionDetailsOptional.isPresent()) {
            HoardingPaymentCollectionDetails existingHoardingPaymentCollectionDetails= hoardingPaymentCollectionDetailsOptional.get();
            existingHoardingPaymentCollectionDetails.setCreatedDate(LocalDateTime.now());
            existingHoardingPaymentCollectionDetails.setUpdatedDate(LocalDateTime.now());
            existingHoardingPaymentCollectionDetails.setUpdatedBy(existingHoardingPaymentCollectionDetails.getUpdatedBy() != null ? existingHoardingPaymentCollectionDetails.getUpdatedBy() : 0);
            existingHoardingPaymentCollectionDetails.setSuspendedStatus(existingHoardingPaymentCollectionDetails.getSuspendedStatus() != null ? existingHoardingPaymentCollectionDetails.getSuspendedStatus() : 0);

            return hoardingPaymentCollectionDetailsRepository.saveAndFlush(existingHoardingPaymentCollectionDetails);
        } else {
            throw new RuntimeException("hoardingPaymentCollectionDetails not found with id: " + id);
        }
    }

    @Override
    public HoardingPaymentCollectionDetails changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingPaymentCollectionDetails> hoardingPaymentCollectionDetailsOpt = hoardingPaymentCollectionDetailsRepository.findById(id);
        if (hoardingPaymentCollectionDetailsOpt.isPresent()) {
            HoardingPaymentCollectionDetails hoardingPaymentCollectionDetails = hoardingPaymentCollectionDetailsOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingPaymentCollectionDetails.setUpdatedDate(currentDateTime);
            hoardingPaymentCollectionDetails.setSuspendedStatus(status);      // 1 means suspended
            hoardingPaymentCollectionDetails.setUpdatedBy(updatedBy);
            return hoardingPaymentCollectionDetailsRepository.saveAndFlush(hoardingPaymentCollectionDetails);
        }
        return null;
    }
}
