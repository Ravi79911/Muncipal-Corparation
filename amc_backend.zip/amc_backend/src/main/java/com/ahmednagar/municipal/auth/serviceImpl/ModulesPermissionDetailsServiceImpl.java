package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.ModulesPermissionDetails;
import com.ahmednagar.municipal.auth.repository.ModulesPermissionDetailsRepository;
import com.ahmednagar.municipal.auth.service.ModulesPermissionDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ModulesPermissionDetailsServiceImpl implements ModulesPermissionDetailsService {

    @Autowired
    ModulesPermissionDetailsRepository modulesPermissionDetailsRepository;

    @Override
    public ModulesPermissionDetails saveModulesPermissionDetailsService(ModulesPermissionDetails modulesPermissionDetails) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        modulesPermissionDetails.setCreatedDate(currentDateTime);
        modulesPermissionDetails.setUpdatedDate(LocalDateTime.now());
        modulesPermissionDetails.setUpdatedBy(modulesPermissionDetails.getUpdatedBy() != null ? modulesPermissionDetails.getUpdatedBy() : 0);
        modulesPermissionDetails.setSuspendedStatus(modulesPermissionDetails.getSuspendedStatus() != null ? modulesPermissionDetails.getSuspendedStatus() : 0);
        return modulesPermissionDetailsRepository.saveAndFlush(modulesPermissionDetails);
    }

    @Override
    public List<ModulesPermissionDetails> findAllModulesPermissionDetails() {
        return modulesPermissionDetailsRepository.findAll();
    }

    @Override
    public List<ModulesPermissionDetails> findAllModulesPermissionDetailsByMunicipalId(Long municipalId) {
        return modulesPermissionDetailsRepository.findByMunicipalId(municipalId);
    }

    @Override
    public ModulesPermissionDetails updateModulesPermissionDetails(Long id, ModulesPermissionDetails updatedModulesPermissionDetails) {
        Optional<ModulesPermissionDetails> modulesPermissionDetailsOptional = modulesPermissionDetailsRepository.findById(id);
        if (modulesPermissionDetailsOptional.isPresent()) {
            ModulesPermissionDetails existingModulesPermissionDetails = modulesPermissionDetailsOptional.get();
            existingModulesPermissionDetails.setSuspendedStatus(updatedModulesPermissionDetails.getSuspendedStatus());
            existingModulesPermissionDetails.setMunicipalId(updatedModulesPermissionDetails.getMunicipalId());

            return modulesPermissionDetailsRepository.saveAndFlush(existingModulesPermissionDetails);
        } else {
            throw new RuntimeException("ModulesPermissionDetails not found with id: " + id);
        }
    }

    @Override
    public ModulesPermissionDetails changeSuspendedStatus(Long id, int status) {
        Optional<ModulesPermissionDetails> modulesPermissionDetailsOptional = modulesPermissionDetailsRepository.findById(id);
        if (modulesPermissionDetailsOptional.isPresent()) {
            ModulesPermissionDetails modulesPermissionDetails = modulesPermissionDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            modulesPermissionDetails.setUpdatedDate(currentDateTime);
            modulesPermissionDetails.setSuspendedStatus(status);
            modulesPermissionDetails.setUpdatedBy(modulesPermissionDetails.getUpdatedBy());
            return modulesPermissionDetailsRepository.saveAndFlush(modulesPermissionDetails);
        }
        return null;
    }

}
