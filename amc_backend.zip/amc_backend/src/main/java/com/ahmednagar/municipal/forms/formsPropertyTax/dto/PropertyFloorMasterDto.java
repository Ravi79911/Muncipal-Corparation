package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PropertyFloorMasterDto {

    private Long id;
    private int propertyMasId;
    private String floorNo;
    private String floorUsageType;
    private String floorOccupancyType;
    private int floorConstructionType;
    private BigDecimal floorBuildupAreaSqft;
    private String rentAgreementNo;
    private LocalDate rentAgreementDate;
    private BigDecimal rentValueAmt;
    private LocalDate rentAgreementFrom;
    private LocalDate rentAgreementUpto;
    private BigDecimal floorArvValue;
    private LocalDate calculatedFrom;
    private int municipalId;
    private int createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;

}
