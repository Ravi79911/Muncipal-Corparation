package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_view_muni_property_demand_master")
public class ViewMunicipalPropertyDemandMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "total buildup area sqft is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "total buildup area sqft must be greater than 0")
    @Column(name = "total_buildup_area_sqft")
    private BigDecimal totalBuildupAreaSqft;

    @NotNull(message = "total carpet area sqft is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "total carpet area sqft must be greater than 0")
    @Column(name = "total_carpet_area_sqft")
    private BigDecimal totalCarpetAreaSqft;

    @NotNull(message = "total area sqmtr is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "total area sqft must be greater than 0")
    @Column(name = "total_area_sqmtr")
    private BigDecimal totalAreaSqmtr;

    @NotNull(message = "alv is required")
    @Column(name = "alv_rate_value")
    private BigDecimal alvRateValue;

    @NotNull(message = "building maintenance deduction is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "building maintenance deduction must be greater than 0")
    @Column(name = "Buldage_maintain_rate")
    private BigDecimal buildingMaintainRate;

    @NotNull(message = "state is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "state tax must be greater than 0")
    @Column(name = "state_tax")
    private BigDecimal stateTax;

    @NotNull(message = "total ARV_ALP value is required")
    @DecimalMin(value = "0", message = "total ARV_ALP value must be greater than or equal to 0")
    @Column(name = "total_arv_alp")
    private BigDecimal totalArvApl;

    @NotNull(message = "total rateable value is required")
    @DecimalMin(value = "0", message = "total rateable value must be greater than or equal to 0")
    @Column(name = "total_ratable_value")
    private BigDecimal totalRateableValue;

    @NotNull(message = "total annual tax is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "total annual tax must be greater than 0")
    @Column(name = "total_annual_tax")
    private BigDecimal totalAnnualTax;

    @Column(name = "effect_from")
    private LocalDate effectFrom;

    @NotNull(message = "memo number is required")
    @Size(max = 50, message = "memo number can't exceed 50 characters")
    @Column(name = "memo_no")
    private String memoNo;

    @NotNull(message = "memo type is required")
    @Size(max = 50, message = "memo type can't exceed 50 characters")
    @Column(name = "memo_type")
    private String memoType;

    @NotNull(message = "PT number is required")
    @Size(max = 50, message = "PT number can't exceed 50 characters")
    @Column(name = "pt_number")
    private String ptNumber;

    @NotNull(message = "holding number is required")
    @Size(max = 50, message = "holding number can't exceed 50 characters")
    @Column(name = "holding_number")
    private String holdingNumber;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @NotNull(message = "created by is required")
    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private ViewMunicipalPropertyMaster viewMunicipalPropertyMaster;

}
