package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.ViewApplicationFirmDetails;
import com.ahmednagar.municipal.auth.model.ViewApplicationFromMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface ViewApplicationFirmDetailsRepository extends JpaRepository<ViewApplicationFirmDetails,Long> {

    Optional<Object> findByViewApplicationFromMaster(ViewApplicationFromMaster existingApplication);

    Optional<Object> findByviewApplicationFromMaster(ViewApplicationFromMaster existingApplication);
}
