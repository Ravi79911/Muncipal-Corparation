package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFeePayMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@EnableJpaRepositories
public interface ApplicationFeePayMasterRepository extends JpaRepository<ApplicationFeePayMaster,Long> {
    List<ApplicationFeePayMaster> findBySuspendedStatus(Integer status);

    List<ApplicationFeePayMaster> findByMunicipalId(int municipalId);

    List<ApplicationFeePayMaster> findByapplicationMasterId_Id(Long applicationMasterId);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM tbl2_application_fee_pay_master WHERE application_master_id = :applicationMasterId", nativeQuery = true)
    void deleteApplicationFeePayMasterByApplicationMasterId(@Param("applicationMasterId") Long ApplicationFromMaster);


    //void deleteByapplicationMasterId(Long applicationMasterId);
}
