package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFeePayMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ApplicationFeePayMasterRepository extends JpaRepository<ApplicationFeePayMaster,Integer> {
    List<ApplicationFeePayMaster> findBySuspendedStatus(Integer status);

    List<ApplicationFeePayMaster> findByMunicipalId(int municipalId);
}
