package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Builder
@Table(name = "tbl_new_license_work_flow_level")
public class NewLicenseWorkFlowLevel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "zone_id", nullable = false)
    private Long zoneId;

    @Column(name = "ward_id", nullable = false)
    private Long wardId;

    @Column(name = "status")
    private String status;

    @Column(name = "status_code") // Explicitly specify the column name
    private Long statusCode;

    @Column(name = "mail_status")
    private Integer mailStatus;

    @Column(name = "remarks")
    private String remarks;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @Transient
    private List<Long> rejectedDocumentIds;

    @ManyToOne
    @JoinColumn(name = "application_master_id", referencedColumnName = "id", nullable = false)
    private ViewApplicationFromMaster applicationMasterId;

    @ManyToOne
    @JoinColumn(name = "application_type_id", referencedColumnName = "id", nullable = false)
    private ViewTradeApplicationTypeMasters applicationTypeId;

    @ManyToOne
    @JoinColumn(name = "temporary_license_payment_id", referencedColumnName = "id")
    private ViewTemporaryLicensePaymentScheduleDetails temporaryLicensePaymentId;

    @ManyToOne
    @JoinColumn(name = "current_role_id", referencedColumnName = "id")
    private RoleMaster currentRoleId;

    @ManyToOne
    @JoinColumn(name = "current_user_id", referencedColumnName = "id")
    private UserMaster currentUserId;

    @ManyToOne
    @JoinColumn(name = "next_user_id", referencedColumnName = "id")
    private UserMaster nextUserId;

    @ManyToOne
    @JoinColumn(name = "next_role_id", referencedColumnName = "id")
    private RoleMaster nextRoleId;

    @ManyToOne
    @JoinColumn(name = "work_flow_master_id", nullable = false, referencedColumnName = "id")
    private WorkFlowMaster workFlowMasterId;

    @ManyToOne
    @JoinColumn(name = "citizen_id", referencedColumnName = "id")
    private CitizenSignUpMaster citizenId;

}
