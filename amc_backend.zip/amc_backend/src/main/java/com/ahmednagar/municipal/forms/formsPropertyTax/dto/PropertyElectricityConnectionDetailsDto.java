package com.ahmednagar.municipal.forms.formsPropertyTax.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PropertyElectricityConnectionDetailsDto {

    private int id;
    private int propertyMasId;
    private String electricityConnectionType;
    private String nameOfConsumer;
    private String electricityDivisionName;
    private String electricityAccountNumber;
    private String electricityBookBindNumber;
    private String electricityConsumerNumber;
    private String electricityConsumerCategory;
    private int municipalId;
    private int createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;

}
