package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.ModuleMasterDto;
import com.ahmednagar.municipal.auth.model.ModuleMaster;
import com.ahmednagar.municipal.auth.repository.ModuleMasterRepository;
import com.ahmednagar.municipal.auth.service.ModuleMasterService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ModuleMasterServiceImpl implements ModuleMasterService {
    @Autowired
    private ModuleMasterRepository moduleMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ModuleMaster saveModuleMaster(ModuleMaster moduleMaster) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        moduleMaster.setCreatedDate(currentDateTime);
        moduleMaster.setUpdatedDate(LocalDateTime.now());
        moduleMaster.setUpdatedBy(moduleMaster.getUpdatedBy() != null ? moduleMaster.getUpdatedBy() : 0);
        moduleMaster.setSuspendedStatus(moduleMaster.getSuspendedStatus() != null ? moduleMaster.getSuspendedStatus() : 0);      // 0 means active// 1 means admin
        return moduleMasterRepository.saveAndFlush(moduleMaster);
    }

    @Override
    public List<ModuleMasterDto> findAllModuleMaster() {
        List<ModuleMaster> moduleMasters = moduleMasterRepository.findAll();
        return moduleMasters.stream()
                .map(moduleMaster -> modelMapper.map(moduleMaster, ModuleMasterDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<ModuleMasterDto> findAllModuleMasterByMunicipalId(Long municipalId) {
        List<ModuleMaster> moduleMasters = moduleMasterRepository.findByMunicipalId(municipalId);
        return moduleMasters.stream()
                .map(moduleMaster -> modelMapper.map(moduleMaster, ModuleMasterDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public ModuleMaster updateModuleMaster(Long id, ModuleMaster updatedModuleMaster) {
        Optional<ModuleMaster> moduleMasterOptional = moduleMasterRepository.findById(id);
        if (moduleMasterOptional.isPresent()) {
            ModuleMaster existingModuleMaster = moduleMasterOptional.get();
            existingModuleMaster.setSuspendedStatus(updatedModuleMaster.getSuspendedStatus());
            existingModuleMaster.setMunicipalId(updatedModuleMaster.getMunicipalId());

            return moduleMasterRepository.saveAndFlush(existingModuleMaster);
        } else {
            throw new RuntimeException("moduleMaster not found with id: " + id);
        }
    }

    @Override
    public ModuleMaster changeSuspendedStatus(Long id, int status) {
        Optional<ModuleMaster> moduleMasterOptional = moduleMasterRepository.findById(id);
        if (moduleMasterOptional.isPresent()) {
            ModuleMaster moduleMaster = moduleMasterOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            moduleMaster.setUpdatedDate(currentDateTime);
            moduleMaster.setSuspendedStatus(status);      // 1 means suspended
            moduleMaster.setUpdatedBy(moduleMaster.getUpdatedBy());
            return moduleMasterRepository.saveAndFlush(moduleMaster);
        }
        return null;
    }
}
