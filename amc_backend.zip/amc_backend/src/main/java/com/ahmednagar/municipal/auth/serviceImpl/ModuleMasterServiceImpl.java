package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.ModuleMaster;
import com.ahmednagar.municipal.auth.repository.ModuleMasterRepository;
import com.ahmednagar.municipal.auth.service.ModuleMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ModuleMasterServiceImpl implements ModuleMasterService {

    @Autowired
    ModuleMasterRepository moduleMasterRepository;

    @Override
    public ModuleMaster saveModuleMaster(ModuleMaster moduleMaster) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        moduleMaster.setCreatedDate(currentDateTime);
        moduleMaster.setUpdatedDate(LocalDateTime.now());
        moduleMaster.setUpdatedBy(moduleMaster.getUpdatedBy() != null ? moduleMaster.getUpdatedBy() : 0);
        moduleMaster.setSuspendedStatus(moduleMaster.getSuspendedStatus() != null ? moduleMaster.getSuspendedStatus() : 0);
        return moduleMasterRepository.saveAndFlush(moduleMaster);
    }

    @Override
    public List<ModuleMaster> findAllModuleMaster() {
        return moduleMasterRepository.findAll();
    }

    @Override
    public List<ModuleMaster> findAllModuleMasterByMunicipalId(Long municipalId) {
        return moduleMasterRepository.findByMunicipalId(municipalId);
    }

    @Override
    public ModuleMaster updateModuleMaster(Long id, ModuleMaster updatedModuleMaster) {
        Optional<ModuleMaster> moduleMasterOptional = moduleMasterRepository.findById(id);
        if (moduleMasterOptional.isPresent()) {
            ModuleMaster existingModuleMaster = moduleMasterOptional.get();
            existingModuleMaster.setSuspendedStatus(updatedModuleMaster.getSuspendedStatus());
            existingModuleMaster.setMunicipalId(updatedModuleMaster.getMunicipalId());

            return moduleMasterRepository.saveAndFlush(existingModuleMaster);
        } else {
            throw new RuntimeException("moduleMaster not found with id: " + id);
        }
    }

    @Override
    public ModuleMaster changeSuspendedStatus(Long id, int status) {
        Optional<ModuleMaster> moduleMasterOptional = moduleMasterRepository.findById(id);
        if (moduleMasterOptional.isPresent()) {
            ModuleMaster moduleMaster = moduleMasterOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            moduleMaster.setUpdatedDate(currentDateTime);
            moduleMaster.setSuspendedStatus(status);
            moduleMaster.setUpdatedBy(moduleMaster.getUpdatedBy());
            return moduleMasterRepository.saveAndFlush(moduleMaster);
        }
        return null;
    }

}
