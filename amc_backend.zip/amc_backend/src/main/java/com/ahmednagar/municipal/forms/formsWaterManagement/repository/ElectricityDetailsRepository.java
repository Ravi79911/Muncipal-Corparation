package com.ahmednagar.municipal.forms.formsWaterManagement.repository;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ElectricityDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ElectricityDetailsRepository extends JpaRepository<ElectricityDetails, Integer> {


    List<ElectricityDetails> findByMunicipalId(int municipalId);
}
