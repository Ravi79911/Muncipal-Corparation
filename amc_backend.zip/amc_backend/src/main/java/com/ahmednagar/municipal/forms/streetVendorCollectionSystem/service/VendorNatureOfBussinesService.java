package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorNatureOfBussines;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface VendorNatureOfBussinesService {

    VendorNatureOfBussines saveVendorNatureOfBussines(VendorNatureOfBussines vendorNatureOfBussines);
    Optional<VendorNatureOfBussines> getVendorNatureOfBussinesById(Long id);
    Optional<VendorNatureOfBussines> updateVendorNatureOfBussines(Long id, VendorNatureOfBussines vendorNatureOfBussines);
    Optional<VendorNatureOfBussines> deleteVendorNatureOfBussines(Long id);
    List<VendorNatureOfBussines> getAllVendorNatureOfBussines();
}
