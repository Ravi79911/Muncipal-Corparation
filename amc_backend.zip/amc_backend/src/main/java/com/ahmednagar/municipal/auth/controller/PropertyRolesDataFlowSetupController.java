package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.PropertyRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.PropertyRolesDataFlowSetup;
import com.ahmednagar.municipal.auth.service.PropertyRolesDataFlowSetupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/roles/data/flow/setup")
public class PropertyRolesDataFlowSetupController {

    @Autowired
    private PropertyRolesDataFlowSetupService propertyRolesDataFlowSetupService;

    @GetMapping("/getAllRole")
    public ResponseEntity<List<PropertyRolesDataFlowSetupDto>> getAllRolesDataFlowSetup() {
        List<PropertyRolesDataFlowSetupDto> role = propertyRolesDataFlowSetupService.findAllRolesDataFlowSetup();
        return ResponseEntity.ok(role);
    }

//    @GetMapping("/forwarded/next-role")
//    public ResponseEntity<?> getNextRoleIdForForward(@RequestParam Long currentRoleId) {
//        RolesDataFlowSetup rolesDataFlowSetup = rolesDataFlowSetupService.getNextRoleIdForForward(currentRoleId);
//        return ResponseEntity.ok(rolesDataFlowSetup);
//
//    }
//
//    @GetMapping("/backward/next-role")
//    public ResponseEntity<List<RolesDataFlowSetup>> getBackWardNextRoleId(@RequestParam Long currentRoleId) {
//        List<RolesDataFlowSetup> nextRoles = rolesDataFlowSetupService.getNextRoleListForBackWard(currentRoleId);
//        return ResponseEntity.ok(nextRoles);
//    }
//
//    @GetMapping("/backoffice/next-role")
//    public ResponseEntity<RolesDataFlowSetup> getBackOfficeNextRoleId(@RequestParam Long currentRoleId, @RequestParam Long statusCode, @RequestParam Integer isActive) {
//        RolesDataFlowSetup nextRoles = rolesDataFlowSetupService.getNextRoleForBacktoBackOffice(currentRoleId, statusCode, isActive);
//        return ResponseEntity.ok(nextRoles);
//    }

    @GetMapping("/document/verification/accept/next-role")
    public ResponseEntity<?> getNextRoleIdForDocumentVerificationAccept(@RequestParam Long currentRoleId,@RequestParam Long statusCode, @RequestParam Integer isActive) {
        PropertyRolesDataFlowSetup propertyRolesDataFlowSetup = propertyRolesDataFlowSetupService.getNextRoleForSingleSelection(currentRoleId, statusCode, isActive);
        return ResponseEntity.ok(propertyRolesDataFlowSetup);

    }

    @GetMapping("/document/verification/reject/next-role")
    public ResponseEntity<List<PropertyRolesDataFlowSetup>> getNextRoleIdForDocumentVerificationReject(@RequestParam Long currentRoleId, @RequestParam Long statusCode, @RequestParam Integer isActive) {
        List<PropertyRolesDataFlowSetup> nextRoles = propertyRolesDataFlowSetupService.getNextRoleListForListSelection(currentRoleId, statusCode, isActive);
        return ResponseEntity.ok(nextRoles);
    }

}
