package com.ahmednagar.municipal.forms.formsWaterManagement.controller;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerDetailsLegacyData;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.ConsumerDetailsLegacyDataService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/water/consumerDetailsLegacyData")
public class ConsumerDetailsLegacyDataController {

    @Autowired
    private ConsumerDetailsLegacyDataService consumerDetailsLegacyDataService;

    @GetMapping("/getConsumerDetailsLegacyData")
    public Optional<ConsumerDetailsLegacyData> getConsumerDetailsLegacyData(String consumerNumber){
        return consumerDetailsLegacyDataService.getConsumerDetailsLegacyData(consumerNumber);
    }

    @PostMapping("/create")
    public ResponseEntity<ConsumerDetailsLegacyData> createConsumerDetailsLegacyData(@Valid @RequestBody ConsumerDetailsLegacyData consumerDetailsLegacyData) {
        ConsumerDetailsLegacyData createdConsumerDetailsLegacyData = consumerDetailsLegacyDataService.createConsumerDetailsLegacyData(consumerDetailsLegacyData);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdConsumerDetailsLegacyData);
    }

}
