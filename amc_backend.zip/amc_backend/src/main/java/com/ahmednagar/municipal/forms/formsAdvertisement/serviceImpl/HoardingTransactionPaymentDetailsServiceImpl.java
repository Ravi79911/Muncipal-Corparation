package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingTransactionPaymentDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingTransactionPaymentDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingTransactionPaymentDetailsRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingTransactionPaymentDetailsService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingTransactionPaymentDetailsServiceImpl implements HoardingTransactionPaymentDetailsService {
    @Autowired
    private HoardingTransactionPaymentDetailsRepository hoardingTransactionPaymentDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingTransactionPaymentDetails saveHoardingTransactionPaymentDetails(HoardingTransactionPaymentDetails hoardingTransactionPaymentDetails) {
        hoardingTransactionPaymentDetails.setCreatedDate(LocalDateTime.now());
        hoardingTransactionPaymentDetails.setUpdatedDate(LocalDateTime.now());
        hoardingTransactionPaymentDetails.setUpdatedBy(hoardingTransactionPaymentDetails.getUpdatedBy() != null ? hoardingTransactionPaymentDetails.getUpdatedBy() : 0);
        hoardingTransactionPaymentDetails.setSuspendedStatus(hoardingTransactionPaymentDetails.getSuspendedStatus() != null ? hoardingTransactionPaymentDetails.getSuspendedStatus() : 0);

        return hoardingTransactionPaymentDetailsRepository.save(hoardingTransactionPaymentDetails);

    }

    @Override
    public List<HoardingTransactionPaymentDetailsDto> findAllHoardingTransactionPaymentDetails() {
        List<HoardingTransactionPaymentDetails> hoardingTransactionPaymentDetails = hoardingTransactionPaymentDetailsRepository.findAll();
        return hoardingTransactionPaymentDetails.stream()
                .map(hoardingTransactionPaymentDetails1 -> modelMapper.map(hoardingTransactionPaymentDetails1, HoardingTransactionPaymentDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingTransactionPaymentDetails findById(Long id) {
        Optional<HoardingTransactionPaymentDetails> hoardingTransactionPaymentDetails=hoardingTransactionPaymentDetailsRepository.findById(id);
        return hoardingTransactionPaymentDetails.orElse(null);

    }

    @Override
    public List<HoardingTransactionPaymentDetails> findAllByMunicipalId(int municipalId) {
        return hoardingTransactionPaymentDetailsRepository.findAllByMunicipalId(municipalId);
    }
    @Override
    public HoardingTransactionPaymentDetails updateHoardingTransactionPaymentDetails(Long id, HoardingTransactionPaymentDetails updatedHoardingTransactionPaymentDetails, int updatedBy) {
        Optional<HoardingTransactionPaymentDetails> hoardingTransactionPaymentDetailsOptional = hoardingTransactionPaymentDetailsRepository.findById(id);
        if (hoardingTransactionPaymentDetailsOptional.isPresent()) {
            HoardingTransactionPaymentDetails existingHoardingTransactionPaymentDetails = hoardingTransactionPaymentDetailsOptional.get();
            //existingHoardingTransactionPaymentDetails.setHoardingCategoryTypeName(updatedHoardingTransactionPaymentDetails.getHoardingCategoryTypeName());
            existingHoardingTransactionPaymentDetails.setUpdatedBy(updatedBy);
            existingHoardingTransactionPaymentDetails.setUpdatedDate(LocalDateTime.now());
            return hoardingTransactionPaymentDetailsRepository.saveAndFlush(existingHoardingTransactionPaymentDetails);
        } else {
            throw new RuntimeException("hoardingTransactionPaymentDetails not found with id: " + id);
        }
    }

    @Override
    public HoardingTransactionPaymentDetails changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingTransactionPaymentDetails> hoardingTransactionPaymentDetailsOpt = hoardingTransactionPaymentDetailsRepository.findById(id);
        if (hoardingTransactionPaymentDetailsOpt.isPresent()) {
            HoardingTransactionPaymentDetails hoardingTransactionPaymentDetails = hoardingTransactionPaymentDetailsOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingTransactionPaymentDetails.setUpdatedDate(currentDateTime);
            hoardingTransactionPaymentDetails.setSuspendedStatus(status);      // 1 means suspended
            hoardingTransactionPaymentDetails.setUpdatedBy(updatedBy);
            return hoardingTransactionPaymentDetailsRepository.saveAndFlush(hoardingTransactionPaymentDetails);
        }
        return null;
    }
}