//package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;
//
//import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
//import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyAdditionalMaster;
//import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyAdditionalMasterService;
//import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
//import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyAdditionalMasterRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.time.LocalDate;
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class PropertyAdditionalMasterServiceImpl implements PropertyAdditionalMasterService {
//
//    @Autowired
//    PropertyAdditionalMasterRepository propertyAdditionalMasterRepository;
//
//    @Autowired
//    MunicipalPropertyMasterRepository municipalPropertyMasterRepository;
//
//    @Override
//    public PropertyAdditionalMaster createPropertyAdditionalMaster(PropertyAdditionalMaster propertyAdditionalMaster) {
//        Long municipalPropertyMasterId = propertyAdditionalMaster.getMunicipalPropertyMaster().getId();
//        Optional<MunicipalPropertyMaster> municipalPropertyMasterOpt = municipalPropertyMasterRepository.findById(municipalPropertyMasterId);
//        if (municipalPropertyMasterOpt.isPresent()) {
//            propertyAdditionalMaster.setCreatedDate(LocalDate.now());
//            return propertyAdditionalMasterRepository.saveAndFlush(propertyAdditionalMaster);
//        } else {
//            throw new RuntimeException("municipal property master not found with id: " + municipalPropertyMasterId);
//        }
//    }
//
//    @Override
//    public List<PropertyAdditionalMaster> getAllPropertyAdditionalMaster() {
//        return propertyAdditionalMasterRepository.findAll();
//    }
//
//    @Override
//    public Optional<PropertyAdditionalMaster> getPropertyAdditionalMasterById(Long id) {
//        return propertyAdditionalMasterRepository.findById(id);
//    }
//
//    @Override
//    public List<PropertyAdditionalMaster> getPropertyAdditionalMasterByMunicipalId(int municipalId) {
//        return propertyAdditionalMasterRepository.findByMunicipalId(municipalId);
//    }
//
//    @Override
//    public PropertyAdditionalMaster patchPropertyAdditionalMasterSuspendedStatus(Long id, int suspendedStatus) {
//        Optional<PropertyAdditionalMaster> patchPropertyAdditional = propertyAdditionalMasterRepository.findById(id);
//        if (patchPropertyAdditional.isPresent()) {
//            PropertyAdditionalMaster existingPropertyAdditional = patchPropertyAdditional.get();
//            existingPropertyAdditional.setSuspendedStatus(suspendedStatus);
//            return propertyAdditionalMasterRepository.saveAndFlush(existingPropertyAdditional);
//        } else {
//            throw new RuntimeException("property additional master not found with id: " + id);
//        }
//    }
//
//}
