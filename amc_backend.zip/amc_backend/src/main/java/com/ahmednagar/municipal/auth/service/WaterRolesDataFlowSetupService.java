package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.WaterRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.WaterRolesDataFlowSetup;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface WaterRolesDataFlowSetupService {

    List<WaterRolesDataFlowSetupDto> findAllRolesDataFlowSetup();

    List<WaterRolesDataFlowSetup> getNextRoleListForListSelection(Long currentRoleId, Long statusCode, Integer isActive);

    WaterRolesDataFlowSetup getNextRoleForSingleSelection(Long currentRoleId, Long statusCode, Integer isActive);

}
