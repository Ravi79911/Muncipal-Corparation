package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.SubMenuPermissionDto;
import com.ahmednagar.municipal.auth.model.SubMenuPermission;
import com.ahmednagar.municipal.auth.service.SubMenuPermissionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class SubMenuPermissionController {
    @Autowired
    private SubMenuPermissionService subMenuPermissionService;

    // for new user created
    @PostMapping("create/SubMenuPermission")
    public ResponseEntity<SubMenuPermission> createSubMenuPermission(@Valid @RequestBody SubMenuPermission subMenuPermission){
        SubMenuPermission createdSubMenuPermission=subMenuPermissionService.saveSubMenuPermission(subMenuPermission);
        if(createdSubMenuPermission==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdSubMenuPermission);

    }
    //for all user
    @GetMapping("/all/SubMenuPermission")
    public  ResponseEntity<List<SubMenuPermissionDto>> getAllSubMenuPermission(){
        List<SubMenuPermissionDto> subMenuPermission=subMenuPermissionService.findAllSubMenuPermission();
        return ResponseEntity.ok(subMenuPermission);
    }
    //find by Municipal id
    @GetMapping("/MunicipalSubMenuPermission/{municipalId}")
    public ResponseEntity<?> getAllSubMenuPermissionByMunicipalId(@PathVariable Long municipalId){
        List<SubMenuPermissionDto> subMenuPermission=subMenuPermissionService.findAllSubMenuPermissionByMunicipalId(municipalId);
        if(subMenuPermission.isEmpty()){
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No SubMenuPermission found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(subMenuPermission);
    }
    //     Update menu for admin
    @PutMapping("/updatedSubMenuPermission/{id}")
    public ResponseEntity<SubMenuPermission> updateSubMenuPermission(@PathVariable("id") Long id, @RequestBody SubMenuPermission updatedSubMenuPermission){
        try{
            SubMenuPermission updated=subMenuPermissionService.updateSubMenuPermission(id,updatedSubMenuPermission);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete fileUrl for admin
    @PatchMapping("/deleteSubMenuPermission/{id}")
    public ResponseEntity<SubMenuPermission> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        SubMenuPermission updatedSubMenuPermission= subMenuPermissionService.changeSuspendedStatus(id, status);         // updatedBy is always 1 for now as it is the admin
        if (updatedSubMenuPermission== null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedSubMenuPermission);
    }

}

