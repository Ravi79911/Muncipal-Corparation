package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.model.SubMenuPermission;
import com.ahmednagar.municipal.auth.service.SubMenuPermissionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class SubMenuPermissionController {

    @Autowired
    SubMenuPermissionService subMenuPermissionService;

    @PostMapping("/createSubMenuPermission")
    public ResponseEntity<SubMenuPermission> createSubMenuPermission(@Valid @RequestBody SubMenuPermission subMenuPermission) {
        SubMenuPermission createdSubMenuPermission = subMenuPermissionService.saveSubMenuPermission(subMenuPermission);
        if (createdSubMenuPermission == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdSubMenuPermission);

    }

    @GetMapping("/getAllSubMenuPermission")
    public ResponseEntity<List<SubMenuPermission>> getAllSubMenuPermission() {
        List<SubMenuPermission> subMenuPermission = subMenuPermissionService.findAllSubMenuPermission();
        return ResponseEntity.ok(subMenuPermission);
    }

    @GetMapping("/getSubMenuPermissionByMunicipalId/{municipalId}")
    public ResponseEntity<?> getAllSubMenuPermissionByMunicipalId(@PathVariable Long municipalId) {
        List<SubMenuPermission> subMenuPermission = subMenuPermissionService.findAllSubMenuPermissionByMunicipalId(municipalId);
        if (subMenuPermission.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No SubMenuPermission found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(subMenuPermission);
    }

    @PutMapping("/subMenuPermission/update/{id}")
    public ResponseEntity<SubMenuPermission> updateSubMenuPermission(@PathVariable("id") Long id, @RequestBody SubMenuPermission updatedSubMenuPermission) {
        try {
            SubMenuPermission updated = subMenuPermissionService.updateSubMenuPermission(id, updatedSubMenuPermission);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/subMenuPermission/suspendedStatus/{id}")
    public ResponseEntity<SubMenuPermission> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        SubMenuPermission updatedSubMenuPermission = subMenuPermissionService.changeSuspendedStatus(id, status);
        if (updatedSubMenuPermission == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedSubMenuPermission);
    }

}

