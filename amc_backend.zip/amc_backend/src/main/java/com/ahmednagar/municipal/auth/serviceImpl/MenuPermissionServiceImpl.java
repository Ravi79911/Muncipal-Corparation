package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.MenuPermission;
import com.ahmednagar.municipal.auth.repository.MenuPermissionRepository;
import com.ahmednagar.municipal.auth.service.MenuPermissionService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class MenuPermissionServiceImpl implements MenuPermissionService {

    @Autowired
    MenuPermissionRepository menuPermissionRepository;

    @Override
    public MenuPermission saveMenuPermission(MenuPermission menuPermission) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        menuPermission.setCreatedDate(currentDateTime);
        menuPermission.setUpdatedDate(LocalDateTime.now());
        menuPermission.setUpdatedBy(menuPermission.getUpdatedBy() != null ? menuPermission.getUpdatedBy() : 0);
        menuPermission.setSuspendedStatus(menuPermission.getSuspendedStatus() != null ? menuPermission.getSuspendedStatus() : 0);
        return menuPermissionRepository.saveAndFlush(menuPermission);
    }

    @Override
    public List<MenuPermission> findAllMenuPermission() {
        return menuPermissionRepository.findAll();
    }

    @Override
    public List<MenuPermission> findAllMenuPermissionByMunicipalId(Long municipalId) {
        List<MenuPermission> menuPermissions = menuPermissionRepository.findByMunicipalId(municipalId);
        return menuPermissionRepository.findByMunicipalId(municipalId);
    }

    @Override
    public MenuPermission updateMenuPermission(Long id, MenuPermission updatedMenuPermission) {
        Optional<MenuPermission> menuPermissionOptional = menuPermissionRepository.findById(id);
        if (menuPermissionOptional.isPresent()) {
            MenuPermission existingMenuPermission = menuPermissionOptional.get();
            existingMenuPermission.setSuspendedStatus(updatedMenuPermission.getSuspendedStatus());
            existingMenuPermission.setMunicipalId(updatedMenuPermission.getMunicipalId());

            return menuPermissionRepository.saveAndFlush(existingMenuPermission);
        } else {
            throw new RuntimeException("MenuPermission not found with id: " + id);
        }
    }

    @Override
    public MenuPermission changeSuspendedStatus(Long id, int status) {
        Optional<MenuPermission> menuPermissionOptional = menuPermissionRepository.findById(id);
        if (menuPermissionOptional.isPresent()) {
            MenuPermission menuPermission = menuPermissionOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            menuPermission.setUpdatedDate(currentDateTime);
            menuPermission.setSuspendedStatus(status);
            menuPermission.setUpdatedBy(menuPermission.getUpdatedBy());
            return menuPermissionRepository.saveAndFlush(menuPermission);
        }
        return null;
    }

}
