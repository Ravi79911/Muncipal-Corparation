package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.AdvertisementRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.AdvertisementRolesDataFlowSetup;
import com.ahmednagar.municipal.auth.repository.AdvertisementRolesDataFlowSetupRepository;
import com.ahmednagar.municipal.auth.service.AdvertisementRolesDataFlowSetupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdvertisementRolesDataFlowSetupServiceImpl implements AdvertisementRolesDataFlowSetupService {

    @Autowired
    private AdvertisementRolesDataFlowSetupRepository advertisementRolesDataFlowSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<AdvertisementRolesDataFlowSetupDto> findAllRolesDataFlowSetup() {
        List<AdvertisementRolesDataFlowSetup> roles = advertisementRolesDataFlowSetupRepository.findAll();
        return roles.stream()
                .map(role -> modelMapper.map(role, AdvertisementRolesDataFlowSetupDto.class))
                .collect(Collectors.toList());
    }


    @Override
    public List<AdvertisementRolesDataFlowSetup> getNextRoleListForListSelection(Long currentRoleId, Long statusCode, Integer isActive) {
        List<AdvertisementRolesDataFlowSetup> list = advertisementRolesDataFlowSetupRepository
                .findAllByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId,statusCode, isActive);
        if (list.isEmpty()) {
            throw new RuntimeException("No next roles found for currentRoleId: " + currentRoleId + " and status code: " + 1007L+"(DocumentVerificationReject)");
        }
        return list;
    }

    @Override
    public AdvertisementRolesDataFlowSetup getNextRoleForSingleSelection(Long currentRoleId, Long statusCode, Integer isActive) {
        return advertisementRolesDataFlowSetupRepository
                .findByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId, statusCode, isActive)
                .orElseThrow(() -> new RuntimeException(
                        "No next role found for currentRoleId: " + currentRoleId +
                                ", statusCode: " + statusCode + ", isActive: " + isActive));
    }

}
