package com.ahmednagar.municipal.config;

import com.ahmednagar.municipal.auth.jwt.JwtHelper;
import com.ahmednagar.municipal.auth.serviceImpl.CustomUserDetailsService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;

import java.util.Map;

@Slf4j
@Component
public class JwtHandshakeInterceptor implements HandshakeInterceptor {

    @Autowired
    JwtHelper jwtHelper;

    @Autowired
    CustomUserDetailsService customUserDetailsService;

//    private final JwtHelper jwtHelper;
//    private final UserDetailsService userDetailsService;
//
//    public JwtHandshakeInterceptor(JwtHelper jwtHelper, UserDetailsService userDetailsService) {
//        this.jwtHelper = jwtHelper;
//        this.userDetailsService = userDetailsService;
//    }
//
//    @Override
//    public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Map<String, Object> attributes) throws Exception {
//        if (request instanceof ServletServerHttpRequest && response instanceof ServletServerHttpResponse) {
//            HttpServletRequest servletRequest = ((ServletServerHttpRequest) request).getServletRequest();
//            String token = servletRequest.getHeader("Authorization");
//
//            if (token != null && token.startsWith("Bearer ")) {
//                token = token.substring(7); // remove "Bearer " prefix
//
//                try {
//                    String username = jwtHelper.getUsernameFromToken(token);
//
//                    if (username != null) {
//                        UserDetails userDetails = userDetailsService.loadUserByUsername(username);
//                        if (jwtHelper.validateToken(token, userDetails)) {
//                            UsernamePasswordAuthenticationToken authentication =
//                                    new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
//                            SecurityContextHolder.getContext().setAuthentication(authentication);
//                            log.info("WebSocket handshake JWT validated for user: {}", username);
//                        } else {
//                            log.warn("Invalid JWT token during WebSocket handshake");
//                        }
//                    }
//                } catch (Exception e) {
//                    log.error("JWT validation error during WebSocket handshake", e);
//                }
//            } else {
//                log.warn("No Bearer token found in Authorization header");
//            }
//        }
//
//        return true; // Proceed with handshake even if JWT is missing or invalid (optional)
//    }
//
//    @Override
//    public void afterHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Exception exception) {
//
//    }

    @Override
    public boolean beforeHandshake(ServerHttpRequest request,
                                   ServerHttpResponse response,
                                   WebSocketHandler wsHandler,
                                   Map<String, Object> attributes) throws Exception {

        if (request instanceof ServletServerHttpRequest servletRequest) {
            HttpServletRequest httpServletRequest = servletRequest.getServletRequest();
            String token = httpServletRequest.getParameter("token");

            if (token != null) {
                try {
                    String username = jwtHelper.getUsernameFromToken(token);
                    UserDetails userDetails = customUserDetailsService.loadUserByUsername(username);

                    if (jwtHelper.validateToken(token, userDetails)) {
                        Authentication authentication = new UsernamePasswordAuthenticationToken(
                                userDetails, null, userDetails.getAuthorities()
                        );

                        attributes.put("user", authentication);
                        return true;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        return false;
    }

    @Override
    public void afterHandshake(ServerHttpRequest request,
                               ServerHttpResponse response,
                               WebSocketHandler wsHandler,
                               Exception exception) {
    }

}
