package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "Tbl_user_login_logs")
public class VendorUserLoginLogs {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  // ID field with auto-increment

    @Column(name = "action_time")
    private String actionTime;  // Action time as string (could be datetime as per your database definition)

    @Column(name = "ip_addrs")
    private String ipAddrs;  // IP address from which the action was performed

    @Column(name = "lattitude")
    private String latitude;  // Latitude of the user

    @Column(name = "longitude")
    private String longitude;  // Longitude of the user

    @Column(name = "log_type")
    private String logType;  // Type of the log (e.g., login, logout, etc.)

    @Column(name = "municipal_id")
    private Long municipalId;  // ID for municipal association (if applicable)

    @Column(name = "created_by")
    private Long createdBy;  // User who created the log entry

    @Column(name = "created_date")
    private LocalDateTime createdDate;  // Date when the log was created

    @Column(name = "suspended_status")
    private int suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private VendorUser vendorUserId;  // User ID associated with the log
}
