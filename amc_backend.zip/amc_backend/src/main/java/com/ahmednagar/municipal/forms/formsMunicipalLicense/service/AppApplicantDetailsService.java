package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.AppApplicantDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.AppApplicantDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface AppApplicantDetailsService {

    AppApplicantDetails saveAppApplicationDetails(AppApplicantDetails appApplicantDetails, int createdBy);

    List<AppApplicantDetails> createAppApplicantDetailsList(List<AppApplicantDetails> appApplicantDetailsList);

    AppApplicantDetails findAppApplicantDetailsById(Long id);

    List<AppApplicantDetailsDto> findAllAppApplicantDetailsByMunicipalId(int municipalId);

    AppApplicantDetails updateAppApplicantDetails(Long id, AppApplicantDetails updatedAppApplicantDetails, int updatedBy);

    AppApplicantDetails changeSuspendedStatus(Long id, int status, int updatedBy);

}
