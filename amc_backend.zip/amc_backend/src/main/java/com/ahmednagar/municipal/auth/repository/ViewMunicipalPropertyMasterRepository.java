package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.ViewMunicipalPropertyMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface ViewMunicipalPropertyMasterRepository extends JpaRepository<ViewMunicipalPropertyMaster,Long> {
}
