package com.ahmednagar.municipal.forms.formsWaterManagement.service;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.DocumentDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.util.List;

@Service
public interface DocumentsDetailsServices {

    DocumentDetails deleteDocumentDetailsById(Long id, int suspendedStatus, int updatedBy);

//    DocumentDetails getDocumentDetailsById(int id);

    List<DocumentDetails> getDocumentDetailsByMunicipalId(int municipalId);

//    DocumentDetails updateDocumentDetails(int id, DocumentDetails documentDetails, int updatedBy);

    DocumentDetails createDocumentDetails(DocumentDetails documentDetails, int createdBy);

    DocumentDetails uploadDocument(MultipartFile file, String documentNum, int status, int createdBy, int suspendedStatus, int municipalId, int newConnectionFormId, Long documentTypeId) throws Exception;

    Resource loadDocumentDetails(Long id) throws IOException;
}
