package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyFloorMaster;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.MunicipalPropertyMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyFloorMasterRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyFloorMasterService;
import com.ahmednagar.municipal.master.propertyTax.model.PropertyConstructionType;
import com.ahmednagar.municipal.master.propertyTax.repository.PropertyConstructionTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PropertyFloorMasterServiceImpl implements PropertyFloorMasterService {

    @Autowired
    PropertyFloorMasterRepository propertyFloorMasterRepository;

    @Autowired
    MunicipalPropertyMasterRepository municipalPropertyMasterRepository;

    @Autowired
    PropertyConstructionTypeRepository propertyConstructionTypeRepository;

    // single entity creation
    @Override
    public PropertyFloorMaster createPropertyFloorMaster(PropertyFloorMaster propertyFloorMaster) {
        propertyFloorMaster.setCreatedDate(LocalDateTime.now());
        return propertyFloorMasterRepository.saveAndFlush(propertyFloorMaster);
    }

    // list of entity creation
    @Override
    public List<PropertyFloorMaster> createPropertyFloorMasterList(List<PropertyFloorMaster> propertyFloorMasterList) {
        if (propertyFloorMasterList.isEmpty()) {
            throw new IllegalArgumentException("the list of PropertyFloorMaster can't be empty");
        }
        // check if all PropertyFloorMaster have the same municipal property master id
        Long firstPropertyMunicipalPropertyMasterId = propertyFloorMasterList.get(0).getMunicipalPropertyMaster().getId();
        boolean allSameMunicipalPropertyMasterId = propertyFloorMasterList.stream()
                .allMatch(propertyFloorMaster -> Objects.equals(propertyFloorMaster
                        .getMunicipalPropertyMaster().getId(), firstPropertyMunicipalPropertyMasterId));
        if (!allSameMunicipalPropertyMasterId) {
            throw new IllegalArgumentException("all PropertyFloorMaster must have same municipal property master id");
        }

        // check if all PropertyFloorMaster have the same property construction type id
//        Long firstPropertyConstructionId = propertyFloorMasterList.get(0).getPropertyConstructionType().getId();
//        boolean allSamePropertyConstructionId = propertyFloorMasterList.stream()
//                .allMatch(propertyFloorMaster -> Objects.equals(propertyFloorMaster
//                        .getPropertyConstructionType().getId(), firstPropertyConstructionId));
//        if (!allSamePropertyConstructionId) {
//            throw new IllegalArgumentException("all PropertyFloorMaster must have same property construction type id");
//        }

        // validate if the municipal property master id exists in the database
        for (PropertyFloorMaster propertyFloorMaster : propertyFloorMasterList) {
            Long municipalPropertyMasterId = propertyFloorMaster.getMunicipalPropertyMaster().getId();
            Optional<MunicipalPropertyMaster> municipalPropertyMaster = municipalPropertyMasterRepository.findById(municipalPropertyMasterId);
            if (!municipalPropertyMaster.isPresent()) {
                throw new IllegalArgumentException("MunicipalPropertyMaster with ID " + municipalPropertyMasterId + " does not exist");
            }
        }

        // validate if the property construction type exists in the database
        for (PropertyFloorMaster propertyFloorMaster : propertyFloorMasterList) {
            Long propertyConstructionTypeId = propertyFloorMaster.getPropertyConstructionType().getId();
            Optional<PropertyConstructionType> propertyConstructionType = propertyConstructionTypeRepository.findById(propertyConstructionTypeId);
            if (!propertyConstructionType.isPresent()) {
                throw new IllegalArgumentException("PropertyConstructionType with ID " + propertyConstructionTypeId + " does not exist");
            }
        }

        LocalDateTime currentDate = LocalDateTime.now();
        List<PropertyFloorMaster> propertyFloorMasterListToSave = propertyFloorMasterList.stream()
                .peek(propertyFloorMaster -> propertyFloorMaster.setCreatedDate(currentDate))
                .collect(Collectors.toList());
        return propertyFloorMasterRepository.saveAllAndFlush(propertyFloorMasterListToSave);
    }

    @Override
    public List<PropertyFloorMaster> getAllPropertyFloorMaster() {
        return propertyFloorMasterRepository.findAll();
    }

    @Override
    public Optional<PropertyFloorMaster> getPropertyFloorMasterById(Long id) {
        return propertyFloorMasterRepository.findById(id);
    }

    @Override
    public List<PropertyFloorMaster> getPropertyFloorMasterByMunicipalId(int municipalId) {
        return propertyFloorMasterRepository.findByMunicipalId(municipalId);
    }

    @Override
    public PropertyFloorMaster patchPropertyFloorMasterSuspendedStatus(Long id, int suspendedStatus) {
        Optional<PropertyFloorMaster> patchPropertyFloor = propertyFloorMasterRepository.findById(id);
        if (patchPropertyFloor.isPresent()) {
            PropertyFloorMaster existingPropertyFloor = patchPropertyFloor.get();
            existingPropertyFloor.setSuspendedStatus(suspendedStatus);
            return propertyFloorMasterRepository.saveAndFlush(existingPropertyFloor);
        } else {
            throw new RuntimeException("property floor master not found with id: " + id);
        }
    }

}
