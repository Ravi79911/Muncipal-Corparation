package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_citizen_sign_up_master")
public class CitizenSignUpMaster implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "citizen name is required")
    @Column(name = "citizen_name", nullable = false, length = 200)
    private String citizenName;

    @NotBlank(message = "guardian name is required")
    @Column(name = "father_mother_husband_name", nullable = false, length = 200)
    private String fatherMotherHusbandName;

    @NotBlank(message = "relationship is required")
    @Column(name = "relationship", nullable = false, length = 50)
    private String relationship;

    @Column(name = "zone_id", nullable = false)
    private Long zoneId;

    @Column(name = "ward_id", nullable = false)
    private Long wardId;

    @Email(message = "invalid email format")
    @Column(name = "email", nullable = false, unique = true, length = 100)
    private String email;

    @NotNull(message = "user name is mandatory")
    @Column(name = "user_name", nullable = false, length = 100)
    private String userName;

    @Pattern(
            regexp = "^\\+91[6-9]\\d{9}$",
            message = "Invalid mobile number. It must be in the format +918989898989"
    )
    @Column(name = "mobile_no", nullable = false, unique = true)
    private String mobileNo;

    @Column(name = "gender", nullable = false, length = 50)
    private String gender;

    @Column(name = "marital_status", nullable = false, length = 50)
    private String maritalStatus;

    @NotNull(message = "date of birth is required")
    @Column(name = "dob", nullable = false)
    private LocalDate dob;

    @Column(name = "profile_image_name")
    private String profileImageName;

    @Column(name = "profile_pic_url")
    private String profilePicUrl;

    @NotBlank(message = "password is required")
    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "is_email_verified", nullable = false)
    private boolean isEmailVerified;

    @Column(name = "is_mobile_verified", nullable = false)
    private boolean isMobileVerified;

    @Column(name = "is_verified", nullable = false)
    private boolean isVerified;

    @Column(name = "email_otp")
    private String emailOtp;

    @Column(name = "email_otp_timestamp")
    private LocalDateTime emailOtpTimestamp;

    @Column(name = "mobile_otp")
    private String mobileOtp;

    @Column(name = "mobile_otp_timestamp")
    private LocalDateTime mobileOtpTimestamp;

    @Column(name = "token")
    private String token;

    @Column(name = "token_timestamp")
    private LocalDateTime tokenTimestamp;

    @NotBlank(message = "permanent address is required")
    @Column(name = "pernanent_address", nullable = false)
    private String permanentAddress;

    @NotBlank(message = "city is required")
    @Column(name = "p_city", nullable = false, length = 50)
    private String p_City;

    @NotBlank(message = "state is required")
    @Column(name = "p_state", nullable = false, length = 50)
    private String p_State;

    @NotNull(message = "pincode is required")
    @Column(name = "p_pincode", nullable = false)
    private Long p_Pincode;

    @NotBlank(message = "corresponding address is required")
    @Column(name = "corresponding_address", nullable = false)
    private String correspondingAddress;

    @NotBlank(message = "city is required")
    @Column(name = "c_city", nullable = false, length = 50)
    private String c_City;

    @NotBlank(message = "state is required")
    @Column(name = "c_state", nullable = false, length = 50)
    private String c_State;

    @NotNull(message = "pincode is required")
    @Column(name = "c_pincode", nullable = false)
    private Long c_Pincode;

    @Column(name = "is_property_exist", nullable = false)
    private Boolean isPropertyExist;

    @Column(name = "holding_no")
    private String holdingNo;

    @Column(name = "is_water_connection_exist", nullable = false)
    private Boolean isWaterConnectionExist;

    @Column(name = "consumer_num")
    private String consumerNum;

    @Column(name = "is_trade_license_exist", nullable = false)
    private Boolean isTradeLicenseExist;

    @Column(name = "licence_num")
    private String licenceNum;

    @Column(name = "is_advertisment_exist", nullable = false)
    private Boolean isAdvertismentExist;

    @Column(name = "advertisement_application_no")
    private String advertisementApplicationNo;

//    @Column(name = "is_market_exist", nullable = false)
//    private boolean isMarketExist;
//
//    @Column(name = "market_application_no")
//    private String marketApplicationNo;

    @Column(name = "ip_address")
    private String ipAddress;

    @Column(name = "created_by", nullable = false)
    private String createdBy;

    @Column(name = "update_by", nullable = false)
    private Integer updateBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "municipal_id", nullable = false)
    private Integer municipalId;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "role_mas_id", referencedColumnName = "id")
    private RoleMaster roleMaster;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        if (roleMaster == null || roleMaster.getRoleName() == null) {
            return Collections.emptyList(); // Return an empty list to avoid NullPointerException
        }
        return List.of(new SimpleGrantedAuthority(roleMaster.getRoleName()));
    }

    @Override
    public String getUsername() {
        return this.email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

}
