package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.ViewHoardingApplicationDetails;
import com.ahmednagar.municipal.auth.model.ViewHoardingApplicationMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface ViewHoardingApplicationDetailsRepository extends JpaRepository<ViewHoardingApplicationDetails,Long> {

    Optional<ViewHoardingApplicationDetails> findByHoardingApplicationMasterId(ViewHoardingApplicationMaster existingApplication);
}
