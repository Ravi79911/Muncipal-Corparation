package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import org.springframework.stereotype.Service;

@Service
public interface LicenseApplicationCounterService {

    int getNextCounterValue(String counterName);

}
