package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.MenuDto;
import com.ahmednagar.municipal.auth.model.Menu;
import com.ahmednagar.municipal.auth.service.MenuService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class MenuController {
    @Autowired
    private MenuService menuService;

    //create menu
    @PostMapping("/createMenu")
    public ResponseEntity<Menu> createMenu(@Valid @RequestBody Menu menu){
        Menu createdMenu=menuService.saveMenu(menu);
        if(createdMenu==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdMenu);
    }
    //for all admin users
    @GetMapping("/allMenu")
    public ResponseEntity<List<MenuDto>> getAllMenu(){
        List<MenuDto> menu=menuService.findAllMenu();
        return ResponseEntity.ok(menu);
    }

    //get menu By MunicipalId
    @GetMapping("/MunicipalMenu/{municipalId}")
    public ResponseEntity<?> getAllMenuByMunicipalId(@PathVariable Long municipalId){
        List<MenuDto> menu=menuService.findAllMenuByMunicipalId(municipalId);
        if (menu.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No menu found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(menu);
    }

    //     Update menu for admin
    @PutMapping("/updatedMenu/{id}")
    public ResponseEntity<Menu> updateMenu(@PathVariable("id") Long id, @RequestBody Menu updatedMenu){
        try{
            Menu updated=menuService.updateMenu(id,updatedMenu);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete fileUrl for admin
    @PatchMapping("/deleteMenu/{id}")
    public ResponseEntity<Menu> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        Menu updatedMenu = menuService.changeSuspendedStatus(id, status);         // updatedBy is always 1 for now as it is the admin
        if (updatedMenu== null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedMenu);
    }

}

