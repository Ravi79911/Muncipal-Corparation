package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class LicenseApplicationWorkflowDto {
    private Long id;
    private LicenseLabelStageDto stageId;
    private Float documentUploaded;
    private String currentStage;
    private String status;
    private int createdBy;
    private LocalDateTime createdDate;
    private String updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private Long municipalId;
}
