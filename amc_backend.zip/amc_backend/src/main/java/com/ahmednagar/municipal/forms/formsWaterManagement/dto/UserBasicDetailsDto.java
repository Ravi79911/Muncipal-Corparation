package com.ahmednagar.municipal.forms.formsWaterManagement.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserBasicDetailsDto {

    private int id;

    @NotNull(message = "Appmas ID is mandatory")
    private int applicationMasId;

    @NotBlank(message = "Consumer name is mandatory")
    @Size(max = 250, message = "Consumer name cannot exceed 250 characters")
    private String consumerName;

    @NotBlank(message = "Father/Gaurdian name is mandatory")
    @Size(max = 250, message = "Father/Gaurdian name cannot exceed 250 characters")
    private String fatherGaurdianName;

    @NotBlank(message = "Address is mandatory")
    @Size(max = 500, message = "Address cannot exceed 500 characters")
    private String address;

    @NotBlank(message = "City is mandatory")
    @Size(max = 150, message = "City name cannot exceed 150 characters")
    private String city;

    @NotBlank(message = "State is mandatory")
    @Size(max = 150, message = "State name cannot exceed 150 characters")
    private String state;

    @NotNull(message = "Pincode is mandatory")
    private Long pincode;

    @Size(max = 150, message = "Landline number cannot exceed 150 characters")
    @Pattern(regexp = "^[0-9]*$", message = "Landline number can only contain digits")
    private String landlineNo;

    @Size(max = 50, message = "Mobile number cannot exceed 50 characters")
    @Pattern(regexp = "^[0-9]*$", message = "Mobile number can only contain digits")
    private String mobileNo;

    @Email(message = "Email should be valid")
    @Size(max = 150, message = "Email cannot exceed 150 characters")
    private String emailId;

    @Size(max = 250, message = "Landmark cannot exceed 250 characters")
    private String landmark;

    @NotNull(message = "Status is mandatory")
    private Integer status;

    @NotNull(message = "Created By is mandatory")
    private int createdBy;

    @NotNull(message = "Created Date is mandatory")
    private LocalDateTime createdDate;

    @NotNull(message = "Updated By is mandatory")
    private int updatedBy;

    @NotNull(message = "Updated Date is mandatory")
    private LocalDateTime updatedDate;

    @NotNull(message = "Suspended Status is mandatory")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is mandatory")
    private int municipalId;
}
