package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.model.ModuleMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ModuleMasterService {

    ModuleMaster saveModuleMaster(ModuleMaster moduleMaster);

    List<ModuleMaster> findAllModuleMaster();

    List<ModuleMaster> findAllModuleMasterByMunicipalId(Long municipalId);

    ModuleMaster updateModuleMaster(Long id, ModuleMaster updatedModuleMaster);

    ModuleMaster changeSuspendedStatus(Long id, int status);

}
