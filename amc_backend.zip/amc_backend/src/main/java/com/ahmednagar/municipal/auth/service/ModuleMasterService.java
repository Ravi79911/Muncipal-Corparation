package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.ModuleMasterDto;
import com.ahmednagar.municipal.auth.model.ModuleMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ModuleMasterService {
    ModuleMaster saveModuleMaster(ModuleMaster moduleMaster);

    List<ModuleMasterDto> findAllModuleMaster();

    List<ModuleMasterDto> findAllModuleMasterByMunicipalId(Long municipalId);

    ModuleMaster updateModuleMaster(Long id, ModuleMaster updatedModuleMaster);

    ModuleMaster changeSuspendedStatus(Long id, int status);
}
