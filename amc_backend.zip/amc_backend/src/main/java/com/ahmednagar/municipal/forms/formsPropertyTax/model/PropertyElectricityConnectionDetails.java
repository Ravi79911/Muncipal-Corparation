package com.ahmednagar.municipal.forms.formsPropertyTax.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_muni_property_electricity_connection_details")
public class PropertyElectricityConnectionDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @NotEmpty(message = "electricity connection type can't be empty")
    @Size(max = 150, message = "electricity connection type can't exceed 50 characters")
    @Column(name = "electric_connection_type")
    private String electricityConnectionType;

    @NotEmpty(message = "name of consumer can't be empty")
    @Size(max = 150, message = "name of consumer can't exceed 100 characters")
    @Column(name = "name_of_consumer")
    private String nameOfConsumer;

    @NotEmpty(message = "electricity division name can't be empty")
    @Size(max = 150, message = "electricity division name can't exceed 100 characters")
    @Column(name = "elec_division_name")
    private String electricityDivisionName;

    @NotEmpty(message = "electricity sub division name can't be empty")
    @Size(max = 150, message = "electricity sub division name can't exceed 50 characters")
    @Column(name = "elec_sub_division_name")
    private String electricitySubDivisionName;

    @NotEmpty(message = "electricity k number can't be empty")
    @Size(max = 150, message = "electricity k number can't exceed 50 characters")
    @Column(name = "elec_k_number")
    private String electricityKNumber;

    @Size(max = 150, message = "electricity account number can't exceed 50 characters")
    @Column(name = "elec_account_no")
    private String electricityAccountNumber;

    @Size(max = 150, message = "electricity book bind number can't exceed 50 characters")
    @Column(name = "elec_book_bind_no")
    private String electricityBookBindNumber;

    @NotEmpty(message = "electricity consumer number can't be empty")
    @Size(max = 150, message = "electricity consumer number can't exceed 50 characters")
    @Column(name = "elec_consumer_number")
    private String electricityConsumerNumber;

    @NotEmpty(message = "electricity consumer category can't be empty")
    @Size(max = 150, message = "electricity consumer category can't exceed 50 characters")
    @Column(name = "elec_consumer_category")
    private String electricityConsumerCategory;

    @NotNull(message = "created by can't be null")
    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
    private MunicipalPropertyMaster municipalPropertyMaster;

}
