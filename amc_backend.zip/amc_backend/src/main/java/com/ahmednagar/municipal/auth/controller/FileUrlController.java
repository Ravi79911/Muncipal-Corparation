package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.FileUrlDto;
import com.ahmednagar.municipal.auth.model.FileUrlMaster;
import com.ahmednagar.municipal.auth.service.FileUrlService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class FileUrlController {

    @Autowired
    private FileUrlService fileUrlService;

    //create fileUrl
    @PostMapping("/createFileUrl")
    public ResponseEntity<FileUrlMaster> createFileUrl(@Valid @RequestBody FileUrlMaster fileUrlMaster) {
        FileUrlMaster createdFileUrlMaster = fileUrlService.createFileUrl(fileUrlMaster);
        if (createdFileUrlMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdFileUrlMaster);
    }

    //for all admin users
    @GetMapping("/allFileUrl")
    public ResponseEntity<List<FileUrlDto>> getAllFileUrl() {
        List<FileUrlDto> fileUrl = fileUrlService.findAllFileUrl();
        return ResponseEntity.ok(fileUrl);
    }

    //get fileUrl By MunicipalId
    @GetMapping("/MunicipalFileUrl/{municipalId}")
    public ResponseEntity<?> getAllFileUrlByMunicipalId(@PathVariable Long municipalId) {
        List<FileUrlDto> fileUrl = fileUrlService.findAllFileUrlByMunicipalId(municipalId);
        if (fileUrl.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No FileUrl found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(fileUrl);
    }

    //     Update fileUrl for admin
    @PutMapping("/updatedFileUrl/{id}")
    public ResponseEntity<FileUrlMaster> updateFileUrl(@PathVariable("id") Long id, @RequestBody FileUrlMaster updatedFileUrlMaster) {
        try {
            FileUrlMaster updated = fileUrlService.updateFileUrl(id, updatedFileUrlMaster);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete fileUrl for admin
    @PatchMapping("/deleteFileUrl/{id}")
    public ResponseEntity<FileUrlMaster> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        FileUrlMaster updatedFileUrlMaster = fileUrlService.changeSuspendedStatus(id, status);         // updatedBy is always 1 for now as it is the admin
        if (updatedFileUrlMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedFileUrlMaster);
    }

}

