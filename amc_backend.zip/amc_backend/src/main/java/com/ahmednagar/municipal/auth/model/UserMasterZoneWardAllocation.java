package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "user_master_zone_ward_allocation")
public class UserMasterZoneWardAllocation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false)
    private UserMaster userMaster;

    @ManyToOne
    @JoinColumn(name = "zone_id", referencedColumnName = "id", nullable = false)
    private AuthZoneMaster zoneMaster;

    @ManyToOne
    @JoinColumn(name = "ward_id", referencedColumnName = "id", nullable = false)
    private AuthWardMaster wardMaster;

}
