package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.AdvertisementWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.model.AdvertisementWorkFlowLevel;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface AdvertisementWorkFlowLevelService {
    AdvertisementWorkFlowLevel handleWorkFlowTransition(AdvertisementWorkFlowLevel advertisementWorkFlowLevel);

    List<AdvertisementWorkFlowLevelDto> findAllWorkFlow();

    AdvertisementWorkFlowLevel createNewApplicationTransation(AdvertisementWorkFlowLevel workFlowRequest);

    List<RemarksDto> getRemarksByApplicationId(Long applicationId);
}
