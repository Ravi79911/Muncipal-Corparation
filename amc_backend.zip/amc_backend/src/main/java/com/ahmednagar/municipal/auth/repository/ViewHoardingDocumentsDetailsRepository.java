package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.ViewHoardingDocumentsDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ViewHoardingDocumentsDetailsRepository extends JpaRepository<ViewHoardingDocumentsDetails,Long> {

    List<ViewHoardingDocumentsDetails> findByViewHoardingApplicationMaster_Id(Long applicationId);

    List<ViewHoardingDocumentsDetails> findByviewHoardingApplicationMaster_Id(Long hoardingApplicationMasterId);
}
