package com.ahmednagar.municipal.forms.formsAdvertisement.utils;

import com.ahmednagar.municipal.forms.formsAdvertisement.service.ApplicationCounterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AdvertisementApplicationNumberGenerator {

    @Autowired
    private ApplicationCounterService applicationCounterService;

    private static final String PERMANENTADVERTISEMENTPREFIX = "PAAPP";
    private static final String TEMPORARYADVERTISEMENTPREFIX = "TAAPP";

    private static final String PERMANENTADVERTISEMENTDEMANDPREFIX = "PA";
    private static final String TEMPORARYADVERTISEMENTDEMANDPREFIX = "TA";

//    private static AtomicInteger advertisementApplicationNo = new AtomicInteger();
//    private static LocalDate lastResetDate = LocalDate.now();

//    static {
//        loadCounterData();
//    }

//    private static synchronized int getNextApplicationNumber() {
//        // No longer reset the counter if the date has changed
//        int nextNumber = advertisementApplicationNo.incrementAndGet();
//        saveCounterData(); // Save the updated counter
//        return nextNumber;
//    }

    public String generatePermanentApplicationNo(Long hoardingCategoryTypeMasterId) {
        // Application type ID as two digits
        String applicationTypePart = String.format("%02d", hoardingCategoryTypeMasterId);

        // Current year, month, and time
        LocalDateTime now = LocalDateTime.now();
        String yearPart = String.format("%02d", now.getYear() % 100); // Last two digits of the year
        String monthPart = String.format("%02d", now.getMonthValue()); // Two-digit month
        String timePart = String.format("%02d%02d", now.getHour(), now.getMinute());

        // Get unique application number and increment
        int uniqueNumber = applicationCounterService.getNextCounterValue("advertisement_application_no") % 1000;
        String serialNumberPart = String.format("%06d", uniqueNumber);

        // Concatenate parts to form the application number
        return PERMANENTADVERTISEMENTPREFIX + applicationTypePart + yearPart + monthPart + timePart + serialNumberPart;
    }

    public String generateTemporaryApplicationNo(Long hoardingCategoryTypeMasterId) {
        // Application type ID as two digits
        String applicationTypePart = String.format("%02d", hoardingCategoryTypeMasterId);

        // Current year, month, and time
        LocalDateTime now = LocalDateTime.now();
        String yearPart = String.format("%02d", now.getYear() % 100); // Last two digits of the year
        String monthPart = String.format("%02d", now.getMonthValue()); // Two-digit month
        String timePart = String.format("%02d%02d", now.getHour(), now.getMinute());

        // Get unique application number and increment
        int uniqueNumber = applicationCounterService.getNextCounterValue("advertisement_application_no") % 1000;
        String serialNumberPart = String.format("%06d", uniqueNumber);

        // Concatenate parts to form the application number
        return TEMPORARYADVERTISEMENTPREFIX + applicationTypePart + yearPart + monthPart + timePart + serialNumberPart;
    }

    public String generatePermanentDemandNo(Long hoardingCategoryTypeMasterId) {
        // Application type ID as two digits
        String applicationTypePart = String.format("%02d", hoardingCategoryTypeMasterId);

        // Get unique application number and increment
        int uniqueNumber = applicationCounterService.getNextCounterValue("advertisement_demand_no") % 1000;
        String serialNumberPart = String.format("%06d", uniqueNumber);

        // Concatenate parts to form the application number
        return PERMANENTADVERTISEMENTDEMANDPREFIX + applicationTypePart + serialNumberPart;
    }

    public String generateTemporaryDemandNo(Long hoardingCategoryTypeMasterId) {
        // Application type ID as two digits
        String applicationTypePart = String.format("%02d", hoardingCategoryTypeMasterId);

        // Get unique application number and increment
        int uniqueNumber = applicationCounterService.getNextCounterValue("advertisement_demand_no") % 1000;
        String serialNumberPart = String.format("%06d", uniqueNumber);

        // Concatenate parts to form the application number
        return TEMPORARYADVERTISEMENTDEMANDPREFIX + applicationTypePart + serialNumberPart;
    }

//    private static void loadCounterData() {
//        try (BufferedReader reader = new BufferedReader(new FileReader(COUNTER_FILE))) {
//            String line = reader.readLine();
//            if (line != null) {
//                String[] data = line.split(",");
//                advertisementApplicationNo.set(Integer.parseInt(data[0]));
//                lastResetDate = LocalDate.parse(data[1]);
//            }
//        } catch (IOException | NumberFormatException e) {
//            // If there's an error, initialize with default values
//            advertisementApplicationNo.set(0);
//            lastResetDate = LocalDate.now();
//        }
//    }
//
//    private static void saveCounterData() {
//        try (BufferedWriter writer = new BufferedWriter(new FileWriter(COUNTER_FILE))) {
//            writer.write(advertisementApplicationNo.get() + "," + lastResetDate.toString());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
}
