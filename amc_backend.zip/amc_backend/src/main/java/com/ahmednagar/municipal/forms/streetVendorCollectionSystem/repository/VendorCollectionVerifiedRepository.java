package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionDetail;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorCollectionVerification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface VendorCollectionVerifiedRepository extends JpaRepository<VendorCollectionVerification, Long> {

//    @Query("SELECT v FROM VendorCollectionVerification v " +
//            "JOIN v.collectionDetailId cd " +
//            "JOIN cd.vendorCollectionMasterId vcm " +
//            "JOIN vcm.zone z " +
//            "JOIN vcm.zoneWard zw " +
//            "WHERE (:zoneId IS NULL OR z.id = :zoneId) " +
//            "AND (:zoneWardId IS NULL OR zw.id = :zoneWardId) " +
//            "AND (:vendorUserId IS NULL OR cd.vendorUserId.id = :vendorUserId) " +
//            "AND (:verifiedStatus IS NULL OR v.verifiedStatus = :verifiedStatus) " +
//            "AND (:dateFrom IS NULL OR v.createdDate >= :dateFrom) " +
//            "AND (:dateTo IS NULL OR v.createdDate <= :dateTo)")
//    List<VendorCollectionVerification> findFiltered(
//            @Param("zoneId") Long zoneId,
//            @Param("zoneWardId") Long zoneWardId,
//            @Param("dateFrom") LocalDateTime dateFrom,
//            @Param("dateTo") LocalDateTime dateTo,
//            @Param("vendorUserId") Long vendorUserId,
//            @Param("verifiedStatus") String verifiedStatus
//    );

//    @EntityGraph(attributePaths = {
//            "collectionDetailId.vendorCollectionMasterId.zone",
//            "collectionDetailId.vendorCollectionMasterId.zoneWard",
//            "collectionDetailId.vendorCollectionMasterId.vendorUser",
//            "collectionDetailId.vendorUserWardAllotmentId.vendorUserMasId"
//    })
//    @Query("SELECT v FROM VendorCollectionVerification v WHERE v.id = :id")
//    Optional<VendorCollectionVerification> findByIdWithRelations(@Param("id") Long id);


    @Query("SELECT v FROM VendorCollectionVerification v " +
            "JOIN v.collectionDetailId cd " +
            "WHERE (:startDateTime IS NULL OR v.createdDate >= :startDateTime) " +
            "AND (:endDateTime IS NULL OR v.createdDate <= :endDateTime) " +
            "AND (:vendorUserId IS NULL OR cd.vendorUserId.id = :vendorUserId)")
    List<VendorCollectionVerification> findByCreatedDateAndVendorUserId(
            @Param("startDateTime") LocalDateTime startDateTime,
            @Param("endDateTime") LocalDateTime endDateTime,
            @Param("vendorUserId") Long vendorUserId);




}
