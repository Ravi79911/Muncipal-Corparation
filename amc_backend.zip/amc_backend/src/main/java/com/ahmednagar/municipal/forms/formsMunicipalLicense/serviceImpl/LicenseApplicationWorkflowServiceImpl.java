package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseApplicationWorkflow;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseWorkflowHistory;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.LicenseApplicationAutoTransferRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.LicenseApplicationWorkflowRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.LicenseLabelStageRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.LicenseWorkflowHistoryRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.LicenseApplicationWorkflowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;



@Service
public class LicenseApplicationWorkflowServiceImpl implements LicenseApplicationWorkflowService {
    @Autowired
    private LicenseApplicationWorkflowRepository licenseApplicationWorkflowRepository;

    @Autowired
    private LicenseLabelStageRepository licenseLabelStageRepository;

    @Autowired
    private LicenseWorkflowHistoryRepository licenseWorkflowHistoryRepository;

    @Autowired
    private LicenseApplicationAutoTransferRepository licenseApplicationAutoTransferRepository;


    @Override
    public LicenseApplicationWorkflow createWorkflow(LicenseApplicationWorkflow licenseApplicationWorkflow) {
        licenseApplicationWorkflow.setCurrentStage("Citizen");
        licenseApplicationWorkflow.setStatus("Pending");
        licenseApplicationWorkflow.setCreatedDate(LocalDateTime.now());
        licenseApplicationWorkflow.setUpdatedDate(LocalDateTime.now());
        return licenseApplicationWorkflowRepository.save(licenseApplicationWorkflow);
    }

    @Override
    public LicenseApplicationWorkflow processDocumentApproval(Long workflowId, boolean isApproved, String actionBy, String comment) {
        // Retrieve the workflow by ID
        LicenseApplicationWorkflow workflow = licenseApplicationWorkflowRepository.findById(workflowId).orElseThrow(() -> new RuntimeException("Workflow not found"));
        System.out.println("This is work flow"+workflow);

        // Create and save the workflow history
        LicenseWorkflowHistory history = new LicenseWorkflowHistory();
        history.setActionTaken(isApproved ? "Document Approved" : "Document Rejected");
        history.setActionBy(actionBy);
        history.setActionDate(LocalDateTime.now());
        history.setApplicationWorkflowId(workflow);
        licenseWorkflowHistoryRepository.save(history);

        // Determine the current stage and update workflow based on approval/rejection
        if (workflow.getStageId().equals("Lipik")) {
            return handleLipikApproval(workflow, isApproved, actionBy, comment);
        } else if (workflow.getStageId().equals("Section Head")) {
            return handleSectionHeadApproval(workflow, isApproved, actionBy, comment);
        } else if (workflow.getStageId().equals("DMC")) {
            return handleDMCApproval(workflow, isApproved, actionBy, comment);
        }
        throw new RuntimeException("Invalid stage: " + workflow.getCurrentStage());
    }

    private LicenseApplicationWorkflow handleLipikApproval(LicenseApplicationWorkflow workflow, boolean isApproved, String actionBy, String comment) {
        if (isApproved) {
            workflow.setStatus("Approved");
            workflow.setCurrentStage("Section Head");  // Move to next stage
        } else {
            workflow.setStatus("Rejected");
            workflow.setCurrentStage("Citizen");  // Return to Citizen for re-upload
        }
        workflow.setUpdatedDate(LocalDateTime.now());
        return licenseApplicationWorkflowRepository.save(workflow);
    }

    private LicenseApplicationWorkflow handleSectionHeadApproval(LicenseApplicationWorkflow workflow, boolean isApproved, String actionBy, String comment) {
        if (isApproved) {
            workflow.setStatus("Approved");
            workflow.setCurrentStage("DMC");  // Move to next stage
        } else {
            workflow.setStatus("Rejected");
            workflow.setCurrentStage("Citizen");  // Return to Citizen
        }
        workflow.setUpdatedDate(LocalDateTime.now());
        return licenseApplicationWorkflowRepository.save(workflow);
    }

    private LicenseApplicationWorkflow handleDMCApproval(LicenseApplicationWorkflow workflow, boolean isApproved, String actionBy, String comment) {
        if (isApproved) {
            workflow.setStatus("Application Approved");
            workflow.setCurrentStage("Payment");  // Proceed to payment stage
        } else {
            workflow.setStatus("Rejected");
            workflow.setCurrentStage("Citizen");  // Return to Citizen
        }
        workflow.setUpdatedDate(LocalDateTime.now());
        return licenseApplicationWorkflowRepository.save(workflow);
    }
//
//    @Override
//    public LicenseApplicationWorkflow updateWorkflowStatus(Long id, String status, String updatedBy) {
//        Optional<LicenseApplicationWorkflow> workflowOpt = licenseApplicationWorkflowRepository.findById(id);
//        if (workflowOpt.isPresent()) {
//            LicenseApplicationWorkflow workflow = workflowOpt.get();
//            workflow.setStatus(status);
//            workflow.setUpdatedBy(updatedBy);
//            workflow.setUpdatedDate(LocalDateTime.now());
//            return licenseApplicationWorkflowRepository.save(workflow);
//        }
//        return null;
//    }
//
//    @Override
//    public LicenseApplicationWorkflow processDocumentRejection(Long id, String updatedBy) {
//        Optional<LicenseApplicationWorkflow> workflowOpt = licenseApplicationWorkflowRepository.findById(id);
//        if (workflowOpt.isPresent()) {
//            LicenseApplicationWorkflow workflow = workflowOpt.get();
//            workflow.setStatus("Rejected");
//            workflow.setUpdatedBy(updatedBy);
//            workflow.setUpdatedDate(LocalDateTime.now());
//
//            LicenseLabelStage currentStage = workflow.getStageId();
//            String role = currentStage.getRole();
//
//            // Case 1 and Case 2: Backward to Citizen
//            if ("Reviewer".equalsIgnoreCase(role) || "Approver".equalsIgnoreCase(role)) {
//                LicenseLabelStage citizenStage = licenseLabelStageRepository.findById(1L)
//                        .orElseThrow(() -> new IllegalArgumentException("Citizen stage not found"));
//                workflow.setStageId(citizenStage);
//            }
//
//            return licenseApplicationWorkflowRepository.save(workflow);
//        }
//        return null;
//    }
//
//    @Override
//    public LicenseApplicationWorkflow processDocumentApproval(Long id, String updatedBy) {
//        Optional<LicenseApplicationWorkflow> workflowOpt = licenseApplicationWorkflowRepository.findById(id);
//        if (workflowOpt.isPresent()) {
//            LicenseApplicationWorkflow workflow = workflowOpt.get();
//            workflow.setStatus("Approved");
//            workflow.setUpdatedBy(updatedBy);
//            workflow.setUpdatedDate(LocalDateTime.now());
//
//            LicenseLabelStage currentStage = workflow.getStageId();
//            String role = currentStage.getRole();
//
//            // If the document is approved and it reaches Section Head -> DMC:
//            if ("Lipik".equals(workflow.getCurrentStage())) {
//                workflow.setCurrentStage("Section Head");
//            } else if ("Section Head".equals(workflow.getCurrentStage())) {
//                workflow.setCurrentStage("DMC");
//            } else if ("DMC".equals(workflow.getCurrentStage()) && "Approved".equals(workflow.getStatus())) {
//                // Proceed to payment
//                workflow.setCurrentStage("Payment");
//            }
//
//            return licenseApplicationWorkflowRepository.save(workflow);
//        }
//        return null;
//    }
//
//    @Override
//    public Optional<LicenseApplicationWorkflow> getWorkflowById(Long id) {
//        return licenseApplicationWorkflowRepository.findById(id);
//    }
}


