package com.ahmednagar.municipal.forms.formsPropertyTax.controller;

import com.ahmednagar.municipal.exception.ApiResponse;
import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyWaterConnectionDetails;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyWaterConnectionDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/forms")
public class PropertyWaterConnectionDetailsController {

    @Autowired
    PropertyWaterConnectionDetailsService propertyWaterConnectionDetailsService;

    @PostMapping("/createPropertyWaterConnectionDetails")
    public ResponseEntity<PropertyWaterConnectionDetails> createPropertyDemand(@Valid @RequestBody PropertyWaterConnectionDetails propertyWaterConnectionDetails) {
        PropertyWaterConnectionDetails newPropertyWaterConnection = propertyWaterConnectionDetailsService.createPropertyWaterConnectionDetails(propertyWaterConnectionDetails);
        return ResponseEntity.ok(newPropertyWaterConnection);
    }

    @GetMapping("/getAllPropertyWaterConnectionDetails")
    public ResponseEntity<List<PropertyWaterConnectionDetails>> getAllPropertyWaterConnection() {
        return ResponseEntity.ok(propertyWaterConnectionDetailsService.getAllPropertyWaterConnectionDetails());
    }

    @GetMapping("/propertyWaterConnectionDetails/{id}")
    public ResponseEntity<Object> getPropertyWaterConnectionById(@PathVariable Long id) {
        Optional<PropertyWaterConnectionDetails> propertyWaterConnection = propertyWaterConnectionDetailsService.getPropertyWaterConnectionDetailsById(id);
        if (propertyWaterConnection.isPresent()) {
            return ResponseEntity.ok(propertyWaterConnection.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
        }
    }

    @GetMapping("/getPropertyWaterConnectionDetailsByMunicipalId/{municipalId}")
    public List<PropertyWaterConnectionDetails> getPropertyWaterConnectionByMunicipalId(@PathVariable int municipalId) {
        return propertyWaterConnectionDetailsService.getPropertyWaterConnectionDetailsByMunicipalId(municipalId);
    }

    @PatchMapping("/propertyWaterConnectionDetails/suspendedStatus/{id}")
    public ResponseEntity<PropertyWaterConnectionDetails> patchPropertyWaterConnectionSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
        PropertyWaterConnectionDetails patchedPropertyWaterConnection = propertyWaterConnectionDetailsService.patchPropertyWaterConnectionDetailsSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedPropertyWaterConnection);
    }

    @PutMapping("/updatePropertyWaterConnectionDetailsById/{id}")
    public ResponseEntity<ApiResponse> updatePropertyWaterConnectionDetails(@PathVariable Long id,
                                                                            @RequestBody PropertyWaterConnectionDetails propertyWaterConnectionDetails) {
        try {
            if (propertyWaterConnectionDetails.getUpdatedBy() == null) {
                return new ResponseEntity<>(new ApiResponse("updated by is mandatory and can't be null", false), HttpStatus.BAD_REQUEST);
            }
            PropertyWaterConnectionDetails updatedDetails = propertyWaterConnectionDetailsService.updatePropertyWaterConnectionDetailsById(id, propertyWaterConnectionDetails);
            return ResponseEntity.ok(new ApiResponse("Property Water Connection Details updated successfully!", true, updatedDetails));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An internal error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/deletePropertyWaterConnectionDetails/{municipalPropertyMasterId}")
    public ResponseEntity<String> deletePropertyWaterConnectionDetails(@PathVariable Long municipalPropertyMasterId) {
        try {
            propertyWaterConnectionDetailsService.deletePropertyWaterConnectionDetailsByMunicipalPropertyMasterId(municipalPropertyMasterId);
            return ResponseEntity.ok("PropertyWaterConnectionDetails details records deleted successfully for MunicipalPropertyMaster id: " + municipalPropertyMasterId);
        } catch (Exception ex) {
            return ResponseEntity.status(500).body("An unexpected error occurred: " + ex.getMessage());
        }
    }

}
