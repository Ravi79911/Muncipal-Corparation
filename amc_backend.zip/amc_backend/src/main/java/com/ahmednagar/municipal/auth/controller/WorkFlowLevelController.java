package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.RemarksDto;
import com.ahmednagar.municipal.auth.dto.WorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.WorkFlowLevel;
import com.ahmednagar.municipal.auth.service.WorkFlowLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/work/flow/level")
public class WorkFlowLevelController {

    @Autowired
    private WorkFlowLevelService workFlowLevelService;

    // Endpoint to handle workflow transitions
    @PostMapping("/transition")
    public ResponseEntity<WorkFlowLevel> handleWorkFlowsTransition(@RequestBody WorkFlowLevel workFlowLevel) {
        WorkFlowLevel updatedWorkFlowLevel = workFlowLevelService.handleWorkFlowsTransition(workFlowLevel);
        return ResponseEntity.ok(updatedWorkFlowLevel);
    }
    //for admin all users
    @GetMapping("/all")
    public ResponseEntity<List<WorkFlowLevelDto>> getAllWorkFlows(){
        List<WorkFlowLevelDto> workFlows=workFlowLevelService.findAllWorkFlows();
        return ResponseEntity.ok(workFlows);
    }

    @PostMapping("/new-application")
    public ResponseEntity<WorkFlowLevel> createNewWorkflow(@RequestBody WorkFlowLevel workFlowRequest) {
        WorkFlowLevel savedWorkflow = workFlowLevelService.createNewApplicationTransation(workFlowRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedWorkflow);
    }

    @GetMapping("/getAllRemarks/{applicationId}")
    public ResponseEntity<List<RemarksDto>> getRemarksByApplicationId(@RequestParam Long applicationId) {
        List<RemarksDto> remarks = workFlowLevelService.getRemarksByApplicationId(applicationId);
        return ResponseEntity.ok(remarks);
    }
}

