package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.AdvertisementTemporaryRolesDataFlowSetup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface AdvertisementTemporaryRolesDataFlowSetupRepository extends JpaRepository<AdvertisementTemporaryRolesDataFlowSetup,Long> {
    Optional<AdvertisementTemporaryRolesDataFlowSetup> findByCurrentRoleIdAndStatusCodeAndIsActive(
            Long currentRoleId, 
            Long statusCode, 
            Integer isActive);

    List<AdvertisementTemporaryRolesDataFlowSetup> findAllByCurrentRoleIdAndStatusCodeAndIsActive(Long currentRoleId, Long statusCode, Integer isActive);
}
