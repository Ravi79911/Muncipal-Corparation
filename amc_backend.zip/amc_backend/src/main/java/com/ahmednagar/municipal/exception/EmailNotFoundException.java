package com.ahmednagar.municipal.exception;

import lombok.Data;

@Data
public class EmailNotFoundException extends RuntimeException {

    private String message;

    public EmailNotFoundException(String message) {
        super(String.format(message));
        this.message = message;
    }

}
