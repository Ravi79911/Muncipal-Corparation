package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.LicenseWorkFlowLevel;
import com.ahmednagar.municipal.auth.model.ViewApplicationFromMaster;
import com.ahmednagar.municipal.auth.model.WorkFlowLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;


@EnableJpaRepositories
public interface LicenseWorkFlowLevelRepository extends JpaRepository<LicenseWorkFlowLevel,Long> {

    @Query(value = "SELECT TOP 1 * FROM tbl_license_work_flow_level WHERE application_master_id = :applicationMasterId AND status_code = :statusCode ORDER BY created_date DESC", nativeQuery = true)
    Optional<LicenseWorkFlowLevel> findLatestWorkFlowByApplicationMasterIdAndStatusCode(@Param("applicationMasterId") Long applicationMasterId, @Param("statusCode") Long statusCode);

    Optional<LicenseWorkFlowLevel> findTopByApplicationMasterIdOrderByCreatedDateDesc(ViewApplicationFromMaster applicationMasterId);

    List<LicenseWorkFlowLevel> findByApplicationMasterId_Id(Long applicationId);
}