package com.ahmednagar.municipal.forms.formsAdvertisement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingTransactionPaymentDetailsDto {
    private Long id;
    private Long paymentCollectionMasterId;
    private String paymentMode;
    private String bankName;
    private String ddChaqueTransNo;
    private LocalDateTime ddChaqueTransDate;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
