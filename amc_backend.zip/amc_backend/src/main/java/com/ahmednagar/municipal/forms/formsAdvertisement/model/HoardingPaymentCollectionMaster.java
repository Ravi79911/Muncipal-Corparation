package com.ahmednagar.municipal.forms.formsAdvertisement.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb2_hoarding_payment_collection_master")
public class HoardingPaymentCollectionMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name = "transaction_no", nullable = false)
    @NotBlank(message = "Transaction number cannot be blank")
    @Size(max = 150, message = "Transaction number cannot exceed 150 characters")
    private String transactionNo;

    @Column(name = "transaction_total_amount", nullable = false)
    @NotBlank(message = "Transaction total amount cannot be blank")
    @Size(max = 150, message = "Transaction total amount cannot exceed 150 characters")
    private String transactionTotalAmount;

    @Column(name = "transaction_paid_amount", nullable = false)
    @NotBlank(message = "Transaction paid amount cannot be blank")
    @Size(max = 150, message = "Transaction paid amount cannot exceed 150 characters")
    private String transactionPaidAmount;

    @Column(name = "transaction_date", nullable = false)
    private LocalDateTime transactionDate;

    @Column(name = "payment_date", nullable = false)
    private LocalDateTime paymentDate;

    @Column(name = "reciept_no", nullable = false)
    @NotBlank(message = "Receipt number cannot be blank")
    @Size(max = 150, message = "Receipt number cannot exceed 150 characters")
    private String receiptNo;

    @Column(name = "receipt_date", nullable = false)
    private LocalDateTime receiptDate;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "hoarding_application_master_id", nullable = false, referencedColumnName = "id")
    private HoardingApplicationMaster hoardingApplicationMasterId;

}
