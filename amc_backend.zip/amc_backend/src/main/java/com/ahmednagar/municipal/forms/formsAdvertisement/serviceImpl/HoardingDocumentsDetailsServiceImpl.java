package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingDocumentsDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingDocumentsDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingApplicationMasterRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingDocumentsDetailsRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingDocumentsDetailsService;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationDocumentsDetails;
import com.ahmednagar.municipal.master.advertisement.model.HoardingDocumentSubCategoryMasterSetup;
import com.ahmednagar.municipal.master.advertisement.repository.HoardingDocumentSubCategoryMasterSetupRepository;
import com.ahmednagar.municipal.master.municipalLicence.model.MlDocumentsMaster;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class HoardingDocumentsDetailsServiceImpl implements HoardingDocumentsDetailsService {

    //private static final String UPLOAD_DIR = "D:\\muncipal_demo\\ahmednagar_muncipal\\src\\main\\resources\\advertisementUpload";
    private static final long MAX_FILE_SIZE = 2 * 1024 * 1024;

    @Value("${upload.advertisement.doc.dir}")
    private String UPLOAD_DIR;

    @Autowired
    private HoardingDocumentsDetailsRepository hoardingDocumentsDetailsRepository;

    @Autowired
    private HoardingApplicationMasterRepository hoardingApplicationMasterRepository;

    @Autowired
    private HoardingDocumentSubCategoryMasterSetupRepository hoardingDocumentSubCategoryMasterSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingDocumentsDetails saveHoardingDocumentsDetails(HoardingDocumentsDetails hoardingDocumentsDetails) {
        hoardingDocumentsDetails.setCreatedDate(LocalDateTime.now());
        hoardingDocumentsDetails.setUpdatedDate(LocalDateTime.now());
        hoardingDocumentsDetails.setUpdatedBy(hoardingDocumentsDetails.getUpdatedBy() != null ? hoardingDocumentsDetails.getUpdatedBy() : 0);
        hoardingDocumentsDetails.setSuspendedStatus(hoardingDocumentsDetails.getSuspendedStatus() != null ? hoardingDocumentsDetails.getSuspendedStatus() : 0);

        return hoardingDocumentsDetailsRepository.save(hoardingDocumentsDetails);

    }

    @Override
    public HoardingDocumentsDetails uploadDocument(MultipartFile file, int createdBy, int suspendedStatus, int municipalId, Long hoardingApplicationMasterId, int hoardingDocumentsSubCategoryMasterId) throws Exception{
        // Validate file type
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        if (!fileName.endsWith(".pdf")) {
            throw new Exception("Only PDF files are allowed.");
        }
        System.out.println(fileName+"rammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm::::::::::::::::::::::::::");

        if (file.getSize() > MAX_FILE_SIZE) {
            throw new Exception("File size exceeds the maximum allowed size of 10 MB.");
        }

        // Get the folder name based on the document type
        String folderName = hoardingDocumentSubCategoryMasterSetupRepository.findById((long) hoardingDocumentsSubCategoryMasterId)
                .map(HoardingDocumentSubCategoryMasterSetup::getSubCategoryName)
                .orElseThrow(() -> new Exception("Invalid document type ID."));

        System.out.println("folderrrrrrrrrrrrrrrrrrrrrrrrr Nameeeeeeeeeeee"+ folderName);

        // Replace spaces in the folder name with underscores
        folderName = folderName.replaceAll("\\s+", "_");

        // Create the new file name using the modified folder name and the random number
        String newFileName = folderName + "_" + UUID.randomUUID() + ".pdf";

        // Generate the file path based on the document type
        Path uploadPath = Paths.get(UPLOAD_DIR + "/" + folderName);

        System.out.println("upload Pathhhhhhhhhhhhhhhhhhhh=========>>>>>>>"+uploadPath);

        try {
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            Path filePath = uploadPath.resolve(newFileName);
            Files.copy(file.getInputStream(), filePath);

            // prepare the relative URL for the uploaded file
            String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/licenseDocumentUpload/")
                    .path(folderName + "/" + newFileName)
                    .toUriString();

            // Prepare DocumentDetails object for saving
            HoardingDocumentsDetails hoardingDocumentsDetails = new HoardingDocumentsDetails();
            hoardingDocumentsDetails.setDocumentUrl(fileUrl);
            hoardingDocumentsDetails.setDocumentFileName(newFileName);
            hoardingDocumentsDetails.setHoardingApplicationMasterId(hoardingApplicationMasterRepository.findById(hoardingApplicationMasterId).orElseThrow());
            hoardingDocumentsDetails.setHoardingDocumentsSubCategoryMasterId(hoardingDocumentSubCategoryMasterSetupRepository.findById((long) hoardingDocumentsSubCategoryMasterId).orElseThrow());
            hoardingDocumentsDetails.setMunicipalId(municipalId);
            hoardingDocumentsDetails.setSuspendedStatus(suspendedStatus);
            hoardingDocumentsDetails.setCreatedDate(LocalDateTime.now());
            hoardingDocumentsDetails.setUpdatedDate(LocalDateTime.now());
            hoardingDocumentsDetails.setCreatedBy(createdBy);
            hoardingDocumentsDetails.setUpdatedBy(createdBy);

            return hoardingDocumentsDetailsRepository.saveAndFlush(hoardingDocumentsDetails);
        } catch (Exception e) {
            throw new Exception("Error uploading document: " + e.getMessage(), e);
        }
    }

    @Override
    public HoardingDocumentsDetails updateHoardingDocumentsDetailsById(Long id, MultipartFile documentUrl) {
        HoardingDocumentsDetails existingHoardingDocumentsDetails = hoardingDocumentsDetailsRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("License Document Upload Details", "id", id));

        deleteDocument(existingHoardingDocumentsDetails.getDocumentUrl());
        existingHoardingDocumentsDetails = handleDocumentUpload(existingHoardingDocumentsDetails, documentUrl);
        existingHoardingDocumentsDetails.setCreatedBy(existingHoardingDocumentsDetails.getCreatedBy());
        System.out.println("created by " + existingHoardingDocumentsDetails.getCreatedBy());
        //existingApplicationDocumentsDetails.setUpdatedDate(LocalDateTime.now());
        return hoardingDocumentsDetailsRepository.saveAndFlush(existingHoardingDocumentsDetails);
    }

    @Override
    public List<HoardingDocumentsDetails> getAllDetailsByHoardingMasterId(Long hoardingMasterId) {
        List<HoardingDocumentsDetails> documentList =
                hoardingDocumentsDetailsRepository.findByHoardingApplicationMasterId_Id(hoardingMasterId);

        if (documentList.isEmpty()) {
            throw new ResourceNotFoundException("Advertisement Documents Details", "hoardingMasterId", hoardingMasterId);
        }

        return documentList;
    }


    @Override
    public List<HoardingDocumentsDetailsDto> findAllHoardingDocumentsDetails() {
        List<HoardingDocumentsDetails> hoardingDocumentsDetails = hoardingDocumentsDetailsRepository.findAll();
        return hoardingDocumentsDetails.stream()
                .map(hoardingDocumentsDetails1 -> modelMapper.map(hoardingDocumentsDetails1, HoardingDocumentsDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingDocumentsDetails findById(Long id) {
        Optional<HoardingDocumentsDetails> hoardingDocumentsDetails=hoardingDocumentsDetailsRepository.findById(id);
        return hoardingDocumentsDetails.orElse(null);

    }

    @Override
    public List<HoardingDocumentsDetails> findAllByMunicipalId(int municipalId) {
        return hoardingDocumentsDetailsRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingDocumentsDetails updateHoardingDocumentsDetails(Long id, HoardingDocumentsDetails updatedHoardingDocumentsDetails, int updatedBy) {
        Optional<HoardingDocumentsDetails> hoardingDocumentsDetailsOptional = hoardingDocumentsDetailsRepository.findById(id);
        if (hoardingDocumentsDetailsOptional.isPresent()) {
            HoardingDocumentsDetails existingHoardingDocumentsDetails= hoardingDocumentsDetailsOptional.get();
            existingHoardingDocumentsDetails.setCreatedDate(LocalDateTime.now());
            existingHoardingDocumentsDetails.setUpdatedDate(LocalDateTime.now());
            existingHoardingDocumentsDetails.setUpdatedBy(existingHoardingDocumentsDetails.getUpdatedBy() != null ? existingHoardingDocumentsDetails.getUpdatedBy() : 0);
            existingHoardingDocumentsDetails.setSuspendedStatus(existingHoardingDocumentsDetails.getSuspendedStatus() != null ? existingHoardingDocumentsDetails.getSuspendedStatus() : 0);

            return hoardingDocumentsDetailsRepository.saveAndFlush(existingHoardingDocumentsDetails);
        } else {
            throw new RuntimeException("hoardingDocumentsDetails not found with id: " + id);
        }
    }

    @Override
    public HoardingDocumentsDetails changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingDocumentsDetails> hoardingDocumentsDetailsOpt = hoardingDocumentsDetailsRepository.findById(id);
        if (hoardingDocumentsDetailsOpt.isPresent()) {
            HoardingDocumentsDetails hoardingDocumentsDetails = hoardingDocumentsDetailsOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingDocumentsDetails.setUpdatedDate(currentDateTime);
            hoardingDocumentsDetails.setSuspendedStatus(status);      // 1 means suspended
            hoardingDocumentsDetails.setUpdatedBy(updatedBy);
            return hoardingDocumentsDetailsRepository.saveAndFlush(hoardingDocumentsDetails);
        }
        return null;
    }
    // handle document upload
    public HoardingDocumentsDetails handleDocumentUpload(HoardingDocumentsDetails hoardingDocumentsDetails, MultipartFile documentUrl) {
        Long masterId = hoardingDocumentsDetails.getHoardingDocumentsSubCategoryMasterId().getId();
        HoardingDocumentSubCategoryMasterSetup master = hoardingDocumentSubCategoryMasterSetupRepository.findById(masterId)
                .orElseThrow(() -> new ResourceNotFoundException("License Upload Document Master", "id", masterId));

        String documentName = master.getSubCategoryName();
        if (documentName == null || documentName.isEmpty()) {
            throw new IllegalArgumentException("Document name is missing.");
        }

        documentName = documentName.replace(" ", "_");

        if (documentUrl != null && !documentUrl.isEmpty()) {
            if (!isPdf(documentUrl)) {
                throw new IllegalArgumentException("Only PDF files are allowed.");
            }
            if (documentUrl.getSize() > MAX_FILE_SIZE) {
                throw new IllegalArgumentException("File size exceeds the maximum limit of " + MAX_FILE_SIZE / (1024 * 1024) + " MB.");
            }
            try {
                // ✅ Step 1: Ensure Local Directory Exists
                Path typeDirectory = Paths.get(UPLOAD_DIR, documentName);
                if (!Files.exists(typeDirectory)) {
                    Files.createDirectories(typeDirectory);
                }

                // ✅ Step 2: Generate Unique Filename
                String newFileName = documentName + "_" + UUID.randomUUID() + ".pdf";
                newFileName = newFileName.replace(" ", "_");

                // ✅ Step 3: Save File Locally
                Path filePath = typeDirectory.resolve(newFileName);
                Files.write(filePath, documentUrl.getBytes());

                // ✅ Step 4: Generate Correct URL for Response (Only for API Response)
                String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                        .path("/propertyDocumentUploads/")
                        .path(documentName + "/")
                        .path(newFileName)
                        .toUriString();

                // ✅ Step 5: Store **Only URL** in Database
                hoardingDocumentsDetails.setDocumentUrl(fileUrl);
                return hoardingDocumentsDetails;

            } catch (IOException e) {
                throw new RuntimeException("Error while saving the document: " + e.getMessage(), e);
            }
        } else {
            throw new IllegalArgumentException("Uploaded file is null or empty.");
        }
    }
    // check allowed extension at the time of save
    private boolean isPdf(MultipartFile file) {
        String contentType = file.getContentType();
        String fileName = file.getOriginalFilename();
        return (contentType != null && contentType.equalsIgnoreCase("application/pdf")) ||
                (fileName != null && fileName.toLowerCase().endsWith(".pdf"));
    }

    // delete old uploaded document correctly
    public void deleteDocument(String documentPath) {
        if (documentPath != null) {
            try {
                URI uri = new URI(documentPath);
                String path = uri.getPath();
                String relativeFilePath = path.replace("/advertisementDocumentUploads/", "");

                Path filePath = Paths.get(UPLOAD_DIR, relativeFilePath);
                Files.deleteIfExists(filePath);
            } catch (IOException | URISyntaxException e) {
                throw new RuntimeException("Error deleting document: " + e.getMessage(), e);
            }
        }
    }
}
