package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingDocumentsDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingDocumentsDetails;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingDocumentsDetailsRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingDocumentsDetailsService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingDocumentsDetailsServiceImpl implements HoardingDocumentsDetailsService {
    @Autowired
    private HoardingDocumentsDetailsRepository hoardingDocumentsDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingDocumentsDetails saveHoardingDocumentsDetails(HoardingDocumentsDetails hoardingDocumentsDetails) {
        hoardingDocumentsDetails.setCreatedDate(LocalDateTime.now());
        hoardingDocumentsDetails.setUpdatedDate(LocalDateTime.now());
        hoardingDocumentsDetails.setUpdatedBy(hoardingDocumentsDetails.getUpdatedBy() != null ? hoardingDocumentsDetails.getUpdatedBy() : 0);
        hoardingDocumentsDetails.setSuspendedStatus(hoardingDocumentsDetails.getSuspendedStatus() != null ? hoardingDocumentsDetails.getSuspendedStatus() : 0);

        return hoardingDocumentsDetailsRepository.save(hoardingDocumentsDetails);

    }

    @Override
    public List<HoardingDocumentsDetailsDto> findAllHoardingDocumentsDetails() {
        List<HoardingDocumentsDetails> hoardingDocumentsDetails = hoardingDocumentsDetailsRepository.findAll();
        return hoardingDocumentsDetails.stream()
                .map(hoardingDocumentsDetails1 -> modelMapper.map(hoardingDocumentsDetails1, HoardingDocumentsDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingDocumentsDetails findById(Long id) {
        Optional<HoardingDocumentsDetails> hoardingDocumentsDetails=hoardingDocumentsDetailsRepository.findById(id);
        return hoardingDocumentsDetails.orElse(null);

    }

    @Override
    public List<HoardingDocumentsDetails> findAllByMunicipalId(int municipalId) {
        return hoardingDocumentsDetailsRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingDocumentsDetails updateHoardingDocumentsDetails(Long id, HoardingDocumentsDetails updatedHoardingDocumentsDetails, int updatedBy) {
        Optional<HoardingDocumentsDetails> hoardingDocumentsDetailsOptional = hoardingDocumentsDetailsRepository.findById(id);
        if (hoardingDocumentsDetailsOptional.isPresent()) {
            HoardingDocumentsDetails existingHoardingDocumentsDetails= hoardingDocumentsDetailsOptional.get();
            //existingHoardingDocumentsDetails.setHoardingCategoryTypeName(updatedHoardingDocumentsDetails.getHoardingCategoryTypeName());
            existingHoardingDocumentsDetails.setUpdatedBy(updatedBy);
            existingHoardingDocumentsDetails.setUpdatedDate(LocalDateTime.now());
            return hoardingDocumentsDetailsRepository.saveAndFlush(existingHoardingDocumentsDetails);
        } else {
            throw new RuntimeException("hoardingDocumentsDetails not found with id: " + id);
        }
    }

    @Override
    public HoardingDocumentsDetails changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingDocumentsDetails> hoardingDocumentsDetailsOpt = hoardingDocumentsDetailsRepository.findById(id);
        if (hoardingDocumentsDetailsOpt.isPresent()) {
            HoardingDocumentsDetails hoardingDocumentsDetails = hoardingDocumentsDetailsOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingDocumentsDetails.setUpdatedDate(currentDateTime);
            hoardingDocumentsDetails.setSuspendedStatus(status);      // 1 means suspended
            hoardingDocumentsDetails.setUpdatedBy(updatedBy);
            return hoardingDocumentsDetailsRepository.saveAndFlush(hoardingDocumentsDetails);
        }
        return null;
    }
}
