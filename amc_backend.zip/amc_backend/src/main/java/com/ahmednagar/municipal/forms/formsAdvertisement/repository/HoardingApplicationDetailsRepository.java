package com.ahmednagar.municipal.forms.formsAdvertisement.repository;

import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface HoardingApplicationDetailsRepository extends JpaRepository<HoardingApplicationDetails,Long> {
    List<HoardingApplicationDetails> findAllByMunicipalId(int municipalId);
}
