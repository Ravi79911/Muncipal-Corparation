package com.ahmednagar.municipal.exception;

import io.jsonwebtoken.MalformedJwtException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // handle ResourceNotFoundException
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiResponse> resourceNotFoundExceptionHandler(ResourceNotFoundException ex) {
        logger.error("Resource not found: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "RESOURCE_NOT_FOUND",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
    }

    // handle validation errors (MethodArgumentNotValidException)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse> handleMethodArgsNotValidException(MethodArgumentNotValidException ex) {
        logger.warn("Validation error: {}", ex.getMessage());

        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String message = error.getDefaultMessage();
            errors.put(fieldName, message);
        });

        ApiResponse apiResponse = new ApiResponse(
                "Validation failed",
                false,
                LocalDateTime.now(),
                "VALIDATION_ERROR",
                errors
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle BadCredentialsException (invalid credentials)
    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ApiResponse> handleBadCredentialsException(BadCredentialsException ex) {
        logger.error("Bad credentials: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                "BAD_CREDENTIALS_ERROR"
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle MaxUploadSizeExceededException (file size exceeds maximum allowed limit)
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<ApiResponse> handleMaxSizeException(MaxUploadSizeExceededException ex) {
        logger.warn("File size exceeded: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                "File size exceeds the maximum allowed limit",
                false,
                "MAX_UPLOAD_SIZE_EXCEEDED"
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.PAYLOAD_TOO_LARGE);
    }

    // handle IllegalArgumentException
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ApiResponse> handleIllegalArgumentException(IllegalArgumentException ex) {
        logger.error("Illegal argument: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                "ILLEGAL_ARGUMENT"
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle RuntimeException (specific handling for RuntimeException)
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ApiResponse> handleRuntimeException(RuntimeException ex) {
        logger.error("RuntimeException occurred: {}", ex.getMessage(), ex);
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "RUNTIME_ERROR",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // handle uncaught general exceptions
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse> handleGenericException(Exception ex) {
        logger.error("Unexpected error: {}", ex.getMessage(), ex);
        ApiResponse apiResponse = new ApiResponse(
                "An unexpected error occurred. Please try again later.",
                false,
                "INTERNAL_SERVER_ERROR"
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // handle API exception
    @ExceptionHandler(ApiException.class)
    public ResponseEntity<ApiResponse> handleApiException(ApiException ex) {
        logger.error("API exception occurred: {}", ex.getMessage(), ex);
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "API_ERROR",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // handle MalformedJwtException (Invalid JWT token)
    @ExceptionHandler(MalformedJwtException.class)
    public ResponseEntity<ApiResponse> handleMalformedJwtException(MalformedJwtException ex) {
        logger.error("Malformed JWT Token: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                "Malformed JWT token, please provide a valid token.",
                false,
                LocalDateTime.now(),
                "JWT_MALFORMED",
                Map.of()
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle SQLException (database-related errors)
    @ExceptionHandler(SQLException.class)
    public ResponseEntity<ApiResponse> handleSQLException(SQLException ex) {
        logger.error("Database error: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                "Database error occurred. Please try again later.",
                false,
                LocalDateTime.now(),
                "DATABASE_ERROR",
                Map.of()
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
