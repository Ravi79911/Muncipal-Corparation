package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationElectricityDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ApplicationElectricityDetailsRepository extends JpaRepository<ApplicationElectricityDetails,Integer> {
    List<ApplicationElectricityDetails> findBySuspendedStatus(Integer status);

    List<ApplicationElectricityDetails> findByMunicipalId(int municipalId);
}
