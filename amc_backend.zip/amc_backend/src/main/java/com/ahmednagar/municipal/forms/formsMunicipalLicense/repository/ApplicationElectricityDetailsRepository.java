package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationElectricityDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@EnableJpaRepositories
public interface ApplicationElectricityDetailsRepository extends JpaRepository<ApplicationElectricityDetails,Long> {
    List<ApplicationElectricityDetails> findBySuspendedStatus(Integer status);

    List<ApplicationElectricityDetails> findByMunicipalId(int municipalId);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM tbl2_application_electricity_details WHERE application_master_id = :applicationMasterId", nativeQuery = true)
    void deleteApplicationElectricityDetailsByApplicationMasterId(@Param("applicationMasterId") Long ApplicationFromMaster);

}
