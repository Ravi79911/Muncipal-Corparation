package com.ahmednagar.municipal.forms.formsMunicipalLicense.controller;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseLabelStage;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.LicenseLabelStageService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/license/label/stage")
public class LicenseLabelStageController {
    @Autowired
    private LicenseLabelStageService licenseLabelStageService;

    @PostMapping("/create")
    public ResponseEntity<LicenseLabelStage> createLicenseLabelStage(@Valid @RequestBody LicenseLabelStage licenseLabelStage) {
        LicenseLabelStage createdLicenseLabelStage = licenseLabelStageService.saveLicenseLabelStage(licenseLabelStage);
        return ResponseEntity.status(201).body(createdLicenseLabelStage);
    }

}
