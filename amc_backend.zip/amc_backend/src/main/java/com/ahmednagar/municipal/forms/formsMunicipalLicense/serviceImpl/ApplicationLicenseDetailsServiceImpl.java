package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationLicenseDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationLicenseDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationLicenseDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationLicenseDetailsService;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.utils.LicenseNumberGenerator;
import com.ahmednagar.municipal.master.municipalLicence.model.TradeApplicationType;
import com.ahmednagar.municipal.master.municipalLicence.repository.TradeApplicationTypeRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ApplicationLicenseDetailsServiceImpl implements ApplicationLicenseDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(ApplicationLicenseDetailsServiceImpl.class);

    @Autowired
    ApplicationLicenseDetailsRepository applicationLicenseDetailsRepository;

    @Autowired
    TradeApplicationTypeRepository tradeApplicationTypeRepository;

    @Autowired
    private LicenseNumberGenerator licenseNumberGenerator;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ApplicationLicenseDetails saveApplicationLicenseDetails(ApplicationLicenseDetails applicationLicenseDetails, int createdBy) {
        // validate and set trade application type id
        TradeApplicationType tradeApplicationType = tradeApplicationTypeRepository.findById(
                        applicationLicenseDetails.getApplicationTypeId().getId())
                .orElseThrow(() -> new IllegalArgumentException("invalid trade application type id"));

        applicationLicenseDetails.setApplicationTypeId(tradeApplicationType);

        // normalize application type name for case-insensitive comparison
        String applicationTypeName = tradeApplicationType.getApplicationTypeName().trim().toLowerCase();

        // generate and set license number based on application type name
        String generatedLicenseNumber = switch (applicationTypeName) {
            case "new application" -> licenseNumberGenerator.generateNewLicenseNo(tradeApplicationType.getId());
            case "temporary application" ->
                    licenseNumberGenerator.generateTemporaryLicenseNo(tradeApplicationType.getId());
            case "renewal" -> licenseNumberGenerator.generateRenewLicenseNo(tradeApplicationType.getId());
            case "amendment" -> licenseNumberGenerator.generateAmendmentLicenseNo(tradeApplicationType.getId());
            case "surrender" -> licenseNumberGenerator.generateSurrenderLicenseNo(tradeApplicationType.getId());
            default -> {
                logger.error("Unknown Application Type Name: {}", applicationTypeName);
                throw new IllegalArgumentException("Unknown application type name: " + applicationTypeName);
            }
        };

        applicationLicenseDetails.setLicenseNo(generatedLicenseNumber);

        LocalDateTime currentDateTime = LocalDateTime.now();
        applicationLicenseDetails.setCreatedDate(currentDateTime);
        applicationLicenseDetails.setSuspendedStatus(
                applicationLicenseDetails.getSuspendedStatus() != null
                        ? applicationLicenseDetails.getSuspendedStatus()
                        : 0);
        applicationLicenseDetails.setCreatedBy(createdBy);

        return applicationLicenseDetailsRepository.saveAndFlush(applicationLicenseDetails);
    }


    @Override
    public ApplicationLicenseDetails findApplicationLicenseDetailsById(Long id) {
        Optional<ApplicationLicenseDetails> applicationLicenseDetails = applicationLicenseDetailsRepository.findById(id);
        return applicationLicenseDetails.orElse(null);

    }

    @Override
    public List<ApplicationLicenseDetailsDto> findAllApplicationLicenseDetailsByMunicipalId(Long municipalId) {
        List<ApplicationLicenseDetails> applicationLicenseDetails = applicationLicenseDetailsRepository.findByMunicipalId(municipalId);
        return applicationLicenseDetails.stream()
                .map(applicationLicenseDetail -> modelMapper.map(applicationLicenseDetail, ApplicationLicenseDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<ApplicationLicenseDetailsDto> findAllApplicationLicenseDetailsByLicenseNo(String LicenseNo) {
        Optional<ApplicationLicenseDetails> applicationLicenseDetails = applicationLicenseDetailsRepository.findByLicenseNo(LicenseNo);
        return applicationLicenseDetails.stream()
                .map(applicationLicenseDetails1 -> modelMapper.map(applicationLicenseDetails1, ApplicationLicenseDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public boolean isLicenseNoExists(String licenseNo) {
        return applicationLicenseDetailsRepository.findByLicenseNo(licenseNo).isPresent();
    }

    @Override
    public ApplicationLicenseDetails updateApplicationLicenseDetails(Long id, ApplicationLicenseDetails updatedApplicationLicenseDetails) {
        Optional<ApplicationLicenseDetails> applicationLicenseDetailsOptional = applicationLicenseDetailsRepository.findById(id);
        if (applicationLicenseDetailsOptional.isPresent()) {
            ApplicationLicenseDetails existingApplicationLicenseDetails = applicationLicenseDetailsOptional.get();
            existingApplicationLicenseDetails.setLicenseHolderName(updatedApplicationLicenseDetails.getLicenseHolderName());
            existingApplicationLicenseDetails.setLicenseType(updatedApplicationLicenseDetails.getLicenseType());
            existingApplicationLicenseDetails.setAgreementNo(updatedApplicationLicenseDetails.getAgreementNo());
            existingApplicationLicenseDetails.setRentAgreementDate(updatedApplicationLicenseDetails.getRentAgreementDate());
            existingApplicationLicenseDetails.setAgreementValidFrom(updatedApplicationLicenseDetails.getAgreementValidFrom());
            existingApplicationLicenseDetails.setAgreementValidUpto(updatedApplicationLicenseDetails.getAgreementValidUpto());

            return applicationLicenseDetailsRepository.saveAndFlush(existingApplicationLicenseDetails);
        } else {
            throw new RuntimeException("applicationLicenseDetails Details not found with id: " + id);
        }
    }
//    @Override
//    public ApplicationLicenseDetails updateApplicationLicenseDetails(Long id, ApplicationLicenseDetailsDto updatedApplicationLicenseDetails) {
//        return null;
//    }

//    @Override
//    public ApplicationLicenseDetails updateApplicationLicenseDetails(Long id, ApplicationLicenseDetailsDto updatedApplicationLicenseDetails) {
//        ApplicationLicenseDetails license = applicationLicenseDetailsRepository.findById(id)
//                .orElseThrow(() -> new RuntimeException("License not found with id: " + id));
//
//        // Map non-null values from DTO to entity
//        modelMapper.map(updatedApplicationLicenseDetails, license);
//
//        return applicationLicenseDetailsRepository.save(license);
//    }

    @Override
    public ApplicationLicenseDetails changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<ApplicationLicenseDetails> applicationLicenseDetailsOptional = applicationLicenseDetailsRepository.findById(id);
        if (applicationLicenseDetailsOptional.isPresent()) {
            ApplicationLicenseDetails applicationLicenseDetails = applicationLicenseDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            applicationLicenseDetails.setSuspendedStatus(status);      // 1 means suspended
            return applicationLicenseDetailsRepository.saveAndFlush(applicationLicenseDetails);
        }
        return null;
    }

    @Transactional
    @Override
    public void deleteApplicationLicenseDetailsByApplicationMasterId(Long applicationMasterId) {
        try{
            applicationLicenseDetailsRepository.deleteApplicationLicenseDetailsByApplicationMasterId(applicationMasterId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

//    @Override
//    public List<ApplicationLicenseDetailsDto> findAllApplicationLicenseDetails() {
//        List<ApplicationLicenseDetails> applicationLicenseDetails = applicationLicenseDetailsRepository.findAll();
//        return applicationLicenseDetails.stream()
//                .map(applicationLicenseDetails1 -> modelMapper.map(applicationLicenseDetails1, ApplicationLicenseDetailsDto.class))
//                .collect(Collectors.toList());
//    }

}