package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationLicenseDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationLicenseDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationLicenseDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationLicenseDetailsService;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.utils.LicenseNumberGenerator;
import com.ahmednagar.municipal.master.municipalLicence.model.TradeApplicationType;
import com.ahmednagar.municipal.master.municipalLicence.repository.TradeApplicationTypeRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ApplicationLicenseDetailsServiceImpl implements ApplicationLicenseDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(ApplicationLicenseDetailsServiceImpl.class);

    @Autowired
    ApplicationLicenseDetailsRepository applicationLicenseDetailsRepository;

    @Autowired
    TradeApplicationTypeRepository tradeApplicationTypeRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ApplicationLicenseDetails saveApplicationLicenseDetails(ApplicationLicenseDetails applicationLicenseDetails, int createdBy) {
        // validate and set trade application type id
        TradeApplicationType tradeApplicationType = tradeApplicationTypeRepository.findById(
                        applicationLicenseDetails.getApplicationTypeId().getId())
                .orElseThrow(() -> new IllegalArgumentException("invalid trade application type id"));

        applicationLicenseDetails.setApplicationTypeId(tradeApplicationType);

        // normalize application type name for case-insensitive comparison
        String applicationTypeName = tradeApplicationType.getApplicationTypeName().trim().toLowerCase();

        // generate and set license number based on application type name
        String generatedLicenseNumber = switch (applicationTypeName) {
            case "new application" -> LicenseNumberGenerator.generateNewLicenseNo(tradeApplicationType.getId());
            case "temporary application" -> LicenseNumberGenerator.generateTemporaryLicenseNo(tradeApplicationType.getId());
            case "renewal" -> LicenseNumberGenerator.generateRenewLicenseNo(tradeApplicationType.getId());
            case "amendment" -> LicenseNumberGenerator.generateAmendmentLicenseNo(tradeApplicationType.getId());
            case "surrender" -> LicenseNumberGenerator.generateSurrenderLicenseNo(tradeApplicationType.getId());
            default -> {
                logger.error("Unknown Application Type Name: {}", applicationTypeName);
                throw new IllegalArgumentException("Unknown application type name: " + applicationTypeName);
            }
        };

        applicationLicenseDetails.setLicenseNo(generatedLicenseNumber);

        LocalDateTime currentDateTime = LocalDateTime.now();
        applicationLicenseDetails.setCreatedDate(currentDateTime);
        applicationLicenseDetails.setSuspendedStatus(
                applicationLicenseDetails.getSuspendedStatus() != null
                        ? applicationLicenseDetails.getSuspendedStatus()
                        : 0);
        applicationLicenseDetails.setCreatedBy(createdBy);

        return applicationLicenseDetailsRepository.saveAndFlush(applicationLicenseDetails);
    }


    @Override
    public ApplicationLicenseDetails findApplicationLicenseDetailsById(Long id) {
        Optional<ApplicationLicenseDetails> applicationLicenseDetails = applicationLicenseDetailsRepository.findById(id);
        return applicationLicenseDetails.orElse(null);

    }

    @Override
    public List<ApplicationLicenseDetailsDto> findAllApplicationLicenseDetailsByMunicipalId(Long municipalId) {
        List<ApplicationLicenseDetails> applicationLicenseDetails = applicationLicenseDetailsRepository.findByMunicipalId(municipalId);
        return applicationLicenseDetails.stream()
                .map(applicationLicenseDetail -> modelMapper.map(applicationLicenseDetail, ApplicationLicenseDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<ApplicationLicenseDetailsDto> findAllApplicationLicenseDetailsByLicenseNo(String LicenseNo) {
        Optional<ApplicationLicenseDetails> applicationLicenseDetails = applicationLicenseDetailsRepository.findByLicenseNo(LicenseNo);
        return applicationLicenseDetails.stream()
                .map(applicationLicenseDetails1 -> modelMapper.map(applicationLicenseDetails1, ApplicationLicenseDetailsDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public ApplicationLicenseDetails updateApplicationLicenseDetails(Long id, ApplicationLicenseDetails updatedApplicationLicenseDetails, int updatedBy) {
        Optional<ApplicationLicenseDetails> applicationLicenseDetailsOptional = applicationLicenseDetailsRepository.findById(id);
        if (applicationLicenseDetailsOptional.isPresent()) {
            ApplicationLicenseDetails existingApplicationLicenseDetails = applicationLicenseDetailsOptional.get();
            existingApplicationLicenseDetails.setSuspendedStatus(updatedApplicationLicenseDetails.getSuspendedStatus());
            existingApplicationLicenseDetails.setMunicipalId(updatedApplicationLicenseDetails.getMunicipalId());

            return applicationLicenseDetailsRepository.saveAndFlush(existingApplicationLicenseDetails);
        } else {
            throw new RuntimeException("applicationLicenseDetails Details not found with id: " + id);
        }
    }

    @Override
    public ApplicationLicenseDetails changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<ApplicationLicenseDetails> applicationLicenseDetailsOptional = applicationLicenseDetailsRepository.findById(id);
        if (applicationLicenseDetailsOptional.isPresent()) {
            ApplicationLicenseDetails applicationLicenseDetails = applicationLicenseDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            applicationLicenseDetails.setSuspendedStatus(status);      // 1 means suspended
            return applicationLicenseDetailsRepository.saveAndFlush(applicationLicenseDetails);
        }
        return null;
    }

}