package com.ahmednagar.municipal.forms.formsMunicipalLicense.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb3_municipal_license_payment_details")
public class MunicipalLicensePaymentDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @NotNull(message = "Payment date is required")
    @Column(name = "payment_date", nullable = false)
    private LocalDateTime paymentDate;

    @NotNull(message = "Amount paid is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Amount paid must be greater than zero")
    @Column(name = "amount_paid", nullable = false, precision = 18, scale = 3)
    private BigDecimal amountPaid;

    @NotNull(message = "Amount due is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Amount due must be greater than zero")
    @Column(name = "amount_due", nullable = false, precision = 18, scale = 3)
    private BigDecimal amountDue;

    @NotEmpty(message = "Payment mode is required")
    @Column(name = "payment_mode", nullable = false, length = 50)
    private String paymentMode;

    @NotEmpty(message = "Transaction ID is required")
    @Column(name = "transaction_id", nullable = false, length = 150)
    private String transactionId;

    @NotEmpty(message = "Payment status is required")
    @Column(name = "status", nullable = false, length = 50)
    private String status;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "municipal_license_id", nullable = false, referencedColumnName = "id")
    private ApplicationLicenseDetails municipalLicenseId;

    @OneToMany(mappedBy = "municipalLicensePaymentId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<MunicipalLicenseTransactionDetails> municipalLicenseTransactionDetails;
}
