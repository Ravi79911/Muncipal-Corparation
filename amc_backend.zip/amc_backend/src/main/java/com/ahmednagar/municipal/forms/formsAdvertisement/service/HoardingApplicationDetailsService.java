package com.ahmednagar.municipal.forms.formsAdvertisement.service;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingApplicationDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingApplicationDetailsService {
    HoardingApplicationDetails saveHoardingApplicationDetails(HoardingApplicationDetails hoardingApplicationDetails);

    List<HoardingApplicationDetailsDto> findAllHoardingApplicationDetails();

    HoardingApplicationDetails findById(Long id);

    List<HoardingApplicationDetails> findAllByMunicipalId(int municipalId);

    HoardingApplicationDetails updateHoardingApplicationDetails(Long id, HoardingApplicationDetails updatedHoardingApplicationDetails, int updatedBy);

    HoardingApplicationDetails changeStatus(Long id, Integer status,  int updatedBy);
}
