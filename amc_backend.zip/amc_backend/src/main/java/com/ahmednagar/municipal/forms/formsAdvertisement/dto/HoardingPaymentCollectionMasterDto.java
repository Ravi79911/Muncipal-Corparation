package com.ahmednagar.municipal.forms.formsAdvertisement.dto;

import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingPaymentCollectionMasterDto {
    private Long id;
    private HoardingApplicationMaster hoardingApplicationMasterId;
    private String transactionNo;
    private String transactionTotalAmount;
    private String transactionPaidAmount;
    private LocalDateTime transactionDate;
    private LocalDateTime paymentDate;
    private String receiptNo;
    private LocalDateTime receiptDate;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
