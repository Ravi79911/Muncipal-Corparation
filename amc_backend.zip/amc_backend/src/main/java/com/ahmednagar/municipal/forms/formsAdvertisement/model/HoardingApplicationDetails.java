package com.ahmednagar.municipal.forms.formsAdvertisement.model;

import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeMasterSetup;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb2_hoarding_application_details")
public class HoardingApplicationDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name = "zone_no", nullable = false)
    @NotNull(message = "Zone number cannot be null")
    private Long zoneNo;

    @Column(name = "ward_no", nullable = false)
    @NotNull(message = "Ward number cannot be null")
    private Long wardNo;

    @Column(name = "hoarding_size", nullable = false)
    @NotNull(message = "Hoarding size cannot be null")
    private Long hoardingSize;

    @Column(name = "hoarding_full_site_address", nullable = false)
    @NotBlank(message = "Hoarding full site address cannot be blank")
    @Size(max = 150, message = "Hoarding full site address cannot exceed 150 characters")
    private String hoardingFullSiteAddress;

    @Column(name = "hoarding_rate_sqft", nullable = false)
    @NotNull(message = "Hoarding rate per sqft cannot be null")
    @DecimalMin(value = "0.000", inclusive = false, message = "Hoarding rate per sqft must be greater than 0")
    private BigDecimal hoardingRateSqft;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "hoarding_type_master_id", nullable = false, referencedColumnName = "id")
    private HoardingTypeMasterSetup hoardingTypeMasterId;

    @ManyToOne
    @JoinColumn(name = "hoarding_application_master_id", nullable = false, referencedColumnName = "id")
    private HoardingApplicationMaster hoardingApplicationMasterId;

}
