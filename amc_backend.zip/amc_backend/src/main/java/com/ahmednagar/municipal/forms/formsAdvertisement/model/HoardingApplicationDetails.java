package com.ahmednagar.municipal.forms.formsAdvertisement.model;

import com.ahmednagar.municipal.master.advertisement.model.*;
import com.ahmednagar.municipal.master.municipalLicence.model.ViewLicenceWardMaster;
import com.ahmednagar.municipal.master.municipalLicence.model.ViewLicenceZoneMaster;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tb2_hoarding_application_details")
public class HoardingApplicationDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "calculated_amount", nullable = false)
    private String calculatedAmount;

//    @Column(name = "zone_id", nullable = false)
//    @NotNull(message = "Zone id cannot be null")
//    private Long zoneId;
//
//    @Column(name = "ward_id", nullable = false)
//    @NotNull(message = "Ward id cannot be null")
//    private Long wardId;

    @NotNull
    @Column(name = "allocated_from_date")
    private LocalDate allocatedFromDate;

    @NotNull
    @Column(name = "allocated_upto_date")
    private LocalDate allocatedUptoDate;

    @Column(name = "calculated_period_days", nullable = false)
    private Long calculatedPeriodDays;

    @Column(name = "calculated_period_months", nullable = false)
    private Long calculatedPeriodMonths;

    @Column(name = "calculated_period_years", nullable = false)
    private Long calculatedPeriodYears;

    @Column(name = "hoarding_length_sqft")
    private BigDecimal hoardingLengthSqft;

    @Column(name = "hoarding_width_sqft")
    private BigDecimal hoardingWidthSqft;

    @Column(name = "hoarding_size", nullable = false)
    private BigDecimal hoardingSize;

    @Column(name = "hoarding_full_site_address", nullable = false)
    @NotBlank(message = "Hoarding full site address cannot be blank")
    @Size(max = 150, message = "Hoarding full site address cannot exceed 150 characters")
    private String hoardingFullSiteAddress;

    @Column(name = "hoarding_rate_sqft", nullable = false)
    private BigDecimal hoardingRateSqft;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "ward_id", referencedColumnName = "id", nullable = false)
    private ViewAdvertisementWardMaster wardId;

    @ManyToOne
    @JoinColumn(name = "zone_id", referencedColumnName = "id", nullable = false)
    private ViewAdvertisementZoneMaster zoneId;

    @OneToMany(mappedBy = "hoardingApplicationDetailsId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<HoardingAllottedDemand> hoardingAllottedDemands;

    @ManyToOne
    @JoinColumn(name = "hoarding_type_master_id", nullable = false, referencedColumnName = "id")
    private HoardingTypeMasterSetup hoardingTypeMasterId;

    @ManyToOne
    @JoinColumn(name = "hoarding_application_master_id", nullable = false, referencedColumnName = "id")
    private HoardingApplicationMaster hoardingApplicationMasterId;

    @ManyToOne
    @JoinColumn(name = "usage_type_id", nullable = false, referencedColumnName = "id")
    private DDAdvertisementUsageTypeMaster usageTypeId;

    @ManyToOne
    @JoinColumn(name = "hoarding_category_type_master_id", nullable = false, referencedColumnName = "id")
    private HoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterId;

    @ManyToOne
    @JoinColumn(name = "hoarding_type_size_master_id", referencedColumnName = "id")
    private HoardingTypeSizeMasterSetup hoardingTypeSizeMasterId;

    @ManyToOne
    @JoinColumn(name = "hoarding_type_rate_master_id", referencedColumnName = "id")
    private HoardingTypeRateMasterSetup hoardingTypeRateMasterId;

}
