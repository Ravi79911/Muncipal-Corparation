package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseApplicationAutoTransfer;
import org.springframework.stereotype.Service;

@Service
public interface LicenseApplicationAutoTransferService {
    LicenseApplicationAutoTransfer saveLicenseApplicationAutoTransfer(LicenseApplicationAutoTransfer licenseApplicationAutoTransfer);
}
