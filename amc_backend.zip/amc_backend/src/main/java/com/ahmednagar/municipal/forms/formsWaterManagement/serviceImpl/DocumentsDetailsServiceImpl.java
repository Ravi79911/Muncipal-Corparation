package com.ahmednagar.municipal.forms.formsWaterManagement.serviceImpl;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.DocumentDetails;
import com.ahmednagar.municipal.forms.formsWaterManagement.repository.DocumnetDetailsRepository;
import com.ahmednagar.municipal.forms.formsWaterManagement.repository.NewConnectionFormShubhamRepository;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.DocumentsDetailsServices;
import com.ahmednagar.municipal.master.waterManagement.modal.DocumentTypeMaster;
import com.ahmednagar.municipal.master.waterManagement.repository.DocumentTypeMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class DocumentsDetailsServiceImpl implements DocumentsDetailsServices {

    // Define the upload directory
//    private static final String UPLOAD_DIR = "D:\\muncipal_demo\\ahmednagar_muncipal\\src\\main\\resources\\waterDocumentUpload";

    @Value("${upload.water.doc.dir}")
    private String UPLOAD_DIR;

    // Define the file size limit (10 MB in bytes)
    private static final long MAX_FILE_SIZE = 2 * 1024 * 1024; // 2 MB

    @Autowired
    private DocumnetDetailsRepository documnetDetailsRepository;

    @Autowired
    private DocumentTypeMasterRepository documentTypeMasterRepository;

    @Autowired
    private NewConnectionFormShubhamRepository newConnectionFormShubhamRepository;

    @Override
    public DocumentDetails deleteDocumentDetailsById(Long id, int suspendedStatus, int updatedBy) {
        Optional<DocumentDetails> documentDetails = documnetDetailsRepository.findById(id);
        if (documentDetails.isPresent()) {
            DocumentDetails documentDetailsToBeDeleted = documentDetails.get();       //get the document details
            if (documentDetailsToBeDeleted.getSuspendedStatus() != suspendedStatus) {                  //check if the status of the document details is equal to the status to be deleted
                documentDetailsToBeDeleted.setSuspendedStatus(suspendedStatus);
//                   documentDetailsToBeDeleted.setUpdatedBy(updatedBy);                   //set the updated by
                return documnetDetailsRepository.saveAndFlush(documentDetailsToBeDeleted);                                                       //return null if the status is not equal to the status to be deleted
            }
        }
        return null;
    }

    @Override
    public List<DocumentDetails> getDocumentDetailsByMunicipalId(int municipalId) {
        if (municipalId != 0) {                                            //if the municipal id is not null
            return documnetDetailsRepository.findByMunicipalId(municipalId);    //return the document details by municipal id
        } else
            return null;
    }

    @Override
    public DocumentDetails createDocumentDetails(DocumentDetails documentDetails, int createdBy) {
        LocalDateTime currentDateTime = LocalDateTime.now();            // current date and time
        documentDetails.setSuspendedStatus(documentDetails.getSuspendedStatus());      // 0 means active
        documentDetails.setCreatedDate(currentDateTime);
//        documentDetails.setUpdatedDate(currentDateTime);
        documentDetails.setCreatedBy(createdBy);                       // 1 means admin
//        documentDetails.setUpdatedBy(createdBy);                       // 1 means admin
        return documnetDetailsRepository.saveAndFlush(documentDetails);
    }


    @Override
    public DocumentDetails uploadDocument(MultipartFile file, String documentNum, int status, int createdBy, int suspendedStatus, int municipalId, int newConnectionFormId, Long documentTypeId) throws Exception {

        try {
        // Validate file type
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        if (!fileName.endsWith(".pdf")) {
            throw new Exception("Only PDF files are allowed.");
        }

//        // Validate file size (10 MB max)
//        long maxFileSize = 10 * 1024 * 1024; // 10 MB
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new Exception("File size exceeds the maximum allowed size of 10 MB.");
        }

        // Get the folder name based on the document type
        String folderName = documentTypeMasterRepository.findById(documentTypeId)
                .map(DocumentTypeMaster::getDocumentTypeName)
                .orElseThrow(() -> new Exception("Invalid document type ID."));

        // Replace spaces in the folder name with underscores
        folderName = folderName.replaceAll("\\s+", "_");

        // Create the new file name using the modified folder name and the random number
        String newFileName = folderName + "_" + UUID.randomUUID() + ".pdf";


        // Generate the file path based on the document type
        Path uploadPath = Paths.get(UPLOAD_DIR + "/" + folderName);
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }


//            Path filePath = uploadPath.resolve(newFileName);
//            Files.copy(file.getInputStream(), filePath);

//        Path filePath = uploadPath.resolve(fileName);
//        try (InputStream inputStream = file.getInputStream()) {
//            // Compress and save the file
//            compressAndSavePDF(inputStream, filePath);

            // Prepare DocumentDetails object for saving
            DocumentDetails documentDetails = new DocumentDetails();
//            documentDetails.setFileNamePath(filePath.toString());
            documentDetails.setFileName(newFileName);
            documentDetails.setDocumentNum(documentNum);
            documentDetails.setDocumentTypeMasterId(documentTypeMasterRepository.findById(documentTypeId).orElseThrow());
            documentDetails.setNewConnectionFormId(newConnectionFormShubhamRepository.findById(newConnectionFormId).orElseThrow());
            documentDetails.setMunicipalId(municipalId);
            documentDetails.setSuspendedStatus(suspendedStatus);
            documentDetails.setCreatedDate(LocalDateTime.now());
//            documentDetails.setRemarks(remarks);
            documentDetails.setCreatedBy(createdBy);
            documentDetails.setStatus(status);
            Path filePath = uploadPath.resolve(newFileName);
            Files.copy(file.getInputStream(), filePath);
            documentDetails.setFileNamePath(filePath.toString());

            return documnetDetailsRepository.saveAndFlush(documentDetails);
        } catch (Exception e) {
            throw new Exception("Error uploading document: " + e.getMessage(), e);
        }
    }

    /**
     * Compresses the PDF file to reduce its size by up to 80% and saves it to the specified path.
     *
//     * @param inputStream the input stream of the original PDF file
//     * @param filePath the path where the compressed PDF file should be saved
//     * @throws IOException if an error occurs during file compression or saving
     */
//    private void compressAndSavePDF(InputStream inputStream, Path filePath) throws IOException {
//        // Create a PDF reader
//        PdfReader reader = new PdfReader(inputStream);
//        PdfWriter writer = new PdfWriter(Files.newOutputStream(filePath));
//
//        // Create a PDF document with compression level set to 80%
//        PdfDocument pdfDoc = new PdfDocument(reader, writer, new StampingProperties());
//        pdfDoc.setCompressionLevel(CompressionConstants.DEFAULT_COMPRESSION);
//
//        // Close documents
//        pdfDoc.close();
//        reader.close();
//        writer.close();
//    }

//        String folderName;
//        Optional<DocumentTypeMaster> checkedDocumentTypeMaster = documentTypeMasterRepository.findById(documentTypeId);
//        if (checkedDocumentTypeMaster.isEmpty()) {
//            throw new Exception("Invalid document type ID.");
//        } else {
//            DocumentTypeMaster selectedDocumentTypeMaster = checkedDocumentTypeMaster.get();    //get the document type master
//            folderName = selectedDocumentTypeMaster.getDocumentTypeName();
//        }

        // Generate the file path based on the document type
//        Path uploadPath = Paths.get(UPLOAD_DIR +"/" + folderName);
//        try {
//            if (!Files.exists(uploadPath)) {
//                Files.createDirectories(uploadPath);
//            }

//            Path filePath = uploadPath.resolve(fileName);
//            Files.copy(file.getInputStream(), filePath);
//
//            LocalDateTime currentDateTime = LocalDateTime.now();            // current date and time
//            DocumentDetails documentDetails = new DocumentDetails();
//            documentDetails.setFileNamePath(file.getOriginalFilename());
//            documentDetails.setFileNo(file.getOriginalFilename());
//            documentDetails.setDocumentTypeMasterId(documentTypeMasterRepository.findById(documentTypeId).orElseThrow());
//            documentDetails.setNewConnectionFormId(newConnectionFormShubhamRepository.findById(newConnectionFormId).orElseThrow());
//            documentDetails.setMunicipalId(municipalId);
//            documentDetails.setSuspendedStatus(suspendedStatus);
//            documentDetails.setCreatedDate(LocalDateTime.now());
//            documentDetails.setRemarks(remarks);
//            documentDetails.setCreatedBy(createdBy);
//            return documnetDetailsRepository.saveAndFlush(documentDetails);
//        } catch (Exception e) {
//            throw new Exception("Error uploading document: " + e.getMessage());
//        }

    @Override
    public Resource loadDocumentDetails(Long id) throws IOException {
        Optional<DocumentDetails> documentDetails = documnetDetailsRepository.findById(id);
        if (documentDetails.isPresent()) {
            return new FileSystemResource(Paths.get(documentDetails.get().getFileNamePath()));
        }
        return null;
    }
}
