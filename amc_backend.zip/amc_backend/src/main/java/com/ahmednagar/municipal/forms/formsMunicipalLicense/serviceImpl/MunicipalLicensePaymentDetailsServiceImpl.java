package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.MunicipalLicensePaymentDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.MunicipalLicensePaymentDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.MunicipalLicensePaymentDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.MunicipalLicensePaymentDetailsService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.springframework.data.jpa.domain.AbstractAuditable_.createdBy;

@Service
public class MunicipalLicensePaymentDetailsServiceImpl implements MunicipalLicensePaymentDetailsService {
    @Autowired
    private MunicipalLicensePaymentDetailsRepository municipalLicensePaymentDetailsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public MunicipalLicensePaymentDetails saveMunicipalLicensePaymentDetails(MunicipalLicensePaymentDetails municipalLicensePaymentDetails) {
        municipalLicensePaymentDetails.setCreatedDate(LocalDateTime.now());
        municipalLicensePaymentDetails.setUpdatedDate(LocalDateTime.now());
        municipalLicensePaymentDetails.setUpdatedBy(municipalLicensePaymentDetails.getUpdatedBy() != null ? municipalLicensePaymentDetails.getUpdatedBy() : 0);
        municipalLicensePaymentDetails.setSuspendedStatus(municipalLicensePaymentDetails.getSuspendedStatus() != null ? municipalLicensePaymentDetails.getSuspendedStatus() : 0);

        return municipalLicensePaymentDetailsRepository.save(municipalLicensePaymentDetails);

    }


    @Override
    public MunicipalLicensePaymentDetails findMunicipalLicensePaymentDetailsById(Long id) {
        Optional<MunicipalLicensePaymentDetails> municipalLicensePaymentDetails=municipalLicensePaymentDetailsRepository.findById(id);
        return municipalLicensePaymentDetails.orElse(null);

    }

    @Override
    public List<MunicipalLicensePaymentDetailsDto> findAllMunicipalLicensePaymentDetailsByMunicipalId(int municipalId) {
        List<MunicipalLicensePaymentDetails> municipalLicensePaymentDetails = municipalLicensePaymentDetailsRepository.findByMunicipalId(municipalId);
        return municipalLicensePaymentDetails.stream()
                .map(municipalLicensePaymentDetails1 -> modelMapper.map(municipalLicensePaymentDetails1, MunicipalLicensePaymentDetailsDto.class))
                .collect(Collectors.toList());
    }


    @Override
    public MunicipalLicensePaymentDetails updateMunicipalLicensePaymentDetails(Long id, MunicipalLicensePaymentDetails updatedMunicipalLicensePaymentDetails, int updatedBy) {
        Optional<MunicipalLicensePaymentDetails> municipalLicensePaymentDetailsOptional = municipalLicensePaymentDetailsRepository.findById(id);
        if (municipalLicensePaymentDetailsOptional.isPresent()) {
            MunicipalLicensePaymentDetails existingMunicipalLicensePaymentDetails = municipalLicensePaymentDetailsOptional.get();
            existingMunicipalLicensePaymentDetails.setSuspendedStatus(updatedMunicipalLicensePaymentDetails.getSuspendedStatus());
            existingMunicipalLicensePaymentDetails.setMunicipalId(updatedMunicipalLicensePaymentDetails.getMunicipalId());

            return municipalLicensePaymentDetailsRepository.saveAndFlush(existingMunicipalLicensePaymentDetails);
        } else {
            throw new RuntimeException("MunicipalLicensePaymentDetails Details not found with id: " + id);
        }
    }

    @Override
    public MunicipalLicensePaymentDetails changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<MunicipalLicensePaymentDetails> municipalLicensePaymentDetailsOptional = municipalLicensePaymentDetailsRepository.findById(id);
        if (municipalLicensePaymentDetailsOptional.isPresent()) {
            MunicipalLicensePaymentDetails municipalLicensePaymentDetails = municipalLicensePaymentDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            municipalLicensePaymentDetails.setSuspendedStatus(status);      // 1 means suspended
            return municipalLicensePaymentDetailsRepository.saveAndFlush(municipalLicensePaymentDetails);
        }
        return null;
    }

}
