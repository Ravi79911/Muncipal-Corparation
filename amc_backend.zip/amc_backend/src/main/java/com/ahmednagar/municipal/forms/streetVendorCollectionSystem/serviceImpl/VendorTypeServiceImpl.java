package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.serviceImpl;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorType;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.repository.VendorTypeRepository;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VendorTypeServiceImpl implements VendorTypeService {

    @Autowired
    private VendorTypeRepository vendorTypeRepository;

    @Override
    public VendorType saveVendorType(VendorType vendorType) {
        vendorType.setCreatedDate(LocalDateTime.now());
        vendorType.setSuspendedStatus(0);
        return vendorTypeRepository.saveAndFlush(vendorType);
    }

    @Override
    public Optional<VendorType> findVendorTypeById(Long id) {
        return vendorTypeRepository.findById(id);
    }

    @Override
    public Optional<VendorType> deleteVendorType(Long id) {
        Optional<VendorType> vendorType = vendorTypeRepository.findById(id);
        if(vendorType.isPresent()){
            vendorType.get().setSuspendedStatus(1);
            vendorTypeRepository.saveAndFlush(vendorType.get());
        }
        return vendorType;
    }

    @Override
    public List<VendorType> getAllVendorTypes() {
        return vendorTypeRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<VendorType> updateVendorType(Long id, VendorType vendorType) {
        Optional<VendorType> vendorType1 = vendorTypeRepository.findById(id);
        if(vendorType1.isPresent()){
            vendorType1.get().setVendorTypeName(vendorType.getVendorTypeName());
            vendorType1.get().setUpdatedDate(LocalDateTime.now());
            vendorType1.get().setUpdatedBy(vendorType.getUpdatedBy());
            vendorTypeRepository.saveAndFlush(vendorType1.get());
        }
        return vendorType1;
    }
}
