package com.ahmednagar.municipal.forms.formsMunicipalLicense.dto;

import com.ahmednagar.municipal.master.municipalLicence.dto.MlRateMasterDto;
import com.ahmednagar.municipal.master.municipalLicence.dto.TradeApplicationTypeDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class TemporaryLicensePaymentScheduleDetailsDto {

    private Long id;
    //private ApplicationLicenseDetailsDto municipalLicenseId;
    private MlRateMasterDto mlRateMasterId;
    private TradeApplicationTypeDto applicationTypeId;
    private LocalDate startDate;
    private LocalDate endDate;
    private int noOfDays;
    private BigDecimal amountPerDay;
    private BigDecimal totalAmountDue;
    //private String status;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;

}
