package com.ahmednagar.municipal.forms.formsWaterManagement.service;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ElectricityDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ElectricityDetailsServices {

    ElectricityDetails createElectricityDetails(ElectricityDetails electricityDetails, int createdBy);

//    ElectricityDetails updateElectricityDetails(int id,ElectricityDetails electricityDetails, int updatedBy);

    ElectricityDetails deleteElectricityDetails(int id, int status, int updatedBy);

    List<ElectricityDetails> getAllElectricityByMunicipalId(int municipalId);

//    ElectricityDetails getElectricityDetailsbyId(int id);

}
