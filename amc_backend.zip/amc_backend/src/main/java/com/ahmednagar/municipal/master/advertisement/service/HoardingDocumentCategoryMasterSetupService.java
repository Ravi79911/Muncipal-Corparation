package com.ahmednagar.municipal.master.advertisement.service;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingDocumentCategoryMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingDocumentCategoryMasterSetup;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingDocumentCategoryMasterSetupService {
    HoardingDocumentCategoryMasterSetup saveHoardingDocumentCategoryMasterSetup(HoardingDocumentCategoryMasterSetup hoardingDocumentCategoryMasterSetup);

    List<HoardingDocumentCategoryMasterSetupDto> findAllHoardingDocumentCategoryMasterSetup();

    HoardingDocumentCategoryMasterSetup findById(Long id);

    List<HoardingDocumentCategoryMasterSetup> findAllByMunicipalId(int municipalId);

    HoardingDocumentCategoryMasterSetup updateHoardingDocumentCategoryMasterSetup(Long id, HoardingDocumentCategoryMasterSetup updatedHoardingDocumentCategoryMasterSetup,int updatedBy);

    HoardingDocumentCategoryMasterSetup changeStatus(Long id, Integer status,int updatedBy);

}
