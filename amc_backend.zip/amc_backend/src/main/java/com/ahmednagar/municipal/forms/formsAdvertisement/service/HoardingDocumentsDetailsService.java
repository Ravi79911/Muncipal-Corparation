package com.ahmednagar.municipal.forms.formsAdvertisement.service;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingDocumentsDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingDocumentsDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public interface HoardingDocumentsDetailsService {
    HoardingDocumentsDetails saveHoardingDocumentsDetails(HoardingDocumentsDetails hoardingDocumentsDetails);

    List<HoardingDocumentsDetailsDto> findAllHoardingDocumentsDetails();

    HoardingDocumentsDetails findById(Long id);

    List<HoardingDocumentsDetails> findAllByMunicipalId(int municipalId);

    HoardingDocumentsDetails updateHoardingDocumentsDetails(Long id, HoardingDocumentsDetails updatedHoardingDocumentsDetails, int updatedBy);

    HoardingDocumentsDetails changeStatus(Long id, Integer status,  int updatedBy);

    HoardingDocumentsDetails uploadDocument(MultipartFile file, int createdBy, int suspendedStatus, int municipalId, Long hoardingApplicationMasterId, int hoardingDocumentsSubCategoryMasterId) throws Exception;

    HoardingDocumentsDetails updateHoardingDocumentsDetailsById(Long id, MultipartFile documentUrl);

    List<HoardingDocumentsDetails> getAllDetailsByHoardingMasterId(Long hoardingMasterId);
}
