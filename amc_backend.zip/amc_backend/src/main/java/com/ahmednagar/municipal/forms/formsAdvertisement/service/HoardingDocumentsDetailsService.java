package com.ahmednagar.municipal.forms.formsAdvertisement.service;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingDocumentsDetailsDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingDocumentsDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HoardingDocumentsDetailsService {
    HoardingDocumentsDetails saveHoardingDocumentsDetails(HoardingDocumentsDetails hoardingDocumentsDetails);

    List<HoardingDocumentsDetailsDto> findAllHoardingDocumentsDetails();

    HoardingDocumentsDetails findById(Long id);

    List<HoardingDocumentsDetails> findAllByMunicipalId(int municipalId);

    HoardingDocumentsDetails updateHoardingDocumentsDetails(Long id, HoardingDocumentsDetails updatedHoardingDocumentsDetails, int updatedBy);

    HoardingDocumentsDetails changeStatus(Long id, Integer status,  int updatedBy);
}
