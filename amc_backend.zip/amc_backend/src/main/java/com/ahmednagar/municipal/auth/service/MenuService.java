package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.MenuDto;
import com.ahmednagar.municipal.auth.model.Menu;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MenuService {
    Menu saveMenu(Menu menu);

    List<MenuDto> findAllMenu();

    List<MenuDto> findAllMenuByMunicipalId(Long municipalId);

    Menu updateMenu(Long id, Menu updatedMenu);

    Menu changeSuspendedStatus(Long id, int status);
}
