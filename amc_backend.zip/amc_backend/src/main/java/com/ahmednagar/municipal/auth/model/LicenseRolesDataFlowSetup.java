package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tb2_license_roles_data_flow_setup")
public class LicenseRolesDataFlowSetup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "current_role_id")
    private Long currentRoleId;

    @Column(name = "next_role_id")
    private Long nextRoleId;

    @Column(name = "status_code")
    private Long statusCode;

    @Column(name = "can_edit")
    private Integer canEdit;

    @Column(name = "is_active")
    private Integer isActive;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

}
