package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.ViewTradeApplicationTypeMasters;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface ViewTradeApplicationTypeMastersRepository extends JpaRepository<ViewTradeApplicationTypeMasters,Long> {
}
