package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.UserDetails;
import com.ahmednagar.municipal.auth.repository.UserDetailsRepository;
import com.ahmednagar.municipal.auth.service.UserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserDetailsRepository userDetailsRepository;

    @Override
    public UserDetails createUserDetails(UserDetails userDetails, int createdBy) {
        if (userDetails != null) {
            userDetails.setUpdatedBy(createdBy);
            userDetails.setCreatedBy(createdBy);
            userDetails.setCreatedDate(LocalDateTime.now());
            userDetails.setUpdatedDate(LocalDateTime.now());
            userDetails.setSuspendedStatus(userDetails.getSuspendedStatus() != null ? userDetails.getSuspendedStatus() : 0);
            userDetailsRepository.saveAndFlush(userDetails);
            return userDetails;
        }
        return null;
    }

    @Override
    public UserDetails updateUserDetails(Long id, UserDetails updatedUserDetails) {
        Optional<UserDetails> userDetailsChanges = userDetailsRepository.findById(id);
        if(userDetailsChanges.isPresent()){
            UserDetails userDetailsEntity = userDetailsChanges.get();
            userDetailsEntity.setUsermasId(updatedUserDetails.getUsermasId());
            userDetailsEntity.setZoneId(updatedUserDetails.getZoneId());
            userDetailsEntity.setWardId(updatedUserDetails.getWardId());
            userDetailsEntity.setUpdatedDate(LocalDateTime.now());
            userDetailsEntity.setUpdatedBy(userDetailsEntity.getUpdatedBy());
            userDetailsRepository.saveAndFlush(userDetailsEntity);
            return userDetailsEntity;
        }
        return null;
    }

    @Override
    public UserDetails changeSuspendedStatus(Long id, int status) {
        Optional<UserDetails> userDetailsStatusChanges = userDetailsRepository.findById(id);
        if(userDetailsStatusChanges.isPresent()){
            UserDetails userDetailsEntity = userDetailsStatusChanges.get();
            userDetailsEntity.setSuspendedStatus(status);
            userDetailsEntity.setUpdatedDate(LocalDateTime.now());
            userDetailsEntity.setUpdatedBy(userDetailsEntity.getUpdatedBy());
            userDetailsRepository.saveAndFlush(userDetailsEntity);
            return userDetailsEntity;
        }
        return null;
    }

    @Override
    public List<UserDetails> getUserDetailsByMunicipalId(Long municipalId) {
        return userDetailsRepository.findByMunicipalId(municipalId);
    }
}
