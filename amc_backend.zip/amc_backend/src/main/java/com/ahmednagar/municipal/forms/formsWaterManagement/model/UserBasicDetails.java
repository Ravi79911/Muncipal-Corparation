package com.ahmednagar.municipal.forms.formsWaterManagement.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbl3_consumer_basic_detail_master")
public class UserBasicDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long id;

    @NotNull(message = "Applicant Name is mandatory")
    @Size(max = 100, message = "Consumer name cannot exceed 100 characters")
    @Column(name = "applicant_name")
    private String applicantName;

    @NotBlank(message = "Consumer name is mandatory")
    @Size(max = 250, message = "Consumer name cannot exceed 250 characters")
    @Column(name = "consumer_name")
    private String consumerName;

    @NotBlank(message = "Father/Guardian name is mandatory")
    @Size(max = 250, message = "Father/Guardian name cannot exceed 250 characters")
    @Column(name = "father_gaurd_name")
    private String fatherGaurdName;

    @NotBlank(message = "Relation is mandatory")
    @Size(max = 50, message = "Relation cannot exceed 50 characters")
    @Column(name = "relation", nullable = false)
    private String relation;

    @NotBlank(message = "Gender is mandatory")
    @Size(max = 20, message = "Gender name cannot exceed 20 characters")
    @Column(name = "gender", nullable = false)
    private String gender;

    // Permanent Address Fields
//    @NotBlank(message = "Permanent address is mandatory")
    @Size(max = 500, message = "Permanent address cannot exceed 500 characters")
    @Column(name = "permanent_address", nullable = false)
    private String permanentAddress;

//    @NotBlank(message = "Permanent city is mandatory")
    @Size(max = 50, message = "Permanent city cannot exceed 50 characters")
    @Column(name = "permanent_city", nullable = false)
    private String permanentCity;

//    @NotBlank(message = "Permanent district is mandatory")
    @Size(max = 50, message = "Permanent district cannot exceed 50 characters")
    @Column(name = "permanent_district", nullable = false)
    private String permanentDistrict;

//    @NotBlank(message = "Permanent state is mandatory")
    @Size(max = 50, message = "Permanent state cannot exceed 50 characters")
    @Column(name = "permanent_state", nullable = false)
    private String permanentState;

    @Digits(integer = 6, fraction = 0, message = "Pincode must be a 6-digit number")
    @Column(name = "permanent_pincode", nullable = false)
    private long permanentPincode;

//    @NotBlank(message = "Permanent landmark is mandatory")
    @Size(max = 100, message = "Permanent landmark cannot exceed 100 characters")
    @Column(name = "permanent_landmark", nullable = false)
    private String permanentLandmark;

    // Correspondence Address Fields
    @Size(max = 500, message = "Correspondence address cannot exceed 500 characters")
    @Column(name = "correspondence_address", nullable = false)
    private String correspondenceAddress;

    @Size(max = 50, message = "Correspondence city cannot exceed 50 characters")
    @Column(name = "correspondence_city", nullable = false)
    private String correspondenceCity;

    @Size(max = 50, message = "Correspondence district cannot exceed 50 characters")
    @Column(name = "correspondence_district", nullable = false)
    private String correspondenceDistrict;

    @Size(max = 50, message = "Correspondence state cannot exceed 50 characters")
    @Column(name = "correspondence_state", nullable = false)
    private String correspondenceState;

    @Digits(integer = 6, fraction = 0, message = "Pincode must be a 6-digit number")
    @Column(name = "correspondence_pincode", nullable = false)
    private long correspondencePincode;

    @Size(max = 100, message = "Correspondence landmark cannot exceed 100 characters")
    @Column(name = "correspondence_landmark", nullable = false)
    private String correspondenceLandmark;

    @Size(max = 150, message = "Landline number cannot exceed 150 characters")
    @Pattern(regexp = "\\d+", message = "Landline number can only contain digits")
    @Column(name = "landline_no", nullable = false)
    private String landlineNo;

    @Size(max = 50, message = "Mobile number cannot exceed 50 characters")
    @Pattern(regexp = "^[0-9]*$", message = "Mobile number can only contain digits")
    @Column(name = "mobile_no", nullable = false)
    private String mobileNo;

    @Email(message = "Email should be valid")
    @Size(max = 150, message = "Email cannot exceed 150 characters")
    @Column(name = "email_id", nullable = false)
    private String emailId;

    @NotNull(message = "Status is mandatory")
    @Column(name = "status")
    private Integer status;

    @NotNull(message = "Created By is mandatory")
    @Column(name = "created_by")
    private long createdBy;

    @NotNull(message = "Created Date is mandatory")
    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @NotNull(message = "Suspended Status is mandatory")
    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is mandatory")
    @Column(name = "municipal_id")
    private long municipalId;

    @ManyToOne
    @JoinColumn(name = "app_mas_id", referencedColumnName = "id", nullable = false)
    private NewConnectionFormShubham newConnectionFormId;

}

//    @NotBlank(message = "Address is mandatory")
//    @Size(max = 500, message = "Address cannot exceed 500 characters")
//    @Column(name = "permanent_address")
//    private String permanentAddress;
//
//    @NotBlank(message = "City is mandatory")
//    @Size(max = 50, message = "City name cannot exceed 50 characters")
//    @Column(name = "city")
//    private String city;
//
//    @NotBlank(message = "State is mandatory")
//    @Size(max = 50, message = "State name cannot exceed 50 characters")
//    @Column(name = "state")
//    private String state;
//
//    @NotNull(message = "Pincode is mandatory")
//    @Column(name = "pincode")
//    private int pincode;
