package com.ahmednagar.municipal.auth.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserMasterDto {

    private Long id;
    private String nameOfUser;
    private String fatherName;
    private String address;
    private String mobile;
    private String email;
    private Long mobileNo;
    private LocalDate dateOfBirth;
    private String userPicture;
    private String userName;
    private String password;
    private boolean isEmailVerified;
    private boolean isMobileVerified;
    private boolean isVerified;
    private String emailOtp;
    private LocalDateTime emailOtpGeneratedDateTime;
    private String mobileOtp;
    private LocalDateTime mobileOtpGeneratedDateTime;
    private String token;
    private LocalDateTime tokenGeneratedDateTime;
    private int createdBy;
    private LocalDateTime createdDate;
    private Integer updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
    private Long roleMasId;

}
