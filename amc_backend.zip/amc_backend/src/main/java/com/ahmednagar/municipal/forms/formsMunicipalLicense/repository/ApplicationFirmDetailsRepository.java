package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationFirmDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ApplicationFirmDetailsRepository extends JpaRepository<ApplicationFirmDetails, Long> {

    List<ApplicationFirmDetails> findBySuspendedStatus(Integer status);

    List<ApplicationFirmDetails> findByMunicipalId(int municipalId);

}
