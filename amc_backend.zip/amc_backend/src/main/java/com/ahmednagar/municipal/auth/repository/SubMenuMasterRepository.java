package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.SubMenuMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface SubMenuMasterRepository extends JpaRepository<SubMenuMaster, Long> {

    List<SubMenuMaster> findByMunicipalId(Long municipalId);

}
