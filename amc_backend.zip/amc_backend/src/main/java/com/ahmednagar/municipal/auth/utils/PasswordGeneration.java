package com.ahmednagar.municipal.auth.utils;

import java.util.Random;

public class PasswordGeneration {

    public static String generateRandomPassword() {
        String lowerCase = "abcdefghijklmnopqrstuvwxyz";
        String upperCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String digits = "0123456789";
        String specialChars = "@#$";

        StringBuilder password = new StringBuilder();
        Random random = new Random();

        // ensure that the password contains at least one character from each category
        password.append(lowerCase.charAt(random.nextInt(lowerCase.length())));
        password.append(upperCase.charAt(random.nextInt(upperCase.length())));
        password.append(digits.charAt(random.nextInt(digits.length())));
        password.append(specialChars.charAt(random.nextInt(specialChars.length())));

        // ensure the password is at least 8 characters
        String allChars = lowerCase + upperCase + digits + specialChars;
        for (int i = password.length(); i < 8; i++) {
            password.append(allChars.charAt(random.nextInt(allChars.length())));
        }

        return password.toString();
    }

}
