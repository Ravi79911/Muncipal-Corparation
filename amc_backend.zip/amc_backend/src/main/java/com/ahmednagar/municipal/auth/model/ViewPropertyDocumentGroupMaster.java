package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name = "tbl_view_property_document_group_master")
public class ViewPropertyDocumentGroupMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotNull(message = "document group name is required")
    @Size(max = 50, message = "document group name should not exceed 50 characters")
    @Column(name = "document_group_name", nullable = false, length = 50)
    private String documentGroupName;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by", nullable = false)
    private Integer createdBy;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

//    @OneToMany(mappedBy = "viewPropertyDocumentGroupMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
//    @JsonManagedReference
//    private List<ViewPropertyUploadDocumentMaster> viewPropertyUploadDocumentMasters = null;


    @OneToMany(mappedBy = "viewPropertyDocumentGroupMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private Set<ViewPropertyUploadDocumentMaster> viewPropertyUploadDocumentMasters;

//    @OneToMany(mappedBy = "propertyDocumentGroupMaster", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    private Set<PropertyUploadDocumentMaster> propertyUploadDocumentMasters;

}
