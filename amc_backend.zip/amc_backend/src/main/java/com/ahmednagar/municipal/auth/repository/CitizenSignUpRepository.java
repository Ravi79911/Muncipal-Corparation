package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.CitizenSignUpMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CitizenSignUpRepository extends JpaRepository<CitizenSignUpMaster, Long> {

    boolean existsByEmail(String email);

    boolean existsByMobileNo(String mobileNo);

    boolean existsByUserName(String userName);

    Optional<CitizenSignUpMaster> findByEmail(String email);

    Optional<CitizenSignUpMaster> findByMobileNo(String mobileNo);

    Optional<CitizenSignUpMaster> findByToken(String token);

//    Optional<CitizenSignUpMaster> findByMobileNo(String mobileNo);
//
//    // optionally, if you want to fetch by both email and mobile (just in case)
//    Optional<CitizenSignUpMaster> findByEmailOrMobileNo(String email, String mobileNo);

}
