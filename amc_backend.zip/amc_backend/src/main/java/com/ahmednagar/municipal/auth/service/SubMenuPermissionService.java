package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.SubMenuPermissionDto;
import com.ahmednagar.municipal.auth.model.SubMenuPermission;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface SubMenuPermissionService {
    SubMenuPermission saveSubMenuPermission(SubMenuPermission subMenuPermission);

    List<SubMenuPermissionDto> findAllSubMenuPermission();

    List<SubMenuPermissionDto> findAllSubMenuPermissionByMunicipalId(Long municipalId);

    SubMenuPermission updateSubMenuPermission(Long id, SubMenuPermission updatedSubMenuPermission);

    SubMenuPermission changeSuspendedStatus(Long id, int status);
}
