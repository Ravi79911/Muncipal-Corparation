package com.ahmednagar.municipal.forms.formsPropertyTax.serviceImpl;

import com.ahmednagar.municipal.forms.formsPropertyTax.dto.PropertyCalculationDetailsEduCessDto;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyCalculationDetailsEduCess;
import com.ahmednagar.municipal.forms.formsPropertyTax.repository.PropertyCalculationDetailsEduCessRepository;
import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyCalculationDetailsEduCessService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PropertyCalculationDetailsEduCessServiceImpl implements PropertyCalculationDetailsEduCessService {

    @Autowired
    PropertyCalculationDetailsEduCessRepository propertyCalculationDetailsEducessRepository;

    @Autowired
    ModelMapper modelMapper;

    @Override
    public PropertyCalculationDetailsEduCess createPropertyCalculationDetailsEduCess(PropertyCalculationDetailsEduCess propertyCalculationDetailsEducess) {
        if (propertyCalculationDetailsEducess.getSuspendedStatus() == null) {
            propertyCalculationDetailsEducess.setSuspendedStatus(0);
        }
        propertyCalculationDetailsEducess.setCreatedDate(LocalDateTime.now());
        return propertyCalculationDetailsEducessRepository.saveAndFlush(propertyCalculationDetailsEducess);
    }

    @Override
    public PropertyCalculationDetailsEduCess findPropertyCalculationDetailsEduCessById(Long id) {
        Optional<PropertyCalculationDetailsEduCess> propertyCalculationDetailsEduCess = propertyCalculationDetailsEducessRepository.findById(id);
        return propertyCalculationDetailsEduCess.orElse(null);

    }

    @Override
    public List<PropertyCalculationDetailsEduCessDto> findAllPropertyCalculationDetailsEduCessByMunicipalId(int municipalId) {
        List<PropertyCalculationDetailsEduCess> propertyCalculationDetailsEduCess = propertyCalculationDetailsEducessRepository.findByMunicipalId(municipalId);
        return propertyCalculationDetailsEduCess.stream()
                .map(propertyCalculationDetailsEduCesse -> modelMapper.map(propertyCalculationDetailsEduCesse, PropertyCalculationDetailsEduCessDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public PropertyCalculationDetailsEduCess updatePropertyCalculationDetailsEduCess(Long id, PropertyCalculationDetailsEduCess updatedPropertyCalculationDetailsEduCess, int updatedBy) {
        Optional<PropertyCalculationDetailsEduCess> propertyCalculationDetailsEducessOptional = propertyCalculationDetailsEducessRepository.findById(id);
        if (propertyCalculationDetailsEducessOptional.isPresent()) {
            PropertyCalculationDetailsEduCess existingPropertyCalculationDetailsEduCess = propertyCalculationDetailsEducessOptional.get();
            existingPropertyCalculationDetailsEduCess.setSuspendedStatus(updatedPropertyCalculationDetailsEduCess.getSuspendedStatus());
            existingPropertyCalculationDetailsEduCess.setMunicipalId(updatedPropertyCalculationDetailsEduCess.getMunicipalId());

            return propertyCalculationDetailsEducessRepository.saveAndFlush(existingPropertyCalculationDetailsEduCess);
        } else {
            throw new RuntimeException("property calculation details edu cess details not found with id: " + id);
        }
    }

    @Override
    public PropertyCalculationDetailsEduCess changeSuspendedStatus(Long id, int status, int updatedBy) {
        Optional<PropertyCalculationDetailsEduCess> propertyCalculationDetailsEducessOptional = propertyCalculationDetailsEducessRepository.findById(id);
        if (propertyCalculationDetailsEducessOptional.isPresent()) {
            PropertyCalculationDetailsEduCess propertyCalculationDetailsEducess = propertyCalculationDetailsEducessOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            propertyCalculationDetailsEducess.setSuspendedStatus(status);
            return propertyCalculationDetailsEducessRepository.saveAndFlush(propertyCalculationDetailsEducess);
        }
        return null;
    }

}
