//package com.ahmednagar.municipal.forms.formsPropertyTax.controller;
//
//import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyAdditionalMaster;
//import com.ahmednagar.municipal.forms.formsPropertyTax.service.PropertyAdditionalMasterService;
//import jakarta.validation.Valid;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//import java.util.Optional;
//
//@RestController
//@CrossOrigin
//@RequestMapping("/forms")
//public class PropertyAdditionalMasterController {
//
//    @Autowired
//    PropertyAdditionalMasterService propertyAdditionalMasterService;
//
//    @RequestMapping("/createPropertyAdditionalMaster")
//    public ResponseEntity<PropertyAdditionalMaster> createPropertyAdditionalMaster(@Valid @RequestBody PropertyAdditionalMaster propertyAdditionalMaster) {
//        PropertyAdditionalMaster newPropertyAdditionalMaster = propertyAdditionalMasterService.createPropertyAdditionalMaster(propertyAdditionalMaster);
//        return ResponseEntity.ok(newPropertyAdditionalMaster);
//    }
//
//    @GetMapping("/getAllPropertyAdditionalMaster")
//    public ResponseEntity<List<PropertyAdditionalMaster>> getAllPropertyAdditional() {
//        return ResponseEntity.ok(propertyAdditionalMasterService.getAllPropertyAdditionalMaster());
//    }
//
//    @GetMapping("propertyAdditionalMaster/{id}")
//    public ResponseEntity<Object> getPropertyAdditionalById(@PathVariable Long id) {
//        Optional<PropertyAdditionalMaster> propertyAdditionalMaster = propertyAdditionalMasterService.getPropertyAdditionalMasterById(id);
//        if (propertyAdditionalMaster.isPresent()) {
//            return ResponseEntity.ok(propertyAdditionalMaster.get());
//        } else {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
//        }
//    }
//
//    @GetMapping("/getPropertyAdditionalMasterByMunicipalId/{municipalId}")
//    public List<PropertyAdditionalMaster> getPropertyAdditionalByMunicipalId(@PathVariable int municipalId) {
//        return propertyAdditionalMasterService.getPropertyAdditionalMasterByMunicipalId(municipalId);
//    }
//
//    @PatchMapping("/propertyAdditionalMaster/suspendedStatus/{id}")
//    public ResponseEntity<PropertyAdditionalMaster> patchPropertyAdditionalSuspendedStatus(@PathVariable Long id, @RequestParam int suspendedStatus) {
//        PropertyAdditionalMaster patchedPropertyAdditionalMaster = propertyAdditionalMasterService.patchPropertyAdditionalMasterSuspendedStatus(id, suspendedStatus);
//        return ResponseEntity.ok(patchedPropertyAdditionalMaster);
//    }
//}
