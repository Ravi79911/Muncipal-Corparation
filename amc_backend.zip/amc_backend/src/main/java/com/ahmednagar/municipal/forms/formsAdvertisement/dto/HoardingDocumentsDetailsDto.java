package com.ahmednagar.municipal.forms.formsAdvertisement.dto;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingDocumentSubCategoryMasterSetupDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingDocumentsDetailsDto {
    private Long id;
    private HoardingDocumentSubCategoryMasterSetupDto hoardingDocumentsSubCategoryMasterId;
    private Long hoardingApplicationMasterId;
    private String documentFileName;
    private String documentUrl;
    private Integer createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
    private Float approvedStatus;
}
