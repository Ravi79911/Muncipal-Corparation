package com.ahmednagar.municipal.forms.formsAdvertisement.dto;

import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingDocumentsDetailsDto {
    private Long id;
    private HoardingApplicationMaster hoardingDocumentsTypeMasterId;
    private Long hoardingApplicationMasterId;
    private String documentUrl;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
