package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationDocumentsDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ApplicationDocumentsDetailsRepository extends JpaRepository<ApplicationDocumentsDetails,Integer> {
    List<ApplicationDocumentsDetails> findBySuspendedStatus(Integer status);

    List<ApplicationDocumentsDetails> findByMunicipalId(int municipalId);
}
