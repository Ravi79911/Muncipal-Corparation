package com.ahmednagar.municipal.auth.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Builder
@Table(name = "tbl_new_property_work_flow_level")
public class NewPropertyWorkFlowLevel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "zone_id", nullable = false)
    private Long zoneId;

    @Column(name = "ward_id", nullable = false)
    private Long wardId;

    @Column(name = "status")
    private String status;

    @Column(name = "status_code")
    private Long statusCode;

    @Column(name = "mail_status")
    private Integer mailStatus;

    @Column(name = "remarks", nullable = false)
    private String remarks;

    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "municipal_id", nullable = false)
    private Long municipalId;

    @Transient
    private List<Long> rejectedDocumentIds;

    @ManyToOne
    @JoinColumn(name = "application_id", referencedColumnName = "id", nullable = false)
    private ViewMunicipalPropertyMaster applicationId;

    @ManyToOne
    @JoinColumn(name = "current_role_id", referencedColumnName = "id")
    private RoleMaster currentRoleId;

    @ManyToOne
    @JoinColumn(name = "current_user_id", referencedColumnName = "id")
    private UserMaster currentUserId;

    @ManyToOne
    @JoinColumn(name = "next_user_id", referencedColumnName = "id")
    private UserMaster nextUserId;

    @ManyToOne
    @JoinColumn(name = "next_role_id", referencedColumnName = "id")
    private RoleMaster nextRoleId;

    @ManyToOne
    @JoinColumn(name = "work_flow_master_id", nullable = false, referencedColumnName = "id")
    private WorkFlowMaster workFlowMasterId;

    @ManyToOne
    @JoinColumn(name = "citizen_id", referencedColumnName = "id")
    private CitizenSignUpMaster citizenId;

}
