package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.AppApplicantDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface AppApplicantDetailsRepository extends JpaRepository<AppApplicantDetails, Long> {

    List<AppApplicantDetails> findByMunicipalId(int municipalId);

    List<AppApplicantDetails> findBySuspendedStatus(Integer status);

}
