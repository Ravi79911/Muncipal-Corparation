package com.ahmednagar.municipal.forms.formsMunicipalLicense.repository;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.AppApplicantDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@EnableJpaRepositories
public interface AppApplicantDetailsRepository extends JpaRepository<AppApplicantDetails, Long> {

    List<AppApplicantDetails> findByMunicipalId(int municipalId);

    List<AppApplicantDetails> findBySuspendedStatus(Integer status);

    //String findApplicationNoByMunicipalPropertyMasterId(Long expectedApplicantMasterId);

    @Query("SELECT mpm.applicationNo FROM ApplicationFromMaster mpm WHERE mpm.id = :applicationMasterId")
    String findApplicationNoByApplicationMasterId(@Param("applicationMasterId") Long applicationMasterId);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM tbl2_app_applicant_details WHERE application_master_id = :applicationMasterId", nativeQuery = true)
    void deleteAppApplicantDetailsByApplicationMasterId(@Param("applicationMasterId") Long ApplicationFromMaster);
    //void deleteAppApplicantDetailsByApplicationMasterId(Long applicationMasterId);

    //void deleteByApplicationMasterId(Long applicationMasterId);
}
