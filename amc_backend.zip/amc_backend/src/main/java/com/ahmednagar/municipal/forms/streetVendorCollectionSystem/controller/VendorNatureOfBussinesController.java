package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.controller;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorNatureOfBussines;
import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service.VendorNatureOfBussinesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/streetVendorCollectionSystem")
public class VendorNatureOfBussinesController {

    @Autowired
    private VendorNatureOfBussinesService vendorNatureOfBussinesService;

    @PostMapping("/saveVendorNatureOfBussines")
    public ResponseEntity<VendorNatureOfBussines> saveVendorNatureOfBussines(@RequestBody VendorNatureOfBussines vendorNatureOfBussines) {
        return ResponseEntity.ok(vendorNatureOfBussinesService.saveVendorNatureOfBussines(vendorNatureOfBussines));
    }

    @GetMapping("/getVendorNatureOfBussinesById/{id}")
    public ResponseEntity<Optional<VendorNatureOfBussines>> getVendorNatureOfBussinesById(@PathVariable Long id) {
        return ResponseEntity.ok(vendorNatureOfBussinesService.getVendorNatureOfBussinesById(id));
    }

    @PutMapping("/updateVendorNatureOfBussines/{id}")
    public ResponseEntity<Optional<VendorNatureOfBussines>> updateVendorNatureOfBussines(@PathVariable Long id, @RequestBody VendorNatureOfBussines vendorNatureOfBussines) {
        return ResponseEntity.ok(vendorNatureOfBussinesService.updateVendorNatureOfBussines(id, vendorNatureOfBussines));
    }

    @GetMapping("/getAllVendorNatureOfBussines")
    public ResponseEntity<Iterable<VendorNatureOfBussines>> getAllVendorNatureOfBussines() {
        return ResponseEntity.ok(vendorNatureOfBussinesService.getAllVendorNatureOfBussines());
    }

    @PatchMapping("/deleteVendorNatureOfBussines/{id}")
    public ResponseEntity<Optional<VendorNatureOfBussines>> deleteVendorNatureOfBussines(@PathVariable Long id) {
       return ResponseEntity.ok(vendorNatureOfBussinesService.deleteVendorNatureOfBussines(id));
    }
}
