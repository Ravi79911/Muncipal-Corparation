package com.ahmednagar.municipal.forms.formsMunicipalLicense.service;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.LicenseApplicationWorkflow;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public interface LicenseApplicationWorkflowService {
   LicenseApplicationWorkflow createWorkflow(LicenseApplicationWorkflow licenseApplicationWorkflow);

    LicenseApplicationWorkflow processDocumentApproval(Long workflowId, boolean isApproved, String actionBy, String comment);
//
//    LicenseApplicationWorkflow updateWorkflowStatus(Long id, String status, String updatedBy);
//
//    LicenseApplicationWorkflow processDocumentRejection(Long id, String updatedBy);
//
//    LicenseApplicationWorkflow processDocumentApproval(Long id, String updatedBy);
//
//    Optional<LicenseApplicationWorkflow> getWorkflowById(Long id);
}
