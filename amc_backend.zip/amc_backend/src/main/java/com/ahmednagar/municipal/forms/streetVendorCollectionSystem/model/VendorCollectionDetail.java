package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "Tbl_collection_detail")
public class VendorCollectionDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "collection_amount")
    private Double collectionAmount;

    @Column(name = "transaction_no")
    private String transactionNo;

    @Column(name = "transaction_date")
    private LocalDateTime transactionDate;

    @Column(name = "transaction_mode")
    private String transactionMode;

    @Column(name = "from_date")
    private LocalDate fromDate;

    @Column(name = "to_date")
    private LocalDate toDate;

    @Column(name = "municipal_id")
    private Long municipalId;

    @Column(name = "receipt_no")
    private String reciptNo;

    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "collection_master_id", referencedColumnName = "id", nullable = false)
    private VendorCollectionMaster vendorCollectionMasterId;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false)
    private VendorUser vendorUserId;

    @ManyToOne
    @JoinColumn(name = "userWardAllotment_id", referencedColumnName = "id", nullable = false)
    private VendorUserWardAllotment vendorUserWardAllotmentId;
}
