package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.ModulesPermissionDetailsDto;
import com.ahmednagar.municipal.auth.model.ModulesPermissionDetails;
import com.ahmednagar.municipal.auth.service.ModulesPermissionDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class ModulesPermissionDetailsController {
    @Autowired
    private ModulesPermissionDetailsService modulesPermissionDetailsService;
    //for created new user
    @PostMapping("/create/ModulesPermissionDetails")
    public ResponseEntity<ModulesPermissionDetails> createModulesPermissionDetails(@Valid @RequestBody ModulesPermissionDetails modulesPermissionDetails){
        ModulesPermissionDetails createdModulesPermissionDetails=modulesPermissionDetailsService.saveModulesPermissionDetailsService(modulesPermissionDetails);
        if(createdModulesPermissionDetails==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdModulesPermissionDetails);

    }
    //for all user
    @GetMapping("/all/ModulesPermissionDetails")
    public ResponseEntity<List<ModulesPermissionDetailsDto>> getAllModulesPermissionDetails(){
        List<ModulesPermissionDetailsDto> modulesPermissionDetails=modulesPermissionDetailsService.findAllModulesPermissionDetails();
        return ResponseEntity.ok(modulesPermissionDetails);
    }
    //get menu By MunicipalId
    @GetMapping("/MunicipalModulesPermissionDetails/{municipalId}")
    public ResponseEntity<?> getAllModulesPermissionDetailsByMunicipalId(@PathVariable Long municipalId){
        List<ModulesPermissionDetailsDto> modulesPermissionDetails=modulesPermissionDetailsService.findAllModulesPermissionDetailsByMunicipalId(municipalId);
        if (modulesPermissionDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No ModulesPermissionDetails found with municipal id: " + municipalId);
        }
        return ResponseEntity.ok(modulesPermissionDetails);
    }
    //     Update menu for admin
    @PutMapping("/updatedModulesPermissionDetails/{id}")
    public ResponseEntity<ModulesPermissionDetails> updateModulesPermissionDetails(@PathVariable("id") Long id, @RequestBody ModulesPermissionDetails updatedModulesPermissionDetails){
        try{
            ModulesPermissionDetails updated=modulesPermissionDetailsService.updateModulesPermissionDetails(id,updatedModulesPermissionDetails);
            return ResponseEntity.ok(updated);
        }catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }

    }

    //delete fileUrl for admin
    @PatchMapping("/deleteModulesPermissionDetails/{id}")
    public ResponseEntity<ModulesPermissionDetails> changeSuspendedStatus(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") int status) {
        ModulesPermissionDetails updatedModulesPermissionDetails = modulesPermissionDetailsService.changeSuspendedStatus(id, status);         // updatedBy is always 1 for now as it is the admin
        if (updatedModulesPermissionDetails== null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(updatedModulesPermissionDetails);
    }

}

