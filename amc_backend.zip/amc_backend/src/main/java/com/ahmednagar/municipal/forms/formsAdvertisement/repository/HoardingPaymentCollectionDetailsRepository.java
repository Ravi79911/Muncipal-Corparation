package com.ahmednagar.municipal.forms.formsAdvertisement.repository;

import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingPaymentCollectionDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface HoardingPaymentCollectionDetailsRepository extends JpaRepository<HoardingPaymentCollectionDetails,Long> {
    List<HoardingPaymentCollectionDetails> findAllByMunicipalId(int municipalId);
}
