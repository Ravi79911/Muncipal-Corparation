package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationDocumentsDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationDocumentsDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationFromMasterRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationDocumentsDetailsService;
import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyDocumentUploadDetails;
import com.ahmednagar.municipal.master.municipalLicence.model.MlDocumentsMaster;
import com.ahmednagar.municipal.master.municipalLicence.repository.MlDocumentsMasterRepository;
import com.ahmednagar.municipal.master.propertyTax.model.PropertyUploadDocumentMaster;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ApplicationDocumentsDetailsServiceImpl implements ApplicationDocumentsDetailsService {

    //    private static final String UPLOAD_DIR = "D:\\muncipal_demo\\ahmednagar_muncipal\\src\\main\\resources\\licenseUpload";
    private static final long MAX_FILE_SIZE = 2 * 1024 * 1024;

    @Value("${upload.license.doc.dir}")
    private String UPLOAD_DIR;

    @Autowired
    private ApplicationDocumentsDetailsRepository applicationDocumentsDetailsRepository;

    @Autowired
    private MlDocumentsMasterRepository mlDocumentsMasterRepository;

    @Autowired
    private ApplicationFromMasterRepository applicationFromMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ApplicationDocumentsDetails saveApplicationDocumentsDetails(ApplicationDocumentsDetails applicationDocumentsDetails) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        applicationDocumentsDetails.setCreatedDate(currentDateTime);
        applicationDocumentsDetails.setSuspendedStatus(applicationDocumentsDetails.getSuspendedStatus() != null ? applicationDocumentsDetails.getSuspendedStatus() : 0);      // 0 means active
        return applicationDocumentsDetailsRepository.saveAndFlush(applicationDocumentsDetails);
    }

    @Override
    public List<String> getAllURLsApplicationFromMasterById(Long applicationMasterId) {
        List<ApplicationDocumentsDetails> documents = applicationDocumentsDetailsRepository.findByApplicationMasterId(applicationMasterId);

        if (documents.isEmpty()) {
            throw new RuntimeException("no documents found for application master id: " + applicationMasterId);
        }

        return documents.stream()
                .map(ApplicationDocumentsDetails::getDocumentPath)
                .collect(Collectors.toList());
    }

    @Override
    public ApplicationDocumentsDetails uploadDocument(MultipartFile file, int createdBy, int suspendedStatus, int municipalId, Long applicationMasterId, int documentsMasterId) throws Exception {
        // validate file type
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        if (!fileName.endsWith(".pdf")) {
            throw new Exception("only pdf files are allowed");
        }
        System.out.println("fileName: " + fileName);

        if (file.getSize() > MAX_FILE_SIZE) {
            throw new Exception("file size exceeds the maximum allowed size of 2 MB");
        }

        // get the folder name based on the document type
        String folderName = mlDocumentsMasterRepository.findById((long) documentsMasterId)
                .map(MlDocumentsMaster::getDocumentName)
                .orElseThrow(() -> new Exception("invalid document type id"));

        System.out.println("folderName: " + folderName);

        // replace spaces in the folder name with underscores
        folderName = folderName.replaceAll("\\s+", "_");

        // create the new file name using the modified folder name and the random number
        String newFileName = folderName + "_" + UUID.randomUUID() + ".pdf";

        // generate the file path based on the document type
        Path uploadPath = Paths.get(UPLOAD_DIR + "/" + folderName);

        System.out.println("uploadPath: " + uploadPath);

        try {
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            Path filePath = uploadPath.resolve(newFileName);
            Files.copy(file.getInputStream(), filePath);

            // prepare the relative URL for the uploaded file
            String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/licenseDocumentUpload/")
                    .path(folderName + "/" + newFileName)
                    .toUriString();

            // prepare document details object for saving
            ApplicationDocumentsDetails applicationDocumentsDetails = new ApplicationDocumentsDetails();
            applicationDocumentsDetails.setDocumentPath(fileUrl);
            applicationDocumentsDetails.setDocumentFileName(newFileName);
            applicationDocumentsDetails.setApplicationMasterId(applicationFromMasterRepository.findById(applicationMasterId).orElseThrow());
            applicationDocumentsDetails.setDocumentsMasterId(mlDocumentsMasterRepository.findById((long) documentsMasterId).orElseThrow());
            applicationDocumentsDetails.setMunicipalId(municipalId);
            applicationDocumentsDetails.setSuspendedStatus(applicationDocumentsDetails.getSuspendedStatus() != null ? applicationDocumentsDetails.getSuspendedStatus() : 0);
            applicationDocumentsDetails.setCreatedDate(LocalDateTime.now());
            applicationDocumentsDetails.setCreatedBy(createdBy);

            return applicationDocumentsDetailsRepository.saveAndFlush(applicationDocumentsDetails);
        } catch (Exception e) {
            throw new Exception("error uploading document: " + e.getMessage(), e);
        }
    }

//    @Override
//    public List<ApplicationDocumentsDetailsDto> findAllApplicationDocumentsDetails() {
//        List<ApplicationDocumentsDetails> applicationDocumentsDetails = applicationDocumentsDetailsRepository.findAll();
//        return applicationDocumentsDetails.stream()
//                .map(applicationDocumentsDetail -> modelMapper.map(applicationDocumentsDetail, ApplicationDocumentsDetailsDto.class))
//                .collect(Collectors.toList());
//    }
//
//    @Override
//    public List<ApplicationDocumentsDetails> findAllActiveApplicationDocumentsDetails(Integer status) {
//        return applicationDocumentsDetailsRepository.findBySuspendedStatus(status);
//    }

    @Override
    public ApplicationDocumentsDetails findApplicationDocumentsDetailsById(int id) {
        Optional<ApplicationDocumentsDetails> applicationDocumentsDetails = applicationDocumentsDetailsRepository.findById(id);
        return applicationDocumentsDetails.orElse(null);

    }

    @Override
    public List<ApplicationDocumentsDetails> findAllApplicationDocumentsDetailByMunicipalId(int municipalId) {
        List<ApplicationDocumentsDetails> applicationDocumentsDetails = applicationDocumentsDetailsRepository.findByMunicipalId(municipalId);
        return applicationDocumentsDetails;
//        return applicationDocumentsDetails.stream()
//                .map(applicationDocumentsDetail -> modelMapper.map(applicationDocumentsDetail, ApplicationDocumentsDetailsDto.class))
//                .collect(Collectors.toList());
    }

    @Override
    public ApplicationDocumentsDetails updateApplicationDocumentsDetailsById(Long id, MultipartFile documentPath) {
        ApplicationDocumentsDetails existingApplicationDocumentsDetails = applicationDocumentsDetailsRepository.findById(Math.toIntExact(id))
                .orElseThrow(() -> new ResourceNotFoundException("License Document Upload Details", "id", id));

        deleteDocument(existingApplicationDocumentsDetails.getDocumentPath());
        existingApplicationDocumentsDetails = handleDocumentUpload(existingApplicationDocumentsDetails, documentPath);
        //existingApplicationDocumentsDetails.setUpdatedBy(updatedBy);
        //existingApplicationDocumentsDetails.setUpdatedDate(LocalDateTime.now());
        return applicationDocumentsDetailsRepository.saveAndFlush(existingApplicationDocumentsDetails);
    }

    @Override
    public ApplicationDocumentsDetails changeSuspendedStatus(int id, int status, int updatedBy) {
        Optional<ApplicationDocumentsDetails> applicationDocumentsDetailsOptional = applicationDocumentsDetailsRepository.findById(id);
        if (applicationDocumentsDetailsOptional.isPresent()) {
            ApplicationDocumentsDetails applicationDocumentsDetails = applicationDocumentsDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            //applicationDocumentsDetails.setUpdatedDate(currentDateTime);
            applicationDocumentsDetails.setSuspendedStatus(status);      // 1 means suspended
            //applicationDocumentsDetails.setUpdatedBy(updatedBy);
            return applicationDocumentsDetailsRepository.saveAndFlush(applicationDocumentsDetails);
        }
        return null;
    }

    // handle document upload
    public ApplicationDocumentsDetails handleDocumentUpload(ApplicationDocumentsDetails applicationDocumentsDetails, MultipartFile documentPath) {
        Long masterId = applicationDocumentsDetails.getDocumentsMasterId().getId();
        MlDocumentsMaster master = mlDocumentsMasterRepository.findById(masterId)
                .orElseThrow(() -> new ResourceNotFoundException("License Upload Document Master", "id", masterId));

        String documentName = master.getDocumentName();
        if (documentName == null || documentName.isEmpty()) {
            throw new IllegalArgumentException("Document name is missing.");
        }

        documentName = documentName.replace(" ", "_");

        if (documentPath != null && !documentPath.isEmpty()) {
            if (!isPdf(documentPath)) {
                throw new IllegalArgumentException("Only PDF files are allowed.");
            }
            if (documentPath.getSize() > MAX_FILE_SIZE) {
                throw new IllegalArgumentException("File size exceeds the maximum limit of " + MAX_FILE_SIZE / (1024 * 1024) + " MB.");
            }
            try {
                // ✅ Step 1: Ensure Local Directory Exists
                Path typeDirectory = Paths.get(UPLOAD_DIR, documentName);
                if (!Files.exists(typeDirectory)) {
                    Files.createDirectories(typeDirectory);
                }

                // ✅ Step 2: Generate Unique Filename
                String newFileName = documentName + "_" + UUID.randomUUID() + ".pdf";
                newFileName = newFileName.replace(" ", "_");

                // ✅ Step 3: Save File Locally
                Path filePath = typeDirectory.resolve(newFileName);
                Files.write(filePath, documentPath.getBytes());

                // ✅ Step 4: Generate Correct URL for Response (Only for API Response)
                String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                        .path("/propertyDocumentUploads/")
                        .path(documentName + "/")
                        .path(newFileName)
                        .toUriString();

                // ✅ Step 5: Store **Only URL** in Database
                applicationDocumentsDetails.setDocumentPath(fileUrl);
                return applicationDocumentsDetails;

            } catch (IOException e) {
                throw new RuntimeException("Error while saving the document: " + e.getMessage(), e);
            }
        } else {
            throw new IllegalArgumentException("Uploaded file is null or empty.");
        }
    }
    // check allowed extension at the time of save
    private boolean isPdf(MultipartFile file) {
        String contentType = file.getContentType();
        String fileName = file.getOriginalFilename();
        return (contentType != null && contentType.equalsIgnoreCase("application/pdf")) ||
                (fileName != null && fileName.toLowerCase().endsWith(".pdf"));
    }

    // delete old uploaded document correctly
    public void deleteDocument(String documentPath) {
        if (documentPath != null) {
            try {
                URI uri = new URI(documentPath);
                String path = uri.getPath();
                String relativeFilePath = path.replace("/propertyDocumentUploads/", "");

                Path filePath = Paths.get(UPLOAD_DIR, relativeFilePath);
                Files.deleteIfExists(filePath);
            } catch (IOException | URISyntaxException e) {
                throw new RuntimeException("Error deleting document: " + e.getMessage(), e);
            }
        }
    }
    @Override
    public void deleteApplicationDocumentDetailsByApplicationMasterId(Long applicationMasterId) {
        try{
            applicationDocumentsDetailsRepository.deleteApplicationDocumentDetailsByApplicationMasterId(applicationMasterId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<ApplicationDocumentsDetails> getAllDetailsByApplicationMasterId(Long applicationMasterId) {
        List<ApplicationDocumentsDetails> documentList =
                applicationDocumentsDetailsRepository.findByApplicationMasterId_Id(applicationMasterId);

        if (documentList.isEmpty()) {
            throw new ResourceNotFoundException("Trade License Documents Details", "applicationMasterId", applicationMasterId);
        }

        return documentList;
    }


}