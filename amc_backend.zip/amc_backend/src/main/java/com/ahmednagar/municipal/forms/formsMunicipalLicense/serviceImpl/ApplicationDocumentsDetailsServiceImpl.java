package com.ahmednagar.municipal.forms.formsMunicipalLicense.serviceImpl;

import com.ahmednagar.municipal.forms.formsMunicipalLicense.dto.ApplicationDocumentsDetailsDto;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.model.ApplicationDocumentsDetails;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationDocumentsDetailsRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.repository.ApplicationFromMasterRepository;
import com.ahmednagar.municipal.forms.formsMunicipalLicense.service.ApplicationDocumentsDetailsService;
import com.ahmednagar.municipal.master.municipalLicence.model.MlDocumentsMaster;
import com.ahmednagar.municipal.master.municipalLicence.repository.MlDocumentsMasterRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ApplicationDocumentsDetailsServiceImpl implements ApplicationDocumentsDetailsService {

    private static final String UPLOAD_DIR = "D:\\muncipal_demo\\ahmednagar_muncipal\\src\\main\\resources\\licenseUpload";
    private static final long MAX_FILE_SIZE = 2 * 1024 * 1024;

    @Autowired
    private ApplicationDocumentsDetailsRepository applicationDocumentsDetailsRepository;

    @Autowired
    private MlDocumentsMasterRepository mlDocumentsMasterRepository;

    @Autowired
    private ApplicationFromMasterRepository applicationFromMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ApplicationDocumentsDetails saveApplicationDocumentsDetails(ApplicationDocumentsDetails applicationDocumentsDetails) {
        LocalDateTime currentDateTime = LocalDateTime.now();        // current date and time
        applicationDocumentsDetails.setCreatedDate(currentDateTime);
        //applicationDocumentsDetails.setUpdatedDate(currentDateTime);
        applicationDocumentsDetails.setSuspendedStatus(applicationDocumentsDetails.getSuspendedStatus() != null ? applicationDocumentsDetails.getSuspendedStatus() : 0);      // 0 means active
        //applicationDocumentsDetails.setUpdatedBy(createdBy);            // 1 means admin
        return applicationDocumentsDetailsRepository.saveAndFlush(applicationDocumentsDetails);
    }

    @Override
    public ApplicationDocumentsDetails uploadDocument(MultipartFile file, int createdBy, int suspendedStatus, int municipalId , Long applicationMasterId, int documentsMasterId) throws Exception {
        // Validate file type
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        if (!fileName.endsWith(".pdf")) {
            throw new Exception("Only PDF files are allowed.");
        }
        System.out.println(fileName+"rammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm::::::::::::::::::::::::::");

        if (file.getSize() > MAX_FILE_SIZE) {
            throw new Exception("File size exceeds the maximum allowed size of 10 MB.");
        }

        // Get the folder name based on the document type
        String folderName = mlDocumentsMasterRepository.findById((long) documentsMasterId)
                .map(MlDocumentsMaster::getDocumentName)
                .orElseThrow(() -> new Exception("Invalid document type ID."));

        System.out.println("folderrrrrrrrrrrrrrrrrrrrrrrrr Nameeeeeeeeeeee"+ folderName);

        // Replace spaces in the folder name with underscores
        folderName = folderName.replaceAll("\\s+", "_");

        // Create the new file name using the modified folder name and the random number
        String newFileName = folderName + "_" + UUID.randomUUID() + ".pdf";

        // Generate the file path based on the document type
        Path uploadPath = Paths.get(UPLOAD_DIR + "/" + folderName);

        System.out.println("upload Pathhhhhhhhhhhhhhhhhhhh=========>>>>>>>"+uploadPath);

        try {
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            Path filePath = uploadPath.resolve(newFileName);
            Files.copy(file.getInputStream(), filePath);

//        Path filePath = uploadPath.resolve(fileName);
//        try (InputStream inputStream = file.getInputStream()) {
//            // Compress and save the file
//            compressAndSavePDF(inputStream, filePath);

            // Prepare DocumentDetails object for saving
            ApplicationDocumentsDetails applicationDocumentsDetails = new ApplicationDocumentsDetails();
            applicationDocumentsDetails.setDocumentPath(filePath.toString());
            applicationDocumentsDetails.setDocumentFileName(newFileName);
            applicationDocumentsDetails.setApplicationMasterId(applicationFromMasterRepository.findById(applicationMasterId).orElseThrow());
            applicationDocumentsDetails.setDocumentsMasterId(mlDocumentsMasterRepository.findById((long) documentsMasterId).orElseThrow());
            applicationDocumentsDetails.setMunicipalId(municipalId);
            applicationDocumentsDetails.setSuspendedStatus(suspendedStatus);
            applicationDocumentsDetails.setCreatedDate(LocalDateTime.now());
            applicationDocumentsDetails.setCreatedBy(createdBy);

            return applicationDocumentsDetailsRepository.saveAndFlush(applicationDocumentsDetails);
        } catch (Exception e) {
            throw new Exception("Error uploading document: " + e.getMessage(), e);
        }
    }

//    @Override
//    public List<ApplicationDocumentsDetailsDto> findAllApplicationDocumentsDetails() {
//        List<ApplicationDocumentsDetails> applicationDocumentsDetails = applicationDocumentsDetailsRepository.findAll();
//        return applicationDocumentsDetails.stream()
//                .map(applicationDocumentsDetail -> modelMapper.map(applicationDocumentsDetail, ApplicationDocumentsDetailsDto.class))
//                .collect(Collectors.toList());
//    }
//
//    @Override
//    public List<ApplicationDocumentsDetails> findAllActiveApplicationDocumentsDetails(Integer status) {
//        return applicationDocumentsDetailsRepository.findBySuspendedStatus(status);
//    }
    @Override
    public ApplicationDocumentsDetails findApplicationDocumentsDetailsById(int id) {
        Optional<ApplicationDocumentsDetails> applicationDocumentsDetails=applicationDocumentsDetailsRepository.findById(id);
        return applicationDocumentsDetails.orElse(null);

    }

    @Override
    public List<ApplicationDocumentsDetails> findAllApplicationDocumentsDetailByMunicipalId(int municipalId) {
        List<ApplicationDocumentsDetails> applicationDocumentsDetails = applicationDocumentsDetailsRepository.findByMunicipalId(municipalId);
        return applicationDocumentsDetails;
//        return applicationDocumentsDetails.stream()
//                .map(applicationDocumentsDetail -> modelMapper.map(applicationDocumentsDetail, ApplicationDocumentsDetailsDto.class))
//                .collect(Collectors.toList());
    }


    @Override
    public ApplicationDocumentsDetails updateApplicationDocumentsDetails(int id, ApplicationDocumentsDetails updatedApplicationDocumentsDetails, int updatedBy) {
        Optional<ApplicationDocumentsDetails> applicationDocumentsDetailsOptional = applicationDocumentsDetailsRepository.findById(id);
        if (applicationDocumentsDetailsOptional.isPresent()) {
            ApplicationDocumentsDetails existingApplicationDocumentsDetails = applicationDocumentsDetailsOptional.get();
            existingApplicationDocumentsDetails.setSuspendedStatus(updatedApplicationDocumentsDetails.getSuspendedStatus());
            existingApplicationDocumentsDetails.setMunicipalId(updatedApplicationDocumentsDetails.getMunicipalId());

            return applicationDocumentsDetailsRepository.saveAndFlush(existingApplicationDocumentsDetails);
        } else {
            throw new RuntimeException("application Document not found with id: " + id);
        }
    }

    @Override
    public ApplicationDocumentsDetails changeSuspendedStatus(int id, int status, int updatedBy) {
        Optional<ApplicationDocumentsDetails> applicationDocumentsDetailsOptional = applicationDocumentsDetailsRepository.findById(id);
        if (applicationDocumentsDetailsOptional.isPresent()) {
            ApplicationDocumentsDetails applicationDocumentsDetails = applicationDocumentsDetailsOptional.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            LocalDate date = LocalDate.now();
            //applicationDocumentsDetails.setUpdatedDate(currentDateTime);
            applicationDocumentsDetails.setSuspendedStatus(status);      // 1 means suspended
            //applicationDocumentsDetails.setUpdatedBy(updatedBy);
            return applicationDocumentsDetailsRepository.saveAndFlush(applicationDocumentsDetails);
        }
        return null;
    }

}
