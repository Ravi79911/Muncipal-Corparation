package com.ahmednagar.municipal.forms.streetVendorCollectionSystem.service;

import com.ahmednagar.municipal.forms.streetVendorCollectionSystem.model.VendorZone;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface VendorZoneService {

    List<VendorZone> findAllZones();
}
