package com.ahmednagar.municipal.master.advertisement.serviceImpl;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingTypeRateMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingTypeRateMasterSetup;
import com.ahmednagar.municipal.master.advertisement.repository.HoardingTypeRateMasterSetupRepository;
import com.ahmednagar.municipal.master.advertisement.service.HoardingTypeRateMasterSetupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingTypeRateMasterSetupServiceImpl implements HoardingTypeRateMasterSetupService {
    @Autowired
    private HoardingTypeRateMasterSetupRepository hoardingTypeRateMasterSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingTypeRateMasterSetup saveHoardingTypeRateMasterSetup(HoardingTypeRateMasterSetup hoardingTypeRateMasterSetup) {
        hoardingTypeRateMasterSetup.setCreatedDate(LocalDateTime.now());
        hoardingTypeRateMasterSetup.setUpdatedDate(LocalDateTime.now());
        hoardingTypeRateMasterSetup.setUpdatedBy(hoardingTypeRateMasterSetup.getUpdatedBy() != null ? hoardingTypeRateMasterSetup.getUpdatedBy() : 0);
        hoardingTypeRateMasterSetup.setSuspendedStatus(hoardingTypeRateMasterSetup.getSuspendedStatus() != null ? hoardingTypeRateMasterSetup.getSuspendedStatus() : 0);

        return hoardingTypeRateMasterSetupRepository.save(hoardingTypeRateMasterSetup);

    }

    @Override
    public List<HoardingTypeRateMasterSetupDto> findAllHoardingTypeRateMasterSetup() {
        List<HoardingTypeRateMasterSetup> hoardingTypeRateMasterSetups = hoardingTypeRateMasterSetupRepository.findAll();
        return hoardingTypeRateMasterSetups.stream()
                .map(hoardingTypeRateMasterSetup -> modelMapper.map(hoardingTypeRateMasterSetup, HoardingTypeRateMasterSetupDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingTypeRateMasterSetup findById(Long id) {
        Optional<HoardingTypeRateMasterSetup> hoardingTypeRateMasterSetup=hoardingTypeRateMasterSetupRepository.findById(id);
        return hoardingTypeRateMasterSetup.orElse(null);

    }

    @Override
    public List<HoardingTypeRateMasterSetup> findAllByMunicipalId(int municipalId) {
        return hoardingTypeRateMasterSetupRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingTypeRateMasterSetup updateHoardingTypeRateMasterSetup(Long id, HoardingTypeRateMasterSetup updatedHoardingTypeRateMasterSetup, int updatedBy) {
        Optional<HoardingTypeRateMasterSetup> hoardingTypeRateMasterSetupOptional = hoardingTypeRateMasterSetupRepository.findById(id);
        if (hoardingTypeRateMasterSetupOptional.isPresent()) {
            HoardingTypeRateMasterSetup existingHoardingTypeRateMasterSetup = hoardingTypeRateMasterSetupOptional.get();
            existingHoardingTypeRateMasterSetup.setUpdatedBy(updatedBy);
            existingHoardingTypeRateMasterSetup.setUpdatedDate(LocalDateTime.now());
            return hoardingTypeRateMasterSetupRepository.saveAndFlush(existingHoardingTypeRateMasterSetup);
        } else {
            throw new RuntimeException("HoardingTypeRateMasterSetup not found with id: " + id);
        }
    }

    @Override
    public HoardingTypeRateMasterSetup changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingTypeRateMasterSetup> hoardingTypeRateMasterSetupOpt = hoardingTypeRateMasterSetupRepository.findById(id);
        if (hoardingTypeRateMasterSetupOpt.isPresent()) {
            HoardingTypeRateMasterSetup hoardingTypeRateMasterSetup = hoardingTypeRateMasterSetupOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingTypeRateMasterSetup.setUpdatedDate(currentDateTime);
            hoardingTypeRateMasterSetup.setSuspendedStatus(status);      // 1 means suspended
            hoardingTypeRateMasterSetup.setUpdatedBy(updatedBy);
            return hoardingTypeRateMasterSetupRepository.saveAndFlush(hoardingTypeRateMasterSetup);
        }
        return null;
    }
}
