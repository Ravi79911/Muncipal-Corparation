package com.ahmednagar.municipal.forms.formsWaterManagement.controller;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.ConsumerPropertyDetails;
import com.ahmednagar.municipal.forms.formsWaterManagement.service.ConsumerPropertyDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/water/forms/consumer-property")
public class ConsumerPropertyDetailsController {

    @Autowired
    private ConsumerPropertyDetailsService consumerPropertyDetailsService;

    @PostMapping("/create")
    public ResponseEntity<?> saveConsumerPropertyDetails(@Valid @RequestBody ConsumerPropertyDetails consumerPropertyDetails, @RequestParam int createdBy) {
        ConsumerPropertyDetails createdConsumerPropertyDetails = consumerPropertyDetailsService.saveConsumerPropertyDetails(consumerPropertyDetails, createdBy);
        if (createdConsumerPropertyDetails == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Consumer Property Details not created");
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdConsumerPropertyDetails);
    }

    @PatchMapping("delete/{id}")
    public ResponseEntity<?> deleteConsumerPropertyDetails(@PathVariable int id, @RequestParam(required = false, defaultValue = "1") int suspendedStatus) {
        ConsumerPropertyDetails deletedConsumerPropertyDetails = consumerPropertyDetailsService.deleteConsumerPropertyDetails(id, suspendedStatus);
        if (deletedConsumerPropertyDetails == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Consumer Property Details not found with the given ID");
        }
        return ResponseEntity.ok(deletedConsumerPropertyDetails);
    }

    @GetMapping("/municipal/{municipalId}")
    public ResponseEntity<?> getConsumerPropertyByMunicipalId(@PathVariable int municipalId) {
        List<ConsumerPropertyDetails> consumerPropertyDetails = consumerPropertyDetailsService.getConsumerPropertyByMunicipalId(municipalId);
        if (consumerPropertyDetails == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)

                    .body("Consumer Property Details not found with the given Municipal ID");
        }
        return ResponseEntity.ok(consumerPropertyDetails);
    }
}
