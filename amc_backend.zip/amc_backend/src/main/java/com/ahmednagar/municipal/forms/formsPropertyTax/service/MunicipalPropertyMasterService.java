package com.ahmednagar.municipal.forms.formsPropertyTax.service;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.MunicipalPropertyMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface MunicipalPropertyMasterService {

    MunicipalPropertyMaster createPropertyMaster(MunicipalPropertyMaster municipalPropertyMaster);

    MunicipalPropertyMaster updatePropertyMaster(Long id, MunicipalPropertyMaster updatedPropertyMaster);

    List<MunicipalPropertyMaster> getPropertyMasterByApplicationNumber(String applicationNo);

    List<MunicipalPropertyMaster> getAllPropertyMaster();

    Optional<MunicipalPropertyMaster> getMunicipalPropertyMasterById(Long id);

    List<MunicipalPropertyMaster> getByMunicipalId(int municipalId);

    boolean isHoldingNoExists(String holdingNo);

    List<MunicipalPropertyMaster> getByZoneWardHoldingNo(Long zoneId, Long zoneWard, String holdingNo);

    MunicipalPropertyMaster patchMunicipalPropertyMasterSuspendedStatus(Long id, int suspendedStatus);

    void deletePropertyMasterById(Long id);

    // MunicipalPropertyMaster updateMunicipalPropertyMasterById(int id, MunicipalPropertyMaster municipalPropertyMaster);

}
