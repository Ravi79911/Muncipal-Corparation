package com.ahmednagar.municipal.forms.formsWaterManagement.repository;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.UserBasicDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface UserBasicDetailsRepository extends JpaRepository<UserBasicDetails, Integer> {

    List<UserBasicDetails> findByMunicipalId(int municipalId);
}
