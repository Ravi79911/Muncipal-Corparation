package com.ahmednagar.municipal.auth.controller;

import com.ahmednagar.municipal.auth.dto.NewPropertyWorkFlowLevelDto;
import com.ahmednagar.municipal.auth.model.NewPropertyWorkFlowLevel;
import com.ahmednagar.municipal.auth.service.NewPropertyWorkFlowLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/work/new-flow/level")
public class NewPropertyWorkFlowLevelController {

    @Autowired
    private NewPropertyWorkFlowLevelService newWorkFlowsService;

    @PostMapping("/new-transition")
    public ResponseEntity<NewPropertyWorkFlowLevel> handleWorkFlowsTransition(@RequestBody NewPropertyWorkFlowLevel newPropertyWorkFlowLevel) {
        NewPropertyWorkFlowLevel updatedWorkFlowLevel = newWorkFlowsService.handleWorkFlowsTransition(newPropertyWorkFlowLevel);
        return ResponseEntity.ok(updatedWorkFlowLevel);
    }

    @PostMapping("/new-application")
    public ResponseEntity<NewPropertyWorkFlowLevel> createNewWorkflow(@RequestBody NewPropertyWorkFlowLevel newPropertyWorkFlowLevel) {
        NewPropertyWorkFlowLevel savedWorkflow = newWorkFlowsService.createNewApplicationTransation(newPropertyWorkFlowLevel);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedWorkflow);
    }

    @GetMapping("/getAllNewWorkFlowsList")
    public ResponseEntity<List<NewPropertyWorkFlowLevelDto>> getAllNewWorkFlowsList() {
        List<NewPropertyWorkFlowLevelDto> workFlows = newWorkFlowsService.getAllNewWorkFlows();
        return ResponseEntity.ok(workFlows);
    }

}
