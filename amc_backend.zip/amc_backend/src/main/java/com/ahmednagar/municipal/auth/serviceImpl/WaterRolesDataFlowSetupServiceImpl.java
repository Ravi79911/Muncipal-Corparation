package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.dto.WaterRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.WaterRolesDataFlowSetup;
import com.ahmednagar.municipal.auth.repository.WaterRolesDataFlowSetupRepository;
import com.ahmednagar.municipal.auth.service.WaterRolesDataFlowSetupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class WaterRolesDataFlowSetupServiceImpl implements WaterRolesDataFlowSetupService {

    @Autowired
    private WaterRolesDataFlowSetupRepository waterRolesDataFlowSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<WaterRolesDataFlowSetupDto> findAllRolesDataFlowSetup() {
        List<WaterRolesDataFlowSetup> roles = waterRolesDataFlowSetupRepository.findAll();
        return roles.stream()
                .map(role -> modelMapper.map(role, WaterRolesDataFlowSetupDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<WaterRolesDataFlowSetup> getNextRoleListForListSelection(Long currentRoleId, Long statusCode, Integer isActive) {
        List<WaterRolesDataFlowSetup> list = waterRolesDataFlowSetupRepository
                .findAllByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId,statusCode, isActive);
        if (list.isEmpty()) {
            throw new RuntimeException("No next roles found for currentRoleId: " + currentRoleId + " and status code: " + 1007L+"(DocumentVerificationReject)");
        }
        return list;
    }

    @Override
    public WaterRolesDataFlowSetup getNextRoleForSingleSelection(Long currentRoleId, Long statusCode, Integer isActive) {
        return waterRolesDataFlowSetupRepository
                .findByCurrentRoleIdAndStatusCodeAndIsActive(currentRoleId, statusCode, isActive)
                .orElseThrow(() -> new RuntimeException(
                        "No next role found for currentRoleId: " + currentRoleId +
                                ", statusCode: " + statusCode + ", isActive: " + isActive));
    }

}
