package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.dto.PropertyRolesDataFlowSetupDto;
import com.ahmednagar.municipal.auth.model.PropertyRolesDataFlowSetup;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface PropertyRolesDataFlowSetupService {

    List<PropertyRolesDataFlowSetupDto> findAllRolesDataFlowSetup();

//    RolesDataFlowSetup getNextRoleIdForForward (Long currentRoleId);
//
//    List<RolesDataFlowSetup> getNextRoleListForBackWard(Long currentRoleId);
//
//    RolesDataFlowSetup getNextRoleIdForDocumentVerificationAccept(Long currentRoleId);

    List<PropertyRolesDataFlowSetup> getNextRoleListForListSelection(Long currentRoleId, Long statusCode, Integer isActive);

    PropertyRolesDataFlowSetup getNextRoleForSingleSelection(Long currentRoleId, Long statusCode, Integer isActive);
}
