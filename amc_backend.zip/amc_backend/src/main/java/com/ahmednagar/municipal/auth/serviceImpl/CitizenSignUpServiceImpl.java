package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.jwt.JwtHelper;
import com.ahmednagar.municipal.auth.model.*;
import com.ahmednagar.municipal.auth.repository.*;
import com.ahmednagar.municipal.auth.service.CitizenSignUpService;
import com.ahmednagar.municipal.auth.utils.IpAddressService;
import com.ahmednagar.municipal.auth.utils.TokenGeneration;
import com.ahmednagar.municipal.exception.*;
import com.ahmednagar.municipal.notification.EmailService;
import com.ahmednagar.municipal.notification.OTPService;
import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Slf4j
@Service
public class CitizenSignUpServiceImpl implements CitizenSignUpService {

    @Autowired
    CitizenSignUpRepository citizenSignUpRepository;

    @Autowired
    AuthZoneRepository authZoneRepository;

    @Autowired
    AuthWardRepository authWardRepository;

    @Autowired
    RoleMasterRepository roleMasterRepository;

    @Autowired
    CitizenPasswordChangeHistoryRepository citizenPasswordChangeHistoryRepository;

    @Autowired
    CitizenOTPHistoryRepository citizenOTPHistoryRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    JwtHelper jwtHelper;

    @Autowired
    TokenGeneration tokenGeneration;

    @Autowired
    OTPService otpService;

    @Autowired
    EmailService emailService;

    @Autowired
    IpAddressService ipAddressService;

    private static final long MAX_FILE_SIZE = 200 * 1024;
    private static final int OTP_EXPIRATION_MINUTES = 5;

    @Value("${upload.auth.citizen.signup.profilePic.dir}")
    private String uploadDir;

    @Override
    public CitizenSignUpMaster registerCitizen(CitizenSignUpMaster citizenSignUpMaster, MultipartFile profileImg, HttpServletRequest request) {

        if (isUserNameExists(citizenSignUpMaster.getUsername())) {
            throw new ResourceAlreadyExistsException("Username already exists. Please choose another.");
        }

        if (isEmailExists(citizenSignUpMaster.getEmail())) {
            throw new ResourceAlreadyExistsException("Email address already exists.");
        }

        if (isMobileNoExists(citizenSignUpMaster.getMobileNo())) {
            throw new ResourceAlreadyExistsException("Mobile number already exists.");
        }

        // validate DOB - user must be at least 14 years old
        if (citizenSignUpMaster.getDob() != null) {
            LocalDate today = LocalDate.now();
            LocalDate minAllowedDob = today.minusYears(14);

            if (citizenSignUpMaster.getDob().isAfter(minAllowedDob)) {
                throw new IllegalArgumentException("date of birth must be at least 14 years ago.");
            }
        }

        // handle profile picture upload if provided
        if (profileImg != null && !profileImg.isEmpty()) {
            handleProfilePicUpload(profileImg, citizenSignUpMaster);
            System.out.println("Image Uploaded: " + citizenSignUpMaster.getProfileImageName());
            System.out.println("Image URL: " + citizenSignUpMaster.getProfilePicUrl());
        } else {
            System.out.println("uploaded file is null or empty");
        }

        // check if the provided zone id exists
        if (!authZoneRepository.existsById(citizenSignUpMaster.getZoneId())) {
            throw new ResourceNotFoundException("Zone", "id", citizenSignUpMaster.getZoneId());
        }

        // check if the provided ward id exists and belongs to the provided zone id
        boolean wardBelongsToZone = authWardRepository.existsByIdAndZoneMasId(citizenSignUpMaster.getWardId(), citizenSignUpMaster.getZoneId());
        if (!wardBelongsToZone) {
            throw new ResourceNotFoundException("Ward", "id", citizenSignUpMaster.getWardId());
        }

        // assign the default role (e.g. - CITIZEN) if not already set
        if (citizenSignUpMaster.getRoleMaster() == null) {
            RoleMaster defaultRole = roleMasterRepository.findByRoleName("CITIZEN")
                    .orElseThrow(() -> new ResourceNotFoundException("Role", "name", "CITIZEN"));
            citizenSignUpMaster.setRoleMaster(defaultRole);
        }

        citizenSignUpMaster.setPassword(passwordEncoder.encode(citizenSignUpMaster.getPassword()));
        citizenSignUpMaster.setCreatedBy("CITIZEN SS ONLINE");
        citizenSignUpMaster.setCreatedDate(LocalDateTime.now());
        citizenSignUpMaster.setUpdatedDate(LocalDateTime.now());
        citizenSignUpMaster.setIpAddress(ipAddressService.getClientIp(request));
        citizenSignUpMaster.setUpdateBy(citizenSignUpMaster.getUpdateBy() != null ? citizenSignUpMaster.getUpdateBy() : 0);
        citizenSignUpMaster.setSuspendedStatus(citizenSignUpMaster.getSuspendedStatus() != null ? citizenSignUpMaster.getSuspendedStatus() : 0);
        CitizenSignUpMaster savedCitizenSignupMaster = citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);
//        generateAndSendOtp(savedCitizenSignupMaster); // generate otp for email & mobile verification

        // save password change history
        CitizenPasswordChangeHistory citizenPasswordHistory = new CitizenPasswordChangeHistory();
        citizenPasswordHistory.setCitizenId(savedCitizenSignupMaster.getId());
        citizenPasswordHistory.setLastPassword(savedCitizenSignupMaster.getPassword());
        citizenPasswordHistory.setLastPasswordTimestamp(LocalDateTime.now());
        citizenPasswordHistory.setIpAddress(ipAddressService.getClientIp(request));
        citizenPasswordHistory.setCreatedBy(savedCitizenSignupMaster.getUpdateBy());
        citizenPasswordHistory.setCreatedDate(LocalDateTime.now());
        citizenPasswordHistory.setMunicipalId(savedCitizenSignupMaster.getMunicipalId());
        citizenPasswordChangeHistoryRepository.saveAndFlush(citizenPasswordHistory); // end of password change history block

        // after saving the user, send a confirmation email
        try {
            emailService.sendSignupConfirmationEmailBeforeOtpVerificationCitizen(savedCitizenSignupMaster.getEmail(), savedCitizenSignupMaster.getCitizenName());
        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send confirmation email to {}", savedCitizenSignupMaster.getEmail(), e);
            throw new MailSendingException("Failed to send confirmation email.");
        } // block end for email sending
        return savedCitizenSignupMaster;
    }

    @Override
    public CitizenSignUpMaster updateCitizenProfile(CitizenSignUpMaster citizenSignUpMaster, MultipartFile imageFile) {
        try {
            // preserve critical fields
            String existingCitizenName = citizenSignUpMaster.getCitizenName();
            LocalDate existingDob = citizenSignUpMaster.getDob();
            String existingMobileNo = citizenSignUpMaster.getMobileNo();

            // handle profile picture update if provided
            if (imageFile != null && !imageFile.isEmpty()) {
                try {
                    handleProfilePicUpload(imageFile, citizenSignUpMaster);
                } catch (FileUploadException e) {
                    log.error("Failed to upload profile picture for citizen {}", citizenSignUpMaster.getCitizenName(), e);
                    throw new FileUploadException("Failed to upload profile picture.", e);
                }
            }

            // restore non-editable fields
            citizenSignUpMaster.setCitizenName(existingCitizenName);
            citizenSignUpMaster.setDob(existingDob);
            citizenSignUpMaster.setMobileNo(existingMobileNo);

            // add conditional fields
            if (Boolean.FALSE.equals(citizenSignUpMaster.getIsPropertyExist())) {
                citizenSignUpMaster.setHoldingNo(null);
            }
            if (Boolean.FALSE.equals(citizenSignUpMaster.getIsWaterConnectionExist())) {
                citizenSignUpMaster.setConsumerNum(null);
            }
            if (Boolean.FALSE.equals(citizenSignUpMaster.getIsTradeLicenseExist())) {
                citizenSignUpMaster.setLicenceNum(null);
            }
            if (Boolean.FALSE.equals(citizenSignUpMaster.getIsAdvertismentExist())) {
                citizenSignUpMaster.setAdvertisementApplicationNo(null);
            }

            citizenSignUpMaster.setUpdatedDate(LocalDateTime.now());

            // send profile update confirmation email
            try {
                emailService.sendProfileUpdateConfirmationEmail(
                        citizenSignUpMaster.getEmail(),
                        citizenSignUpMaster.getCitizenName()
                );
            } catch (MessagingException | UnsupportedEncodingException e) {
                log.error("Failed to send confirmation email to {} for citizen {}", citizenSignUpMaster.getEmail(), citizenSignUpMaster.getCitizenName(), e);
                throw new ProfileUpdateException("Failed to send profile update confirmation email.", e);
            }

            return citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);
        } catch (ProfileUpdateException e) {
            log.error("Error occurred while updating citizen profile for citizen {}", citizenSignUpMaster.getCitizenName(), e);
            throw e;
        } catch (Exception e) {
            log.error("Exception occurred while updating citizen profile for citizen {}", citizenSignUpMaster.getCitizenName(), e);
            throw new ProfileUpdateException("Unexpected error occurred during profile update: " + e.getMessage(), e);
        }
    }

    @Override
    public String getProfilePicUrlFromToken(String token) {
        String jwt = token.replace("Bearer ", "");
        String email;

        try {
            email = jwtHelper.getUsernameFromToken(jwt);
        } catch (Exception e) {
            throw new InvalidTokenException("Invalid or expired token");
        }

        CitizenSignUpMaster citizen = citizenSignUpRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen", "email", email));

        String profilePicUrl = citizen.getProfilePicUrl();

        if (profilePicUrl == null || profilePicUrl.isEmpty()) {
            throw new ApiException("Profile picture URL is not available.");
        }
        return profilePicUrl;
    }

//    @Override
//    public Resource getCitizenProfilePicByCitizenId(Long citizenId) throws IOException {
//        // fetch the citizen data from the database and get the profile image name
//        CitizenSignUpMaster citizen = citizenSignUpRepository.findById(citizenId)
//                .orElseThrow(() -> new IllegalArgumentException("citizen not found with id: " + citizenId));
//
//        // get the profile image name from the citizen object
//        String fileName = citizen.getProfileImageName();
//
//        if (fileName == null || fileName.isEmpty()) {
//            throw new IOException("profile picture not found for citizen id: " + citizenId);
//        }
//
//        // get the path where the profile picture is stored
//        Path filePath = Paths.get(uploadDir, fileName);
//
//        // check if the file exists
//        if (!Files.exists(filePath)) {
//            throw new IOException("profile picture file not found in the file system");
//        }
//        return new FileSystemResource(filePath.toFile());
//    }

    @Override
    public CitizenSignUpMaster findCitizenProfileByJwt(String jwt) {
        try {
            String citizenEmail = jwtHelper.getUsernameFromToken(jwt);
            log.info("extracted citizen email from JWT: {}", citizenEmail);

            CitizenSignUpMaster citizenSignUpMaster = citizenSignUpRepository.findByEmail(citizenEmail)
                    .orElseThrow(() -> new ResourceNotFoundException("citizen", "email", citizenEmail));

            log.info("citizen found with email: {}", citizenSignUpMaster.getEmail());
            return citizenSignUpMaster;
        } catch (IllegalArgumentException e) {
            log.error("Invalid JWT token: {}", e.getMessage(), e);
            throw new ProfileRetrievalException("Invalid JWT token provided.", e);
        } catch (Exception ex) {
            log.error("Unexpected error fetching citizen profile: {}", ex.getMessage(), ex);
            throw new ProfileRetrievalException("An error occurred while fetching the citizen profile.", ex);
        }
    }

    @Override
    public CitizenSignUpMaster findByCitizenId(Long id) {
        return citizenSignUpRepository.findById(id).orElse(null);
    }

    @Override
    public boolean isEmailExists(String email) {
        return citizenSignUpRepository.existsByEmail(email);
    }

    @Override
    public boolean isUserNameExists(String username) {
        return citizenSignUpRepository.existsByUserName(username);
    }

    @Override
    public boolean isMobileNoExists(String mobileNo) {
        return citizenSignUpRepository.existsByMobileNo(mobileNo);
    }

    @Override
    public void generateAndSendOtp(CitizenSignUpMaster citizenSignUpMaster) {
        // generate email otp
        String emailOtp = otpService.generateOTP();
        citizenSignUpMaster.setEmailOtp(emailOtp);
        citizenSignUpMaster.setEmailOtpTimestamp(LocalDateTime.now());

        // generate mobile otp
        String mobileOtp = otpService.generateOTP();
        citizenSignUpMaster.setMobileOtp(mobileOtp);
        citizenSignUpMaster.setMobileOtpTimestamp(LocalDateTime.now());
        citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);

        // save otp history
        CitizenOTPHistory citizenOTPHistory = new CitizenOTPHistory(
                citizenSignUpMaster.getEmail(),
                citizenSignUpMaster.getMobileNo(),
                emailOtp,
                mobileOtp,
                citizenSignUpMaster.getEmailOtpTimestamp(),
                citizenSignUpMaster.getMobileOtpTimestamp()
        );
        citizenOTPHistoryRepository.saveAndFlush(citizenOTPHistory);

        // send otp via email
        otpService.sendEmailOTP(citizenSignUpMaster.getEmail(), emailOtp);

        // send otp via sms
        otpService.sendSMSOTP(citizenSignUpMaster.getMobileNo(), mobileOtp);
    }

    @Override
    public String sendOtpForMobileLogin(String mobileNo) {
        // check if the mobile number exists in the database
        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpRepository.findByMobileNo(mobileNo).orElse(null);

        if (citizenSignUpMaster == null) {
            return "mobile number not registered";
        }

        // generate and send OTP
        String mobileOtp = otpService.generateOTP();
        otpService.sendSMSOTP(mobileNo, mobileOtp);

        // store the OTP and expiration in the database
        citizenSignUpMaster.setMobileOtp(mobileOtp);
        citizenSignUpMaster.setMobileOtpTimestamp(LocalDateTime.now().plusMinutes(OTP_EXPIRATION_MINUTES));
        citizenSignUpRepository.save(citizenSignUpMaster);

        // save otp history
        CitizenOTPHistory citizenOTPHistory = new CitizenOTPHistory(
                null,
                citizenSignUpMaster.getMobileNo(),
                null,
                mobileOtp,
                null,
                citizenSignUpMaster.getMobileOtpTimestamp()
        );
        citizenOTPHistoryRepository.saveAndFlush(citizenOTPHistory);

        return "OTP sent successfully";
    }


    @Override
    public boolean validateEmailOtp(CitizenSignUpMaster citizenSignUpMaster, String otp) {
        if (citizenSignUpMaster.getEmailOtpTimestamp().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            return false; // otp expired
        }
        if (citizenSignUpMaster.getEmailOtp().equals(otp)) {
            // otp matches, update email verification status
            citizenSignUpMaster.setEmailVerified(true);
            citizenSignUpMaster.setEmailOtp(null); // clear otp after successful verification
            citizenSignUpMaster.setEmailOtpTimestamp(null); // clear otp timestamp
            citizenSignUpMaster.setUpdatedDate(LocalDateTime.now());
            citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);

            // check if both email and mobile are verified
            if (citizenSignUpMaster.isEmailVerified() && citizenSignUpMaster.isMobileVerified()) {
                citizenSignUpMaster.setVerified(true); // set overall verified status
                citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);
                // send confirmation email when the user is fully verified
                try {
                    emailService.sendSignupConfirmationEmail(citizenSignUpMaster.getEmail(), citizenSignUpMaster.getCitizenName());
                } catch (MessagingException | UnsupportedEncodingException e) {
                    log.error("Failed to send confirmation email to {}", citizenSignUpMaster.getEmail(), e);
                }
            }
            return true; // verification successful
        }
        return false; // otp mismatch
    }

    @Override
    public boolean validateMobileOtp(CitizenSignUpMaster citizenSignUpMaster, String otp) {
        if (citizenSignUpMaster.getMobileOtpTimestamp().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            return false; // otp expired
        }
        if (citizenSignUpMaster.getMobileOtp().equals(otp)) {
            // otp matches, update mobile verification status
            citizenSignUpMaster.setMobileVerified(true);
            citizenSignUpMaster.setMobileOtp(null); // clear otp after successful verification
            citizenSignUpMaster.setMobileOtpTimestamp(null); // clear OTP timestamp
            citizenSignUpMaster.setUpdatedDate(LocalDateTime.now());
            citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);

            // check if both email and mobile are verified
            if (citizenSignUpMaster.isEmailVerified() && citizenSignUpMaster.isMobileVerified()) {
                citizenSignUpMaster.setVerified(true); // set overall verified status
                citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);
                // send confirmation email when the user is fully verified
                try {
                    emailService.sendSignupConfirmationEmail(citizenSignUpMaster.getEmail(), citizenSignUpMaster.getCitizenName());
                } catch (MessagingException | UnsupportedEncodingException e) {
                    log.error("Failed to send confirmation email to {}", citizenSignUpMaster.getEmail(), e);
                }
            }
            return true; // verification successful
        }
        return false; // otp mismatch
    }

    @Override
    public String validateForgotUsernameOtp(CitizenSignUpMaster citizenSignUpMaster, String emailOtp, String mobileOtp) {
        LocalDateTime otpGenerationDateTime = LocalDateTime.now();

        // validate email otp
        if (citizenSignUpMaster.getEmailOtp() == null || !citizenSignUpMaster.getEmailOtp().equals(emailOtp)) {
            return "Invalid email OTP.";
        }

        // validate email otp expiration
        if (citizenSignUpMaster.getEmailOtpTimestamp().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(otpGenerationDateTime)) {
            return "Email OTP has expired.";
        }

        // validate mobile otp
        if (citizenSignUpMaster.getMobileOtp() == null || !citizenSignUpMaster.getMobileOtp().equals(mobileOtp)) {
            return "Invalid mobile OTP.";
        }

        // validate mobile otp expiration
        if (citizenSignUpMaster.getMobileOtpTimestamp().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(otpGenerationDateTime)) {
            return "Mobile OTP has expired.";
        }

        // otp are valid, send the username to the user
        try {
            emailService.sendUsernameToUserEmail(citizenSignUpMaster.getEmail(), citizenSignUpMaster.getUsername(), citizenSignUpMaster.getCitizenName());
            // clear otp after successful verification
            citizenSignUpMaster.setEmailOtp(null);
            citizenSignUpMaster.setMobileOtp(null);
            citizenSignUpMaster.setEmailOtpTimestamp(null);
            citizenSignUpMaster.setMobileOtpTimestamp(null);

            // update verification status
            citizenSignUpMaster.setEmailVerified(true);
            citizenSignUpMaster.setMobileVerified(true);
            citizenSignUpMaster.setUpdatedDate(LocalDateTime.now());
            citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);

        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send username email to {}", citizenSignUpMaster.getEmail(), e);
            return "OTP validated successfully, but we couldn't send the username email at the moment.";
        }
        return "OTP validated successfully. Your username has been sent to your email.";
    }

    @Override
    public void resendEmailOtp(CitizenSignUpMaster citizenSignUpMaster) {
        // check if the email otp timestamp is null or if otp has expired
        if (citizenSignUpMaster.getEmailOtpTimestamp() == null ||
                citizenSignUpMaster.getEmailOtpTimestamp().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            // otp expired, regenerate otp
            String newEmailOtp = otpService.generateOTP();
            citizenSignUpMaster.setEmailOtp(newEmailOtp);
            citizenSignUpMaster.setEmailOtpTimestamp(LocalDateTime.now());
            citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);

            // send the new otp via email
            otpService.sendEmailOTP(citizenSignUpMaster.getEmail(), newEmailOtp);

            // save otp history
            CitizenOTPHistory citizenOTPHistory = new CitizenOTPHistory(
                    citizenSignUpMaster.getEmail(),
                    null,
                    newEmailOtp,
                    null,
                    citizenSignUpMaster.getEmailOtpTimestamp(),
                    null
            );
            citizenOTPHistoryRepository.saveAndFlush(citizenOTPHistory);
        } else {
            // otp is still valid, so no need to regenerate
            otpService.sendEmailOTP(citizenSignUpMaster.getEmail(), citizenSignUpMaster.getEmailOtp());
        }
    }

    @Override
    public void resendMobileOtp(CitizenSignUpMaster citizenSignUpMaster) {
        // check if the mobile otp timestamp is null or expired
        if (citizenSignUpMaster.getEmailOtpTimestamp() == null ||
                citizenSignUpMaster.getMobileOtpTimestamp().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            // otp expired, regenerate otp
            String newMobileOtp = otpService.generateOTP();
            citizenSignUpMaster.setMobileOtp(newMobileOtp);
            citizenSignUpMaster.setMobileOtpTimestamp(LocalDateTime.now());
            citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);

            // send the new otp via sms
            otpService.sendSMSOTP(citizenSignUpMaster.getMobileNo(), newMobileOtp);

            // save otp history
            CitizenOTPHistory citizenOTPHistory = new CitizenOTPHistory(
                    null,
                    citizenSignUpMaster.getMobileNo(),
                    null,
                    newMobileOtp,
                    null,
                    citizenSignUpMaster.getMobileOtpTimestamp()
            );
            citizenOTPHistoryRepository.saveAndFlush(citizenOTPHistory);
        } else {
            // otp is still valid, so no need to regenerate
            otpService.sendSMSOTP(citizenSignUpMaster.getMobileNo(), citizenSignUpMaster.getMobileOtp());
        }
    }

    @Override
    public String forgotUsername(ForgotUserNameRequest forgotUserNameRequest) {
        // validate if the email exists
        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpRepository.findByEmail(forgotUserNameRequest.getEmail())
                .orElseThrow(() -> new EmailNotFoundException("Email not found: " + forgotUserNameRequest.getEmail()));

        // validate if the mobile number exists
        if (!citizenSignUpMaster.getMobileNo().equals(forgotUserNameRequest.getMobileNo())) {
            throw new IllegalArgumentException("Mobile number doesn't match with the provided email");
        }

        // generate otp for both email and mobile number
        generateAndSendOtp(citizenSignUpMaster);
        return "OTP has been sent to your email and mobile number. Please verify them.";
    }

    @Override
    public String requestChangeEmailOrMobile(Long citizenId, ChangeEmailMobileRequest changeEmailMobileRequest) {
        // fetch the citizen by citizen id
        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpRepository.findById(citizenId).orElseThrow(() -> new IllegalArgumentException("citizen not found with id: " + citizenId));

        boolean isEmailChange = changeEmailMobileRequest.getExistingEmailMobile().equals(citizenSignUpMaster.getEmail());
        boolean isMobileChange = changeEmailMobileRequest.getExistingEmailMobile().equals(citizenSignUpMaster.getMobileNo());

        // validate if the existing contact matches the current email or mobile
        if (!isEmailChange && !isMobileChange) {
            throw new IllegalArgumentException("Existing email or mobile does not match");
        }

        // check if the new contact (email or mobile) is valid
        if (isEmailChange && isEmailExists(changeEmailMobileRequest.getNewEmailMobile())) {
            throw new IllegalArgumentException("Email address already exists");
        }

        if (isMobileChange && isMobileNoExists(changeEmailMobileRequest.getNewEmailMobile())) {
            throw new IllegalArgumentException("Mobile number already exists");
        }

        // generate otp for the new contact (email or mobile)
        String otp = otpService.generateOTP();

        if (isEmailChange) {
            citizenSignUpMaster.setEmailOtp(otp);
            citizenSignUpMaster.setEmailOtpTimestamp(LocalDateTime.now());
            citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);
            otpService.sendEmailOTP(changeEmailMobileRequest.getNewEmailMobile(), otp);
        } else if (isMobileChange) {
            citizenSignUpMaster.setMobileOtp(otp);
            citizenSignUpMaster.setMobileOtpTimestamp(LocalDateTime.now());
            citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);
            otpService.sendSMSOTP(changeEmailMobileRequest.getNewEmailMobile(), otp);
        }

        // save otp history
        CitizenOTPHistory citizenOTPHistory = new CitizenOTPHistory(
                citizenSignUpMaster.getEmail(),
                citizenSignUpMaster.getMobileNo(),
                isEmailChange ? otp : null,
                isMobileChange ? otp : null,
                isEmailChange ? LocalDateTime.now() : null,
                isMobileChange ? LocalDateTime.now() : null
        );
        citizenOTPHistoryRepository.saveAndFlush(citizenOTPHistory);
        return "OTP sent to " + changeEmailMobileRequest.getNewEmailMobile();
    }

    @Override
    public boolean validateChangeEmailOrMobileOtp(Long citizenId, String otp, ChangeEmailMobileRequest changeEmailMobileRequest) {
        // fetch the citizen by citizen id
        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpRepository.findById(citizenId)
                .orElseThrow(() -> new IllegalArgumentException("citizen not found" + citizenId));

        // check if the otp matches the one sent to the email or mobile
        boolean isEmailOtpValid = (citizenSignUpMaster.getEmailOtp() != null && citizenSignUpMaster.getEmailOtp().equals(otp));
        boolean isMobileOtpValid = (citizenSignUpMaster.getMobileOtp() != null && citizenSignUpMaster.getMobileOtp().equals(otp));

        // validate the otp expiration time
        if ((isEmailOtpValid && citizenSignUpMaster.getEmailOtpTimestamp().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) ||
                (isMobileOtpValid && citizenSignUpMaster.getMobileOtpTimestamp().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now()))) {
            throw new IllegalArgumentException("OTP has expired");
        }

        // perform the update based on which contact (email/mobile) was validated
        if (isEmailOtpValid && changeEmailMobileRequest.getNewEmailMobile() != null) {
            // check if the new email is the same as the existing email
            if (citizenSignUpMaster.getEmail().equals(changeEmailMobileRequest.getNewEmailMobile())) {
                throw new IllegalArgumentException("your existing email and new email are the same");
            }

            // if email otp is valid, update the email
            citizenSignUpMaster.setEmail(changeEmailMobileRequest.getNewEmailMobile());  // update to the new email
            citizenSignUpMaster.setEmailOtp(null); // clear otp after successful validation
            citizenSignUpMaster.setEmailOtpTimestamp(null); // clear otp timestamp
            citizenSignUpMaster.setUpdatedDate(LocalDateTime.now());
            citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);

            // send confirmation email
            try {
                emailService.sendEmailOrMobileChangeConfirmationEmail(citizenSignUpMaster.getEmail(), citizenSignUpMaster.getUsername(), citizenSignUpMaster.getCitizenName(), "email");
            } catch (MessagingException | UnsupportedEncodingException e) {
                log.error("Failed to send confirmation email to {}", citizenSignUpMaster.getEmail(), e);
                return false;
            } // end of send confirmation mail
            return true;
        }

        if (isMobileOtpValid && changeEmailMobileRequest.getNewEmailMobile() != null) {
            // check if the new mobile number is the same as the existing mobile number
            if (citizenSignUpMaster.getMobileNo().equals(changeEmailMobileRequest.getNewEmailMobile())) {
                throw new IllegalArgumentException("Your existing mobile number and new mobile number are the same");
            }

            // if mobile otp is valid, update the mobile number
            citizenSignUpMaster.setMobileNo(changeEmailMobileRequest.getNewEmailMobile());  // update to the new mobile number
            citizenSignUpMaster.setMobileOtp(null); // clear otp after successful validation
            citizenSignUpMaster.setMobileOtpTimestamp(null); // clear otp timestamp
            citizenSignUpMaster.setUpdatedDate(LocalDateTime.now());
            citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);

            // send confirmation email
            try {
                emailService.sendEmailOrMobileChangeConfirmationEmail(citizenSignUpMaster.getEmail(), citizenSignUpMaster.getUsername(), citizenSignUpMaster.getCitizenName(), "mobile");
            } catch (MessagingException | UnsupportedEncodingException e) {
                log.error("Failed to send confirmation email to {}", citizenSignUpMaster.getEmail(), e);
                return false;
            } // end of send confirmation mail
            return true;
        }
        // if otp do not match, return false
        return false;
    }

    @Override
    public String changePassword(Long citizenId, ChangePasswordRequest changePasswordRequest) {
        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpRepository.findById(citizenId).orElseThrow(() -> new RuntimeException("user not found with id: " + citizenId));

        // validate old password
        if (!passwordEncoder.matches(changePasswordRequest.getOldPassword(), citizenSignUpMaster.getPassword())) {
            throw new ApiException("old password is incorrect");
        }

        // check if new password & confirm password are same
        if (!changePasswordRequest.getNewPassword().equals(changePasswordRequest.getConfirmPassword())) {
            throw new ApiException("new password and confirm password are not same");
        }

        // check if the new password is different from the old password
        if (passwordEncoder.matches(changePasswordRequest.getNewPassword(), citizenSignUpMaster.getPassword())) {
            throw new ApiException("your new password can't be the same as your old password");
        }

        // update the password
        citizenSignUpMaster.setPassword(passwordEncoder.encode(changePasswordRequest.getNewPassword()));
        citizenSignUpMaster.setUpdatedDate(LocalDateTime.now());
        citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);

        // save password change history
        CitizenPasswordChangeHistory citizenPasswordHistory = new CitizenPasswordChangeHistory();
        citizenPasswordHistory.setCitizenId(citizenSignUpMaster.getId());
        citizenPasswordHistory.setLastPassword(citizenSignUpMaster.getPassword());
        citizenPasswordHistory.setLastPasswordTimestamp(LocalDateTime.now());
        citizenPasswordHistory.setIpAddress("127.0.0.1");
        citizenPasswordHistory.setCreatedBy(citizenSignUpMaster.getUpdateBy());
        citizenPasswordHistory.setCreatedDate(LocalDateTime.now());
        citizenPasswordHistory.setMunicipalId(citizenSignUpMaster.getMunicipalId());
        citizenPasswordChangeHistoryRepository.saveAndFlush(citizenPasswordHistory); // end of password change history block

        // send a confirmation email
        try {
            emailService.sendChangePasswordEmail(citizenSignUpMaster.getEmail(), citizenSignUpMaster.getCitizenName());
        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send confirmation email to {}", citizenSignUpMaster.getEmail(), e);
            return "password reset successful, but we couldn't send the confirmation email at the moment.";
        } // end of send confirmation mail
        return "your password has been changed successfully";
    }

    @Override
    public String forgotPassword(String email) {
        CitizenSignUpMaster citizenSignUpMaster = citizenSignUpRepository.findByEmail(email).orElseThrow(() -> new EmailNotFoundException("email not found" + email));
        String generateToken = tokenGeneration.generateToken();
        try {
            emailService.sendResetPasswordEmailCitizen(email, generateToken, citizenSignUpMaster.getCitizenName());
        } catch (Exception e) {
            throw new RuntimeException("unable to send link. Please try again later.");
        }
        citizenSignUpMaster.setToken(generateToken);
        citizenSignUpMaster.setTokenTimestamp(LocalDateTime.now());
        citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);
        return "please check your mail, a link has been sent to reset your password.";
    }

    @Override
    public String resetPassword(String token, ForgotPassword forgotPassword) {

//        System.out.println("New Password: " + forgotPassword.getNewPassword());
//        System.out.println("Confirm Password: " + forgotPassword.getConfirmPassword());
//        System.out.println("Password matches: " + forgotPassword.getNewPassword().equals(forgotPassword.getConfirmPassword()));

        if (forgotPassword.getNewPassword().equals(forgotPassword.getConfirmPassword())) {
            CitizenSignUpMaster citizenSignUpMaster = citizenSignUpRepository.findByToken(token).orElseThrow(() -> new EmailNotFoundException("email not found "));
            if (citizenSignUpMaster.getToken().equals(token) && Duration.between(citizenSignUpMaster.getTokenTimestamp(), LocalDateTime.now()).getSeconds() < 5 * 60) {

                // check if new password is same as old password
                if (passwordEncoder.matches(forgotPassword.getNewPassword(), citizenSignUpMaster.getPassword())) {
                    return "Your new password can't be the same as your previous password";
                }

                citizenSignUpMaster.setPassword(passwordEncoder.encode(forgotPassword.getNewPassword()));
                citizenSignUpMaster.setToken(null);
                citizenSignUpMaster.setTokenTimestamp(null);
                citizenSignUpRepository.saveAndFlush(citizenSignUpMaster);

                // save password change history
                CitizenPasswordChangeHistory citizenPasswordHistory = new CitizenPasswordChangeHistory();
                citizenPasswordHistory.setCitizenId(citizenSignUpMaster.getId());
                citizenPasswordHistory.setLastPassword(citizenSignUpMaster.getPassword());
                citizenPasswordHistory.setLastPasswordTimestamp(LocalDateTime.now());
                citizenPasswordHistory.setIpAddress("127.0.0.1");
                citizenPasswordHistory.setCreatedBy(citizenSignUpMaster.getUpdateBy());
                citizenPasswordHistory.setCreatedDate(LocalDateTime.now());
                citizenPasswordHistory.setMunicipalId(citizenSignUpMaster.getMunicipalId());
                citizenPasswordChangeHistoryRepository.saveAndFlush(citizenPasswordHistory); // end of password change history block

                // send email after successful password reset
                try {
                    emailService.sendResetPasswordSuccessEmail(citizenSignUpMaster.getEmail(), citizenSignUpMaster.getCitizenName());
                } catch (MessagingException | UnsupportedEncodingException e) {
                    log.error("Failed to send confirmation email to {}", citizenSignUpMaster.getEmail(), e);
                    return "password reset successful, but we couldn't send the confirmation email at the moment.";
                } // end of send confirmation mail
                return "your password has been changed successfully, please login with your new password, A confirmation email has been sent to your mail.";
            } else {
                return "your session has been expired please try again";
            }
        } else {
            return "new password doesn't match with confirm password";
        }
    }

    private void handleProfilePicUpload(MultipartFile profilePic, CitizenSignUpMaster citizen) {

        if (profilePic.getSize() > MAX_FILE_SIZE) {
            throw new ApiException("file size exceeds 200KB");
        }

        // validate image type
        String fileExtension = StringUtils.getFilenameExtension(profilePic.getOriginalFilename());
        if (!("jpg".equalsIgnoreCase(fileExtension) || "png".equalsIgnoreCase(fileExtension))) {
            throw new ApiException("Invalid file type. Only JPG and PNG are allowed.");
        }

        Path baseDir = Paths.get(uploadDir);
        String folderName = baseDir.getFileName().toString();  // assuming uploadDir ends with the folder name

        // check if the citizen object has an ID (indicating an update operation)
        if (citizen.getId() != null) {
            // handle existing profile picture deletion
            CitizenSignUpMaster existingCitizen = citizenSignUpRepository.findById(citizen.getId())
                    .orElseThrow(() -> new ResourceNotFoundException("CitizenSignUpMaster", "id", citizen.getId()));

            String existingProfileImageName = existingCitizen.getProfileImageName();
            if (existingProfileImageName != null && !existingProfileImageName.isEmpty()) {
                Path existingFilePath = baseDir.resolve(existingProfileImageName);
                try {
                    if (Files.exists(existingFilePath)) {
                        Files.delete(existingFilePath);
                        log.info("Deleted existing profile picture: {}", existingFilePath);
                    }
                } catch (IOException e) {
                    throw new ApiException("failed to delete existing profile picture");
                }
            } else {
                // if no existing profile image, handle as a new image upload
                log.info("No existing profile picture found for citizen.");
            }
        }

        // save the new profile picture
        String newFileName = "userPicture_" + UUID.randomUUID() + "." + fileExtension;
        try {
            // ensure the directory exists (create if not)
            if (!Files.exists(baseDir)) {
                Files.createDirectories(baseDir);
            }
            // create the full path where the file will be stored and write the file.
            Path filePath = baseDir.resolve(newFileName);
            Files.write(filePath, profilePic.getBytes());

            // generate the public URL using ServletUriComponentsBuilder
            String publicUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/citizenSignupProfilePic/")
//                    .path(folderName + "/")
                    .path(newFileName)
                    .toUriString();

            citizen.setProfileImageName(newFileName);
            citizen.setProfilePicUrl(publicUrl);

            log.info("Uploaded profile picture to dir: {} with name: {}", filePath, filePath.getFileName());

        } catch (IOException e) {
            throw new ApiException("Failed to store profile picture. Please try again later.");
        }
    }

}
