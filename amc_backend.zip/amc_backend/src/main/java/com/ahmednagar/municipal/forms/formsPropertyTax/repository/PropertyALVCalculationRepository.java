package com.ahmednagar.municipal.forms.formsPropertyTax.repository;

import com.ahmednagar.municipal.forms.formsPropertyTax.model.PropertyALVCalculation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface PropertyALVCalculationRepository extends JpaRepository<PropertyALVCalculation, Long> {

}
