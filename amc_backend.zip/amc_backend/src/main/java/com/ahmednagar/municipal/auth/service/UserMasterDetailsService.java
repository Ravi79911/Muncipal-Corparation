package com.ahmednagar.municipal.auth.service;

import com.ahmednagar.municipal.auth.model.UserMasterDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserMasterDetailsService {

    UserMasterDetails createUserDetails(UserMasterDetails userMasterDetails, int createdBy);

    UserMasterDetails updateUserDetails(Long id, UserMasterDetails updatedUserMasterDetails);

    UserMasterDetails changeSuspendedStatus(Long id, int status);

    List<UserMasterDetails> getUserDetailsByMunicipalId(Long municipalId);

}
