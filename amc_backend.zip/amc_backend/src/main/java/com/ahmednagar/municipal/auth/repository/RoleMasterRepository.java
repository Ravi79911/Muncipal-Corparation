package com.ahmednagar.municipal.auth.repository;

import com.ahmednagar.municipal.auth.model.RoleMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface RoleMasterRepository extends JpaRepository<RoleMaster, Long> {

    Optional<RoleMaster> findByRoleName(String roleName);

    List<RoleMaster> findByMunicipalId(int municipalId);

}
