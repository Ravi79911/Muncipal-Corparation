package com.ahmednagar.municipal.master.advertisement.repository;

import com.ahmednagar.municipal.master.advertisement.model.DDAdvertisementUsageTypeMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface DDAdvertisementUsageTypeMasterRepository extends JpaRepository<DDAdvertisementUsageTypeMaster,Long> {
}
