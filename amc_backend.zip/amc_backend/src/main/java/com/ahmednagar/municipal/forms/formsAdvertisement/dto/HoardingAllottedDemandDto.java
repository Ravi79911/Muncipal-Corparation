package com.ahmednagar.municipal.forms.formsAdvertisement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoardingAllottedDemandDto {
    private Long id;
    private Long hoardingApplicationDetailId;
    private String calculatedAmount;
    private Long calculatedPeriodDays;
    private Long calculatedPeriodMonths;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private Integer suspendedStatus;
    private int municipalId;
}
