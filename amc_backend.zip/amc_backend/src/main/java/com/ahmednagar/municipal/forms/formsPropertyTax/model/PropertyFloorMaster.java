package com.ahmednagar.municipal.forms.formsPropertyTax.model;

import com.ahmednagar.municipal.master.propertyTax.model.PropertyConstructionType;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_muni_property_floor_master")
public class PropertyFloorMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "floor number is required")
    @Column(name = "floor_no")
    private String floorNo;

    @NotNull(message = "floor usage type is required")
    @Size(max = 50, message = "floor usage type can be up to 50 characters")
    @Column(name = "floor_usage_type", length = 50)
    private String floorUsageType;

    @NotNull(message = "floor occupancy type is required")
    @Column(name = "floor_occupancy_type")
    private String floorOccupancyType;

    @NotNull(message = "floor build-up area sqft is required")
    @Digits(integer = 15, fraction = 3, message = "floor build-up area sqft must be a valid decimal")
    @Column(name = "floor_buildup_area_sqft", precision = 18, scale = 3)
    private BigDecimal floorBuildupAreaSqft;

    @Column(name = "floor_buildup_area_sqmtr", precision = 18, scale = 3)
    private BigDecimal floorBuildupAreaSqMtr;

    @NotNull(message = "carpet area sqft is required")
    @Digits(integer = 15, fraction = 3, message = "carpet area sqft must be a valid decimal")
    @Column(name = "carpet_area_sqft", precision = 18, scale = 3)
    private BigDecimal carpetAreaSqft;

    @Column(name = "carpet_area_sqmtr", precision = 18, scale = 3)
    private BigDecimal carpetAreaSqMtr;

    @Digits(integer = 16, fraction = 2, message = "floor ALP value must be a valid decimal")
    @Column(name = "floor_alp_value", precision = 18, scale = 2)
    private BigDecimal floorAlpValue;

    @NotNull(message = "floor rateable value is required")
    @Digits(integer = 15, fraction = 3, message = "floor rateable value must be a valid decimal")
    @Column(name = "floor_rateable_value", precision = 18, scale = 3)
    private BigDecimal floorRateableValue;

    @Size(max = 50, message = "rent agreement number can be up to 50 characters")
    @Column(name = "rent_agreement_no", length = 50)
    private String rentAgreementNo;

    @Column(name = "rent_agreement_date")
    private LocalDate rentAgreementDate;

    @Digits(integer = 16, fraction = 2, message = "rent value amount must be a valid decimal")
    @Column(name = "rent_value_amt", precision = 18, scale = 2)
    private BigDecimal rentValueAmt;

    @Column(name = "rent_agreement_from")
    private LocalDate rentAgreementFrom;

    @Column(name = "rent_agreement_upto")
    private LocalDate rentAgreementUpto;

    @Column(name = "calculated_from")
    private LocalDate calculatedFrom;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id")
    private int municipalId;

    @NotNull(message = "created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Min(value = 0, message = "suspended status must be 0 (inactive) or 1 (active)")
    @Max(value = 1, message = "suspended status must be 0 (inactive) or 1 (active)")
    @Column(name = "suspended_status")
    private int suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "property_mas_id", referencedColumnName = "id", nullable = false)
    private MunicipalPropertyMaster municipalPropertyMaster;

    @ManyToOne
    @JoinColumn(name = "floor_construction_type", referencedColumnName = "id", nullable = false)
    private PropertyConstructionType propertyConstructionType;

    @OneToMany(mappedBy = "propertyFloorMaster", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<PropertyFloorTaxationDetails> propertyFloorTaxationDetails;

}
