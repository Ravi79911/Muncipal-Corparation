package com.ahmednagar.municipal.auth.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_view_muni_property_master")
public class ViewMunicipalPropertyMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "application_no", nullable = false)
    private String applicationNo;

    @Column(name = "holding_no", nullable = false)
    private String holdingNo;

    @NotBlank(message = "mode of transfer is required")
    @Size(max = 50, message = "mode of transfer can't exceed 50 characters")
    @Column(name = "mode_of_transfer", nullable = false)
    private String modeOfTransfer;

    @NotNull(message = "date of transfer is required")
    @Column(name = "date_of_transfer", nullable = false)
    private LocalDate dateOfTransfer;

    @NotBlank(message = "land khata number is required")
    @Size(max = 50, message = "land khata number can't exceed 50 characters")
    @Column(name = "land_khata_no", nullable = false)
    private String landKhataNo;

    @NotBlank(message = "plot number is required")
    @Size(max = 50, message = "plot number can't exceed 50 characters")
    @Column(name = "plot_no", nullable = false)
    private String plotNo;

    @NotNull(message = "area of land in sqft is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "area of land in sqft must be greater than 0")
    @Column(name = "area_of_land_sqft", nullable = false, precision = 18, scale = 3)
    private BigDecimal areaOfLandSqft;

    @NotNull(message = "area of land in decimal is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "area of land in decimal must be greater than 0")
    @Column(name = "area_of_land_decimal", nullable = false, precision = 18, scale = 3)
    private BigDecimal areaOfLandDecimal;

    @NotBlank(message = "property age is required")
    @Size(max = 50, message = "property age can't exceed 50 characters")
    @Column(name = "property_age", nullable = false)
    private String propertyAge;

    @NotBlank(message = "village mauja name is required")
    @Size(max = 50, message = "village mauja name can't exceed 50 characters")
    @Column(name = "village_mauja_name", nullable = false)
    private String villageMaujaName;

    @NotBlank(message = "property address is required")
    @Size(max = 500, message = "property address can't exceed 500 characters")
    @Column(name = "property_address", nullable = false)
    private String propertyAddress;

    @NotBlank(message = "property city is required")
    @Size(max = 50, message = "property city can't exceed 50 characters")
    @Column(name = "city", nullable = false)
    private String propertyCity;

    @NotBlank(message = "property district is required")
    @Size(max = 50, message = "property district can't exceed 50 characters")
    @Column(name = "district", nullable = false)
    private String propertyDistrict;

    @NotBlank(message = "property state is required")
    @Size(max = 50, message = "property state can't exceed 50 characters")
    @Column(name = "state", nullable = false)
    private String propertyState;

    @NotNull(message = "property pincode is required")
    @Column(name = "pincode", nullable = false)
    private Long propertyPinCode;

    @NotBlank(message = "property correspondence address is required")
    @Size(max = 50, message = "property correspondence address can't exceed 50 characters")
    @Column(name = "correspondence_address", nullable = false)
    private String propertyCorrespondenceAddress;

    @NotBlank(message = "property correspondence city is required")
    @Size(max = 50, message = "property correspondence city can't exceed 50 characters")
    @Column(name = "correspondence_city", nullable = false)
    private String propertyCorrespondenceCity;

    @NotBlank(message = "property correspondence district is required")
    @Size(max = 50, message = "property correspondence district can't exceed 50 characters")
    @Column(name = "correspondence_district", nullable = false)
    private String propertyCorrespondenceDistrict;

    @NotBlank(message = "property correspondence state is required")
    @Size(max = 50, message = "property correspondence state can't exceed 50 characters")
    @Column(name = "correspondence_state", nullable = false)
    private String propertyCorrespondenceState;

    @NotNull(message = "property correspondence pincode is required")
    @Column(name = "correspondence_pincode", nullable = false)
    private Long propertyCorrespondencePinCode;

    @Column(name = "application_date", nullable = false)
    private LocalDateTime applicationDate;

    @NotNull(message = "municipal id is required")
    @Column(name = "municipal_id", nullable = false)
    private int municipalId;

    @NotNull(message = "created by is required")
    @Column(name = "created_by", nullable = false)
    private Integer createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

//    @Column(name = "application_fyear")
//    private Long financialYearMaster;

    @ManyToOne
    @JoinColumn(name = "application_fyear", referencedColumnName = "fin_id")
    private ViewFinancialYearMaster viewFinancialYearMaster;

    @ManyToOne
    @JoinColumn(name = "application_asses_type_name", referencedColumnName = "id")
    private ViewPropertyAssismentTypeMaster viewPropertyAssismentTypeMaster;

    @ManyToOne
    @JoinColumn(name = "ward_name", referencedColumnName = "id")
    private AuthWardMaster authWardMaster;

    @ManyToOne
    @JoinColumn(name = "zone_name", referencedColumnName = "id", nullable = false)
    private AuthZoneMaster authZoneMaster;

    @ManyToOne
    @JoinColumn(name = "ownership_type_nm", referencedColumnName = "id")
    private ViewOwnershipMaster viewOwnershipMaster;

    @ManyToOne
    @JoinColumn(name = "property_type_nm", referencedColumnName = "id")
    private ViewPropertyTypeMaster viewPropertyTypeMaster;

    @ManyToOne
    @JoinColumn(name = "property_category_uses_nm", referencedColumnName = "id")
    private PropertyCategoryUsesTypeMaster propertyCategoryUsesTypeMaster;

    @ManyToOne
    @JoinColumn(name = "road_type_name", referencedColumnName = "id")
    private ViewRoadTypeMaster viewRoadTypeMaster;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewMunicipalPropertyMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewMunicipalPropertyOwnerMaster> viewMunicipalPropertyOwnerMasters = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewMunicipalPropertyMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewMunicipalPropertyElectricityConnectionDetails> viewMunicipalPropertyElectricityConnectionDetails = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewMunicipalPropertyMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewMunicipalPropertyWaterConnectionDetails> viewMunicipalPropertyWaterConnectionDetails = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewMunicipalPropertyMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewMunicipalPropertyAdditionalDetails> viewMunicipalPropertyAdditionalDetails = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewMunicipalPropertyMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewMunicipalPropertyBuildingPlanDetails> viewMunicipalPropertyBuildingPlanDetails = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewMunicipalPropertyMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewMunicipalPropertyDemandMaster> viewMunicipalPropertyDemandMasters = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewMunicipalPropertyMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewMunicipalPropertyDocumentUploadDetails> viewMunicipalPropertyDocumentUploadDetails = null;

    @ToString.Exclude
    @OneToMany(mappedBy = "viewMunicipalPropertyMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ViewMunicipalPropertyFloorMaster> viewMunicipalPropertyFloorMasters = null;

}
