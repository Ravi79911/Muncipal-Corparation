package com.ahmednagar.municipal.forms.formsWaterManagement.repository;

import com.ahmednagar.municipal.forms.formsWaterManagement.model.NewConnectionFormShubham;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface NewConnectionFormShubhamRepository extends JpaRepository<NewConnectionFormShubham,Integer> {

    List<NewConnectionFormShubham> findByMunicipalId(int municipalId);

}
