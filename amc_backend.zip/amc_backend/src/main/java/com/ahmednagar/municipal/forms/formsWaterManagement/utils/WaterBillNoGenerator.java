package com.ahmednagar.municipal.forms.formsWaterManagement.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

public class WaterBillNoGenerator {
    private static final String PREFIX = "WCD";
    private static final AtomicInteger counter = new AtomicInteger();

    public static String generateBillNo() {
//        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MMyy");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HHmmss");
        LocalDateTime now = LocalDateTime.now();

//        String datePart = now.format(dateFormatter);
        String timePart = now.format(timeFormatter);
        int uniqueNumber = counter.incrementAndGet();
        String uniqueNumberPart = String.format("%03d", uniqueNumber);

        return PREFIX + timePart + uniqueNumberPart;
    }
}
