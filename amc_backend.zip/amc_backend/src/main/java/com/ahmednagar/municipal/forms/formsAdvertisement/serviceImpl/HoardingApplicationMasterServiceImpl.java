package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.exception.ResourceNotFoundException;
import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingApplicationMasterDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationMaster;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingApplicationMasterRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingApplicationMasterService;
import com.ahmednagar.municipal.forms.formsAdvertisement.utils.AdvertisementApplicationNumberGenerator;
import com.ahmednagar.municipal.master.advertisement.model.HoardingCategoryTypeMasterSetup;
import com.ahmednagar.municipal.master.advertisement.repository.HoardingCategoryTypeMasterSetupRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingApplicationMasterServiceImpl implements HoardingApplicationMasterService {

    private static final Logger logger = LoggerFactory.getLogger(HoardingApplicationMasterServiceImpl.class);

    @Autowired
    private HoardingApplicationMasterRepository hoardingApplicationMasterRepository;

    @Autowired
    private HoardingCategoryTypeMasterSetupRepository hoardingCategoryTypeMasterSetupRepository;

    @Autowired
    private AdvertisementApplicationNumberGenerator advertisementApplicationNumberGenerator;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingApplicationMaster saveHoardingApplicationMaster(HoardingApplicationMaster hoardingApplicationMaster) {
        // validate and set hoarding category type id
        HoardingCategoryTypeMasterSetup hoardingCategoryTypeMasterSetup = hoardingCategoryTypeMasterSetupRepository.findById(
                        hoardingApplicationMaster.getHoardingCategoryTypeMasterId().getId())
                .orElseThrow(() -> new IllegalArgumentException("invalid hoardingCategoryTypeMaster id"));

        hoardingApplicationMaster.setHoardingCategoryTypeMasterId(hoardingCategoryTypeMasterSetup);

        // normalize application type name for case-insensitive comparison
        String hoardingCategoryTypeName = hoardingCategoryTypeMasterSetup.getHoardingCategoryTypeName().trim().toLowerCase();

        // generate and set license number based on application type name
        String generatedApplicationNumber = switch (hoardingCategoryTypeName.toLowerCase()) {
            case "permanent hoarding" ->
                    advertisementApplicationNumberGenerator.generatePermanentApplicationNo(hoardingCategoryTypeMasterSetup.getId());
            case "temporary hoarding" ->
                    advertisementApplicationNumberGenerator.generateTemporaryApplicationNo(hoardingCategoryTypeMasterSetup.getId());
            default -> {
                logger.error("Unknown Application Type Name: {}", hoardingCategoryTypeName);
                throw new IllegalArgumentException("Unknown application type name: " + hoardingCategoryTypeName);
            }
        };

        hoardingApplicationMaster.setApplicationNo(generatedApplicationNumber);

        LocalDateTime currentDateTime = LocalDateTime.now();
        hoardingApplicationMaster.setCreatedDate(currentDateTime);
        hoardingApplicationMaster.setUpdatedDate(currentDateTime);
        hoardingApplicationMaster.setUpdatedBy(hoardingApplicationMaster.getUpdatedBy() != null ? hoardingApplicationMaster.getUpdatedBy() : 0);
        hoardingApplicationMaster.setSuspendedStatus(
                hoardingApplicationMaster.getSuspendedStatus() != null
                        ? hoardingApplicationMaster.getSuspendedStatus()
                        : 0);

        return hoardingApplicationMasterRepository.saveAndFlush(hoardingApplicationMaster);
    }

    @Override
    public List<HoardingApplicationMasterDto> findAllHoardingApplicationMaster() {
        List<HoardingApplicationMaster> hoardingApplicationMasters = hoardingApplicationMasterRepository.findAll();
        return hoardingApplicationMasters.stream()
                .map(hoardingApplicationMaster -> modelMapper.map(hoardingApplicationMaster, HoardingApplicationMasterDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingApplicationMaster findById(Long id) {
        Optional<HoardingApplicationMaster> hoardingApplicationMaster = hoardingApplicationMasterRepository.findById(id);
        return hoardingApplicationMaster.orElse(null);

    }

    @Override
    public List<HoardingApplicationMaster> findAllByMunicipalId(int municipalId) {
        return hoardingApplicationMasterRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingApplicationMaster updateHoardingApplicationMaster(Long id, HoardingApplicationMaster updatedHoardingApplicationMaster) {
        Optional<HoardingApplicationMaster> hoardingApplicationMasterOptional = hoardingApplicationMasterRepository.findById(id);
        if (hoardingApplicationMasterOptional.isPresent()) {
            HoardingApplicationMaster existingHoardingApplicationMaster = hoardingApplicationMasterOptional.get();
            existingHoardingApplicationMaster.setCreatedDate(LocalDateTime.now());
            existingHoardingApplicationMaster.setUpdatedDate(LocalDateTime.now());
            existingHoardingApplicationMaster.setNoOfHoardings(updatedHoardingApplicationMaster.getNoOfHoardings());
            existingHoardingApplicationMaster.setNameOfAdvertiser(updatedHoardingApplicationMaster.getNameOfAdvertiser());
            existingHoardingApplicationMaster.setAdvertiserMobileNo(updatedHoardingApplicationMaster.getAdvertiserMobileNo());
            existingHoardingApplicationMaster.setEmailId(updatedHoardingApplicationMaster.getEmailId());
            existingHoardingApplicationMaster.setWhatsappNo(updatedHoardingApplicationMaster.getWhatsappNo());
            existingHoardingApplicationMaster.setAdvertiserAddress(updatedHoardingApplicationMaster.getAdvertiserAddress());
            existingHoardingApplicationMaster.setPurposeOfHoarding(updatedHoardingApplicationMaster.getPurposeOfHoarding());
            existingHoardingApplicationMaster.setUpdatedBy(updatedHoardingApplicationMaster.getUpdatedBy());
//            existingHoardingApplicationMaster.setUpdatedBy(existingHoardingApplicationMaster.getUpdatedBy() != null ? existingHoardingApplicationMaster.getUpdatedBy() : 0);
//            existingHoardingApplicationMaster.setSuspendedStatus(existingHoardingApplicationMaster.getSuspendedStatus() != null ? existingHoardingApplicationMaster.getSuspendedStatus() : 0);

            return hoardingApplicationMasterRepository.saveAndFlush(existingHoardingApplicationMaster);
        } else {
            throw new RuntimeException("hoardingApplicationMaster not found with id: " + id);
        }
    }

    @Override
    public HoardingApplicationMaster changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingApplicationMaster> hoardingApplicationMasterOpt = hoardingApplicationMasterRepository.findById(id);
        if (hoardingApplicationMasterOpt.isPresent()) {
            HoardingApplicationMaster hoardingApplicationMaster = hoardingApplicationMasterOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingApplicationMaster.setUpdatedDate(currentDateTime);
            hoardingApplicationMaster.setSuspendedStatus(status);      // 1 means suspended
            hoardingApplicationMaster.setUpdatedBy(updatedBy);
            return hoardingApplicationMasterRepository.saveAndFlush(hoardingApplicationMaster);
        }
        return null;
    }

    @Override
    public HoardingApplicationMaster findByApplicationNo(String applicationNo) {
        Optional<HoardingApplicationMaster> hoardingApplication = hoardingApplicationMasterRepository.findByApplicationNo(applicationNo);
        return hoardingApplication.orElseThrow(() -> new RuntimeException("Application not found with applicationNo: " + applicationNo));
    }

    @Override
    public boolean isHordingApplicationNoExists(String applicationNo) {
        return hoardingApplicationMasterRepository.findByApplicationNo(applicationNo).isPresent();
    }

    @Transactional
    @Override
    public void deleteHoardingApplicationMasterById(Long id) {
        hoardingApplicationMasterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("HoardingApplicationMaster", "id", id));
        hoardingApplicationMasterRepository.deleteById(id);
    }
}