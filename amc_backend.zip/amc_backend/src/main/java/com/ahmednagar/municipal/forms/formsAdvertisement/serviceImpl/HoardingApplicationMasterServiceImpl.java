package com.ahmednagar.municipal.forms.formsAdvertisement.serviceImpl;

import com.ahmednagar.municipal.forms.formsAdvertisement.dto.HoardingApplicationMasterDto;
import com.ahmednagar.municipal.forms.formsAdvertisement.model.HoardingApplicationMaster;
import com.ahmednagar.municipal.forms.formsAdvertisement.repository.HoardingApplicationMasterRepository;
import com.ahmednagar.municipal.forms.formsAdvertisement.service.HoardingApplicationMasterService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingApplicationMasterServiceImpl implements HoardingApplicationMasterService {
    @Autowired
    private HoardingApplicationMasterRepository hoardingApplicationMasterRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingApplicationMaster saveHoardingApplicationMaster(HoardingApplicationMaster hoardingApplicationMaster) {
        hoardingApplicationMaster.setCreatedDate(LocalDateTime.now());
        hoardingApplicationMaster.setUpdatedDate(LocalDateTime.now());
        hoardingApplicationMaster.setUpdatedBy(hoardingApplicationMaster.getUpdatedBy() != null ? hoardingApplicationMaster.getUpdatedBy() : 0);
        hoardingApplicationMaster.setSuspendedStatus(hoardingApplicationMaster.getSuspendedStatus() != null ? hoardingApplicationMaster.getSuspendedStatus() : 0);

        return hoardingApplicationMasterRepository.save(hoardingApplicationMaster);

    }

    @Override
    public List<HoardingApplicationMasterDto> findAllHoardingApplicationMaster() {
        List<HoardingApplicationMaster> hoardingApplicationMasters = hoardingApplicationMasterRepository.findAll();
        return hoardingApplicationMasters.stream()
                .map(hoardingApplicationMaster -> modelMapper.map(hoardingApplicationMaster, HoardingApplicationMasterDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingApplicationMaster findById(Long id) {
        Optional<HoardingApplicationMaster> hoardingApplicationMaster=hoardingApplicationMasterRepository.findById(id);
        return hoardingApplicationMaster.orElse(null);

    }

    @Override
    public List<HoardingApplicationMaster> findAllByMunicipalId(int municipalId) {
        return hoardingApplicationMasterRepository.findAllByMunicipalId(municipalId);
    }

    @Override
    public HoardingApplicationMaster updateHoardingApplicationMaster(Long id, HoardingApplicationMaster updatedHoardingApplicationMaster, int updatedBy) {
        Optional<HoardingApplicationMaster> hoardingApplicationMasterOptional = hoardingApplicationMasterRepository.findById(id);
        if (hoardingApplicationMasterOptional.isPresent()) {
            HoardingApplicationMaster existingHoardingApplicationMaster = hoardingApplicationMasterOptional.get();
            //existingHoardingApplicationMaster.setHoardingCategoryTypeName(updatedHoardingCategoryTypeMasterSetup.getHoardingCategoryTypeName());
            existingHoardingApplicationMaster.setUpdatedBy(updatedBy);
            existingHoardingApplicationMaster.setUpdatedDate(LocalDateTime.now());
            return hoardingApplicationMasterRepository.saveAndFlush(existingHoardingApplicationMaster);
        } else {
            throw new RuntimeException("hoardingApplicationMaster not found with id: " + id);
        }
    }

    @Override
    public HoardingApplicationMaster changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingApplicationMaster> hoardingApplicationMasterOpt = hoardingApplicationMasterRepository.findById(id);
        if (hoardingApplicationMasterOpt.isPresent()) {
            HoardingApplicationMaster hoardingApplicationMaster = hoardingApplicationMasterOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingApplicationMaster.setUpdatedDate(currentDateTime);
            hoardingApplicationMaster.setSuspendedStatus(status);      // 1 means suspended
            hoardingApplicationMaster.setUpdatedBy(updatedBy);
            return hoardingApplicationMasterRepository.saveAndFlush(hoardingApplicationMaster);
        }
        return null;
    }
}