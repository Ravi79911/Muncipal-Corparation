package com.ahmednagar.municipal.master.advertisement.serviceImpl;

import com.ahmednagar.municipal.master.advertisement.dto.HoardingDocumentCategoryMasterSetupDto;
import com.ahmednagar.municipal.master.advertisement.model.HoardingDocumentCategoryMasterSetup;
import com.ahmednagar.municipal.master.advertisement.repository.HoardingDocumentCategoryMasterSetupRepository;
import com.ahmednagar.municipal.master.advertisement.service.HoardingDocumentCategoryMasterSetupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HoardingDocumentCategoryMasterSetupServiceImpl implements HoardingDocumentCategoryMasterSetupService {
    @Autowired
    private HoardingDocumentCategoryMasterSetupRepository hoardingDocumentCategoryMasterSetupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public HoardingDocumentCategoryMasterSetup saveHoardingDocumentCategoryMasterSetup(HoardingDocumentCategoryMasterSetup hoardingDocumentCategoryMasterSetup) {
        hoardingDocumentCategoryMasterSetup.setCreatedDate(LocalDateTime.now());
        hoardingDocumentCategoryMasterSetup.setUpdatedDate(LocalDateTime.now());
        hoardingDocumentCategoryMasterSetup.setUpdatedBy(hoardingDocumentCategoryMasterSetup.getUpdatedBy() != null ? hoardingDocumentCategoryMasterSetup.getUpdatedBy() : 0);
        hoardingDocumentCategoryMasterSetup.setSuspendedStatus(hoardingDocumentCategoryMasterSetup.getSuspendedStatus() != null ? hoardingDocumentCategoryMasterSetup.getSuspendedStatus() : 0);

        return hoardingDocumentCategoryMasterSetupRepository.save(hoardingDocumentCategoryMasterSetup);

    }

    @Override
    public List<HoardingDocumentCategoryMasterSetupDto> findAllHoardingDocumentCategoryMasterSetup() {
        List<HoardingDocumentCategoryMasterSetup> hoardingDocumentCategoryMasterSetups = hoardingDocumentCategoryMasterSetupRepository.findAll();
        return hoardingDocumentCategoryMasterSetups.stream()
                .map(hoardingDocumentCategoryMasterSetup -> modelMapper.map(hoardingDocumentCategoryMasterSetup, HoardingDocumentCategoryMasterSetupDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public HoardingDocumentCategoryMasterSetup findById(Long id) {
        Optional<HoardingDocumentCategoryMasterSetup> hoardingDocumentCategoryMasterSetup=hoardingDocumentCategoryMasterSetupRepository.findById(id);
        return hoardingDocumentCategoryMasterSetup.orElse(null);

    }

    @Override
    public List<HoardingDocumentCategoryMasterSetup> findAllByMunicipalId(int municipalId) {
        return hoardingDocumentCategoryMasterSetupRepository.findAllByMunicipalId(municipalId);
    }
    @Override
    public HoardingDocumentCategoryMasterSetup updateHoardingDocumentCategoryMasterSetup(Long id, HoardingDocumentCategoryMasterSetup updatedHoardingDocumentCategoryMasterSetup, int updatedBy) {
        Optional<HoardingDocumentCategoryMasterSetup> hoardingDocumentCategoryMasterSetupOptional = hoardingDocumentCategoryMasterSetupRepository.findById(id);
        if (hoardingDocumentCategoryMasterSetupOptional.isPresent()) {
            HoardingDocumentCategoryMasterSetup existingHoardingDocumentCategoryMasterSetup= hoardingDocumentCategoryMasterSetupOptional.get();
            existingHoardingDocumentCategoryMasterSetup.setDocumentCategoryName(updatedHoardingDocumentCategoryMasterSetup.getDocumentCategoryName());
            existingHoardingDocumentCategoryMasterSetup.setUpdatedBy(updatedBy);
            existingHoardingDocumentCategoryMasterSetup.setUpdatedDate(LocalDateTime.now());
            return hoardingDocumentCategoryMasterSetupRepository.saveAndFlush(existingHoardingDocumentCategoryMasterSetup);
        } else {
            throw new RuntimeException("HoardingDocumentCategoryMasterSetup not found with id: " + id);
        }
    }

    @Override
    public HoardingDocumentCategoryMasterSetup changeStatus(Long id, Integer status, int updatedBy) {
        Optional<HoardingDocumentCategoryMasterSetup> hoardingDocumentCategoryMasterSetupOpt = hoardingDocumentCategoryMasterSetupRepository.findById(id);
        if (hoardingDocumentCategoryMasterSetupOpt.isPresent()) {
            HoardingDocumentCategoryMasterSetup hoardingDocumentCategoryMasterSetup = hoardingDocumentCategoryMasterSetupOpt.get();
            LocalDateTime currentDateTime = LocalDateTime.now();
            hoardingDocumentCategoryMasterSetup.setUpdatedDate(currentDateTime);
            hoardingDocumentCategoryMasterSetup.setSuspendedStatus(status);      // 1 means suspended
            hoardingDocumentCategoryMasterSetup.setUpdatedBy(updatedBy);
            return hoardingDocumentCategoryMasterSetupRepository.saveAndFlush(hoardingDocumentCategoryMasterSetup);
        }
        return null;
    }
}
