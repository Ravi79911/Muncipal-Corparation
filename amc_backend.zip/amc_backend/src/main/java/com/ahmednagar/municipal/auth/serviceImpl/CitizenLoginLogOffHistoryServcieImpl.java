package com.ahmednagar.municipal.auth.serviceImpl;

import com.ahmednagar.municipal.auth.model.CitizenLoginLogOffHistory;
import com.ahmednagar.municipal.auth.repository.CitizenLoginLogOffHistoryRepository;
import com.ahmednagar.municipal.auth.service.CitizenLoginLogOffHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CitizenLoginLogOffHistoryServcieImpl implements CitizenLoginLogOffHistoryService {

    @Autowired
    CitizenLoginLogOffHistoryRepository citizenLoginLogOffHistoryRepository;

    @Override
    public CitizenLoginLogOffHistory saveCitizenLoginLogoff(CitizenLoginLogOffHistory citizenLoginLogoffHistory) {
        return citizenLoginLogOffHistoryRepository.saveAndFlush(citizenLoginLogoffHistory);
    }

    @Override
    public List<CitizenLoginLogOffHistory> getAllCitizenLoginLogoffHistories() {
        return citizenLoginLogOffHistoryRepository.findAll();
    }

    @Override
    public CitizenLoginLogOffHistory updateCitizenLoginLogoff(Long id, CitizenLoginLogOffHistory citizenLoginLogoffHistory) {
        CitizenLoginLogOffHistory existing = citizenLoginLogOffHistoryRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Record not found with id: " + id));

        if (citizenLoginLogoffHistory.getLoginLogoffStatus() != null) {
            existing.setLoginLogoffStatus(citizenLoginLogoffHistory.getLoginLogoffStatus());
        }
        if (citizenLoginLogoffHistory.getIpAddress() != null) {
            existing.setIpAddress(citizenLoginLogoffHistory.getIpAddress());
        }
        if (citizenLoginLogoffHistory.getLocationAddress() != null) {
            existing.setLocationAddress(citizenLoginLogoffHistory.getLocationAddress());
        }
        existing.setUpdatedDate(LocalDateTime.now());
        return citizenLoginLogOffHistoryRepository.saveAndFlush(existing);
    }

    @Override
    public CitizenLoginLogOffHistory changeSuspendedStatus(Long id, Integer suspendedStatus) {
        CitizenLoginLogOffHistory existing = citizenLoginLogOffHistoryRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Record not found with id: " + id));

        if (suspendedStatus == null) {
            suspendedStatus = 1;
        }
        existing.setSuspendedStatus(suspendedStatus);
        return citizenLoginLogOffHistoryRepository.saveAndFlush(existing);
    }

}
